#!/bin/bash
echo "🚀 Iniciando creación de Release..."
python3 scripts/build_release.py
echo "✨ Completado. El ZIP está en la carpeta 'releases'."
