import re

# Update RecipesPage.tsx
recipes_file = "frontend/src/pages/recipes/RecipesPage.tsx"
with open(recipes_file, "r") as f:
    recipes_code = f.read()

# Add edit state and delete mutation
recipes_additions = """
  const [editingId, setEditingId] = useState<string | null>(null);

  const removeRecipe = useMutation({
    mutationFn: posService.deleteRecipe,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['recipes'] })
  });

  const updateRecipe = useMutation({
    mutationFn: async (data: RecipeForm) => { await posService.updateRecipe(editingId!, data); },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recipes'] });
      setEditingId(null);
      reset({ product_id: '', description: '', yield: 1, items: [{ inventory_item_id: '', quantity: 1, unit: 'g' }] });
    }
  });

  const handleEdit = (recipe: any) => {
    setEditingId(recipe.id);
    reset({
      product_id: recipe.product_id,
      description: recipe.description || '',
      yield: recipe.yield || 1,
      items: recipe.items?.length ? recipe.items.map((i: any) => ({
        inventory_item_id: i.inventory_item_id,
        quantity: i.quantity,
        unit: i.unit
      })) : [{ inventory_item_id: '', quantity: 1, unit: 'g' }]
    });
  };
"""

recipes_code = recipes_code.replace("const create = useMutation({", recipes_additions + "\n  const create = useMutation({")

recipes_code = recipes_code.replace("Crear Receta", "{editingId ? 'Editar Receta' : 'Crear Receta'}")
recipes_code = recipes_code.replace("onSubmit={handleSubmit((values) => { create.mutate(values); reset(); })}", "onSubmit={handleSubmit((values) => { if (editingId) updateRecipe.mutate(values); else { create.mutate(values); reset(); } })}")

# Update buttons
recipes_code = recipes_code.replace(
    "<IconButton><EditIcon /></IconButton>",
    "<IconButton onClick={() => handleEdit(recipe)}><EditIcon /></IconButton>"
)
recipes_code = recipes_code.replace(
    '<IconButton color="error"><DeleteIcon /></IconButton>',
    '<IconButton color="error" onClick={() => { if(confirm("¿Seguro?")) removeRecipe.mutate(recipe.id); }}><DeleteIcon /></IconButton>'
)

with open(recipes_file, "w") as f:
    f.write(recipes_code)

# Update InventoryPage.tsx
inv_file = "frontend/src/pages/inventory/InventoryPage.tsx"
with open(inv_file, "r") as f:
    inv_code = f.read()

# Add products query and replace textfield with select
inv_additions = """
  const { data: prodData } = useQuery({ queryKey: ['products'], queryFn: () => posService.products(1, 100) });
  const isProdPaginated = prodData && !Array.isArray(prodData) && 'data' in prodData;
  const products = isProdPaginated ? (prodData as any).data : (Array.isArray(prodData) ? prodData : []);
"""

inv_code = inv_code.replace("const { register, handleSubmit, reset } = useForm<MovementForm>({ defaultValues: { product_id: 'prod-1', quantity: 1, reason: '' } });", "const { register, handleSubmit, reset } = useForm<MovementForm>({ defaultValues: { product_id: '', quantity: 1, reason: '' } });\n" + inv_additions)

select_html = """
              <TextField select label="Producto" {...register('product_id')} SelectProps={{ native: true }}>
                <option value=""></option>
                {products.map((p: any) => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </TextField>
"""

inv_code = inv_code.replace("<TextField label=\"Producto ID\" {...register('product_id')} />", select_html)

with open(inv_file, "w") as f:
    f.write(inv_code)

print("UI Files updated")
