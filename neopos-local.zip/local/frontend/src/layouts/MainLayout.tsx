import {
  AppBar,
  Avatar,
  Box,
  Button,
  Chip,
  Drawer,
  IconButton,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Stack,
  Toolbar,
  Typography,
  Dialog,
  DialogContent,
  TextField,
  InputAdornment,
  Divider,
  Menu,
  MenuItem
} from '@mui/material';
import DashboardIcon from '@mui/icons-material/Dashboard';
import TableRestaurantIcon from '@mui/icons-material/TableRestaurant';
import ReceiptLongIcon from '@mui/icons-material/ReceiptLong';
import SoupKitchenIcon from '@mui/icons-material/SoupKitchen';
import Inventory2Icon from '@mui/icons-material/Inventory2';
import FastfoodIcon from '@mui/icons-material/Fastfood';
import GroupsIcon from '@mui/icons-material/Groups';
import PointOfSaleIcon from '@mui/icons-material/PointOfSale';
import AssessmentIcon from '@mui/icons-material/Assessment';
import SmartToyIcon from '@mui/icons-material/SmartToy';
import SettingsIcon from '@mui/icons-material/Settings';
import MenuIcon from '@mui/icons-material/Menu';
import WifiOffIcon from '@mui/icons-material/WifiOff';
import WifiIcon from '@mui/icons-material/Wifi';
import SearchIcon from '@mui/icons-material/Search';
import LogoutIcon from '@mui/icons-material/Logout';
import BugReportIcon from '@mui/icons-material/BugReport';
import { logout } from '../services/authService';
import { posService } from '../services/posService';
import { useState, useEffect } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { useAuthStore } from '../stores/authStore';
import { useSettingsStore } from '../stores/settingsStore';
import { canAccess } from '../utils/permissions';
import type { RestaurantTable, Product } from '../types/domain';

const drawerWidth = 260;

const navItems = [
  { label: 'Dashboard', path: '/dashboard', permission: 'dashboard', icon: <DashboardIcon /> },
  { label: 'Mesas', path: '/tables', permission: 'tables', icon: <TableRestaurantIcon /> },
  { label: 'Cocina', path: '/kitchen', permission: 'kitchen', icon: <SoupKitchenIcon /> },
  { label: 'Productos', path: '/products', permission: 'products', icon: <FastfoodIcon /> },
  { label: 'Recetas', path: '/recipes', permission: 'products', icon: <SoupKitchenIcon /> },
  { label: 'Inventario', path: '/inventory', permission: 'inventory', icon: <Inventory2Icon /> },
  { label: 'Clientes', path: '/clients', permission: 'cash', icon: <GroupsIcon /> },
  { label: 'Caja', path: '/cash', permission: 'cash', icon: <PointOfSaleIcon /> },
  { label: 'Pedidos (Historial)', path: '/order-history', permission: 'orders', icon: <ReceiptLongIcon /> },
  { label: 'Facturacion', path: '/invoices', permission: 'invoices', icon: <ReceiptLongIcon /> },
  { label: 'Reportes', path: '/reports', permission: 'reports', icon: <AssessmentIcon /> },
  { label: 'Asistente IA', path: '/ai-assistant', permission: 'ai-assistant', icon: <SmartToyIcon /> }
];

export function MainLayout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { user, role, clear, refreshToken } = useAuthStore();
  const { autoFocusSearch } = useSettingsStore();
  const location = useLocation();
  const navigate = useNavigate();

  // Sync status
  const [syncState, setSyncState] = useState<'success' | 'warning' | 'error'>('warning');
  const [syncLabel, setSyncLabel] = useState('Conectando...');

  useEffect(() => {
    const fetchSync = () => {
      posService.syncStatus().then((data) => {
        if (!data) return;
        const now = new Date().getTime();
        const lastSuccess = new Date(data.last_success).getTime();
        
        if (data.status === 'success' || data.status === 'pending') {
          // Si el estatus es pending, asume que está pendiente por conectarse (amarillo)
          if (data.status === 'pending') {
             setSyncState('warning');
             setSyncLabel('Pendiente');
          } else {
             // success
             // Verificamos si lleva más de 3h sin éxito
             if (now - lastSuccess > 3 * 60 * 60 * 1000) {
               setSyncState('error');
               setSyncLabel('Sin conexión > 3h');
             } else {
               setSyncState('success');
               setSyncLabel('Sincronizado');
             }
          }
        } else if (data.status === 'error') {
           if (now - lastSuccess > 3 * 60 * 60 * 1000 && lastSuccess > 0) {
             setSyncState('error');
             setSyncLabel('Error > 3h');
           } else {
             setSyncState('warning');
             setSyncLabel('Falló intento');
           }
        }
      }).catch(console.error);
    };
    fetchSync();
    const interval = setInterval(fetchSync, 60000);
    return () => clearInterval(interval);
  }, []);

  // Dialog de Búsqueda
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [products, setProducts] = useState<Product[]>([]);
  const [tables, setTables] = useState<RestaurantTable[]>([]);
  const [selectedIndex, setSelectedIndex] = useState<number>(-1);
  
  // Profile menu
  const [profileAnchorEl, setProfileAnchorEl] = useState<null | HTMLElement>(null);
  const handleProfileClick = (event: React.MouseEvent<HTMLElement>) => {
    setProfileAnchorEl(event.currentTarget);
  };
  const handleProfileClose = () => {
    setProfileAnchorEl(null);
  };

  // Escuchar atajo Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setSearchOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Cargar datos al abrir modal
  useEffect(() => {
    if (searchOpen) {
      setSearchQuery('');
      setSelectedIndex(-1);
      posService.tables()
        .then(data => setTables(data))
        .catch(err => console.error("Error cargando mesas para búsqueda:", err));
    }
  }, [searchOpen]);

  // Reset index when query changes
  useEffect(() => {
    setSelectedIndex(-1);
  }, [searchQuery]);

  const handleOpenSearch = () => setSearchOpen(true);
  const handleCloseSearch = () => setSearchOpen(false);

  const filteredPages = navItems
    .filter(item => canAccess(role, item.permission))
    .filter(item => item.label.toLowerCase().includes(searchQuery.toLowerCase()));

  const filteredTables = tables.filter(t => 
    `mesa ${t.number}`.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const hasResults = filteredPages.length > 0 || filteredTables.length > 0;

  interface SearchResultItem {
    type: 'page' | 'product' | 'table';
    id: string;
    label: string;
    action: () => void;
  }

  const combinedItems: SearchResultItem[] = [
    ...filteredPages.map(page => ({
      type: 'page' as const,
      id: page.path,
      label: page.label,
      action: () => {
        navigate(page.path);
        handleCloseSearch();
      }
    })),
    ...filteredTables.map(table => ({
      type: 'table' as const,
      id: table.id,
      label: `Mesa ${table.number}`,
      action: () => {
        navigate('/tables');
        handleCloseSearch();
      }
    }))
  ];

  const handleSearchKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => {
        const next = Math.min(prev + 1, combinedItems.length - 1);
        setTimeout(() => document.getElementById(`search-item-${next}`)?.scrollIntoView({ block: 'nearest' }), 0);
        return next;
      });
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => {
        if (prev === 0) return -1;
        const next = Math.max(-1, prev - 1);
        setTimeout(() => document.getElementById(`search-item-${next}`)?.scrollIntoView({ block: 'nearest' }), 0);
        return next;
      });
    } else if (e.key === 'Enter') {
      if (selectedIndex >= 0 && selectedIndex < combinedItems.length) {
        e.preventDefault();
        combinedItems[selectedIndex].action();
      }
    }
  };

  const handleLogout = async () => {
    if (refreshToken) {
      try {
        await logout(refreshToken);
      } catch (err) {
        console.error("Error logging out from server", err);
      }
    }
    clear();
  };

  const drawer = (
    <Box sx={{ height: '100%', bgcolor: '#0f172a', color: 'white', display: 'flex', flexDirection: 'column' }}>
      <Stack sx={{ px: 3, py: 2.5 }} direction="row" alignItems="center" justifyContent="space-between">
        <Typography variant="h5" sx={{ fontWeight: 'bold' }}>NeoPOSS</Typography>
        <Chip
          icon={syncState === 'error' ? <WifiOffIcon /> : <WifiIcon />}
          label={syncLabel}
          color={syncState}
          size="small"
          sx={{ height: 24, fontSize: '0.75rem', fontWeight: 600 }}
        />
      </Stack>
      <List sx={{ 
        px: 1.5, 
        flex: 1, 
        overflowY: 'auto',
        scrollbarWidth: 'none',
        msOverflowStyle: 'none',
        '&::-webkit-scrollbar': { display: 'none' }
      }}>
        {navItems
          .filter((item) => canAccess(role, item.permission))
          .map((item) => (
            <ListItemButton
              key={item.path}
              component={NavLink}
              to={item.path}
              selected={location.pathname === item.path}
              sx={{
                borderRadius: 2,
                mb: 0.5,
                color: '#e2e8f0',
                '&.Mui-selected': { bgcolor: '#1e293b', color: 'white' },
                '&:hover': { bgcolor: '#1e293b' }
              }}
              onClick={() => setMobileOpen(false)}
            >
              <ListItemIcon sx={{ color: 'inherit', minWidth: 40 }}>{item.icon}</ListItemIcon>
              <ListItemText primary={item.label} />
            </ListItemButton>
          ))}
      </List>
      <Box sx={{ p: 2 }}>
        <Button 
          variant="outlined" 
          startIcon={<SearchIcon />} 
          fullWidth 
          sx={{ 
            mb: 2, 
            color: '#e2e8f0', 
            borderColor: '#334155', 
            '&:hover': { borderColor: '#cbd5e1' },
            justifyContent: 'flex-start',
            px: 2
          }}
          onClick={handleOpenSearch}
        >
          <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', alignItems: 'center' }}>
            <span>Buscar</span>
            <Box sx={{ 
              fontSize: '0.7rem', 
              color: '#94a3b8', 
              border: '1px solid #475569', 
              borderRadius: 1, 
              px: 0.8, 
              py: 0.15, 
              bgcolor: '#1e293b' 
            }}>
              Ctrl K
            </Box>
          </Box>
        </Button>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Button 
            onClick={handleProfileClick} 
            sx={{ display: 'flex', alignItems: 'center', gap: 1.5, textTransform: 'none', color: 'white', p: 1, borderRadius: 2, '&:hover': { bgcolor: 'rgba(255,255,255,0.1)' } }}
          >
            <Avatar sx={{ bgcolor: 'secondary.main', width: 32, height: 32, fontSize: '1rem' }}>{user?.name?.[0] ?? 'A'}</Avatar>
            <Typography variant="body2" sx={{ fontWeight: 500 }}>
              {user?.name ?? 'Administrador'}
            </Typography>
          </Button>
        </Box>
        <Menu
          anchorEl={profileAnchorEl}
          open={Boolean(profileAnchorEl)}
          onClose={handleProfileClose}
          PaperProps={{ sx: { bgcolor: '#1e293b', color: 'white', minWidth: 200 } }}
          anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
          transformOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        >
          <MenuItem onClick={() => { handleProfileClose(); navigate('/settings'); }}>
            <ListItemIcon><SettingsIcon fontSize="small" sx={{ color: 'white' }} /></ListItemIcon>
            Configuración
          </MenuItem>
          <MenuItem onClick={() => { handleProfileClose(); handleLogout(); }} sx={{ color: '#f87171' }}>
            <ListItemIcon><LogoutIcon fontSize="small" sx={{ color: '#f87171' }} /></ListItemIcon>
            Cerrar Sesión
          </MenuItem>
        </Menu>
      </Box>
    </Box>
  );

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: 'background.default' }}>
      <AppBar position="fixed" sx={{ display: { md: 'none' }, bgcolor: 'white', color: 'text.primary', borderBottom: '1px solid #e2e8f0', boxShadow: 'none' }}>
        <Toolbar sx={{ gap: 2 }}>
          <IconButton onClick={() => setMobileOpen(true)} aria-label="Abrir menu">
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" sx={{ flex: 1, fontWeight: 'bold' }}>
            NeoPOS
          </Typography>
        </Toolbar>
      </AppBar>
      <Box component="nav" sx={{ width: { md: drawerWidth }, flexShrink: { md: 0 } }}>
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={() => setMobileOpen(false)}
          ModalProps={{ keepMounted: true }}
          sx={{ display: { xs: 'block', md: 'none' }, '& .MuiDrawer-paper': { width: drawerWidth, overflow: 'hidden' } }}
        >
          {drawer}
        </Drawer>
        <Drawer
          variant="permanent"
          sx={{ display: { xs: 'none', md: 'block' }, '& .MuiDrawer-paper': { width: drawerWidth, border: 0, overflow: 'hidden' } }}
          open
        >
          {drawer}
        </Drawer>
      </Box>
      <Box component="main" sx={{ flexGrow: 1, width: { md: `calc(100% - ${drawerWidth}px)` }, pt: { xs: 9, md: 3 }, px: { xs: 2, lg: 3 }, pb: 3 }}>
        <Outlet />
      </Box>

      {/* Modal de Búsqueda Global (Command Palette) conforme a DESIGN.md */}
      <Dialog 
        open={searchOpen} 
        onClose={handleCloseSearch}
        disableAutoFocus={!autoFocusSearch}
        maxWidth="sm"
        fullWidth
        slotProps={{
          backdrop: {
            style: {
              backdropFilter: 'blur(8px)',
              backgroundColor: 'rgba(15, 23, 42, 0.6)'
            }
          }
        }}
        PaperProps={{
          sx: {
            bgcolor: '#0f172a', // Slate Primary
            color: 'white',
            borderRadius: 3,
            boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.7)',
            border: '1px solid #1e293b',
            overflow: 'hidden'
          }
        }}
      >
        <DialogContent sx={{ p: 2.5 }}>
          <TextField
            fullWidth
            autoFocus={autoFocusSearch}
            placeholder="Buscar páginas, productos, mesas..."
            variant="standard"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={handleSearchKeyDown}
            slotProps={{
              input: {
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon sx={{ color: '#0891b2', mr: 1 }} /> {/* Electric Cyan */}
                  </InputAdornment>
                ),
                disableUnderline: true,
                style: {
                  color: 'white',
                  fontSize: '1.05rem',
                  padding: '8px 12px'
                }
              }
            }}
            sx={{ 
              mb: 2,
              bgcolor: 'rgba(30, 41, 59, 0.4)',
              borderRadius: 2,
              border: '1px solid #1e293b',
              '&:focus-within': {
                borderColor: 'primary.main', // Amber Accent focus
                boxShadow: '0 0 0 1px #0f172a'
              }
            }}
          />
          <Divider sx={{ borderColor: '#1e293b', mb: 2 }} />
          
          <Box sx={{ maxHeight: 350, overflowY: 'auto', scrollbarWidth: 'none', '&::-webkit-scrollbar': { display: 'none' } }}>
            {searchQuery && !hasResults && (
              <Box sx={{ py: 6, textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1 }}>
                <Typography variant="body1" sx={{ color: '#94a3b8' }}>
                  No se encontraron resultados para "{searchQuery}"
                </Typography>
                <Typography variant="caption" sx={{ color: '#64748b' }}>
                  Intenta buscar palabras clave como 'mesa', 'cocina' o el nombre de un plato.
                </Typography>
              </Box>
            )}
 
            {/* Sección de Páginas */}
            {filteredPages.length > 0 && (
              <Box sx={{ mb: 2.5 }}>
                <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 'bold', px: 1, textTransform: 'uppercase', letterSpacing: 0.8, fontSize: '0.7rem' }}>
                  Páginas
                </Typography>
                <List dense sx={{ p: 0, mt: 0.5 }}>
                  {filteredPages.map((page, idx) => {
                    const isSelected = selectedIndex === idx;
                    return (
                      <ListItemButton
                        id={`search-item-${idx}`}
                        key={page.path}
                        selected={isSelected}
                        onClick={() => {
                          navigate(page.path);
                          handleCloseSearch();
                        }}
                        sx={{
                          borderRadius: 1.5,
                          my: 0.25,
                          color: '#cbd5e1',
                          bgcolor: isSelected ? 'rgba(15, 23, 42, 0.15)' : 'transparent',
                          outline: isSelected ? '2px solid #0f172a' : 'none',
                          transition: 'all 0.15s ease',
                          '&:hover': { 
                            bgcolor: 'rgba(15, 23, 42, 0.08)', // Amber Accent Glow
                            color: 'primary.main',
                            transform: 'scale(0.995)',
                            '& .MuiListItemIcon-root': { color: 'primary.main' }
                          }
                        }}
                      >
                        <ListItemIcon sx={{ color: 'inherit', minWidth: 36, transition: 'color 0.15s' }}>
                          {page.icon}
                        </ListItemIcon>
                        <ListItemText primary={page.label} slotProps={{ primary: { style: { fontWeight: 500 } } }} />
                      </ListItemButton>
                    );
                  })}
                </List>
              </Box>
            )}
 
            {/* Sección de Mesas */}
            {filteredTables.length > 0 && (
              <Box sx={{ mb: 1 }}>
                <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 'bold', px: 1, textTransform: 'uppercase', letterSpacing: 0.8, fontSize: '0.7rem' }}>
                  Mesas
                </Typography>
                <List dense sx={{ p: 0, mt: 0.5 }}>
                  {filteredTables.map((table, idx) => {
                    const absIdx = filteredPages.length + idx;
                    const isSelected = selectedIndex === absIdx;
                    return (
                      <ListItemButton
                        id={`search-item-${absIdx}`}
                        key={table.id}
                        selected={isSelected}
                        onClick={() => {
                          navigate('/tables');
                          handleCloseSearch();
                        }}
                        sx={{
                          borderRadius: 1.5,
                          my: 0.25,
                          color: '#cbd5e1',
                          bgcolor: isSelected ? 'rgba(15, 23, 42, 0.15)' : 'transparent',
                          outline: isSelected ? '2px solid #0f172a' : 'none',
                          transition: 'all 0.15s ease',
                          '&:hover': { 
                            bgcolor: 'rgba(15, 23, 42, 0.08)', // Amber Accent Glow
                            color: 'primary.main',
                            transform: 'scale(0.995)',
                            '& .MuiListItemIcon-root': { color: 'primary.main' }
                          }
                        }}
                      >
                        <ListItemIcon sx={{ color: '#0891b2', minWidth: 36, transition: 'color 0.15s' }}> {/* Electric Cyan */}
                          <TableRestaurantIcon />
                        </ListItemIcon>
                        <ListItemText primary={`Mesa ${table.number}`} slotProps={{ primary: { style: { fontWeight: 500 } } }} />
                        <Chip 
                          size="small" 
                          label={table.status === 'OCCUPIED' ? 'Ocupada' : 'Disponible'} 
                          sx={{ 
                            height: 20, 
                            fontSize: '0.68rem', 
                            fontWeight: 600,
                            color: table.status === 'OCCUPIED' ? '#dc2626' : '#16a34a', // Error (Rojo) y Éxito (Verde)
                            borderColor: table.status === 'OCCUPIED' ? '#dc2626' : '#16a34a',
                            bgcolor: 'transparent'
                          }}
                          variant="outlined"
                        />
                      </ListItemButton>
                    );
                  })}
                </List>
              </Box>
            )}
          </Box>
          
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 2, pt: 1.5, borderTop: '1px solid #1e293b', color: '#475569', fontSize: '0.72rem' }}>
            <span>Navega o selecciona un elemento con un toque</span>
            <span>Esc para cerrar</span>
          </Box>
        </DialogContent>
      </Dialog>
    </Box>
  );
}
