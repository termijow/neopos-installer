import type {
  Category,
  Client,
  InventoryMovement,
  KitchenOrder,
  Product,
  RestaurantTable
} from '../types/domain';

export const mockTables: RestaurantTable[] = Array.from({ length: 120 }, (_, index) => {
  const statuses: RestaurantTable['status'][] = ['FREE', 'OCCUPIED', 'RESERVED', 'CLEANING'];
  return {
    id: `table-${index + 1}`,
    number: index + 1,
    capacity: index % 5 === 0 ? 8 : index % 3 === 0 ? 6 : 4,
    status: statuses[index % statuses.length]
  };
});

export const mockCategories: Category[] = [
  { id: 'cat-1', name: 'Entradas', active: true },
  { id: 'cat-2', name: 'Hamburguesas', active: true },
  { id: 'cat-3', name: 'Bebidas', active: true },
  { id: 'cat-4', name: 'Postres', active: true }
];

export const mockProducts: Product[] = [
  { id: 'prod-1', name: 'Hamburguesa Clasica', code: 'HAMB-001', price: 26000, category_id: 'cat-2', category: 'Hamburguesas', active: true },
  { id: 'prod-2', name: 'Hamburguesa Doble', code: 'HAMB-002', price: 34000, category_id: 'cat-2', category: 'Hamburguesas', active: true },
  { id: 'prod-3', name: 'Papas Rusticas', code: 'ENT-001', price: 12000, category_id: 'cat-1', category: 'Entradas', active: true },
  { id: 'prod-4', name: 'Coca Cola', code: 'BEB-001', price: 6000, category_id: 'cat-3', category: 'Bebidas', active: true },
  { id: 'prod-5', name: 'Limonada Natural', code: 'BEB-002', price: 9000, category_id: 'cat-3', category: 'Bebidas', active: true },
  { id: 'prod-6', name: 'Brownie con Helado', code: 'POS-001', price: 15000, category_id: 'cat-4', category: 'Postres', active: true }
];

export const mockKitchenOrders: KitchenOrder[] = [
  { id: 'kds-25', order_id: '25', status: 'COOKING', notes: 'Mesa 12 - sin cebolla' },
  { id: 'kds-26', order_id: '26', status: 'PENDING', notes: 'Mesa 8 - bebidas primero' },
  { id: 'kds-27', order_id: '27', status: 'READY', notes: 'Mesa 3 - para llevar' }
];

export const mockInventory: InventoryMovement[] = [
  { id: 'mov-1', product_id: 'prod-1', product: 'Carne hamburguesa', quantity: 40, type: 'IN', created_at: new Date().toISOString() },
  { id: 'mov-2', product_id: 'prod-3', product: 'Papa criolla', quantity: 12, type: 'OUT', created_at: new Date().toISOString() },
  { id: 'mov-3', product_id: 'prod-4', product: 'Coca Cola', quantity: 6, type: 'SALE', created_at: new Date().toISOString() }
];

export const mockClients: Client[] = [
  { id: 'client-1', document_type: 'CC', document: '1020304050', name: 'Laura Gomez', email: 'laura@example.com', phone: '3001112233' },
  { id: 'client-2', document_type: 'NIT', document: '900123456-7', name: 'Empresa Demo SAS', email: 'contabilidad@example.com', phone: '6015550101' }
];

export const salesDaily = [
  { name: 'Lun', ventas: 1800000 },
  { name: 'Mar', ventas: 2300000 },
  { name: 'Mie', ventas: 1950000 },
  { name: 'Jue', ventas: 2700000 },
  { name: 'Vie', ventas: 3900000 },
  { name: 'Sab', ventas: 5200000 },
  { name: 'Dom', ventas: 4100000 }
];

export const salesMonthly = [
  { name: 'Ene', ventas: 62000000 },
  { name: 'Feb', ventas: 58000000 },
  { name: 'Mar', ventas: 71000000 },
  { name: 'Abr', ventas: 69000000 },
  { name: 'May', ventas: 83000000 },
  { name: 'Jun', ventas: 36000000 }
];

export const topProducts = [
  { name: 'Hamburguesa Doble', ventas: 450 },
  { name: 'Limonada Natural', ventas: 380 },
  { name: 'Hamburguesa Clasica', ventas: 310 },
  { name: 'Papas Rusticas', ventas: 290 },
  { name: 'Brownie Helado', ventas: 180 }
];

export const peakHours = [
  { time: '12:00', pedidos: 45 },
  { time: '13:00', pedidos: 80 },
  { time: '14:00', pedidos: 65 },
  { time: '18:00', pedidos: 50 },
  { time: '19:00', pedidos: 110 },
  { time: '20:00', pedidos: 130 },
  { time: '21:00', pedidos: 90 },
];

export const profitability = [
  { name: 'Ene', ingresos: 62000000, costos: 35000000, utilidad: 27000000 },
  { name: 'Feb', ingresos: 58000000, costos: 33000000, utilidad: 25000000 },
  { name: 'Mar', ingresos: 71000000, costos: 40000000, utilidad: 31000000 },
  { name: 'Abr', ingresos: 69000000, costos: 38000000, utilidad: 31000000 },
  { name: 'May', ingresos: 83000000, costos: 45000000, utilidad: 38000000 },
  { name: 'Jun', ingresos: 36000000, costos: 20000000, utilidad: 16000000 },
];

