import type { Role } from '../types/domain';

export const roleLabels: Record<Role, string> = {
  admin: 'Administrador',
  manager: 'Gerente',
  cashier: 'Cajero',
  waiter: 'Mesero',
  kitchen: 'Cocina'
};

export const permissions: Record<Role, string[]> = {
  admin: ['*'],
  manager: ['dashboard', 'inventory', 'reports', 'products', 'settings', 'ai-assistant'],
  cashier: ['tables', 'orders', 'cash', 'invoices', 'ai-assistant'],
  waiter: ['tables', 'orders'],
  kitchen: ['kitchen']
};

export function canAccess(role: Role | undefined, permission: string) {
  if (!role) return false;
  const allowed = permissions[role] ?? [];
  return allowed.includes('*') || allowed.includes(permission);
}

export function getHomePath(role: string | undefined): string {
  if (role === 'cashier' || role === 'cajero') return '/tables';
  if (role === 'kitchen') return '/kitchen';
  if (role === 'waiter') return '/tables';
  return '/dashboard';
}
