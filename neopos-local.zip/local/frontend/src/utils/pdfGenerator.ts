import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

interface PDFGeneratorOptions {
  type: string;
  label: string;
  from: string;
  to: string;
  data: any;
  userName?: string;
  companyName?: string;
  companyNIT?: string;
  branchName?: string;
}

export function generatePDF(options: PDFGeneratorOptions) {
  const { type, label, from, to, data, userName = 'Usuario', companyName = 'NeoPOS', companyNIT = '', branchName = '' } = options;
  
  const doc = new jsPDF({
    orientation: type === 'ledger' || type === 'daily' || type === 'monthly' ? 'landscape' : 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  
  // Header styles
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text(companyName, pageWidth / 2, 15, { align: 'center' });
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  if (companyNIT) {
    doc.text(`NIT: ${companyNIT}`, pageWidth / 2, 21, { align: 'center' });
  }
  if (branchName) {
    doc.text(`Sucursal: ${branchName}`, pageWidth / 2, 26, { align: 'center' });
  }

  // Report details
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text(`Reporte: ${label}`, 14, 35);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Fecha de consulta: ${from} a ${to}`, 14, 41);
  doc.text(`Generado por: ${userName}`, 14, 46);
  doc.text(`Fecha generación: ${format(new Date(), "dd/MM/yyyy HH:mm", { locale: es })}`, 14, 51);

  // Divider
  doc.setLineWidth(0.5);
  doc.line(14, 54, pageWidth - 14, 54);

  let startY = 60;

  switch (type) {
    case 'daily':
    case 'monthly':
    case 'ledger':
      generateSalesPDF(doc, type, data, startY, pageWidth);
      break;
    case 'tax':
      generateTaxPDF(doc, data, startY, pageWidth);
      break;
    case 'cash':
      generateCashPDF(doc, data, startY, pageWidth);
      break;
    case 'inventory':
      generateInventoryPDF(doc, data, startY, pageWidth);
      break;
    default:
      doc.text('Tipo de reporte no soportado', 14, startY);
  }

  // Add footer to all pages
  const pageCount = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(150);
    doc.text(
      `Generado por NeoPOS - Página ${i} de ${pageCount}`,
      pageWidth / 2,
      doc.internal.pageSize.getHeight() - 10,
      { align: 'center' }
    );
  }

  doc.save(`${label.toLowerCase().replace(/\s+/g, '-')}-${from}-a-${to}.pdf`);
}

function formatCurrency(amount: number) {
  return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(amount);
}

function formatDate(dateString: string) {
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return format(d, 'dd/MM/yyyy HH:mm');
  } catch {
    return dateString;
  }
}

// Sales Report Generator (Daily, Monthly, Ledger)
function generateSalesPDF(doc: jsPDF, type: string, data: any, startY: number, pageWidth: number) {
  const sales = data.sales || [];
  
  if (sales.length === 0) {
    doc.text('No hay registros para este periodo.', 14, startY);
    return;
  }

  // Calculate Summary
  let totalAmount = 0;
  let totalInvoices = 0;
  let totalProducts = 0;
  
  sales.forEach((s: any) => {
    totalAmount += s.Total || 0;
    totalProducts += s.Quantity || 0;
  });
  
  const uniqueInvoices = new Set(sales.map((s: any) => s.InvoiceNum));
  totalInvoices = uniqueInvoices.size;
  const ticketPromedio = totalInvoices > 0 ? totalAmount / totalInvoices : 0;
  
  const uniqueClients = new Set(sales.map((s: any) => s.ClientName));

  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('Resumen Ejecutivo', 14, startY);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Total Vendido: ${formatCurrency(totalAmount)}`, 14, startY + 6);
  doc.text(`Facturas: ${totalInvoices}`, 14, startY + 11);
  doc.text(`Ticket Promedio: ${formatCurrency(ticketPromedio)}`, 14, startY + 16);
  doc.text(`Productos Vendidos: ${totalProducts}`, 100, startY + 6);
  doc.text(`Clientes Atendidos: ${uniqueClients.size}`, 100, startY + 11);
  
  startY += 26;

  // Table
  const tableData = sales.map((s: any) => [
    formatDate(s.Date),
    s.InvoiceNum || 'N/A',
    s.ClientName || 'Consumidor Final',
    s.ProductName,
    s.Quantity,
    formatCurrency(s.Subtotal || 0),
    formatCurrency(s.Tax || 0),
    formatCurrency(s.Total || 0)
  ]);

  autoTable(doc, {
    startY: startY,
    head: [['Fecha/Hora', 'Factura', 'Cliente', 'Producto', 'Cant.', 'Subtotal', 'IVA', 'Total']],
    body: tableData,
    theme: 'grid',
    headStyles: { fillColor: [47, 84, 150] },
    styles: { fontSize: 8 },
    columnStyles: {
      4: { halign: 'center' },
      5: { halign: 'right' },
      6: { halign: 'right' },
      7: { halign: 'right' }
    }
  });
}

// Tax Report Generator
function generateTaxPDF(doc: jsPDF, data: any, startY: number, pageWidth: number) {
  const sales = data.sales || [];
  
  if (sales.length === 0) {
    doc.text('No hay registros para este periodo.', 14, startY);
    return;
  }

  let totalBase = 0;
  let totalIVA = 0;
  let totalGeneral = 0;
  
  sales.forEach((s: any) => {
    totalBase += s.Subtotal || 0;
    totalIVA += s.Tax || 0;
    totalGeneral += s.Total || 0;
  });

  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('Resumen Tributario', 14, startY);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Total Base Gravable: ${formatCurrency(totalBase)}`, 14, startY + 6);
  doc.text(`Total IVA 19%: ${formatCurrency(totalIVA)}`, 14, startY + 11);
  doc.text(`Total General: ${formatCurrency(totalGeneral)}`, 14, startY + 16);
  
  startY += 26;

  const tableData = sales.map((s: any) => [
    formatDate(s.Date),
    s.InvoiceNum || 'N/A',
    formatCurrency(s.Subtotal || 0),
    formatCurrency(s.Tax || 0),
    formatCurrency(0), // Impoconsumo
    formatCurrency(s.Total || 0)
  ]);

  autoTable(doc, {
    startY: startY,
    head: [['Fecha', 'Factura', 'Base Gravable', 'IVA', 'Impoconsumo', 'Total']],
    body: tableData,
    theme: 'grid',
    headStyles: { fillColor: [47, 84, 150] },
    styles: { fontSize: 8 },
    columnStyles: {
      2: { halign: 'right' },
      3: { halign: 'right' },
      4: { halign: 'right' },
      5: { halign: 'right' }
    }
  });
}

// Cash Report Generator
function generateCashPDF(doc: jsPDF, data: any, startY: number, pageWidth: number) {
  if (!data || !data.Summary) {
    doc.text('No hay registros para este periodo.', 14, startY);
    return;
  }

  const summary = data.Summary;

  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('Resumen de Caja', 14, startY);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  
  let leftY = startY + 6;
  doc.text(`Caja Inicial: ${formatCurrency(summary.OpeningAmount)}`, 14, leftY); leftY+=6;
  doc.text(`Ventas Totales: ${formatCurrency(summary.NetTotal)}`, 14, leftY); leftY+=6;
  doc.text(`Ingresos Manuales: ${formatCurrency(summary.ManualDeposits)}`, 14, leftY); leftY+=6;
  doc.text(`Egresos Manuales: ${formatCurrency(summary.ManualWithdraws)}`, 14, leftY); leftY+=6;
  
  let rightY = startY + 6;
  doc.text(`Caja Esperada: ${formatCurrency(summary.ExpectedClose)}`, 110, rightY); rightY+=6;
  doc.text(`Caja Real (Cierre): ${formatCurrency(summary.ClosingAmount)}`, 110, rightY); rightY+=6;
  
  doc.setFont('helvetica', 'bold');
  doc.text(`Diferencia: ${formatCurrency(summary.Difference)}`, 110, rightY); 
  doc.setFont('helvetica', 'normal');
  
  startY = Math.max(leftY, rightY) + 10;

  if (data.PaymentMethods && data.PaymentMethods.length > 0) {
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('Por Método de Pago', 14, startY);
    startY += 5;
    
    const methodsTable = data.PaymentMethods.map((m: any) => [m.Method, m.Count, formatCurrency(m.Total)]);
    autoTable(doc, {
      startY: startY,
      head: [['Método', 'Transacciones', 'Total']],
      body: methodsTable,
      theme: 'grid',
      headStyles: { fillColor: [47, 84, 150] },
      styles: { fontSize: 8 }
    });
    startY = (doc as any).lastAutoTable.finalY + 10;
  }

  if (data.Movements && data.Movements.length > 0) {
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('Movimientos de Caja', 14, startY);
    startY += 5;
    
    const movTable = data.Movements.map((m: any) => [
      formatDate(m.Time),
      m.Type === 'DEPOSIT' ? 'Ingreso' : 'Egreso',
      m.Concept,
      m.User,
      formatCurrency(m.Value)
    ]);
    autoTable(doc, {
      startY: startY,
      head: [['Hora', 'Tipo', 'Descripción', 'Usuario', 'Valor']],
      body: movTable,
      theme: 'grid',
      headStyles: { fillColor: [47, 84, 150] },
      styles: { fontSize: 8 },
      columnStyles: { 4: { halign: 'right' } }
    });
  }
}

// Inventory Report Generator
function generateInventoryPDF(doc: jsPDF, data: any, startY: number, pageWidth: number) {
  const products = data.Products || [];
  
  if (products.length === 0) {
    doc.text('No hay productos en el inventario.', 14, startY);
    return;
  }

  let totalValue = 0;
  let outOfStock = 0;
  let lowStock = 0;

  products.forEach((p: any) => {
    const value = p.Stock * p.Cost;
    if (value > 0) totalValue += value;
    if (p.Stock <= 0) outOfStock++;
    else if (p.Stock <= p.MinStock) lowStock++;
  });

  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('Resumen de Inventario', 14, startY);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Total Productos: ${products.length}`, 14, startY + 6);
  doc.text(`Valor Total del Inventario (Costo): ${formatCurrency(totalValue)}`, 14, startY + 11);
  doc.text(`Agotados: ${outOfStock}`, 110, startY + 6);
  doc.text(`Stock Bajo: ${lowStock}`, 110, startY + 11);
  
  startY += 20;

  const tableData = products.map((p: any) => [
    p.Code || 'N/A',
    p.Name,
    p.Category || '-',
    p.Stock,
    formatCurrency(p.Cost),
    formatCurrency(p.Stock > 0 ? p.Stock * p.Cost : 0)
  ]);

  autoTable(doc, {
    startY: startY,
    head: [['Código', 'Producto', 'Categoría', 'Stock', 'Costo Unit.', 'Valor Total']],
    body: tableData,
    theme: 'grid',
    headStyles: { fillColor: [47, 84, 150] },
    styles: { fontSize: 8 },
    columnStyles: {
      3: { halign: 'center' },
      4: { halign: 'right' },
      5: { halign: 'right' }
    }
  });
}
