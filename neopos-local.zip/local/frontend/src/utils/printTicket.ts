import { cop } from './format';

import { useSettingsStore } from '../stores/settingsStore';

interface PrintItem {
  name: string;
  quantity: number;
  unit_price: number;
  total: number;
}

interface PrintData {
  id: string;
  created_at: string;
  payment_method: string;
  subtotal: number;
  discount: number;
  tip: number;
  total: number;
  items: PrintItem[];
  customer_name?: string;
  is_mesa?: boolean;
  table_name?: string;
}

export const printTicket = (data: PrintData) => {
  const { companyConfig, feConfig } = useSettingsStore.getState();
  const businessName = companyConfig?.name || 'NeoPOS';
  const nit = companyConfig?.nit || '';
  const address = companyConfig?.address || '';
  const phone = companyConfig?.phone || '';

  const displayId = data.id.split('-')[0].toUpperCase();
  const dateObj = new Date(data.created_at);
  const dateOnly = dateObj.toLocaleDateString();
  const timeOnly = dateObj.toLocaleTimeString();
  const origin = data.is_mesa ? (data.table_name ? data.table_name.toUpperCase() : 'MESA') : 'CAJA RÁPIDA';

  const paymentMethodLabel = data.payment_method === 'CASH' ? 'Efectivo' :
                             data.payment_method === 'CREDIT_CARD' ? 'Tarjeta de Crédito' :
                             data.payment_method === 'DEBIT_CARD' ? 'Tarjeta de Débito' :
                             data.payment_method === 'TRANSFER' ? 'Transferencia' :
                             data.payment_method === 'QR' ? 'Código QR' : data.payment_method;

  const printContent = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <title>Ticket #${displayId}</title>
        <style>
          @page {
            margin: 0;
          }
          html, body {
            margin: 0;
            padding: 0;
            height: auto;
            background-color: #fff;
          }
          body { 
            font-family: 'Courier New', Courier, monospace; 
            width: 100%; 
            margin: 0;
            padding: 0 4mm 0 0; /* Espacio seguro solo a la derecha para proteger los precios */
            box-sizing: border-box;
            font-size: 11px;
            color: #000;
          }
          h2 { 
            text-align: left; 
            margin: 0 0 5px 0; 
            font-size: 13px;
            text-transform: uppercase;
          }
          @media print {
            body {
              color: black !important;
              background-color: white !important;
            }
          }
          .divider { 
            border-bottom: 1px dashed #000; 
            margin: 6px 0; 
          }
          .info {
            margin-bottom: 8px;
            text-align: left;
          }
          .info div {
            margin-bottom: 2px;
          }
          .item { 
            margin-bottom: 5px; 
          }
          .item-name {
            display: block;
            word-break: break-word;
            overflow-wrap: break-word;
          }
          .item-price {
            display: block;
            padding-left: 10px;
            font-weight: bold;
          }
          .total-section {
            margin-top: 8px;
          }
          .total-line {
            margin-bottom: 3px;
          }
          .total-label {
            display: inline-block;
          }
          .total-value {
            display: inline-block;
            margin-left: 5px;
            font-weight: bold;
          }
          .total { 
            font-size: 13px; 
            margin-top: 5px;
            border-top: 1px dashed #000;
            padding-top: 3px;
          }
          .footer {
            text-align: left;
            margin-top: 10px;
            font-size: 10px;
            padding-bottom: 2mm;
          }
        </style>
      </head>
      <body>
        <h2>${businessName}</h2>
        <div class="info">
          ${nit ? `<div>NIT: ${nit}</div>` : ''}
          ${address ? `<div>${address}</div>` : ''}
          ${phone ? `<div>Tel: ${phone}</div>` : ''}
          <div style="margin-top: 8px;">TICKET: #${displayId}</div>
          <div>ORIGEN: ${origin}</div>
          ${data.customer_name ? `<div>CLIENTE: ${data.customer_name}</div>` : ''}
          <div>Fecha: ${dateOnly}</div>
          <div>Hora: ${timeOnly}</div>
          <div>Método: ${paymentMethodLabel}</div>
        </div>
        
        <div class="divider"></div>
        
        ${(data.items || []).map((item) => `
          <div class="item">
            <div class="item-name">${item.quantity}x ${item.name}</div>
            <div class="item-price">${cop(item.total)}</div>
          </div>
        `).join('')}
        
        <div class="divider"></div>
        
        <div class="total-section">
          <div class="total-line"><span class="total-label">Subtotal:</span><span class="total-value">${cop(data.subtotal)}</span></div>
          ${data.tip > 0 ? `<div class="total-line"><span class="total-label">Propina:</span><span class="total-value">${cop(data.tip)}</span></div>` : ''}
          ${data.discount > 0 ? `<div class="total-line"><span class="total-label">Descuento:</span><span class="total-value">-${cop(data.discount)}</span></div>` : ''}
          <div class="total-line"><span class="total-label">Base:</span><span class="total-value">${cop((data.subtotal - (data.discount || 0)) / 1.08)}</span></div>
          <div class="total-line"><span class="total-label">Impoconsumo (8%):</span><span class="total-value">${cop((data.subtotal - (data.discount || 0)) - ((data.subtotal - (data.discount || 0)) / 1.08))}</span></div>
          <div class="total-line total"><span class="total-label">TOTAL:</span><span class="total-value">${cop(data.total)}</span></div>
        </div>
        
        <div class="divider"></div>
        
        <div class="footer">
          ${feConfig?.resolution ? `<p style="font-size: 9px; margin-top: 5px;">Resolución DIAN: ${feConfig.resolution}</p>` : ''}
          <p style="margin-top: 10px;">¡Gracias por su compra!</p>
          <p>Sistema NeoPOS</p>
        </div>
      </body>
    </html>
  `;

  const printWindow = window.open('', '_blank', 'width=350,height=600,menubar=no,toolbar=no,location=no,status=no');
  
  if (printWindow) {
    printWindow.document.open();
    printWindow.document.write(printContent);
    // Add a little floating button to actually print from the simulator
    printWindow.document.write(`
      <style>
        @media print {
          .no-print { display: none !important; }
        }
        .simulator-btn {
          position: fixed;
          bottom: 10px;
          right: 10px;
          background: #0f172a;
          color: white;
          border: none;
          padding: 8px 12px;
          border-radius: 4px;
          cursor: pointer;
          font-family: sans-serif;
          font-size: 12px;
        }
      </style>
      <button class="no-print simulator-btn" onclick="window.print()">🖨️ Imprimir (SO)</button>
    `);
    printWindow.document.close();
  } else {
    console.warn("El navegador bloqueó la ventana emergente del ticket.");
  }
};
