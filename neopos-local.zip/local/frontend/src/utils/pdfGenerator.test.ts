import { beforeEach, describe, expect, it, vi } from 'vitest';
import autoTable from 'jspdf-autotable';
import { generatePDF } from './pdfGenerator';

const pdfMocks = vi.hoisted(() => ({ instances: [] as any[] }));

vi.mock('jspdf', () => ({
  default: class MockJsPDF {
    internal = {
      pageSize: { getWidth: () => 210, getHeight: () => 297 },
      getNumberOfPages: () => 1
    };
    text = vi.fn();
    setFont = vi.fn();
    setFontSize = vi.fn();
    setLineWidth = vi.fn();
    line = vi.fn();
    setTextColor = vi.fn();
    setFillColor = vi.fn();
    setDrawColor = vi.fn();
    roundedRect = vi.fn();
    setPage = vi.fn();
    addPage = vi.fn();
    save = vi.fn();
    splitTextToSize = vi.fn((value: string) => value.split('\n'));

    constructor() {
      pdfMocks.instances.push(this);
    }
  }
}));

vi.mock('jspdf-autotable', () => ({
  default: vi.fn((doc: any, options: any) => {
    doc.lastAutoTable = { finalY: options.startY + 20 };
  })
}));

describe('cash PDF report', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    pdfMocks.instances.length = 0;
  });

  it('includes payment-method totals and literal cash observations', () => {
    generatePDF({
      type: 'cash',
      label: 'Caja',
      from: '2026-07-25',
      to: '2026-07-25',
      data: {
        Summary: {
          OpeningAmount: 100000,
          NetTotal: 250000,
          ManualDeposits: 10000,
          ManualWithdraws: 5000,
          ExpectedClose: 355000,
          ClosingAmount: 355000,
          Difference: 0,
          Notes: 'Apertura: fondo completo\n\nCierre: se verificó el efectivo contado.'
        },
        PaymentMethods: [
          { Method: 'Efectivo', Count: 2, Total: 150000 },
          { Method: 'Tarjeta', Count: 1, Total: 100000 }
        ]
      }
    });

    expect(vi.mocked(autoTable)).toHaveBeenCalledOnce();
    const tableOptions = vi.mocked(autoTable).mock.calls[0][1] as any;
    expect(tableOptions.body).toEqual([
      ['Efectivo', 2, expect.any(String)],
      ['Tarjeta', 1, expect.any(String)]
    ]);
    expect(tableOptions.foot[0][0]).toBe('TOTAL GENERAL');

    const pdf = pdfMocks.instances[0];
    const textCalls = pdf.text.mock.calls.map(([value]: [string | string[]]) => value);
    expect(textCalls).toContain('Resumen por método de pago');
    expect(textCalls).toContain('Observaciones y estipulaciones de caja');
    expect(textCalls.some((value: string | string[]) => Array.isArray(value) && value.join('\n').includes('Apertura: fondo completo'))).toBe(true);
    expect(pdf.save).toHaveBeenCalledOnce();
  });
});
