export interface QueuedRequest {
  id: string;
  url: string;
  method: string;
  body?: unknown;
  createdAt: string;
}

const key = 'neopos:offline-queue';

export function queueRequest(request: Omit<QueuedRequest, 'id' | 'createdAt'>) {
  const queue = getQueue();
  queue.push({
    ...request,
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString()
  });
  localStorage.setItem(key, JSON.stringify(queue));
}

export function getQueue(): QueuedRequest[] {
  try {
    return JSON.parse(localStorage.getItem(key) ?? '[]') as QueuedRequest[];
  } catch {
    return [];
  }
}

export function replaceQueue(queue: QueuedRequest[]) {
  localStorage.setItem(key, JSON.stringify(queue));
}
