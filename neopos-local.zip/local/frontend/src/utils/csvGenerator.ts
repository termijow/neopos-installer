import * as XLSX from 'xlsx';
import { format } from 'date-fns';

interface CSVGeneratorOptions {
  type: string;
  label: string;
  from: string;
  to: string;
  data: any;
}

export function generateCSV(options: CSVGeneratorOptions) {
  const { type, label, from, to, data } = options;
  let aoa: any[][] = [];

  const addEmptyLine = () => aoa.push([]);

  // Title
  aoa.push([`Reporte: ${label}`]);
  aoa.push([`Fechas: ${from} a ${to}`]);
  addEmptyLine();

  switch (type) {
    case 'daily':
    case 'monthly':
    case 'ledger':
      aoa = aoa.concat(generateSalesCSV(data));
      break;
    case 'tax':
      aoa = aoa.concat(generateTaxCSV(data));
      break;
    case 'cash':
      aoa = aoa.concat(generateCashCSV(data));
      break;
    case 'inventory':
      aoa = aoa.concat(generateInventoryCSV(data));
      break;
    default:
      aoa.push(['Tipo de reporte no soportado']);
  }

  const ws = XLSX.utils.aoa_to_sheet(aoa);
  const csv = XLSX.utils.sheet_to_csv(ws, { FS: ';' });
  const standardCsv = XLSX.utils.sheet_to_csv(ws, { FS: ',' });

  const blob = new Blob(["\uFEFF" + standardCsv], { type: 'text/csv;charset=utf-8;' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${label.toLowerCase().replace(/\s+/g, '-')}-${from}-a-${to}.csv`;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(url);
  document.body.removeChild(a);
}

function formatDate(dateString: string) {
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return format(d, 'dd/MM/yyyy HH:mm');
  } catch {
    return dateString;
  }
}

function generateSalesCSV(data: any): any[][] {
  const sales = data.sales || [];
  if (sales.length === 0) return [['No hay registros para este periodo.']];

  let totalAmount = 0;
  let totalProducts = 0;
  
  sales.forEach((s: any) => {
    totalAmount += s.Total || 0;
    totalProducts += s.Quantity || 0;
  });

  const uniqueInvoices = new Set(sales.map((s: any) => s.InvoiceNum));
  const uniqueClients = new Set(sales.map((s: any) => s.ClientName));
  const ticketPromedio = uniqueInvoices.size > 0 ? totalAmount / uniqueInvoices.size : 0;

  const aoa: any[][] = [];
  
  // Summary
  aoa.push(['Resumen Ejecutivo']);
  aoa.push(['Total Vendido', totalAmount]);
  aoa.push(['Facturas', uniqueInvoices.size]);
  aoa.push(['Ticket Promedio', ticketPromedio]);
  aoa.push(['Productos Vendidos', totalProducts]);
  aoa.push(['Clientes Atendidos', uniqueClients.size]);
  aoa.push([]);

  // Table
  aoa.push(['Fecha/Hora', 'Factura', 'Cliente', 'Producto', 'Cant.', 'Subtotal', 'IVA', 'Total']);
  
  sales.forEach((s: any) => {
    aoa.push([
      formatDate(s.Date),
      s.InvoiceNum || 'N/A',
      s.ClientName || 'Consumidor Final',
      s.ProductName,
      s.Quantity,
      s.Subtotal || 0,
      s.Tax || 0,
      s.Total || 0
    ]);
  });

  return aoa;
}

function generateTaxCSV(data: any): any[][] {
  const sales = data.sales || [];
  if (sales.length === 0) return [['No hay registros para este periodo.']];

  let totalBase = 0;
  let totalIVA = 0;
  let totalGeneral = 0;
  
  sales.forEach((s: any) => {
    totalBase += s.Subtotal || 0;
    totalIVA += s.Tax || 0;
    totalGeneral += s.Total || 0;
  });

  const aoa: any[][] = [];
  
  // Summary
  aoa.push(['Resumen Tributario']);
  aoa.push(['Total Base Gravable', totalBase]);
  aoa.push(['Total IVA 19%', totalIVA]);
  aoa.push(['Total General', totalGeneral]);
  aoa.push([]);

  // Table
  aoa.push(['Fecha', 'Factura', 'Base Gravable', 'IVA', 'Impoconsumo', 'Total']);
  
  sales.forEach((s: any) => {
    aoa.push([
      formatDate(s.Date),
      s.InvoiceNum || 'N/A',
      s.Subtotal || 0,
      s.Tax || 0,
      0, // Impoconsumo
      s.Total || 0
    ]);
  });

  return aoa;
}

function generateCashCSV(data: any): any[][] {
  if (!data || !data.Summary) return [['No hay registros para este periodo.']];

  const summary = data.Summary;
  const aoa: any[][] = [];

  // Summary
  aoa.push(['Resumen de Caja']);
  aoa.push(['Caja Inicial', summary.OpeningAmount]);
  aoa.push(['Ventas Totales', summary.NetTotal]);
  aoa.push(['Ingresos Manuales', summary.ManualDeposits]);
  aoa.push(['Egresos Manuales', summary.ManualWithdraws]);
  aoa.push(['Caja Esperada', summary.ExpectedClose]);
  aoa.push(['Caja Real (Cierre)', summary.ClosingAmount]);
  aoa.push(['Diferencia', summary.Difference]);
  aoa.push([]);

  if (data.PaymentMethods && data.PaymentMethods.length > 0) {
    aoa.push(['Por Método de Pago']);
    aoa.push(['Método', 'Transacciones', 'Total']);
    data.PaymentMethods.forEach((m: any) => {
      aoa.push([m.Method, m.Count, m.Total]);
    });
    aoa.push([]);
  }

  if (data.Movements && data.Movements.length > 0) {
    aoa.push(['Movimientos de Caja']);
    aoa.push(['Hora', 'Tipo', 'Descripción', 'Usuario', 'Valor']);
    data.Movements.forEach((m: any) => {
      aoa.push([
        formatDate(m.Time),
        m.Type === 'DEPOSIT' ? 'Ingreso' : 'Egreso',
        m.Concept,
        m.User,
        m.Value
      ]);
    });
  }

  return aoa;
}

function generateInventoryCSV(data: any): any[][] {
  const products = data.Products || [];
  if (products.length === 0) return [['No hay productos en el inventario.']];

  let totalValue = 0;
  let outOfStock = 0;
  let lowStock = 0;

  products.forEach((p: any) => {
    const value = p.Stock * p.Cost;
    if (value > 0) totalValue += value;
    if (p.Stock <= 0) outOfStock++;
    else if (p.Stock <= p.MinStock) lowStock++;
  });

  const aoa: any[][] = [];

  // Summary
  aoa.push(['Resumen de Inventario']);
  aoa.push(['Total Productos', products.length]);
  aoa.push(['Valor Total del Inventario (Costo)', totalValue]);
  aoa.push(['Agotados', outOfStock]);
  aoa.push(['Stock Bajo', lowStock]);
  aoa.push([]);

  // Table
  aoa.push(['Código', 'Producto', 'Categoría', 'Stock', 'Costo Unit.', 'Valor Total']);
  
  products.forEach((p: any) => {
    aoa.push([
      p.Code || 'N/A',
      p.Name,
      p.Category || '-',
      p.Stock,
      p.Cost,
      p.Stock > 0 ? p.Stock * p.Cost : 0
    ]);
  });

  return aoa;
}
