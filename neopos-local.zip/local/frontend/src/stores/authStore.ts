import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Role, User } from '../types/domain';

interface AuthState {
  accessToken?: string;
  refreshToken?: string;
  user?: User;
  role?: Role;
  remember: boolean;
  setSession: (accessToken: string, refreshToken: string, remember: boolean, role?: string) => void;
  setUser: (user: User) => void;
  clear: () => void;
}

function parseBranchIdFromToken(token: string): string | undefined {
  try {
    const payload = token.split('.')[1];
    const decoded = atob(payload);
    const claims = JSON.parse(decoded);
    return claims.branch_id;
  } catch {
    return undefined;
  }
}

function isTokenValid(token: string): boolean {
  const branchId = parseBranchIdFromToken(token);
  return !!branchId;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      remember: true,
      setSession: (accessToken, refreshToken, remember, role) => {
        if (!isTokenValid(accessToken)) {
          set({ accessToken: undefined, refreshToken: undefined, user: undefined, role: undefined });
          return;
        }
        const branchId = parseBranchIdFromToken(accessToken) || 'branch-1';
        set({
          accessToken,
          refreshToken,
          remember,
          role: (role as Role) || 'cashier',
          user: {
            id: 'local-user',
            name: role === 'admin' ? 'Administrador' : 'Cajero',
            email: role === 'admin' ? 'admin@pos.local' : 'cajero@pos.local',
            role_name: (role as Role) || 'cashier',
            branch_id: branchId
          }
        });
      },
      setUser: (user) => set({ user, role: user.role_name }),
      clear: () => set({ accessToken: undefined, refreshToken: undefined, user: undefined, role: undefined })
    }),
    { name: 'neopos:auth' }
  )
);
