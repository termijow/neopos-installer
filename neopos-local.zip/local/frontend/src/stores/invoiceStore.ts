import { create } from 'zustand';
import type { InvoiceDraft } from '../types/domain';

interface InvoiceState {
  draft?: InvoiceDraft;
  setDraft: (draft?: InvoiceDraft) => void;
}

export const useInvoiceStore = create<InvoiceState>((set) => ({
  setDraft: (draft) => set({ draft })
}));
