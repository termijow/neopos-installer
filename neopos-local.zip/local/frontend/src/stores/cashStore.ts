import { create } from 'zustand';
import type { CashSummary } from '../types/domain';

interface CashState {
  summary: CashSummary;
  setSummary: (summary: CashSummary) => void;
}

export const useCashStore = create<CashState>((set) => ({
  summary: {
    opening_amount: 250000,
    cash_sales: 1280000,
    card_sales: 840000,
    transfers: 310000,
    tips: 95000,
    total: 2525000
  },
  setSummary: (summary) => set({ summary })
}));
