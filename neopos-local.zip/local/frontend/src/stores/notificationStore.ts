import { create } from 'zustand';

interface NotificationState {
  open: boolean;
  message: string;
  severity: 'success' | 'info' | 'warning' | 'error';
  showNotification: (message: string, severity?: 'success' | 'info' | 'warning' | 'error') => void;
  hideNotification: () => void;
}

export const useNotificationStore = create<NotificationState>((set) => ({
  open: false,
  message: '',
  severity: 'info',
  showNotification: (message, severity = 'info') => set({ open: true, message, severity }),
  hideNotification: () => set({ open: false })
}));
