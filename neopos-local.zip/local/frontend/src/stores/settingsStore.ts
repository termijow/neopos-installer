import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

type PaymentMethod = 'CASH' | 'CREDIT_CARD' | 'DEBIT_CARD' | 'TRANSFER' | 'QR';

export interface CompanyConfig {
  name: string;
  nit: string;
  address: string;
  email: string;
  phone: string;
  logoUrl: string;
}

export interface FeConfig {
  provider: string;
  prefix: string;
  resolution: string;
  rangeStart: string;
  rangeEnd: string;
}

export interface PrinterConfig {
  cash: string;
  kitchen: string;
  bar: string;
}

interface SettingsState {
  branchId: string;
  isSetupComplete: boolean;
  companyConfig: CompanyConfig;
  feConfig: FeConfig;
  printerConfig: PrinterConfig;
  autoFocusSearch: boolean;
  showProductImages: boolean;
  showNegativeInventoryWarning: boolean;
  defaultPaymentMethod: PaymentMethod;
  defaultTipPercent: number;
  setBranchId: (branchId: string) => void;
  setSetupComplete: (isSetupComplete: boolean) => void;
  setCompanyConfig: (config: Partial<CompanyConfig>) => void;
  setFeConfig: (config: Partial<FeConfig>) => void;
  setPrinterConfig: (config: Partial<PrinterConfig>) => void;
  setAutoFocusSearch: (autoFocusSearch: boolean) => void;
  setShowProductImages: (showProductImages: boolean) => void;
  setShowNegativeInventoryWarning: (show: boolean) => void;
  setDefaultPaymentMethod: (method: PaymentMethod) => void;
  setDefaultTipPercent: (percent: number) => void;
}

const safeStorage = {
  getItem: (name: string) => {
    try {
      return typeof localStorage !== 'undefined' ? localStorage.getItem(name) : null;
    } catch {
      return null;
    }
  },
  setItem: (name: string, value: string) => {
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(name, value);
      }
    } catch {
      // Ignore
    }
  },
  removeItem: (name: string) => {
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.removeItem(name);
      }
    } catch {
      // Ignore
    }
  }
};

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      branchId: '00000000-0000-0000-0000-000000000000',
      isSetupComplete: false,
      companyConfig: {
        name: 'NeoPOS Restaurante',
        nit: '900123456-7',
        address: 'Bogotá, Colombia',
        email: 'admin@pos.local',
        phone: '6015550101',
        logoUrl: ''
      },
      feConfig: {
        provider: 'siigo',
        prefix: 'FE',
        resolution: '18764000000000',
        rangeStart: '1',
        rangeEnd: '5000'
      },
      printerConfig: {
        cash: 'EPSON-TM-T20',
        kitchen: 'KITCHEN-80MM',
        bar: 'BAR-58MM'
      },
      autoFocusSearch: true,
      showProductImages: false,
      showNegativeInventoryWarning: true,
      defaultPaymentMethod: 'CASH',
      defaultTipPercent: 10,
      setBranchId: (branchId) => set({ branchId }),
      setSetupComplete: (isSetupComplete) => set({ isSetupComplete }),
      setCompanyConfig: (config) => set((state) => ({ companyConfig: { ...state.companyConfig, ...config } })),
      setFeConfig: (config) => set((state) => ({ feConfig: { ...state.feConfig, ...config } })),
      setPrinterConfig: (config) => set((state) => ({ printerConfig: { ...state.printerConfig, ...config } })),
      setAutoFocusSearch: (autoFocusSearch) => set({ autoFocusSearch }),
      setShowProductImages: (showProductImages) => set({ showProductImages }),
      setShowNegativeInventoryWarning: (showNegativeInventoryWarning) => set({ showNegativeInventoryWarning }),
      setDefaultPaymentMethod: (defaultPaymentMethod) => set({ defaultPaymentMethod }),
      setDefaultTipPercent: (defaultTipPercent) => set({ defaultTipPercent })
    }),
    { 
      name: 'neopos:settings',
      storage: createJSONStorage(() => safeStorage)
    }
  )
);
