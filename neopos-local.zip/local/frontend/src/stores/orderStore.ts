import { create } from 'zustand';
import type { OrderItem, Product } from '../types/domain';

interface OrderState {
  items: OrderItem[];
  notes: string;
  addProduct: (product: Product) => void;
  removeItem: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  updatePrice: (productId: string, price: number) => void;
  setNotes: (notes: string) => void;
  clear: () => void;
}

export const useOrderStore = create<OrderState>((set) => ({
  items: [],
  notes: '',
  addProduct: (product) =>
    set((state) => {
      const existing = state.items.find((item) => item.product_id === product.id);
      if (existing) {
        return {
          items: state.items.map((item) =>
            item.product_id === product.id
              ? { ...item, quantity: item.quantity + 1, total: (item.quantity + 1) * item.unit_price }
              : item
          )
        };
      }
      return {
        items: [
          ...state.items,
          {
            product_id: product.id,
            name: product.name,
            quantity: 1,
            unit_price: product.price,
            total: product.price
          }
        ]
      };
    }),
  removeItem: (productId) => set((state) => ({ items: state.items.filter((item) => item.product_id !== productId) })),
  updateQuantity: (productId, quantity) =>
    set((state) => ({
      items: state.items.map((item) =>
        item.product_id === productId ? { ...item, quantity, total: quantity * item.unit_price } : item
      )
    })),
  updatePrice: (productId, price) =>
    set((state) => ({
      items: state.items.map((item) =>
        item.product_id === productId ? { ...item, unit_price: price, total: item.quantity * price } : item
      )
    })),
  setNotes: (notes) => set({ notes }),
  clear: () => set({ items: [], notes: '' })
}));
