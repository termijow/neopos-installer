import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { RestaurantTable } from '../types/domain';

interface TableState {
  selectedTable?: RestaurantTable;
  setSelectedTable: (table?: RestaurantTable) => void;
}

const safeStorage = {
  getItem: (name: string) => {
    try {
      return typeof localStorage !== 'undefined' ? localStorage.getItem(name) : null;
    } catch {
      return null;
    }
  },
  setItem: (name: string, value: string) => {
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(name, value);
      }
    } catch {
      // Ignore
    }
  },
  removeItem: (name: string) => {
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.removeItem(name);
      }
    } catch {
      // Ignore
    }
  }
};

export const useTableStore = create<TableState>()(
  persist(
    (set) => ({
      selectedTable: undefined,
      setSelectedTable: (selectedTable) => {
        console.log("ZUSTAND: setSelectedTable called with:", selectedTable ? `Mesa ${selectedTable.number} (status: ${selectedTable.status})` : 'undefined');
        set({ selectedTable });
      }
    }),
    {
      name: 'neopos:table',
      storage: createJSONStorage(() => safeStorage)
    }
  )
);
