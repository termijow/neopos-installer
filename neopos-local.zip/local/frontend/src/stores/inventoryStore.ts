import { create } from 'zustand';

interface InventoryState {
  lastSync?: string;
  setLastSync: (lastSync: string) => void;
}

export const useInventoryStore = create<InventoryState>((set) => ({
  setLastSync: (lastSync) => set({ lastSync })
}));
