export type Role = 'admin' | 'manager' | 'cashier' | 'waiter' | 'kitchen';

export type TableStatus = 'FREE' | 'OCCUPIED' | 'RESERVED' | 'CLEANING';
export type KitchenStatus = 'PENDING' | 'COOKING' | 'READY' | 'SERVED';
export type PaymentMethod = 'CASH' | 'CREDIT_CARD' | 'DEBIT_CARD' | 'TRANSFER' | 'QR';

export interface User {
  id: string;
  name: string;
  email: string;
  role_name: Role;
  branch_id?: string;
}

export interface AuthTokens {
  access_token: string;
  refresh_token: string;
  token_type: string;
  expires_in: number;
}

export interface ApiEnvelope<T> {
  data: T;
  message?: string;
  error?: string;
}

export interface RestaurantTable {
  id: string;
  number: number;
  capacity: number;
  status: TableStatus;
  branch_id?: string;
}

export interface Product {
  id: string;
  name: string;
  code?: string;
  price: number;
  tax_id?: string;
  category_id?: string;
  category?: string;
  tax_type?: string;
  tax?: number;
  image?: string;
  active: boolean;
}

export interface Category {
  id: string;
  name: string;
  active: boolean;
  is_hidden?: boolean;
}

export interface OrderItem {
  id?: string;
  product_id: string;
  name: string;
  quantity: number;
  unit_price: number;
  total: number;
  notes?: string;
}

export interface Order {
  id: string;
  table_id: string;
  customer_name?: string;
  status: 'PENDING' | 'IN_PREPARATION' | 'READY' | 'DELIVERED' | 'BILLED' | 'CANCELED';
  total: number;
  items: OrderItem[];
}

export interface KitchenOrder {
  id: string;
  order_id: string;
  branch_id?: string;
  status: KitchenStatus;
  notes?: string;
  created_at?: string;
  updated_at?: string;
}

export interface InventoryMovement {
  id: string;
  product_id: string;
  product?: string;
  quantity: number;
  type: 'IN' | 'OUT' | 'ADJUSTMENT' | 'SALE';
  reason?: string;
  created_at?: string;
}

export interface Client {
  id: string;
  document_type: 'NIT' | 'CC' | 'CE' | 'PASSPORT';
  document: string;
  name: string;
  email: string;
  phone: string;
}

export interface CashSummary {
  opening_amount: number;
  cash_sales: number;
  card_sales: number;
  transfers: number;
  tips: number;
  total: number;
}

export interface InvoiceDraft {
  client: Client;
  subtotal: number;
  tax: number;
  total: number;
  items: OrderItem[];
}

export interface RecipeItem {
  id?: string;
  inventory_item_id: string;
  quantity: number;
  unit: string;
}

export interface Recipe {
  id: string;
  product_id: string;
  description: string;
  yield: number;
  items: RecipeItem[];
}

export interface ImportRow {
  id?: string;
  index?: number;
  category: string;
  subcategory?: string;
  name: string;
  product_name: string;
  price: number;
  tax_type?: string;
  available?: boolean;
  barcode?: string;
  sku?: string;
  order_index?: number;
  image?: string;
  status: 'new' | 'existing' | 'error' | 'Nuevo' | 'Existente' | 'Error';
  action: 'import' | 'update' | 'skip' | 'duplicate';
  errors?: string[];
  product_id?: string;
  category_id?: string;
  included?: boolean;
}
