import { Grid, Paper, Stack, Typography, Alert, AlertTitle, Box, Chip } from '@mui/material';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import TableRestaurantIcon from '@mui/icons-material/TableRestaurant';
import PendingActionsIcon from '@mui/icons-material/PendingActions';
import ReceiptIcon from '@mui/icons-material/Receipt';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import { Area, AreaChart, Bar, BarChart, CartesianGrid, ComposedChart, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { PageHeader } from '../../components/PageHeader';
import { StatCard } from '../../components/StatCard';
import { cop } from '../../utils/format';
import { salesDaily, salesMonthly, topProducts, peakHours, profitability } from '../../utils/mockData';
import { useAuthStore } from '../../stores/authStore';
import { useQuery } from '@tanstack/react-query';
import { posService } from '../../services/posService';
import { useNavigate } from 'react-router-dom';

export function DashboardPage() {
  const { role } = useAuthStore();
  const isCashier = role === 'cashier';
  const navigate = useNavigate();
  
  const { data: reportData } = useQuery({ 
    queryKey: ['dashboard'], 
    queryFn: posService.dashboardReports, 
    retry: false,
    staleTime: 0,
    refetchOnMount: true,
    refetchInterval: 15000, // refresh every 15 seconds automatically
  });

  // Live tables query — auto-refreshes every 10s and whenever tables change
  const { data: tablesData } = useQuery({
    queryKey: ['tables'],
    queryFn: posService.tables,
    staleTime: 0,
    refetchInterval: 10000,
    refetchOnWindowFocus: true,
  });
  const d_salesDaily = reportData
    ? (reportData.chart_data || []).map((item: any) => ({ name: item.label, ventas: item.value }))
    : salesDaily;
  
  const d_salesMonthly = reportData ? (reportData.salesMonthly || []) : salesMonthly;
  const d_topProducts = reportData ? (reportData.topProducts || []) : topProducts;
  const d_peakHours = reportData ? (reportData.peakHours || []) : peakHours;
  const d_profitability = reportData ? (reportData.profitability || []) : profitability;

  const totalVentasDia = reportData?.sales_today !== undefined ? reportData.sales_today : 0;
  const facturasDia = reportData?.recent_invoices_count !== undefined ? reportData.recent_invoices_count : 0;
  const pedidosPendientes = reportData?.pending_orders !== undefined ? reportData.pending_orders : 0;

  // Derive tables from the live tables query (always up to date)
  const allTables: any[] = Array.isArray(tablesData) ? tablesData : ((tablesData as any)?.data || []);
  const liveTotalTables = allTables.length;
  const liveOccupied = allTables.filter((t: any) => t.status === 'OCCUPIED').length;
  const mesasOcupadas = liveTotalTables > 0
    ? `${liveOccupied} / ${liveTotalTables}`
    : (reportData?.occupied_tables !== undefined && reportData?.total_tables !== undefined)
      ? `${reportData.occupied_tables} / ${reportData.total_tables}`
      : '0 / 0';

  // --- LOW STOCK ALERTS ---
  const { data: stockRaw } = useQuery({ 
    queryKey: ['inventory-stock'], 
    queryFn: posService.inventoryStock,
    refetchInterval: 30000, // check every 30s
    staleTime: 0,
  });
  const { data: prodRaw } = useQuery({ 
    queryKey: ['products'], 
    queryFn: () => posService.products(1, 1000),
    staleTime: 60000,
  });
  const stockData: Record<string, number> = (stockRaw as any)?.data || stockRaw || {};
  const allProducts: any[] = (prodRaw as any)?.data || (Array.isArray(prodRaw) ? prodRaw : []);

  const LOW_STOCK_THRESHOLD = 5;
  const CRITICAL_STOCK_THRESHOLD = 0;

  const lowStockItems = allProducts
    .filter((p: any) => {
      const qty = stockData[p.id] ?? null;
      return qty !== null && qty <= LOW_STOCK_THRESHOLD;
    })
    .map((p: any) => ({ name: p.name, stock: stockData[p.id] ?? 0, category: p.category?.name }))
    .sort((a, b) => a.stock - b.stock);

  const criticalItems = lowStockItems.filter(i => i.stock <= CRITICAL_STOCK_THRESHOLD);
  const warningItems = lowStockItems.filter(i => i.stock > CRITICAL_STOCK_THRESHOLD && i.stock <= LOW_STOCK_THRESHOLD);


  if (isCashier) {
    return (
      <Stack spacing={3}>
        <PageHeader title="Dashboard" subtitle="Resumen operativo del turno." />
        <Grid container spacing={2}>
          <Grid item xs={12} sm={4} lg={4}><StatCard label="Mesas ocupadas" value={mesasOcupadas} helper="Capacidad total" icon={<TableRestaurantIcon />} /></Grid>
          <Grid item xs={12} sm={4} lg={4}><StatCard label="Pedidos pendientes" value={pedidosPendientes} helper="Cocina activa" icon={<PendingActionsIcon />} /></Grid>
          <Grid item xs={12} sm={4} lg={4}><StatCard label="Facturas emitidas" value={facturasDia} helper="Turno actual" icon={<ReceiptIcon />} /></Grid>
        </Grid>
        
        <Grid container spacing={2}>
          {/* Platos más vendidos */}
          <Grid item xs={12} lg={6}>
            <Paper sx={{ p: 3, height: 360 }}>
              <Typography variant="h6" sx={{ mb: 2 }}>Platos Más Vendidos</Typography>
              <ResponsiveContainer width="100%" height="85%">
                <BarChart data={d_topProducts} layout="vertical" margin={{ left: 30 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis dataKey="name" type="category" width={100} tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Bar dataKey="ventas" fill="#8b5cf6" radius={[0, 6, 6, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Paper>
          </Grid>

          {/* Horas Pico */}
          <Grid item xs={12} lg={6}>
            <Paper sx={{ p: 3, height: 360 }}>
              <Typography variant="h6" sx={{ mb: 2 }}>Horas Pico de Venta</Typography>
              <ResponsiveContainer width="100%" height="85%">
                <AreaChart data={d_peakHours}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip />
                  <Area type="monotone" dataKey="pedidos" stroke="#f59e0b" fill="#fde68a" />
                </AreaChart>
              </ResponsiveContainer>
            </Paper>
          </Grid>
        </Grid>
      </Stack>
    );
  }

  return (
    <Stack spacing={3}>
      <PageHeader title="Dashboard" subtitle="Resumen operativo de ventas, mesas, pedidos, caja y facturacion." />
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6} lg={3}><StatCard label="Ventas del dia" value={typeof totalVentasDia === 'number' ? cop(totalVentasDia) : totalVentasDia} helper="+12% vs ayer" icon={<AttachMoneyIcon />} /></Grid>
        <Grid item xs={12} sm={6} lg={3}><StatCard label="Mesas ocupadas" value={mesasOcupadas} helper="Capacidad total" icon={<TableRestaurantIcon />} /></Grid>
        <Grid item xs={12} sm={6} lg={3}><StatCard label="Pedidos pendientes" value={pedidosPendientes} helper="Cocina activa" icon={<PendingActionsIcon />} /></Grid>
        <Grid item xs={12} sm={6} lg={3}><StatCard label="Facturas emitidas" value={facturasDia} helper="Turno actual" icon={<ReceiptIcon />} /></Grid>
      </Grid>

      
      <Grid container spacing={2}>
        {/* Ventas Diarias */}
        <Grid item xs={12} lg={7}>
          <Paper sx={{ p: 3, height: 360 }}>
            <Typography variant="h6" sx={{ mb: 2 }}>Ventas diarias</Typography>
            <ResponsiveContainer width="100%" height="85%">
              <BarChart data={d_salesDaily}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip formatter={(value) => cop(Number(value))} />
                <Bar dataKey="ventas" fill="#0891b2" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>

        {/* Ventas Mensuales */}
        <Grid item xs={12} lg={5}>
          <Paper sx={{ p: 3, height: 360 }}>
            <Typography variant="h6" sx={{ mb: 2 }}>Ventas mensuales</Typography>
            <ResponsiveContainer width="100%" height="85%">
              <LineChart data={d_salesMonthly}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip formatter={(value) => cop(Number(value))} />
                <Line type="monotone" dataKey="ventas" stroke="#16a34a" strokeWidth={3} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>

        {/* Utilidades vs Costos */}
        <Grid item xs={12} lg={6}>
          <Paper sx={{ p: 3, height: 360 }}>
            <Typography variant="h6" sx={{ mb: 2 }}>Ingresos, Costos y Utilidades</Typography>
            <ResponsiveContainer width="100%" height="85%">
              <ComposedChart data={d_profitability}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip formatter={(value) => cop(Number(value))} />
                <Legend />
                <Bar dataKey="ingresos" stackId="a" fill="#3b82f6" name="Ingresos Totales" />
                <Bar dataKey="costos" stackId="b" fill="#ef4444" name="Costos" />
                <Line type="monotone" dataKey="utilidad" stroke="#10b981" strokeWidth={3} name="Utilidad Neta" />
              </ComposedChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>

        {/* Platos más vendidos */}
        <Grid item xs={12} lg={3}>
          <Paper sx={{ p: 3, height: 360 }}>
            <Typography variant="h6" sx={{ mb: 2 }}>Platos Más Vendidos</Typography>
            <ResponsiveContainer width="100%" height="85%">
              <BarChart data={d_topProducts} layout="vertical" margin={{ left: 30 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" width={100} tick={{ fontSize: 12 }} />
                <Tooltip />
                <Bar dataKey="ventas" fill="#8b5cf6" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>

        {/* Horas Pico */}
        <Grid item xs={12} lg={3}>
          <Paper sx={{ p: 3, height: 360 }}>
            <Typography variant="h6" sx={{ mb: 2 }}>Horas Pico de Venta</Typography>
            <ResponsiveContainer width="100%" height="85%">
              <AreaChart data={d_peakHours}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip />
                <Area type="monotone" dataKey="pedidos" stroke="#f59e0b" fill="#fde68a" />
              </AreaChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>
      </Grid>
    </Stack>
  );
}
