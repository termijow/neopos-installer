import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, Button, Paper, Stack, TextField, Typography, Avatar, Divider, Chip, CircularProgress, Alert } from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import SmartToyIcon from '@mui/icons-material/SmartToy';
import PersonIcon from '@mui/icons-material/Person';
import { PageHeader } from '../../components/PageHeader';
import { posService } from '../../services/posService';
import { useMutation } from '@tanstack/react-query';

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  actions?: { label: string; type: string; payload: string }[];
  timestamp: Date;
}

export function AiAssistantPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text: '¡Hola! Soy tu Asistente IA de NeoPOS. ¿En qué puedo ayudarte hoy? Puedes preguntarme cosas como "cómo van las ventas", "alertas de inventario" o "estado de facturación".',
      actions: [],
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  const chatMutation = useMutation({
    mutationFn: posService.aiChat,
    onSuccess: (data) => {
      setMessages((prev) => [
        ...prev,
        {
          id: `reply-${Date.now()}`,
          sender: 'assistant',
          text: data.text || data.response || 'No recibí respuesta.',
          actions: data.actions || [],
          timestamp: new Date(),
        },
      ]);
    },
    onError: (err: any) => {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          sender: 'assistant',
          text: `Error: ${err.message || 'No se pudo comunicar con el asistente de IA.'}`,
          timestamp: new Date(),
        },
      ]);
    },
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, chatMutation.isPending]);

  const handleSend = (textToSend = input) => {
    if (!textToSend.trim()) return;

    const userMessageId = `user-${Date.now()}`;
    setMessages((prev) => [
      ...prev,
      {
        id: userMessageId,
        sender: 'user',
        text: textToSend,
        timestamp: new Date(),
      },
    ]);
    setInput('');

    chatMutation.mutate(textToSend);
  };

  const handleActionClick = (action: { label: string; type: string; payload: string }) => {
    if (action.type === 'NAVIGATE') {
      navigate(action.payload);
    } else if (action.type === 'TRIGGER_MODAL') {
      // Temporary fallback until specific modals are wired
      alert(`Desencadenando modal: ${action.payload}`);
    }
  };

  const suggestions = [
    { label: 'Reporte de Ventas', query: '¿Cómo van las ventas hoy?' },
    { label: 'Alertas de Inventario', query: '¿Qué productos están bajos en stock?' },
    { label: 'Estado de Facturación', query: '¿Cuál es el estado de la facturación electrónica?' },
  ];

  return (
    <Stack spacing={3} sx={{ height: 'calc(100vh - 120px)' }}>
      <PageHeader
        title="Asistente de IA"
        subtitle="Analiza ventas, monitorea inventario y revisa facturas con soporte de IA local."
      />

      <Paper sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', p: 2 }}>
        {/* Messages list */}
        <Box sx={{ flexGrow: 1, overflowY: 'auto', mb: 2, pr: 1 }}>
          <Stack spacing={2}>
            {messages.map((msg) => {
              const isUser = msg.sender === 'user';
              return (
                <Stack
                  key={msg.id}
                  direction={isUser ? 'row-reverse' : 'row'}
                  spacing={1.5}
                  alignItems="flex-start"
                  sx={{ alignSelf: isUser ? 'flex-end' : 'flex-start', maxWidth: '75%' }}
                >
                  <Avatar sx={{ bgcolor: isUser ? 'primary.main' : 'secondary.main' }}>
                    {isUser ? <PersonIcon /> : <SmartToyIcon />}
                  </Avatar>
                  <Paper
                    sx={{
                      p: 2,
                      bgcolor: isUser ? 'primary.main' : '#f1f5f9',
                      color: isUser ? 'white' : 'text.primary',
                      borderRadius: isUser ? '16px 4px 16px 16px' : '4px 16px 16px 16px',
                      boxShadow: 1,
                    }}
                  >
                    <Typography variant="body1" sx={{ whiteSpace: 'pre-line' }}>
                      {msg.text}
                    </Typography>

                    {msg.actions && msg.actions.length > 0 && (
                      <Stack direction="row" spacing={1} sx={{ mt: 2, flexWrap: 'wrap', gap: 1 }}>
                        {msg.actions.map((act, idx) => (
                          <Button
                            key={idx}
                            variant="contained"
                            color={isUser ? "secondary" : "primary"}
                            size="small"
                            onClick={() => handleActionClick(act)}
                            sx={{ borderRadius: 2, textTransform: 'none' }}
                          >
                            {act.label}
                          </Button>
                        ))}
                      </Stack>
                    )}

                    <Typography
                      variant="caption"
                      sx={{
                        display: 'block',
                        mt: 0.5,
                        textAlign: isUser ? 'right' : 'left',
                        color: isUser ? 'rgba(255,255,255,0.7)' : 'text.secondary',
                      }}
                    >
                      {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </Typography>
                  </Paper>
                </Stack>
              );
            })}
            {chatMutation.isPending && (
              <Stack direction="row" spacing={1.5} alignItems="center" sx={{ maxWidth: '75%' }}>
                <Avatar sx={{ bgcolor: 'secondary.main' }}>
                  <SmartToyIcon />
                </Avatar>
                <Paper sx={{ p: 2, bgcolor: '#f1f5f9', borderRadius: '4px 16px 16px 16px' }}>
                  <Stack direction="row" spacing={1} alignItems="center">
                    <CircularProgress size={16} color="secondary" />
                    <Typography variant="body2" color="text.secondary">
                      Analizando datos...
                    </Typography>
                  </Stack>
                </Paper>
              </Stack>
            )}
            <div ref={messagesEndRef} />
          </Stack>
        </Box>

        {chatMutation.isError && (
          <Alert severity="warning" sx={{ mb: 2 }}>
            La consulta falló. Si tu suscripción o licencia local ha expirado, debes renovarla para poder usar el asistente inteligente de IA.
          </Alert>
        )}

        <Divider />

        {/* Input section */}
        <Box sx={{ pt: 2 }}>
          {/* Quick Suggestions */}
          <Stack direction="row" spacing={1} sx={{ mb: 2, overflowX: 'auto', py: 0.5 }}>
            {suggestions.map((sug) => (
              <Chip
                key={sug.label}
                label={sug.label}
                onClick={() => handleSend(sug.query)}
                clickable
                color="secondary"
                variant="outlined"
                disabled={chatMutation.isPending}
              />
            ))}
          </Stack>

          <Stack direction="row" spacing={1}>
            <TextField
              fullWidth
              placeholder="Pregúntame sobre ventas, inventario o facturación..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSend();
              }}
              disabled={chatMutation.isPending}
            />
            <Button
              variant="contained"
              color="primary"
              onClick={() => handleSend()}
              disabled={chatMutation.isPending || !input.trim()}
              sx={{ px: 3 }}
            >
              <SendIcon />
            </Button>
          </Stack>
        </Box>
      </Paper>
    </Stack>
  );
}
