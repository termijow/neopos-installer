import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { SettingsPage } from './SettingsPage';
import { useNotificationStore } from '../../stores/notificationStore';

describe('SettingsPage', () => {
  beforeEach(() => {
    useNotificationStore.setState({ open: false, message: '', severity: 'info' });
  });

  it('triggers notification on Guardar configuracion button click', () => {
    render(<SettingsPage />);
    const btn = screen.getByRole('button', { name: /Guardar configuraci[oó]n/i });
    fireEvent.click(btn);
    const store = useNotificationStore.getState();
    expect(store.open).toBe(true);
    expect(store.message).toContain("Configuración guardada");
  });
});
