import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, Grid, MenuItem, Paper, Stack, TextField, Typography, Switch, FormControlLabel, Box, CircularProgress, Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions, LinearProgress } from '@mui/material';
import SaveIcon from '@mui/icons-material/Save';
import { PageHeader } from '../../components/PageHeader';
import { useNotificationStore } from '../../stores/notificationStore';
import { useSettingsStore } from '../../stores/settingsStore';
import { posService } from '../../services/posService';
import UpdateIcon from '@mui/icons-material/Update';
import CloudSyncIcon from '@mui/icons-material/CloudSync';

export function SettingsPage() {
  const navigate = useNavigate();
  const showNotification = useNotificationStore(state => state.showNotification);
  const { 
    companyConfig,
    feConfig,
    printerConfig,
    setCompanyConfig,
    setFeConfig,
    setPrinterConfig,
    autoFocusSearch, 
    setAutoFocusSearch,
    showProductImages,
    setShowProductImages,
    showNegativeInventoryWarning,
    setShowNegativeInventoryWarning,
    defaultPaymentMethod,
    setDefaultPaymentMethod,
    defaultTipPercent,
    setDefaultTipPercent
  } = useSettingsStore();

  const [company, setCompany] = useState(companyConfig);
  const [fe, setFe] = useState(feConfig);
  const [printers, setPrinters] = useState(printerConfig);

  const [autofocus, setAutofocus] = useState(autoFocusSearch);
  const [productImages, setProductImages] = useState(showProductImages);
  const [negativeWarning, setNegativeWarning] = useState(showNegativeInventoryWarning);
  const [payMethod, setPayMethod] = useState(defaultPaymentMethod);
  const [defaultTip, setDefaultTip] = useState(defaultTipPercent);
  const [aiMonthlyLimit, setAiMonthlyLimit] = useState(10);
  const [electronicInvoiceMonthlyLimit, setElectronicInvoiceMonthlyLimit] = useState(20);
  const [aiUsed, setAiUsed] = useState(0);
  const [electronicInvoiceUsed, setElectronicInvoiceUsed] = useState(0);
  const [loadingUsageLimits, setLoadingUsageLimits] = useState(true);

  const [checkingUpdate, setCheckingUpdate] = useState(false);
  const [updateAvailable, setUpdateAvailable] = useState<string | null>(null);
  const [updateDialogOpen, setUpdateDialogOpen] = useState(false);
  const [downloadingUpdate, setDownloadingUpdate] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [restarting, setRestarting] = useState(false);
  const [syncing, setSyncing] = useState(false);

  useEffect(() => {
    let mounted = true;
    posService.getUsageLimits()
      .then((limits) => {
        if (!mounted) return;
        setAiMonthlyLimit(limits.ai_monthly_limit);
        setElectronicInvoiceMonthlyLimit(limits.electronic_invoice_monthly_limit);
        setAiUsed(limits.ai_used);
        setElectronicInvoiceUsed(limits.electronic_invoice_used);
      })
      .catch(() => {
        // Cloud may be offline; keep safe defaults and allow local settings to load.
      })
      .finally(() => mounted && setLoadingUsageLimits(false));
    return () => { mounted = false; };
  }, []);

  const handleTriggerSync = async () => {
    setSyncing(true);
    try {
      await posService.triggerSync();
      showNotification("Sincronización iniciada manualmente", "success");
    } catch (err) {
      showNotification("Error al iniciar la sincronización", "error");
    } finally {
      setSyncing(false);
    }
  };

  const handleCheckUpdate = async () => {
    setCheckingUpdate(true);
    try {
      const res = await posService.checkForUpdates();
      if (res.hasUpdate) {
        setUpdateAvailable(res.version || 'v2.1.0');
        setUpdateDialogOpen(true);
      } else {
        showNotification("NeoPOS está actualizado", "info");
      }
    } catch (err) {
      showNotification("Error buscando actualizaciones", "error");
    } finally {
      setCheckingUpdate(false);
    }
  };

  const handleInstallUpdate = () => {
    setDownloadingUpdate(true);
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      setDownloadProgress(progress);
      if (progress >= 100) {
        clearInterval(interval);
        setDownloadingUpdate(false);
        setRestarting(true);
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      }
    }, 300);
  };

  const handleSave = async () => {
    if (aiMonthlyLimit < 1 || electronicInvoiceMonthlyLimit < 1) {
      showNotification('Los límites deben ser mayores que cero', 'error');
      return;
    }
    setCompanyConfig(company);
    setFeConfig(fe);
    setPrinterConfig(printers);
    setAutoFocusSearch(autofocus);
    setShowProductImages(productImages);
    setShowNegativeInventoryWarning(negativeWarning);
    setDefaultPaymentMethod(payMethod);
    setDefaultTipPercent(defaultTip);
    showNotification("Configuración guardada localmente", "info");
    try {
      const limits = await posService.updateUsageLimits({
        ai_monthly_limit: aiMonthlyLimit,
        electronic_invoice_monthly_limit: electronicInvoiceMonthlyLimit
      });
      setAiUsed(limits.ai_used ?? aiUsed);
      setElectronicInvoiceUsed(limits.electronic_invoice_used ?? electronicInvoiceUsed);
      showNotification("Configuración guardada exitosamente", "success");
    } catch (err: any) {
      showNotification(`Configuración guardada localmente. ${err?.message || "No se pudieron actualizar los límites Cloud"}`, "warning");
    }
  };

  return (
    <Stack spacing={3}>
      <PageHeader 
        title="Configuración" 
        subtitle={
          <span>
            Empresa, facturación electrónica, impresoras y parámetros{' '}
            <span 
              onClick={() => navigate('/debug')} 
              style={{ cursor: 'pointer' }}
            >
              operativos.
            </span>
          </span>
        } 
      />
      <Grid container spacing={3}>
        <Grid item xs={12} lg={6}>
          <Paper sx={{ p: 3, borderRadius: 3, boxShadow: '0 4px 20px -2px rgba(0,0,0,0.05)' }}>
            <Stack spacing={2.5}>
              <Typography variant="h6" fontWeight="bold" color="primary.main">Empresa</Typography>
              <TextField 
                label="Nombre de la Empresa" 
                value={company.name} 
                onChange={(e) => setCompany({...company, name: e.target.value})} 
                fullWidth 
                disabled={companyConfig.name !== 'NeoPOS Restaurante' && companyConfig.name.trim() !== ''}
                helperText={companyConfig.name !== 'NeoPOS Restaurante' && companyConfig.name.trim() !== '' ? "El nombre de la empresa ya fue registrado y no puede modificarse." : "Atención: El nombre de la empresa solo se puede configurar una vez."}
              />
              <TextField label="NIT" value={company.nit} onChange={(e) => setCompany({...company, nit: e.target.value})} fullWidth />
              <TextField label="Dirección" value={company.address} onChange={(e) => setCompany({...company, address: e.target.value})} fullWidth />
              <TextField label="Correo Electrónico" value={company.email} onChange={(e) => setCompany({...company, email: e.target.value})} fullWidth />
              <TextField label="Teléfono" value={company.phone} onChange={(e) => setCompany({...company, phone: e.target.value})} fullWidth />
              <TextField label="Logo URL" value={company.logoUrl} onChange={(e) => setCompany({...company, logoUrl: e.target.value})} fullWidth placeholder="https://ejemplo.com/logo.png" />
            </Stack>
          </Paper>
        </Grid>
        
        <Grid item xs={12} lg={6}>
          <Stack spacing={3}>
            <Paper sx={{ p: 3, borderRadius: 3, boxShadow: '0 4px 20px -2px rgba(0,0,0,0.05)' }}>
              <Stack spacing={2.5}>
                <Typography variant="h6" fontWeight="bold" color="primary.main">Facturación Electrónica</Typography>
                <TextField label="Proveedor Tecnológico" select value={fe.provider} onChange={(e) => setFe({...fe, provider: e.target.value})} fullWidth>
                  <MenuItem value="siigo">Siigo</MenuItem>
                  <MenuItem value="alegra">Alegra</MenuItem>
                  <MenuItem value="carvajal">Carvajal</MenuItem>
                </TextField>
                <TextField label="Prefijo" value={fe.prefix} onChange={(e) => setFe({...fe, prefix: e.target.value})} fullWidth />
                <TextField label="Resolución DIAN" value={fe.resolution} onChange={(e) => setFe({...fe, resolution: e.target.value})} fullWidth />
                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <TextField label="Rango Inicial" value={fe.rangeStart} onChange={(e) => setFe({...fe, rangeStart: e.target.value})} fullWidth />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField label="Rango Final" value={fe.rangeEnd} onChange={(e) => setFe({...fe, rangeEnd: e.target.value})} fullWidth />
                  </Grid>
                </Grid>
              </Stack>
            </Paper>

            <Paper sx={{ p: 3, borderRadius: 3, boxShadow: '0 4px 20px -2px rgba(0,0,0,0.05)' }}>
              <Stack spacing={2.5}>
                <Typography variant="h6" fontWeight="bold" color="primary.main">Preferencias del Sistema</Typography>
                <FormControlLabel
                  control={
                    <Switch 
                      checked={autofocus} 
                      onChange={(e) => setAutofocus(e.target.checked)} 
                      color="secondary"
                    />
                  }
                  label={
                    <Box sx={{ ml: 1 }}>
                      <Typography variant="body1" fontWeight="500">
                        Enfoque automático de barra de búsqueda
                      </Typography>
                      <Typography variant="caption" color="text.secondary" display="block">
                        El cursor se activa automáticamente en la barra de búsqueda al iniciar un pedido o al abrir la búsqueda global (Ctrl + K).
                      </Typography>
                    </Box>
                  }
                />
                <FormControlLabel
                  control={
                    <Switch 
                      checked={productImages} 
                      onChange={(e) => setProductImages(e.target.checked)} 
                      color="secondary"
                    />
                  }
                  label={
                    <Box sx={{ ml: 1 }}>
                      <Typography variant="body1" fontWeight="500">
                        Habilitar imágenes de productos
                      </Typography>
                      <Typography variant="caption" color="text.secondary" display="block">
                        Habilita la carga y previsualización de imágenes para productos. Desactivado por defecto para mejorar el rendimiento.
                      </Typography>
                    </Box>
                  }
                />
                <FormControlLabel
                  control={
                    <Switch 
                      checked={negativeWarning} 
                      onChange={(e) => setNegativeWarning(e.target.checked)} 
                      color="secondary"
                    />
                  }
                  label={
                    <Box sx={{ ml: 1 }}>
                      <Typography variant="body1" fontWeight="500">
                        Advertencia de Inventario Negativo
                      </Typography>
                      <Typography variant="caption" color="text.secondary" display="block">
                        Muestra un aviso si estás vendiendo productos (o ingredientes de recetas) sin stock suficiente, pero permite continuar con la venta.
                      </Typography>
                    </Box>
                  }
                />
                <TextField
                  select
                  label="Medio de pago por defecto (Shift+Click)"
                  value={payMethod}
                  onChange={(e) => setPayMethod(e.target.value as any)}
                  fullWidth
                  helperText="Se usa al hacer Shift+Click en el botón Cobrar de la vista de mesas."
                >
                  <MenuItem value="CASH">Efectivo</MenuItem>
                  <MenuItem value="CREDIT_CARD">Tarjeta Crédito</MenuItem>
                  <MenuItem value="DEBIT_CARD">Tarjeta Débito</MenuItem>
                  <MenuItem value="TRANSFER">Transferencia</MenuItem>
                  <MenuItem value="QR">QR / Nequi</MenuItem>
                </TextField>
                <TextField
                  select
                  label="Propina por Defecto"
                  value={defaultTip}
                  onChange={(e) => setDefaultTip(Number(e.target.value))}
                  fullWidth
                  helperText="La propina predeterminada que se aplicará a nuevas órdenes."
                >
                  <MenuItem value={0}>Sin propina predeterminada</MenuItem>
                  <MenuItem value={5}>5%</MenuItem>
                  <MenuItem value={10}>10%</MenuItem>
                  <MenuItem value={12}>12%</MenuItem>
                  <MenuItem value={15}>15%</MenuItem>
                </TextField>
              </Stack>
            </Paper>
          </Stack>
        </Grid>

        <Grid item xs={12}>
          <Paper sx={{ p: 3, borderRadius: 3, boxShadow: '0 4px 20px -2px rgba(0,0,0,0.05)' }}>
            <Stack spacing={2.5}>
              <Typography variant="h6" fontWeight="bold" color="primary.main">Impresoras de Comandas</Typography>
              <Grid container spacing={3}>
                <Grid item xs={12} md={4}>
                  <TextField fullWidth label="Impresora Caja" value={printers.cash} onChange={(e) => setPrinters({...printers, cash: e.target.value})} />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField fullWidth label="Impresora Cocina" value={printers.kitchen} onChange={(e) => setPrinters({...printers, kitchen: e.target.value})} />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField fullWidth label="Impresora Barra" value={printers.bar} onChange={(e) => setPrinters({...printers, bar: e.target.value})} />
                </Grid>
              </Grid>
            </Stack>
          </Paper>
        </Grid>

        <Grid item xs={12}>
          <Paper sx={{ p: 3, borderRadius: 3, boxShadow: '0 4px 20px -2px rgba(0,0,0,0.05)' }}>
            <Stack spacing={2.5}>
              <Typography variant="h6" fontWeight="bold" color="primary.main">Límites de uso Cloud</Typography>
              <Typography variant="body2" color="text.secondary">
                Límites mensuales del negocio. Las facturas cuentan únicamente cuando Factus responde como validada/aceptada; los rechazos y reintentos no consumen cupo.
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    type="number"
                    label="Respuestas IA máximas al mes"
                    value={aiMonthlyLimit}
                    onChange={(e) => setAiMonthlyLimit(Math.max(1, Number(e.target.value)))}
                    inputProps={{ min: 1, max: 100000 }}
                    disabled={loadingUsageLimits}
                    helperText={`${aiUsed} usadas este mes`}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    type="number"
                    label="Facturas electrónicas máximas al mes"
                    value={electronicInvoiceMonthlyLimit}
                    onChange={(e) => setElectronicInvoiceMonthlyLimit(Math.max(1, Number(e.target.value)))}
                    inputProps={{ min: 1, max: 100000 }}
                    disabled={loadingUsageLimits}
                    helperText={`${electronicInvoiceUsed} validadas este mes`}
                  />
                </Grid>
              </Grid>
            </Stack>
          </Paper>
        </Grid>

        <Grid item xs={12}>
          <Paper sx={{ p: 3, borderRadius: 3, boxShadow: '0 4px 20px -2px rgba(0,0,0,0.05)' }}>
            <Stack spacing={2.5}>
              <Typography variant="h6" fontWeight="bold" color="primary.main">Actualizaciones del Sistema</Typography>
              <Typography variant="body2" color="text.secondary">
                Verifica si hay nuevas versiones de NeoPOS disponibles para descargar e instalar.
              </Typography>
              <Box>
                <Button 
                  variant="outlined" 
                  color="primary" 
                  startIcon={checkingUpdate ? <CircularProgress size={20} /> : <UpdateIcon />}
                  onClick={handleCheckUpdate}
                  disabled={checkingUpdate}
                >
                  {checkingUpdate ? 'Buscando actualizaciones...' : 'Buscar Actualizaciones'}
                </Button>
              </Box>
            </Stack>
          </Paper>
        </Grid>

        <Grid item xs={12}>
          <Paper sx={{ p: 3, borderRadius: 3, boxShadow: '0 4px 20px -2px rgba(0,0,0,0.05)' }}>
            <Stack spacing={2.5}>
              <Typography variant="h6" fontWeight="bold" color="primary.main">Sincronización con la Nube</Typography>
              <Typography variant="body2" color="text.secondary">
                NeoPOS se sincroniza automáticamente cada hora. Puedes forzar una sincronización manual si lo necesitas.
              </Typography>
              <Box>
                <Button 
                  variant="outlined" 
                  color="secondary" 
                  startIcon={syncing ? <CircularProgress size={20} color="secondary" /> : <CloudSyncIcon />}
                  onClick={handleTriggerSync}
                  disabled={syncing}
                >
                  {syncing ? 'Sincronizando...' : 'Sincronizar Ahora'}
                </Button>
              </Box>
            </Stack>
          </Paper>
        </Grid>

        <Grid item xs={12}>
          <Button 
            variant="contained" 
            size="large" 
            startIcon={<SaveIcon />} 
            onClick={handleSave} 
            color="primary"
            sx={{ 
              px: 4, 
              py: 1.5, 
              borderRadius: 2.5,
              fontWeight: 'bold',
              textTransform: 'none',
              boxShadow: '0 10px 15px -3px rgba(15, 23, 42, 0.3)',
              transition: 'transform 0.15s',
              '&:active': { transform: 'scale(0.97)' }
            }}
          >
            Guardar Configuración
          </Button>
        </Grid>
      </Grid>

      <Dialog open={updateDialogOpen} onClose={() => !downloadingUpdate && !restarting && setUpdateDialogOpen(false)}>
        <DialogTitle>Actualización Disponible</DialogTitle>
        <DialogContent>
          {restarting ? (
            <Box sx={{ textAlign: 'center', py: 3 }}>
              <CircularProgress sx={{ mb: 2 }} />
              <Typography>Reiniciando NeoPOS...</Typography>
            </Box>
          ) : downloadingUpdate ? (
            <Box sx={{ py: 2 }}>
              <Typography gutterBottom>Descargando actualización...</Typography>
              <LinearProgress variant="determinate" value={downloadProgress} sx={{ height: 10, borderRadius: 5 }} />
              <Typography variant="caption" sx={{ mt: 1, display: 'block', textAlign: 'right' }}>
                {downloadProgress}%
              </Typography>
            </Box>
          ) : (
            <DialogContentText>
              Hay una nueva versión disponible ({updateAvailable}). ¿Desea instalarla?
            </DialogContentText>
          )}
        </DialogContent>
        {!downloadingUpdate && !restarting && (
          <DialogActions>
            <Button onClick={() => setUpdateDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleInstallUpdate} variant="contained" color="primary">
              Instalar
            </Button>
          </DialogActions>
        )}
      </Dialog>
    </Stack>
  );
}
