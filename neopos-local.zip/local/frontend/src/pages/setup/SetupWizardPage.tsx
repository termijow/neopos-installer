import { useState } from 'react';
import { Box, Button, Paper, Stack, Step, StepLabel, Stepper, TextField, Typography, MenuItem, Grid } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useSettingsStore } from '../../stores/settingsStore';
import { useNotificationStore } from '../../stores/notificationStore';
import { useAuthStore } from '../../stores/authStore';
import { api } from '../../services/api';
import { useEffect } from 'react';

const steps = ['Licencia y Validación', 'Datos de Empresa', 'Facturación Electrónica', 'Impresoras'];

export function SetupWizardPage() {
  const navigate = useNavigate();
  const showNotification = useNotificationStore(state => state.showNotification);
  const { role } = useAuthStore();
  const { 
    companyConfig, feConfig, printerConfig, 
    setCompanyConfig, setFeConfig, setPrinterConfig, setSetupComplete 
  } = useSettingsStore();

  const [activeStep, setActiveStep] = useState(0);
  
  // Local state for the wizard
  const [licenseKey, setLicenseKey] = useState('');
  const [company, setCompany] = useState(companyConfig);
  const [fe, setFe] = useState(feConfig);
  const [printers, setPrinters] = useState(printerConfig);

  // Al montar, revisar si ya se configuró desde otro navegador
  useEffect(() => {
    api<any>('/settings')
      .then(settings => {
        if (!Array.isArray(settings)) return;
        const setupItem = settings.find((s: any) => s.key === 'is_setup_complete');
        if (setupItem && (setupItem.value === '"true"' || setupItem.value === 'true')) {
          setSetupComplete(true);
          navigate('/');
        }
      })
      .catch(err => console.error("Error comprobando estado de setup:", err));
  }, [setSetupComplete, navigate]);

  const handleNext = async () => {
    if (activeStep === 0) {
      if (licenseKey.trim().length < 10) {
        showNotification("Por favor ingrese una licencia válida", "error");
        return;
      }
      showNotification("Licencia validada correctamente", "success");
    }
    
    if (activeStep === steps.length - 1) {
      // Finish
      setCompanyConfig(company);
      setFeConfig(fe);
      setPrinterConfig(printers);
      setSetupComplete(true);
      
      // Guardar globalmente en la BD para que otros navegadores no pidan setup
      try {
        await api('/settings', {
          method: 'POST',
          body: JSON.stringify({ key: 'is_setup_complete', value: '"true"' })
        });
      } catch (err) {
        console.error("No se pudo guardar la config global", err);
      }

      showNotification("Configuración inicial completada", "success");
      navigate('/');
    } else {
      setActiveStep((prev) => prev + 1);
    }
  };

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
  };

  const renderStepContent = (step: number) => {
    switch (step) {
      case 0:
        return (
          <Stack spacing={3} sx={{ mt: 2 }}>
            <Typography variant="body1" color="text.secondary">
              Ingrese su clave de licencia de NeoPOS para validar su software.
            </Typography>
            <TextField 
              label="Clave de Licencia" 
              value={licenseKey}
              onChange={(e) => setLicenseKey(e.target.value)}
              fullWidth 
              placeholder="XXXX-XXXX-XXXX-XXXX"
            />
          </Stack>
        );
      case 1:
        return (
          <Stack spacing={2} sx={{ mt: 2 }}>
            <TextField label="Nombre de la Empresa" value={company.name} onChange={(e) => setCompany({...company, name: e.target.value})} fullWidth />
            <TextField label="NIT" value={company.nit} onChange={(e) => setCompany({...company, nit: e.target.value})} fullWidth />
            <TextField label="Dirección" value={company.address} onChange={(e) => setCompany({...company, address: e.target.value})} fullWidth />
            <TextField label="Correo Electrónico" value={company.email} onChange={(e) => setCompany({...company, email: e.target.value})} fullWidth />
            <TextField label="Teléfono" value={company.phone} onChange={(e) => setCompany({...company, phone: e.target.value})} fullWidth />
            <TextField label="Logo URL" value={company.logoUrl} onChange={(e) => setCompany({...company, logoUrl: e.target.value})} fullWidth placeholder="https://ejemplo.com/logo.png" />
          </Stack>
        );
      case 2:
        return (
          <Stack spacing={2} sx={{ mt: 2 }}>
            <TextField label="Proveedor Tecnológico" select value={fe.provider} onChange={(e) => setFe({...fe, provider: e.target.value})} fullWidth>
              <MenuItem value="siigo">Siigo</MenuItem>
              <MenuItem value="alegra">Alegra</MenuItem>
              <MenuItem value="carvajal">Carvajal</MenuItem>
            </TextField>
            <TextField label="Prefijo" value={fe.prefix} onChange={(e) => setFe({...fe, prefix: e.target.value})} fullWidth />
            <TextField label="Resolución DIAN" value={fe.resolution} onChange={(e) => setFe({...fe, resolution: e.target.value})} fullWidth />
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <TextField label="Rango Inicial" value={fe.rangeStart} onChange={(e) => setFe({...fe, rangeStart: e.target.value})} fullWidth />
              </Grid>
              <Grid item xs={6}>
                <TextField label="Rango Final" value={fe.rangeEnd} onChange={(e) => setFe({...fe, rangeEnd: e.target.value})} fullWidth />
              </Grid>
            </Grid>
          </Stack>
        );
      case 3:
        return (
          <Stack spacing={2} sx={{ mt: 2 }}>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              Configure los nombres o direcciones IP de sus impresoras en red o locales. 
            </Typography>
            <TextField fullWidth label="Impresora Caja" value={printers.cash} onChange={(e) => setPrinters({...printers, cash: e.target.value})} />
            <TextField fullWidth label="Impresora Cocina" value={printers.kitchen} onChange={(e) => setPrinters({...printers, kitchen: e.target.value})} />
            <TextField fullWidth label="Impresora Barra" value={printers.bar} onChange={(e) => setPrinters({...printers, bar: e.target.value})} />
          </Stack>
        );
      default:
        return null;
    }
  };

  return (
    <Box sx={{ minHeight: '100vh', display: 'grid', placeItems: 'center', bgcolor: '#0f172a', p: 2 }}>
      <Paper sx={{ width: '100%', maxWidth: 700, p: 4 }}>
        <Typography variant="h5" fontWeight="bold" gutterBottom>
          Configuración Inicial NeoPOS
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 4 }}>
          Bienvenido a NeoPOS. Por favor, complete la siguiente documentación para iniciar.
        </Typography>

        <Stepper activeStep={activeStep} alternativeLabel sx={{ mb: 4 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>

        <Box sx={{ minHeight: 300 }}>
          {renderStepContent(activeStep)}
        </Box>

        <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 4 }}>
          <Button 
            disabled={activeStep === 0} 
            onClick={handleBack}
            variant="outlined"
          >
            Atrás
          </Button>
          <Button 
            variant="contained" 
            color="primary"
            onClick={handleNext}
          >
            {activeStep === steps.length - 1 ? 'Finalizar' : 'Siguiente'}
          </Button>
        </Box>
      </Paper>
    </Box>
  );
}
