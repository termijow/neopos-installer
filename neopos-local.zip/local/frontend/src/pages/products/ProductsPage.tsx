import { zodResolver } from '@hookform/resolvers/zod';
import { Avatar, Button, Chip, Grid, IconButton, Paper, Stack, Table, TableBody, TableCell, TableHead, TableRow, TextField, Typography, MenuItem, Dialog, DialogTitle, DialogContent, DialogActions, Box } from '@mui/material';
import ImageIcon from '@mui/icons-material/Inventory2';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import DownloadIcon from '@mui/icons-material/Download';
import EditIcon from '@mui/icons-material/Edit';
import SearchIcon from '@mui/icons-material/Search';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState, useMemo } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { z } from 'zod';
import { PageHeader } from '../../components/PageHeader';
import { AppPagination } from '../../components/AppPagination';
import { posService } from '../../services/posService';
import { cop } from '../../utils/format';
import { mockCategories, mockProducts } from '../../utils/mockData';
import { useAuthStore } from '../../stores/authStore';
import { useSettingsStore } from '../../stores/settingsStore';
import type { Product } from '../../types/domain';
import { CategoryManager } from './CategoryManager';
import { ProductsImportWizard } from './ProductsImportWizard';

const schema = z.object({
  name: z.string().min(2, 'El nombre debe tener al menos 2 caracteres'),
  code: z.string().optional(),
  price: z.coerce.number().min(1, 'El precio debe ser mayor a 0'),
  tax_type: z.enum(['IVA', 'INC', 'EXENTO']).default('IVA'),
  tax: z.coerce.number().min(0).max(100).optional(),
  category_id: z.string().min(1, 'Debe seleccionar una categoría'),
  image: z.string().optional()
});

type ProductForm = z.infer<typeof schema>;

export function ProductsPage() {
  const queryClient = useQueryClient();
  const { role, accessToken } = useAuthStore();
  const { showProductImages } = useSettingsStore();
  const [search, setSearch] = useState('');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [deletingProduct, setDeletingProduct] = useState<Product | null>(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(50);
  const [isImportWizardOpen, setIsImportWizardOpen] = useState(false);

  const { data: responseData } = useQuery({
    queryKey: ['products'],
    queryFn: () => posService.products(1, 1000)
  });

  const productsList = (responseData && !Array.isArray(responseData) && 'data' in (responseData as any)) ? (responseData as any).data : (Array.isArray(responseData) ? responseData : mockProducts);


  const { data: categories = mockCategories } = useQuery({
    queryKey: ['categories'],
    queryFn: posService.categories
  });

  const create = useMutation({
    mutationFn: posService.createProduct,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['products'] })
  });

  const update = useMutation({
    mutationFn: ({ id, payload }: { id: string; payload: Partial<Product> }) =>
      posService.updateProduct(id, payload),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['products'] })
  });

  const remove = useMutation({
    mutationFn: posService.deleteProduct,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['products'] })
  });

  // Dedicated form hook for creating products
  const { register: registerCreate, handleSubmit: handleSubmitCreate, reset: resetCreate, setValue: setValueCreate, control: controlCreate, formState: { errors: errorsCreate }, watch: watchCreate } = useForm<ProductForm>({
    resolver: zodResolver(schema),
    defaultValues: { name: '', code: '', price: 0, tax_type: 'IVA', tax: 19, category_id: '', image: '' }
  });
  const taxTypeCreate = watchCreate('tax_type');

  // Dedicated form hook for editing products
  const { register: registerEdit, handleSubmit: handleSubmitEdit, reset: resetEdit, setValue: setValueEdit, control: controlEdit, formState: { errors: errorsEdit }, watch: watchEdit } = useForm<ProductForm>({
    resolver: zodResolver(schema),
    defaultValues: { name: '', code: '', price: 0, tax_type: 'IVA', tax: 19, category_id: '', image: '' }
  });
  const taxTypeEdit = watchEdit('tax_type');

  const onSubmitCreate = (values: ProductForm) => {
    const payload = {
      name: values.name,
      code: values.code || '',
      price: values.price,
      tax_type: values.tax_type,
      tax: values.tax_type === 'EXENTO' ? 0 : values.tax,
      category_id: values.category_id,
      image: values.image || '',
      active: true
    };

    create.mutate(payload, {
      onSuccess: () => {
        resetCreate({ name: '', code: '', price: 0, tax_type: 'IVA', tax: 19, category_id: '', image: '' });
      }
    });
  };

  const onSubmitEdit = (values: ProductForm) => {
    if (!editingProduct) return;
    const payload = {
      name: values.name,
      code: values.code || '',
      price: values.price,
      tax_type: values.tax_type,
      tax: values.tax_type === 'EXENTO' ? 0 : values.tax,
      category_id: values.category_id,
      image: values.image || '',
      active: editingProduct.active
    };

    update.mutate(
      { id: editingProduct.id, payload },
      {
        onSuccess: () => {
          setEditingProduct(null);
          resetEdit({ name: '', code: '', price: 0, tax_type: 'IVA', tax: 19, category_id: '', image: '' });
        }
      }
    );
  };

  const handleEdit = (product: Product) => {
    setEditingProduct(product);
    resetEdit({
      name: product.name,
      code: product.code || '',
      price: product.price,
      tax_type: (product as any).tax_type || 'IVA',
      tax: (product as any).tax ?? 19,
      category_id: product.category_id || '',
      image: product.image || ''
    });
  };

  const handleDeleteConfirm = () => {
    if (!deletingProduct) return;
    remove.mutate(deletingProduct.id, {
      onSuccess: () => {
        setDeletingProduct(null);
      }
    });
  };

  const filtered = useMemo(() => {
    return productsList.filter((product: Product) => {
      const matchSearch = product.name.toLowerCase().includes(search.toLowerCase()) || 
                          (product.code && product.code.toLowerCase().includes(search.toLowerCase()));
      return matchSearch;
    });
  }, [productsList, search]);

  const paginated = filtered.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  const canEditOrCreate = role === 'admin' || role === 'manager';

  return (
    <Stack spacing={3}>
      <Stack direction="row" justifyContent="space-between" alignItems="center">
        <PageHeader title="Productos" subtitle="CRUD de productos, impuestos, categorias, imagen y estado." />
        <Stack direction="row" spacing={2} alignItems="center">
          <CategoryManager />
          {canEditOrCreate && (
            <>
              <Button 
                variant="outlined" 
                color="primary"
                startIcon={<DownloadIcon />}
                onClick={() => posService.downloadExportCSV().catch(err => console.error(err))}
              >
                Exportar CSV
              </Button>
              <Button 
                variant="contained" 
                color="secondary"
                onClick={() => setIsImportWizardOpen(true)}
              >
                Importar CSV
              </Button>
            </>
          )}
        </Stack>
      </Stack>
      <Grid container spacing={2}>
        {canEditOrCreate && (
          <Grid item xs={12} lg={4}>
            <Paper component="form" sx={{ p: 2 }} onSubmit={handleSubmitCreate(onSubmitCreate)}>
              <Stack spacing={2}>
                <Typography variant="h6">
                  Crear producto
                </Typography>
                <TextField label="Nombre" {...registerCreate('name')} error={!!errorsCreate.name} helperText={errorsCreate.name?.message} />
                <TextField label="Codigo" {...registerCreate('code')} />
                <TextField
                  label="Precio"
                  type="number"
                  {...registerCreate('price')}
                  error={!!errorsCreate.price}
                  helperText={errorsCreate.price?.message}
                />
                <Stack direction="row" spacing={2}>
                  <Controller
                    name="tax_type"
                    control={controlCreate}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        select
                        label="Tipo de Impuesto"
                        sx={{ flex: 1 }}
                      >
                        <MenuItem value="IVA">IVA</MenuItem>
                        <MenuItem value="INC">Impoconsumo (INC)</MenuItem>
                        <MenuItem value="EXENTO">Exento</MenuItem>
                      </TextField>
                    )}
                  />
                  {taxTypeCreate !== 'EXENTO' && (
                    <TextField 
                      label="Porcentaje %" 
                      type="number" 
                      sx={{ flex: 1 }}
                      {...registerCreate('tax')} 
                    />
                  )}
                </Stack>
                
                <Controller
                  name="category_id"
                  control={controlCreate}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      select
                      label="Categoría"
                      error={!!errorsCreate.category_id}
                      helperText={errorsCreate.category_id?.message}
                      fullWidth
                    >
                      {categories.map((cat) => (
                        <MenuItem key={cat.id} value={cat.id}>
                          {cat.name}
                        </MenuItem>
                      ))}
                    </TextField>
                  )}
                />

                {showProductImages && (
                  <Stack direction="row" spacing={1} alignItems="center">
                    <TextField label="Imagen URL" {...registerCreate('image')} sx={{ flex: 1 }} />
                    <Button variant="outlined" component="label">
                      Subir
                      <input type="file" hidden accept="image/*" onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const formData = new FormData();
                          formData.append('image', file);
                          try {
                            const res = await fetch('http://localhost:8080/api/v1/products/upload', {
                              method: 'POST',
                              headers: { 'Authorization': 'Bearer ' + useAuthStore.getState().accessToken },
                              body: formData
                            });
                            const data = await res.json();
                            if (data.url) {
                               setValueCreate('image', data.url);
                            }
                          } catch (err) {
                            console.error(err);
                          }
                        }
                      }} />
                    </Button>
                  </Stack>
                )}

                <Button type="submit" variant="contained" startIcon={<AddIcon />}>
                  Crear
                </Button>
              </Stack>
            </Paper>
          </Grid>
        )}
        <Grid item xs={12} lg={canEditOrCreate ? 8 : 12}>
          <Paper sx={{ p: 2 }}>
            <Stack spacing={2}>
              <TextField label="Buscar producto" value={search} onChange={(event) => setSearch(event.target.value)} InputProps={{ startAdornment: <SearchIcon sx={{ mr: 1, color: 'text.secondary' }} /> }} />
              <Table>
                <TableHead>
                  <TableRow>
                    {showProductImages && <TableCell sx={{ width: 64 }}>Imagen</TableCell>}
                    <TableCell>Nombre</TableCell>
                    <TableCell>Codigo</TableCell>
                    <TableCell>Categoría</TableCell>
                    <TableCell>Precio</TableCell>
                    <TableCell>IVA</TableCell>
                    <TableCell>Estado</TableCell>
                    <TableCell align="right">Acciones</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {paginated.map((product: Product) => (
                    <TableRow key={product.id}>
                      {showProductImages && (
                        <TableCell sx={{ width: 64, py: 0.5 }}>
                          {product.image ? (
                            <Avatar
                              src={product.image}
                              alt={product.name}
                              variant="rounded"
                              sx={{ width: 44, height: 44, border: '1px solid #e2e8f0' }}
                            />
                          ) : (
                            <Avatar
                              variant="rounded"
                              sx={{ width: 44, height: 44, bgcolor: '#f1f5f9', color: '#94a3b8' }}
                            >
                              <ImageIcon fontSize="small" />
                            </Avatar>
                          )}
                        </TableCell>
                      )}
                      <TableCell>{product.name}</TableCell>
                      <TableCell>{product.code ?? '-'}</TableCell>
                      <TableCell>
                        {typeof product.category === 'object' && product.category
                          ? ((product.category as unknown) as { name: string }).name
                          : (product.category || '-')}
                      </TableCell>
                      <TableCell>{cop(product.price)}</TableCell>
                      <TableCell>
                        {product.tax_type === 'EXENTO' ? 'Exento' : `${product.tax_type || 'IVA'} ${product.tax ?? 19}%`}
                      </TableCell>
                      <TableCell><Chip size="small" label={product.active ? 'Activo' : 'Inactivo'} color={product.active ? 'success' : 'default'} /></TableCell>
                      <TableCell align="right">
                        <IconButton disabled={!canEditOrCreate} onClick={() => handleEdit(product)}><EditIcon /></IconButton>
                        <IconButton color="error" disabled={!canEditOrCreate} onClick={() => setDeletingProduct(product)}><DeleteIcon /></IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <AppPagination
                count={filtered.length}
                page={page}
                onPageChange={(newPage) => setPage(newPage)}
                rowsPerPage={rowsPerPage}
                onRowsPerPageChange={(newRowsPerPage) => {
                  setRowsPerPage(newRowsPerPage);
                  setPage(0);
                }}
                labelRowsPerPage="Productos por página:"
              />
            </Stack>
          </Paper>
        </Grid>
      </Grid>

      {/* Edit Product Dialog */}
      <Dialog
        open={editingProduct !== null}
        onClose={() => {
          setEditingProduct(null);
          resetEdit({ name: '', code: '', price: 0, tax: 19, category_id: '', image: '' });
        }}
        maxWidth="sm"
        fullWidth
        slotProps={{
          backdrop: {
            style: { backgroundColor: 'rgba(15, 23, 42, 0.4)' }
          }
        }}
        PaperProps={{
          sx: {
            background: '#ffffff',
            border: '1px solid #e2e8f0',
            boxShadow: '0 10px 30px rgba(15, 23, 42, 0.06)',
            color: '#0f172a',
            borderRadius: 2
          }
        }}
      >
        <DialogTitle sx={{ color: '#0f172a', fontWeight: 'bold', fontSize: '1.25rem', pb: 1 }}>
          Editar producto
        </DialogTitle>
        <DialogContent sx={{ pb: 3 }}>
          <Stack component="form" spacing={2.5} sx={{ mt: 1 }} onSubmit={handleSubmitEdit(onSubmitEdit)}>
            <TextField
              label="Nombre"
              {...registerEdit('name')}
              error={!!errorsEdit.name}
              helperText={errorsEdit.name?.message}
              fullWidth
              sx={{
                bgcolor: '#ffffff',
                borderRadius: 1,
                '& .MuiOutlinedInput-root': {
                  color: '#0f172a',
                  '& fieldset': {
                    borderColor: 'rgba(15, 23, 42, 0.1)',
                  },
                  '&:hover fieldset': {
                    borderColor: 'rgba(15, 23, 42, 0.2)',
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: 'rgba(15, 23, 42, 0.3)',
                  },
                },
                '& .MuiInputLabel-root': {
                  color: '#475569',
                  '&.Mui-focused': {
                    color: '#0f172a',
                  }
                }
              }}
            />
            <TextField
              label="Codigo"
              {...registerEdit('code')}
              fullWidth
              sx={{
                bgcolor: '#ffffff',
                borderRadius: 1,
                '& .MuiOutlinedInput-root': {
                  color: '#0f172a',
                  '& fieldset': {
                    borderColor: 'rgba(15, 23, 42, 0.1)',
                  },
                  '&:hover fieldset': {
                    borderColor: 'rgba(15, 23, 42, 0.2)',
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: 'rgba(15, 23, 42, 0.3)',
                  },
                },
                '& .MuiInputLabel-root': {
                  color: '#475569',
                  '&.Mui-focused': {
                    color: '#0f172a',
                  }
                }
              }}
            />
            <TextField
              label="Precio"
              type="number"
              {...registerEdit('price')}
              error={!!errorsEdit.price}
              disabled={role !== 'admin'}
              helperText={
                errorsEdit.price?.message ||
                (role !== 'admin'
                  ? 'Precios solo modificables desde Cloud para edición'
                  : '')
              }
              fullWidth
              sx={{
                bgcolor: '#ffffff',
                borderRadius: 1,
                '& .MuiOutlinedInput-root': {
                  color: '#0f172a',
                  '& fieldset': {
                    borderColor: 'rgba(15, 23, 42, 0.1)',
                  },
                  '&:hover fieldset': {
                    borderColor: 'rgba(15, 23, 42, 0.2)',
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: 'rgba(15, 23, 42, 0.3)',
                  },
                },
                '& .MuiInputLabel-root': {
                  color: '#475569',
                  '&.Mui-focused': {
                    color: '#0f172a',
                  }
                }
              }}
            />
            <Stack direction="row" spacing={2} sx={{ width: '100%' }}>
              <Controller
                name="tax_type"
                control={controlEdit}
                render={({ field }) => (
                  <TextField
                    {...field}
                    select
                    label="Tipo de Impuesto"
                    fullWidth
                    sx={{
                      flex: 1,
                      bgcolor: '#ffffff',
                      borderRadius: 1,
                      '& .MuiOutlinedInput-root': {
                        color: '#0f172a',
                        '& fieldset': { borderColor: 'rgba(15, 23, 42, 0.1)' },
                        '&:hover fieldset': { borderColor: 'rgba(15, 23, 42, 0.2)' },
                        '&.Mui-focused fieldset': { borderColor: 'rgba(15, 23, 42, 0.3)' },
                      },
                      '& .MuiInputLabel-root': {
                        color: '#475569',
                        '&.Mui-focused': { color: '#0f172a' }
                      }
                    }}
                  >
                    <MenuItem value="IVA">IVA</MenuItem>
                    <MenuItem value="INC">Impoconsumo (INC)</MenuItem>
                    <MenuItem value="EXENTO">Exento</MenuItem>
                  </TextField>
                )}
              />
              {taxTypeEdit !== 'EXENTO' && (
                <TextField
                  label="Porcentaje %"
                  type="number"
                  {...registerEdit('tax')}
                  fullWidth
                  sx={{
                    flex: 1,
                    bgcolor: '#ffffff',
                    borderRadius: 1,
                    '& .MuiOutlinedInput-root': {
                      color: '#0f172a',
                      '& fieldset': { borderColor: 'rgba(15, 23, 42, 0.1)' },
                      '&:hover fieldset': { borderColor: 'rgba(15, 23, 42, 0.2)' },
                      '&.Mui-focused fieldset': { borderColor: 'rgba(15, 23, 42, 0.3)' },
                    },
                    '& .MuiInputLabel-root': {
                      color: '#475569',
                      '&.Mui-focused': { color: '#0f172a' }
                    }
                  }}
                />
              )}
            </Stack>
            
            <Controller
              name="category_id"
              control={controlEdit}
              render={({ field }) => (
                <TextField
                  {...field}
                  select
                  label="Categoría"
                  error={!!errorsEdit.category_id}
                  helperText={errorsEdit.category_id?.message}
                  fullWidth
                  sx={{
                    bgcolor: '#ffffff',
                    borderRadius: 1,
                    '& .MuiOutlinedInput-root': {
                      color: '#0f172a',
                      '& fieldset': {
                        borderColor: 'rgba(15, 23, 42, 0.1)',
                      },
                      '&:hover fieldset': {
                        borderColor: 'rgba(15, 23, 42, 0.2)',
                      },
                      '&.Mui-focused fieldset': {
                        borderColor: 'rgba(15, 23, 42, 0.3)',
                      },
                    },
                    '& .MuiInputLabel-root': {
                      color: '#475569',
                      '&.Mui-focused': {
                        color: '#0f172a',
                      }
                    }
                  }}
                >
                  {categories.map((cat) => (
                    <MenuItem key={cat.id} value={cat.id}>
                      {cat.name}
                    </MenuItem>
                  ))}
                </TextField>
              )}
            />

            {showProductImages && (
              <Stack direction="row" spacing={1} alignItems="center">
                <TextField
                  label="Imagen URL"
                  {...registerEdit('image')}
                  sx={{
                    flex: 1,
                    bgcolor: '#ffffff',
                    borderRadius: 1,
                    '& .MuiOutlinedInput-root': {
                      color: '#0f172a',
                      '& fieldset': {
                        borderColor: 'rgba(15, 23, 42, 0.1)',
                      },
                      '&:hover fieldset': {
                        borderColor: 'rgba(15, 23, 42, 0.2)',
                      },
                      '&.Mui-focused fieldset': {
                        borderColor: 'rgba(15, 23, 42, 0.3)',
                      },
                    },
                    '& .MuiInputLabel-root': {
                      color: '#475569',
                      '&.Mui-focused': {
                        color: '#0f172a',
                      }
                    }
                  }}
                />
                <Button variant="outlined" component="label" sx={{ height: 56, color: '#0f172a', borderColor: 'rgba(15, 23, 42, 0.2)', '&:hover': { borderColor: 'rgba(15, 23, 42, 0.4)' } }}>
                  Subir
                  <input type="file" hidden accept="image/*" onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const formData = new FormData();
                      formData.append('image', file);
                      try {
                        const res = await fetch('http://localhost:8080/api/v1/products/upload', {
                          method: 'POST',
                          headers: { 'Authorization': 'Bearer ' + useAuthStore.getState().accessToken },
                          body: formData
                        });
                        const data = await res.json();
                        if (data.url) {
                           setValueEdit('image', data.url);
                        }
                      } catch (err) {
                        console.error(err);
                      }
                    }
                  }} />
                </Button>
              </Stack>
            )}

            <Stack direction="row" spacing={2} justifyContent="flex-end" sx={{ mt: 2 }}>
              <Button
                variant="outlined"
                onClick={() => {
                  setEditingProduct(null);
                  resetEdit({ name: '', code: '', price: 0, tax: 19, category_id: '', image: '' });
                }}
                sx={{ color: '#475569', borderColor: 'rgba(15, 23, 42, 0.2)', '&:hover': { borderColor: 'rgba(15, 23, 42, 0.4)', bgcolor: 'rgba(15, 23, 42, 0.05)' } }}
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                variant="contained"
                startIcon={<EditIcon />}
                color="primary"
              >
                Guardar
              </Button>
            </Stack>
          </Stack>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={deletingProduct !== null}
        onClose={() => setDeletingProduct(null)}
        maxWidth="xs"
        fullWidth
        slotProps={{
          backdrop: {
            style: { backgroundColor: 'rgba(15, 23, 42, 0.4)' }
          }
        }}
        PaperProps={{
          sx: {
            background: '#ffffff',
            border: '1px solid #e2e8f0',
            boxShadow: '0 10px 30px rgba(15, 23, 42, 0.06)',
            color: '#0f172a',
            borderRadius: 2
          }
        }}
      >
        <DialogTitle sx={{ color: '#0f172a', fontWeight: 'bold', fontSize: '1.25rem', pb: 1 }}>
          Eliminar producto
        </DialogTitle>
        <DialogContent sx={{ pb: 2 }}>
          <Typography variant="body1" sx={{ color: '#475569' }}>
            ¿Estás seguro de que deseas eliminar el producto "{deletingProduct?.name}"? Esta acción no se puede deshacer.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3, pt: 1, gap: 1 }}>
          <Button
            variant="outlined"
            onClick={() => setDeletingProduct(null)}
            sx={{ color: '#475569', borderColor: 'rgba(15, 23, 42, 0.2)', '&:hover': { borderColor: 'rgba(15, 23, 42, 0.4)', bgcolor: 'rgba(15, 23, 42, 0.05)' } }}
          >
            Cancelar
          </Button>
          <Button
            variant="contained"
            color="error"
            onClick={handleDeleteConfirm}
            sx={{ bgcolor: '#ef4444', color: '#ffffff', '&:hover': { bgcolor: '#dc2626' } }}
          >
            Eliminar
          </Button>
        </DialogActions>
      </Dialog>
      {canEditOrCreate && (
        <ProductsImportWizard
          open={isImportWizardOpen}
          onClose={() => setIsImportWizardOpen(false)}
          onSuccess={() => {
            queryClient.invalidateQueries({ queryKey: ['products'] });
            queryClient.invalidateQueries({ queryKey: ['categories'] });
          }}
        />
      )}
    </Stack>
  );
}
