import React, { useState } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Button, Stepper, Step, StepLabel, Typography,
  Box, Paper, Table, TableBody, TableCell, TableHead, TableRow,
  Checkbox, Select, MenuItem, Chip, CircularProgress, Alert, LinearProgress
} from '@mui/material';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import DownloadIcon from '@mui/icons-material/Download';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { posService } from '../../services/posService';
import type { ImportRow } from '../../types/domain';

interface ProductsImportWizardProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

const steps = [
  'Subir Archivo',
  'Previsualización',
  'Resumen',
  'Importación',
  'Resultado Final'
];

export function ProductsImportWizard({ open, onClose, onSuccess }: ProductsImportWizardProps) {
  const [activeStep, setActiveStep] = useState(0);
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const [importId, setImportId] = useState<string | null>(null);
  const [previewData, setPreviewData] = useState<ImportRow[]>([]);
  const [rowsOverrides, setRowsOverrides] = useState<Record<string, string>>({});
  const [executionResult, setExecutionResult] = useState<any>(null);

  const handleNext = async () => {
    setError(null);
    
    if (activeStep === 0) {
      if (!file) {
        setError('Por favor, selecciona un archivo CSV.');
        return;
      }
      setLoading(true);
      try {
        const response = await posService.uploadImportCSV(file);
        if (!response.headers_valid) {
          setError(`Faltan columnas obligatorias: ${response.missing_headers?.join(', ')}`);
          setLoading(false);
          return;
        }
        setImportId(response.import_id);
        
        // Immediately fetch preview
        const previewResponse = await posService.getImportPreview(response.import_id);
        const dataArray = previewResponse.data?.rows || previewResponse.rows || [];
        setPreviewData(dataArray);
        
        setActiveStep(1);
      } catch (err: any) {
        setError(err.message || 'Error al validar el archivo');
      } finally {
        setLoading(false);
      }
    } else if (activeStep === 1) {
      setActiveStep(2);
    } else if (activeStep === 2) {
      if (!importId) return;
      setActiveStep(3);
      executeImportProcess();
    }
  };

  const executeImportProcess = async () => {
    setLoading(true);
    try {
      const res = await posService.executeImport(importId!, rowsOverrides);
      const data = res.data || res;
      setExecutionResult(data);
      setActiveStep(4);
    } catch (err: any) {
      setError(err.message || 'Error al ejecutar la importación');
      setActiveStep(2); // Go back to summary on error
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
  };

  const reset = () => {
    setActiveStep(0);
    setFile(null);
    setPreviewData([]);
    setRowsOverrides({});
    setExecutionResult(null);
    setError(null);
    setImportId(null);
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  const downloadTemplate = () => {
    posService.downloadImportTemplate().catch(() => setError('Error descargando la plantilla'));
  };

  const updateRowAction = (id: string, action: string) => {
    setRowsOverrides(prev => ({ ...prev, [id]: action }));
  };

  // Helper to get effective action for a row
  const getAction = (row: ImportRow) => {
    return rowsOverrides[row.id!] || row.action;
  };

  const stats = {
    new: previewData.filter(r => getAction(r) === 'import' && (r.status === 'new' || r.status === 'Nuevo')).length,
    update: previewData.filter(r => getAction(r) === 'update' && (r.status === 'existing' || r.status === 'Existente')).length,
    skip: previewData.filter(r => getAction(r) === 'skip').length,
    error: previewData.filter(r => r.status === 'error' || r.status === 'Error').length,
  };

  return (
    <Dialog open={open} onClose={loading ? undefined : handleClose} maxWidth="xl" fullWidth>
      <DialogTitle sx={{ bgcolor: 'primary.main', color: 'primary.contrastText', mb: 2 }}>
        Asistente de Importación de Productos (ERP)
      </DialogTitle>
      
      <DialogContent dividers sx={{ minHeight: '500px' }}>
        <Stepper activeStep={activeStep} alternativeLabel sx={{ mb: 4 }}>
          {steps.map((label) => (
            <Step key={label}><StepLabel>{label}</StepLabel></Step>
          ))}
        </Stepper>

        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

        {activeStep === 0 && (
          <Box display="flex" flexDirection="column" alignItems="center" justifyContent="center" gap={3} py={4}>
            <Box display="flex" gap={2}>
              <Button variant="outlined" startIcon={<DownloadIcon />} onClick={downloadTemplate}>
                Descargar Plantilla Oficial
              </Button>
            </Box>
            
            <Paper variant="outlined" sx={{ p: 4, width: '100%', maxWidth: 500, textAlign: 'center', bgcolor: 'grey.50', cursor: 'pointer' }}>
              <input
                accept=".csv"
                style={{ display: 'none' }}
                id="csv-upload-button"
                type="file"
                onChange={(e) => setFile(e.target.files?.[0] || null)}
              />
              <label htmlFor="csv-upload-button">
                <Box display="flex" flexDirection="column" alignItems="center">
                  <UploadFileIcon sx={{ fontSize: 48, color: 'primary.main', mb: 1 }} />
                  <Typography variant="h6" gutterBottom>
                    {file ? file.name : 'Haz clic para seleccionar tu archivo CSV'}
                  </Typography>
                  <Button variant="contained" component="span" sx={{ mt: 2 }}>
                    Seleccionar Archivo
                  </Button>
                </Box>
              </label>
            </Paper>
          </Box>
        )}

        {activeStep === 1 && (
          <Box>
            <Typography variant="subtitle1" gutterBottom fontWeight="bold">
              Previsualización de Datos ({previewData.length} productos detectados)
            </Typography>
            <Paper variant="outlined" sx={{ maxHeight: 450, overflow: 'auto' }}>
              <Table stickyHeader size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Categoría</TableCell>
                    <TableCell>Producto</TableCell>
                    <TableCell>SKU</TableCell>
                    <TableCell>Precio</TableCell>
                    <TableCell>Disp.</TableCell>
                    <TableCell>Estado</TableCell>
                    <TableCell>Acción</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {previewData.map((row, idx) => {
                    const currentAction = getAction(row);
                    const isError = row.status === 'error' || row.status === 'Error';
                    
                    return (
                      <TableRow key={row.id || idx} hover selected={currentAction !== 'skip' && !isError}>
                        <TableCell>{row.category} {row.subcategory ? `> ${row.subcategory}` : ''}</TableCell>
                        <TableCell>{row.product_name || row.name}</TableCell>
                        <TableCell>{row.sku}</TableCell>
                        <TableCell>${row.price}</TableCell>
                        <TableCell>{row.available ? 'Sí' : 'No'}</TableCell>
                        <TableCell>
                          {(row.status === 'new' || row.status === 'Nuevo') && <Chip label="Nuevo" color="success" size="small" />}
                          {(row.status === 'existing' || row.status === 'Existente') && <Chip label="Existente" color="warning" size="small" />}
                          {isError && <Chip label="Error" color="error" size="small" />}
                          {row.errors && row.errors.length > 0 && <Typography variant="caption" color="error" display="block">{row.errors.join(', ')}</Typography>}
                        </TableCell>
                        <TableCell>
                          {isError ? (
                            <Typography variant="body2" color="error">Omitido (Error)</Typography>
                          ) : (row.status === 'existing' || row.status === 'Existente') ? (
                            <Select
                              value={currentAction}
                              size="small"
                              onChange={(e) => updateRowAction(row.id!, e.target.value)}
                            >
                              <MenuItem value="update">Actualizar</MenuItem>
                              <MenuItem value="duplicate">Crear Duplicado</MenuItem>
                              <MenuItem value="skip">Omitir</MenuItem>
                            </Select>
                          ) : (
                            <Select
                              value={currentAction}
                              size="small"
                              onChange={(e) => updateRowAction(row.id!, e.target.value)}
                            >
                              <MenuItem value="import">Importar</MenuItem>
                              <MenuItem value="skip">Omitir</MenuItem>
                            </Select>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </Paper>
          </Box>
        )}

        {activeStep === 2 && (
          <Box textAlign="center" py={4}>
            <Typography variant="h5" gutterBottom>Resumen antes de Importar</Typography>
            <Box display="flex" justifyContent="center" gap={4} my={4}>
              <Box>
                <Typography variant="h3" color="success.main">{stats.new}</Typography>
                <Typography variant="body2" color="textSecondary">Nuevos</Typography>
              </Box>
              <Box>
                <Typography variant="h3" color="warning.main">{stats.update}</Typography>
                <Typography variant="body2" color="textSecondary">A Actualizar</Typography>
              </Box>
              <Box>
                <Typography variant="h3" color="text.secondary">{stats.skip}</Typography>
                <Typography variant="body2" color="textSecondary">Omitidos</Typography>
              </Box>
              <Box>
                <Typography variant="h3" color="error.main">{stats.error}</Typography>
                <Typography variant="body2" color="textSecondary">Con Errores</Typography>
              </Box>
            </Box>
            <Typography variant="body1">
              ¿Estás seguro de que deseas proceder con la importación? Todo se ejecutará en una única transacción de base de datos segura.
            </Typography>
          </Box>
        )}

        {activeStep === 3 && (
          <Box textAlign="center" py={8}>
            <CircularProgress size={60} sx={{ mb: 4 }} />
            <Typography variant="h6" gutterBottom>Importando Productos...</Typography>
            <Typography variant="body2" color="textSecondary">
              Por favor, no cierres esta ventana. Esto puede tomar unos segundos.
            </Typography>
            <Box sx={{ width: '60%', mx: 'auto', mt: 4 }}>
              <LinearProgress />
            </Box>
          </Box>
        )}

        {activeStep === 4 && executionResult && (
          <Box textAlign="center" py={6}>
            <CheckCircleIcon color="success" sx={{ fontSize: 64, mb: 2 }} />
            <Typography variant="h5" gutterBottom>Importación Completada Exitosamente</Typography>
            <Paper elevation={0} sx={{ bgcolor: 'grey.50', p: 3, maxWidth: 400, mx: 'auto', mt: 3, textAlign: 'left' }}>
              <Typography variant="body1"><b>Productos creados:</b> {executionResult.imported}</Typography>
              <Typography variant="body1"><b>Productos actualizados:</b> {executionResult.updated}</Typography>
              <Typography variant="body1"><b>Categorías creadas:</b> {executionResult.categories_created}</Typography>
              <Typography variant="body1"><b>Productos omitidos:</b> {executionResult.omitted}</Typography>
              <Typography variant="body1" sx={{ mt: 2, color: 'text.secondary' }}>
                Tiempo total: {executionResult.execution_time} segundos.
              </Typography>
            </Paper>
          </Box>
        )}
      </DialogContent>
      
      <DialogActions sx={{ p: 3 }}>
        {activeStep < 3 && (
          <Button onClick={handleClose} disabled={loading} color="inherit">
            Cancelar
          </Button>
        )}
        {activeStep === 4 ? (
          <Button onClick={() => { handleClose(); onSuccess(); }} variant="contained">
            Finalizar
          </Button>
        ) : activeStep < 3 ? (
          <Box display="flex" gap={1}>
            <Button disabled={activeStep === 0 || loading} onClick={handleBack}>
              Atrás
            </Button>
            <Button
              variant="contained"
              onClick={handleNext}
              disabled={loading || (activeStep === 0 && !file)}
              color={activeStep === 2 ? 'success' : 'primary'}
            >
              {loading ? <CircularProgress size={24} /> : activeStep === 2 ? 'CONFIRMAR IMPORTACIÓN' : 'Siguiente'}
            </Button>
          </Box>
        ) : null}
      </DialogActions>
    </Dialog>
  );
}
