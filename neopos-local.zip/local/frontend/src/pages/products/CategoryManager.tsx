import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  Button, Dialog, DialogTitle, DialogContent, DialogActions, 
  Stack, TextField, IconButton, List, ListItem, ListItemText, 
  ListItemSecondaryAction, Typography, Paper
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import CategoryIcon from '@mui/icons-material/Category';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import { posService } from '../../services/posService';
import { useAuthStore } from '../../stores/authStore';
import type { Category } from '../../types/domain';

export function CategoryManager() {
  const [open, setOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [name, setName] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  
  const queryClient = useQueryClient();
  const { role } = useAuthStore();
  const canEditOrCreate = role === 'admin' || role === 'manager';

  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: posService.categories
  });

  const create = useMutation({
    mutationFn: posService.createCategory,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      setName('');
      setErrorMsg('');
    }
  });

  const update = useMutation({
    mutationFn: ({ id, payload }: { id: string; payload: Partial<Category> }) => posService.updateCategory(id, payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      setEditingCategory(null);
      setName('');
      setErrorMsg('');
    }
  });

  const remove = useMutation({
    mutationFn: posService.deleteCategory,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      setErrorMsg('');
    },
    onError: (err: any) => {
      setErrorMsg(err.message || 'Error al eliminar categoría');
    }
  });

  const toggleVisibility = useMutation({
    mutationFn: ({ id, is_hidden }: { id: string; is_hidden: boolean }) => posService.updateCategory(id, { is_hidden }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['categories'] })
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    
    if (editingCategory) {
      update.mutate({ id: editingCategory.id, payload: { name } });
    } else {
      create.mutate({ name });
    }
  };

  const handleEdit = (cat: Category) => {
    setEditingCategory(cat);
    setName(cat.name);
    setErrorMsg('');
  };

  const handleCancelEdit = () => {
    setEditingCategory(null);
    setName('');
    setErrorMsg('');
  };

  return (
    <>
      <Button 
        variant="outlined" 
        startIcon={<CategoryIcon />} 
        onClick={() => setOpen(true)}
        disabled={!canEditOrCreate}
      >
        Administrar Categorías
      </Button>

      <Dialog 
        open={open} 
        onClose={() => setOpen(false)}
        maxWidth="sm"
        fullWidth
        slotProps={{
          backdrop: {
            style: { backgroundColor: 'rgba(15, 23, 42, 0.4)' }
          }
        }}
        PaperProps={{
          sx: {
            background: '#ffffff',
            border: '1px solid #e2e8f0',
            boxShadow: '0 10px 30px rgba(15, 23, 42, 0.06)',
            color: '#0f172a',
            borderRadius: 2
          }
        }}
      >
        <DialogTitle sx={{ color: '#0f172a', fontWeight: 'bold', fontSize: '1.25rem', pb: 1 }}>
          Administrar Categorías
        </DialogTitle>
        <DialogContent sx={{ pb: 2 }}>
          {errorMsg && (
            <Typography color="error" sx={{ mb: 2, bgcolor: 'rgba(239, 68, 68, 0.1)', p: 1, borderRadius: 1 }}>
              {errorMsg}
            </Typography>
          )}
          <Stack component="form" onSubmit={handleSubmit} direction="row" spacing={1} sx={{ mb: 3, mt: 1 }}>
            <TextField 
              label={editingCategory ? "Editar categoría" : "Nueva categoría"}
              value={name}
              onChange={(e) => setName(e.target.value)}
              size="small"
              fullWidth
              sx={{
                bgcolor: '#ffffff',
                '& .MuiOutlinedInput-root': { color: '#0f172a' },
                '& .MuiInputLabel-root': { color: '#475569' }
              }}
            />
            <Button type="submit" variant="contained" disabled={!name.trim()}>
              {editingCategory ? 'Guardar' : 'Crear'}
            </Button>
            {editingCategory && (
              <Button variant="outlined" onClick={handleCancelEdit}>
                Cancelar
              </Button>
            )}
          </Stack>

          <Paper variant="outlined" sx={{ maxHeight: 300, overflow: 'auto', bgcolor: '#f8fafc', borderColor: '#e2e8f0' }}>
            <List dense>
              {categories.map((cat: Category) => (
                <ListItem key={cat.id} divider>
                  <ListItemText primary={cat.name} secondary={cat.is_hidden ? "Oculta en ventas" : ""} sx={{ color: '#0f172a' }} />
                  <ListItemSecondaryAction>
                    <IconButton edge="end" aria-label="toggle-visibility" onClick={() => toggleVisibility.mutate({ id: cat.id, is_hidden: !cat.is_hidden })} size="small" sx={{ mr: 1, color: cat.is_hidden ? 'text.disabled' : 'primary.main' }}>
                      {cat.is_hidden ? <VisibilityOffIcon fontSize="small" /> : <VisibilityIcon fontSize="small" />}
                    </IconButton>
                    <IconButton edge="end" aria-label="edit" onClick={() => handleEdit(cat)} size="small" sx={{ mr: 1 }}>
                      <EditIcon fontSize="small" />
                    </IconButton>
                    <IconButton edge="end" aria-label="delete" onClick={() => remove.mutate(cat.id)} size="small" color="error">
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </ListItemSecondaryAction>
                </ListItem>
              ))}
            </List>
          </Paper>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3, pt: 1 }}>
          <Button onClick={() => setOpen(false)} sx={{ color: '#475569' }}>Cerrar</Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
