import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Button, Card, CardActionArea, CardContent, Stack, Typography, Box,
  Dialog, DialogTitle, DialogContent, DialogActions, TextField,
  Select, MenuItem, FormControl, InputLabel, Chip
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import CheckIcon from '@mui/icons-material/Check';
import AddIcon from '@mui/icons-material/Add';
import CallSplitIcon from '@mui/icons-material/CallSplit';
import MergeTypeIcon from '@mui/icons-material/MergeType';
import SwapHorizIcon from '@mui/icons-material/SwapHoriz';
import PaymentIcon from '@mui/icons-material/Payment';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { PageHeader } from '../../components/PageHeader';
import { StatusChip } from '../../components/StatusChip';
import { posService } from '../../services/posService';
import { useTableStore } from '../../stores/tableStore';
import { useNotificationStore } from '../../stores/notificationStore';
import { useSettingsStore } from '../../stores/settingsStore';
import { useAuthStore } from '../../stores/authStore';
import { printTicket } from '../../utils/printTicket';
import type { RestaurantTable } from '../../types/domain';
import { mockTables } from '../../utils/mockData';
import { SplitBillDialog } from './SplitBillDialog';

type Decoration = { id: string; type: 'rect' | 'circle'; w: number; h: number; label?: string; x: number; y: number };

const colors: Record<RestaurantTable['status'], string> = {
  FREE: '#dcfce7',
  OCCUPIED: '#fee2e2',
  RESERVED: '#fef3c7',
  CLEANING: '#dbeafe'
};

export function TablesPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const showNotification = useNotificationStore(state => state.showNotification);
  const { selectedTable, setSelectedTable } = useTableStore();
  const [secondaryTables, setSecondaryTables] = useState<RestaurantTable[]>([]);
  
  const { data = mockTables } = useQuery({ queryKey: ['tables'], queryFn: posService.tables });
  
  const open = useMutation({ 
    mutationFn: posService.openTable, 
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['tables'] }),
    onError: (err: any) => showNotification(err.message || "Error al abrir mesa", "error")
  });
  
  const close = useMutation({ 
    mutationFn: posService.closeTable, 
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['tables'] }),
    onError: (err: any) => {
      if (err.message && err.message.includes("active orders")) {
        showNotification("No puedes cerrar esta mesa porque aun hay un pedido pendiente.", "error");
      } else {
        showNotification(err.message || "Error al cerrar mesa", "error");
      }
    }
  });
  
  const createTable = useMutation({ 
    mutationFn: posService.createTable, 
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['tables'] }),
    onError: (err: any) => showNotification(err.message || "Error al crear mesa", "error")
  });
  
  const [mergedPairs, setMergedPairs] = useState<{from: string, to: string}[]>(() => {
    const saved = localStorage.getItem('table_merged_pairs');
    return saved ? JSON.parse(saved) : [];
  });

  const transferTable = useMutation({ 
    mutationFn: ({id, target}: {id: string, target: string}) => posService.transferTable(id, target), 
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tables'] });
      setSecondaryTables([]);
      showNotification("Mesa transferida exitosamente", "success");
    },
    onError: (err: any) => showNotification(err.message || "Error al transferir mesa", "error")
  });
  
  const mergeTables = useMutation({ 
    mutationFn: ({id, target}: {id: string, target: string}) => posService.mergeTables(id, target), 
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['tables'] });
      const newPairs = [...mergedPairs, { from: variables.id, to: variables.target }];
      setMergedPairs(newPairs);
      localStorage.setItem('table_merged_pairs', JSON.stringify(newPairs));
      setSecondaryTables([]);
      showNotification("Mesas unidas exitosamente", "success");
    },
    onError: (err: any) => showNotification(err.message || "Error al unir mesas", "error")
  });
  
  const splitBill = useMutation({ 
    mutationFn: ({id, payload}: {id: string, payload: unknown}) => posService.splitBill(id, payload), 
    onSuccess: () => showNotification("Cuenta dividida exitosamente", "success"),
    onError: (err: any) => showNotification(err.message || "Error al dividir cuenta", "error")
  });

  const [isEditing, setIsEditing] = useState(false);
  const [modalState, setModalState] = useState<'TRANSFER' | 'MERGE' | 'SPLIT' | 'CREATE_TABLE' | 'CREATE_DECORATION' | null>(null);
  const [modalInput, setModalInput] = useState('');
  const [modalDecoType, setModalDecoType] = useState<'rect' | 'circle'>('rect');

  // Payment modal
  const { defaultPaymentMethod } = useSettingsStore();
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState(defaultPaymentMethod);
  const [paymentTableId, setPaymentTableId] = useState<string | null>(null);

  const paymentMethods = [
    { value: 'CASH', label: 'Efectivo' },
    { value: 'CREDIT_CARD', label: 'Tarjeta Crédito' },
    { value: 'DEBIT_CARD', label: 'Tarjeta Débito' },
    { value: 'TRANSFER', label: 'Transferencia' },
    { value: 'QR', label: 'QR / Nequi' },
  ] as const;

  const { user } = useAuthStore();

  const handlePayTable = async (tableId: string, method: string) => {
    try {
      // 1. Get active order
      let order;
      try {
        order = await posService.getActiveOrderByTable(tableId);
      } catch (orderErr: any) {
        throw new Error('No hay orden activa en esta mesa. Tome un pedido primero.');
      }
      if (!order || !order.items?.length) {
        throw new Error('No hay orden activa en esta mesa. Tome un pedido primero.');
      }

      // 2. Get active cash session
      let cashSessionId: string;
      const cashSession = await posService.getActiveCashSession();
      if (!cashSession || !cashSession.id) {
        throw new Error('No hay caja abierta. Abra caja primero.');
      }
      cashSessionId = cashSession.id;

      // 3. Register the sale
      const saleItems = order.items.map(item => ({
        product_id: item.product_id,
        name: item.name,
        quantity: item.quantity,
        unit_price: item.unit_price,
      }));

      // Use branch_id from user (token)
      const branchId = user?.branch_id || '';
      
      await posService.registerSale({
        branch_id: branchId,
        order_id: order.id,
        cash_session_id: cashSessionId,
        payment_method: method,
        discount: 0,
        tip: 0,
        items: saleItems,
      });

      // 4. Mark order as BILLED
      await posService.updateOrder(order.id, { status: 'BILLED' });

      // 5. Close table
      await posService.closeTable(tableId);

      // Print ticket via web printer
      const printData = {
        id: order.id,
        created_at: new Date().toISOString(),
        payment_method: method,
        subtotal: order.total,
        discount: 0,
        tip: 0,
        total: order.total,
        items: saleItems.map(item => ({
          name: item.name,
          quantity: item.quantity,
          unit_price: item.unit_price,
          total: item.quantity * item.unit_price
        })),
        is_mesa: true,
        table_name: `Mesa ${selectedTable?.number}`
      };
      printTicket(printData);

      queryClient.invalidateQueries({ queryKey: ['tables'] });
      showNotification(`Mesa cobrada (${paymentMethods.find(m => m.value === method)?.label || method})`, "success");
      setPaymentModalOpen(false);
      setPaymentTableId(null);
      setSelectedTable(undefined);
    } catch (err: any) {
      showNotification(err.message || "Error al cobrar mesa", "error");
    }
  };

  const handlePayClick = (e: React.MouseEvent) => {
    if (!selectedTable || selectedTable.status !== 'OCCUPIED') return;
    if (e.shiftKey) {
      // Shift+Click = pago rápido con medio de pago por defecto
      handlePayTable(selectedTable.id, defaultPaymentMethod);
    } else {
      setPaymentTableId(selectedTable.id);
      setPaymentMethod(defaultPaymentMethod);
      setPaymentModalOpen(true);
    }
  };
  
  const [positions, setPositions] = useState<Record<string, { x: number, y: number, w?: number, h?: number }>>(() => {
    const saved = localStorage.getItem('table_positions');
    return saved ? JSON.parse(saved) : {};
  });

  const [decorations, setDecorations] = useState<Decoration[]>(() => {
    const saved = localStorage.getItem('table_decorations');
    return saved ? JSON.parse(saved) : [];
  });

  const [activeAction, setActiveAction] = useState<{
    id: string;
    type: 'table' | 'deco';
    action: 'drag' | 'resize';
    startX: number;
    startY: number;
    startPosVal: { x: number; y: number; w: number; h: number };
    resizeDirection?: 'se' | 's' | 'e';
  } | null>(null);

  const [selectedDecoId, setSelectedDecoId] = useState<string | null>(null);

  useEffect(() => {
    const newPos = { ...positions };
    let changed = false;
    data.forEach((table: RestaurantTable, i: number) => {
      if (!newPos[table.id]) {
        newPos[table.id] = { x: (i % 6) * 120 + 20, y: Math.floor(i / 6) * 120 + 20, w: 100, h: 80 };
        changed = true;
      }
    });
    if (changed) {
      setPositions(newPos);
      localStorage.setItem('table_positions', JSON.stringify(newPos));
    }

    // Limpiar uniones de mesas que ya están libres (pagadas)
    const freeTables = new Set(data.filter((t: RestaurantTable) => t.status === 'FREE').map((t: RestaurantTable) => t.id));
    if (mergedPairs.length > 0) {
      const activePairs = mergedPairs.filter(p => !freeTables.has(p.from) && !freeTables.has(p.to));
      if (activePairs.length !== mergedPairs.length) {
        setMergedPairs(activePairs);
        localStorage.setItem('table_merged_pairs', JSON.stringify(activePairs));
      }
    }
  }, [data]);

  const handleElementMouseDown = (e: React.MouseEvent, id: string, type: 'table' | 'deco') => {
    if (!isEditing) return;
    e.stopPropagation();
    e.preventDefault();
    
    if (type === 'table') {
      const table = data.find((t: RestaurantTable) => t.id === id);
      if (table) setSelectedTable(table);
      setSelectedDecoId(null);
    } else {
      setSelectedDecoId(id);
      setSelectedTable(undefined);
    }
    
    let x = 0, y = 0, w = 100, h = 80;
    if (type === 'table') {
      const pos = positions[id] || { x: 0, y: 0 };
      x = pos.x;
      y = pos.y;
      w = pos.w || 100;
      h = pos.h || 80;
    } else {
      const deco = decorations.find(d => d.id === id);
      if (deco) {
        x = deco.x;
        y = deco.y;
        w = deco.w;
        h = deco.h;
      }
    }
    
    setActiveAction({
      id,
      type,
      action: 'drag',
      startX: e.clientX,
      startY: e.clientY,
      startPosVal: { x, y, w, h }
    });
  };

  const handleResizeMouseDown = (e: React.MouseEvent, id: string, type: 'table' | 'deco', direction: 'se' | 's' | 'e') => {
    if (!isEditing) return;
    e.stopPropagation();
    e.preventDefault();
    
    let x = 0, y = 0, w = 100, h = 80;
    if (type === 'table') {
      const pos = positions[id] || { x: 0, y: 0 };
      x = pos.x;
      y = pos.y;
      w = pos.w || 100;
      h = pos.h || 80;
    } else {
      const deco = decorations.find(d => d.id === id);
      if (deco) {
        x = deco.x;
        y = deco.y;
        w = deco.w;
        h = deco.h;
      }
    }
    
    setActiveAction({
      id,
      type,
      action: 'resize',
      startX: e.clientX,
      startY: e.clientY,
      startPosVal: { x, y, w, h },
      resizeDirection: direction
    });
  };

  useEffect(() => {
    if (!activeAction) return;

    const handleMouseMove = (e: MouseEvent) => {
      const deltaX = e.clientX - activeAction.startX;
      const deltaY = e.clientY - activeAction.startY;
      const { id, type, action, startPosVal, resizeDirection } = activeAction;
      
      if (action === 'drag') {
        const newX = Math.max(0, startPosVal.x + deltaX);
        const newY = Math.max(0, startPosVal.y + deltaY);
        
        if (type === 'table') {
          setPositions(prev => ({
            ...prev,
            [id]: {
              ...prev[id],
              x: newX,
              y: newY,
              w: startPosVal.w,
              h: startPosVal.h
            }
          }));
        } else {
          setDecorations(decos => decos.map(d => d.id === id ? { ...d, x: newX, y: newY } : d));
        }
      } else if (action === 'resize') {
        let newW = startPosVal.w;
        let newH = startPosVal.h;
        
        if (resizeDirection === 'e' || resizeDirection === 'se') {
          newW = Math.max(40, startPosVal.w + deltaX);
        }
        if (resizeDirection === 's' || resizeDirection === 'se') {
          newH = Math.max(40, startPosVal.h + deltaY);
        }
        
        if (type === 'table') {
          setPositions(prev => ({
            ...prev,
            [id]: {
              ...prev[id],
              w: newW,
              h: newH
            }
          }));
        } else {
          setDecorations(decos => decos.map(d => d.id === id ? { ...d, w: newW, h: newH } : d));
        }
      }
    };

    const handleMouseUp = () => {
      if (activeAction.type === 'table') {
        localStorage.setItem('table_positions', JSON.stringify(positions));
      } else {
        localStorage.setItem('table_decorations', JSON.stringify(decorations));
      }
      setActiveAction(null);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [activeAction, positions, decorations]);

  const handleDragStart = (e: React.DragEvent, id: string, type: 'table' | 'deco' = 'table') => {
    e.dataTransfer.setData('source_id', id);
    e.dataTransfer.setData('source_type', type);
    e.dataTransfer.setData('source_table_id', id);
    const rect = (e.target as HTMLElement).getBoundingClientRect();
    e.dataTransfer.setData('offsetX', (e.clientX - rect.left).toString());
    e.dataTransfer.setData('offsetY', (e.clientY - rect.top).toString());
  };

  const handleDropOnCanvas = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDropOnTable = (e: React.DragEvent, targetTableId: string) => {
    e.preventDefault();
    e.stopPropagation();
    if (isEditing) return;
    
    const sourceTableId = e.dataTransfer.getData('source_table_id');
    if (!sourceTableId || sourceTableId === targetTableId) return;

    const sourceTable = data.find((t: RestaurantTable) => t.id === sourceTableId);
    setSelectedTable(sourceTable!);
    const targetTable = data.find((t: RestaurantTable) => t.id === targetTableId);
    setModalInput(targetTable?.number.toString() || '');
    setModalState('TRANSFER');
  };

  const handleCloseTable = (tableId: string) => {
    const tablesToClose = new Set<string>([tableId]);
    let added = true;
    while (added) {
      added = false;
      mergedPairs.forEach(pair => {
        if (tablesToClose.has(pair.from) && !tablesToClose.has(pair.to)) {
          tablesToClose.add(pair.to);
          added = true;
        } else if (tablesToClose.has(pair.to) && !tablesToClose.has(pair.from)) {
          tablesToClose.add(pair.from);
          added = true;
        }
      });
    }
    
    tablesToClose.forEach(id => {
      close.mutate(id);
    });
    
    showNotification("Cerrando mesa(s)...", "info");
  };

  const handleModalSubmit = () => {
    if (!selectedTable && modalState !== 'CREATE_TABLE' && modalState !== 'CREATE_DECORATION') return;
    
    if (modalState === 'CREATE_TABLE') {
      const num = parseInt(modalInput);
      if (num) {
        createTable.mutate({ number: num, capacity: 4, status: 'FREE' });
        showNotification("Creando mesa " + num, "info");
      }
    } else if (modalState === 'CREATE_DECORATION') {
      const newDeco: Decoration = {
        id: `deco_${Date.now()}`,
        type: modalDecoType,
        w: modalDecoType === 'rect' ? 120 : 60,
        h: modalDecoType === 'rect' ? 60 : 60,
        label: modalInput,
        x: 20,
        y: 20
      };
      const newDecos = [...decorations, newDeco];
      setDecorations(newDecos);
      localStorage.setItem('table_decorations', JSON.stringify(newDecos));
      showNotification("Decoración agregada", "info");
    } else if (modalState === 'TRANSFER') {
      const target = data.find((tbl: RestaurantTable) => tbl.number === parseInt(modalInput));
      if (target) {
        transferTable.mutate({id: selectedTable!.id, target: target.id});
        showNotification("Transfiriendo mesa...", "info");
      } else {
        showNotification("Mesa no encontrada", "error");
      }
    } else if (modalState === 'MERGE') {
      if (secondaryTables.length > 0) {
        // Unir seleccionadas
        for (const t of secondaryTables) {
          mergeTables.mutate({id: selectedTable!.id, target: t.id});
        }
        showNotification("Uniendo mesas...", "info");
      } else {
        const target = data.find((tbl: RestaurantTable) => tbl.number === parseInt(modalInput));
        if (target) {
          mergeTables.mutate({id: selectedTable!.id, target: target.id});
          showNotification("Uniendo mesas...", "info");
        } else {
          showNotification("Mesa no encontrada", "error");
        }
      }
    }
    
    setModalState(null);
    setModalInput('');
  };

  const handleTableClick = (e: React.MouseEvent, table: RestaurantTable) => {
    if (isEditing) return;
    if (e.shiftKey && selectedTable && selectedTable.id !== table.id) {
      setSecondaryTables(prev => {
        const isSelected = prev.find(t => t.id === table.id);
        if (isSelected) return prev.filter(t => t.id !== table.id);
        return [...prev, table];
      });
    } else {
      setSelectedTable(table);
      setSecondaryTables([]);
    }
  };

  const triggerTransfer = () => {
    setModalInput(secondaryTables.length > 0 ? secondaryTables[0].number.toString() : '');
    setModalState('TRANSFER');
  };

  const triggerMerge = () => {
    setModalInput('');
    setModalState('MERGE');
  };

  return (
    <Stack spacing={3} sx={{ height: '100%' }}>
      <PageHeader
        title="Mapa de Mesas"
        subtitle={isEditing ? "Modo Edición: Haz clic y arrastra las mesas para organizarlas. Usa los controles en los bordes para redimensionar." : "Usa Shift + Click para seleccionar dos mesas. Arrastra una mesa sobre otra para transferir."}
        actions={
          <Stack direction="row" spacing={2}>
            {isEditing && (
              <>
                <Button startIcon={<AddIcon />} onClick={() => { setModalInput(''); setModalDecoType('rect'); setModalState('CREATE_DECORATION'); }} variant="outlined" color="secondary">
                  Nueva Decoración
                </Button>
                <Button startIcon={<AddIcon />} onClick={() => { setModalInput(''); setModalState('CREATE_TABLE'); }} variant="contained" color="secondary">
                  Nueva mesa
                </Button>
              </>
            )}
            <Button
              startIcon={isEditing ? <CheckIcon /> : <EditIcon />}
              onClick={() => {
                setIsEditing(!isEditing);
                setSelectedDecoId(null);
              }}
              variant={isEditing ? "contained" : "outlined"}
              color="primary"
            >
              {isEditing ? "Finalizar Edición" : "Editar mesas"}
            </Button>
          </Stack>
        }
      />
      
      {!isEditing && (
        <Stack direction="row" gap={1} flexWrap="wrap">
          <Button variant="outlined" startIcon={<SwapHorizIcon />} onClick={triggerTransfer} disabled={!selectedTable}>Transferir mesa</Button>
          <Button variant="outlined" startIcon={<MergeTypeIcon />} onClick={triggerMerge} disabled={!selectedTable}>Unir mesas</Button>
          <Button variant="outlined" startIcon={<CallSplitIcon />} onClick={() => { setModalInput(''); setModalState('SPLIT'); }} disabled={!selectedTable}>Dividir cuenta</Button>
          <Button variant="contained" color="success" disabled={!selectedTable || selectedTable.status === 'OCCUPIED'} onClick={() => selectedTable && open.mutate(selectedTable.id)}>Abrir</Button>
          <Button variant="contained" color="error" disabled={!selectedTable || selectedTable.status === 'FREE'} onClick={() => selectedTable && handleCloseTable(selectedTable.id)}>Cerrar</Button>
          <Button 
            variant="contained" 
            startIcon={<PaymentIcon />}
            disabled={!selectedTable || selectedTable.status !== 'OCCUPIED'}
            onClick={handlePayClick}
            sx={{ bgcolor: '#16a34a', '&:hover': { bgcolor: '#15803d' } }}
          >
            Cobrar {selectedTable?.status === 'OCCUPIED' ? '(Shift = rápido)' : ''}
          </Button>
          <Button 
            variant="contained" 
            color="primary" 
            disabled={!selectedTable} 
            onClick={() => {
              if (selectedTable) {
                if (selectedTable.status === 'FREE') {
                  open.mutate(selectedTable.id, {
                    onSuccess: () => navigate('/orders')
                  });
                } else {
                  navigate('/orders');
                }
              }
            }}
          >
            Tomar Pedido
          </Button>
        </Stack>
      )}
      
      <Box
        sx={{
          flexGrow: 1,
          minHeight: '60vh',
          bgcolor: isEditing ? '#f3f4f6' : 'background.paper',
          border: isEditing ? '2px dashed #0891b2' : '2px dashed #ccc',
          borderRadius: 2,
          position: 'relative',
          overflow: 'hidden'
        }}
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDropOnCanvas}
      >
        <svg style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: 'none', zIndex: 0 }}>
          <defs>
            <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
              <polygon points="0 0, 10 3.5, 0 7" fill="#0891b2" />
            </marker>
          </defs>
          {mergedPairs.map((pair, idx) => {
            const posFrom = positions[pair.from];
            const posTo = positions[pair.to];
            if (!posFrom || !posTo) return null;
            
            const x1 = posFrom.x + (posFrom.w || 100) / 2;
            const y1 = posFrom.y + (posFrom.h || 80) / 2;
            const x2 = posTo.x + (posTo.w || 100) / 2;
            const y2 = posTo.y + (posTo.h || 80) / 2;
            return (
              <line key={idx} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#0891b2" strokeWidth="3" strokeDasharray="5,5" markerEnd="url(#arrowhead)" />
            );
          })}
        </svg>

        {decorations.map((deco) => {
          const isSelected = selectedDecoId === deco.id;
          return (
            <Box
              key={deco.id}
              draggable={!isEditing}
              onDragStart={(e) => !isEditing && handleDragStart(e, deco.id, 'deco')}
              onMouseDown={(e) => isEditing && handleElementMouseDown(e, deco.id, 'deco')}
              sx={{
                position: 'absolute',
                left: deco.x,
                top: deco.y,
                width: deco.w,
                height: deco.h,
                bgcolor: deco.type === 'rect' ? '#d1d5db' : '#86efac',
                borderRadius: deco.type === 'circle' ? '50%' : 1,
                cursor: isEditing ? 'grab' : 'default',
                zIndex: isSelected ? 10 : 0,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: 1,
                opacity: 0.8,
                outline: isSelected && isEditing ? '3px solid #0891b2' : 'none',
                overflow: isEditing ? 'visible' : 'hidden',
                '&:active': { cursor: isEditing ? 'grabbing' : 'default' }
              }}
            >
              {deco.label && (
                <Typography variant="caption" sx={{ color: 'rgba(0,0,0,0.6)', fontWeight: 'bold', textAlign: 'center', px: 1, userSelect: 'none' }}>
                  {deco.label}
                </Typography>
              )}
              {/* Resize Handles */}
              {isEditing && isSelected && (
                <>
                  <Box
                    onMouseDown={(e) => handleResizeMouseDown(e, deco.id, 'deco', 'e')}
                    sx={{ position: 'absolute', top: 0, right: -4, width: 8, height: '100%', cursor: 'ew-resize', zIndex: 20 }}
                  />
                  <Box
                    onMouseDown={(e) => handleResizeMouseDown(e, deco.id, 'deco', 's')}
                    sx={{ position: 'absolute', bottom: -4, left: 0, width: '100%', height: 8, cursor: 'ns-resize', zIndex: 20 }}
                  />
                  <Box
                    onMouseDown={(e) => handleResizeMouseDown(e, deco.id, 'deco', 'se')}
                    sx={{ position: 'absolute', bottom: -4, right: -4, width: 10, height: 10, bgcolor: 'primary.main', border: '1px solid white', borderRadius: '50%', cursor: 'nwse-resize', zIndex: 21 }}
                  />
                </>
              )}
            </Box>
          );
        })}

        {data.map((table: RestaurantTable) => {
          const pos = positions[table.id] || { x: 0, y: 0 };
          const isPrimary = selectedTable?.id === table.id;
          const isSecondary = secondaryTables.some(t => t.id === table.id);
          const isSelected = isPrimary;
          
          let outline = 'none';
          if (isPrimary) outline = '3px solid #0891b2';
          if (isSecondary) outline = '3px solid #8b5cf6';

          return (
            <Card
              key={table.id}
              draggable={!isEditing}
              onDragStart={(e) => !isEditing && handleDragStart(e, table.id)}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => handleDropOnTable(e, table.id)}
              onMouseDown={(e) => isEditing && handleElementMouseDown(e, table.id, 'table')}
              sx={{
                width: pos.w || 100,
                height: pos.h || 80,
                position: 'absolute',
                left: pos.x,
                top: pos.y,
                cursor: isEditing ? 'grab' : 'pointer',
                bgcolor: colors[table.status],
                outline: outline,
                transition: activeAction ? 'none' : 'outline 0.2s, box-shadow 0.2s',
                '&:active': { cursor: isEditing ? 'grabbing' : 'pointer', opacity: isEditing ? 0.8 : 1 },
                zIndex: (isPrimary || isSecondary) ? 10 : 1,
                overflow: isEditing ? 'visible' : 'hidden'
              }}
            >
              <CardActionArea 
                onClick={(e) => handleTableClick(e, table)} 
                onDoubleClick={() => {
                  if (!isEditing) {
                    setSelectedTable(table);
                    if (table.status === 'FREE') {
                      open.mutate(table.id, {
                        onSuccess: () => navigate('/orders')
                      });
                    } else {
                      navigate('/orders');
                    }
                  }
                }}
                sx={{ height: '100%', width: '100%' }}
              >
                <CardContent sx={{ p: 1, height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', '&:last-child': { pb: 1 } }}>
                  <Stack spacing={0.5} alignItems="center" justifyContent="center">
                    <Typography variant="subtitle2" fontWeight="bold" sx={{ userSelect: 'none' }}>Mesa {table.number}</Typography>
                    <StatusChip status={table.status} />
                    <Typography variant="caption" color="text.secondary" sx={{ userSelect: 'none' }}>{table.capacity} p.</Typography>
                  </Stack>
                </CardContent>
              </CardActionArea>
              {/* Resize Handles */}
              {isEditing && isSelected && (
                <>
                  <Box
                    onMouseDown={(e) => handleResizeMouseDown(e, table.id, 'table', 'e')}
                    sx={{ position: 'absolute', top: 0, right: -4, width: 8, height: '100%', cursor: 'ew-resize', zIndex: 20 }}
                  />
                  <Box
                    onMouseDown={(e) => handleResizeMouseDown(e, table.id, 'table', 's')}
                    sx={{ position: 'absolute', bottom: -4, left: 0, width: '100%', height: 8, cursor: 'ns-resize', zIndex: 20 }}
                  />
                  <Box
                    onMouseDown={(e) => handleResizeMouseDown(e, table.id, 'table', 'se')}
                    sx={{ position: 'absolute', bottom: -4, right: -4, width: 10, height: 10, bgcolor: 'primary.main', border: '1px solid white', borderRadius: '50%', cursor: 'nwse-resize', zIndex: 21 }}
                  />
                </>
              )}
            </Card>
          );
        })}
      </Box>

      <Dialog open={!!modalState} onClose={() => setModalState(null)} maxWidth="xs" fullWidth>
        <DialogTitle>
          {modalState === 'CREATE_TABLE' && 'Crear nueva mesa'}
          {modalState === 'CREATE_DECORATION' && 'Crear nueva decoración'}
          {modalState === 'TRANSFER' && 'Transferir mesa'}
          {modalState === 'MERGE' && 'Unir mesas'}
          {modalState === 'SPLIT' && 'Dividir cuenta'}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 2 }}>
            {modalState === 'CREATE_DECORATION' && (
              <Stack spacing={2}>
                <FormControl fullWidth>
                  <InputLabel>Tipo</InputLabel>
                  <Select
                    value={modalDecoType}
                    label="Tipo"
                    onChange={(e) => setModalDecoType(e.target.value as 'rect' | 'circle')}
                  >
                    <MenuItem value="rect">Barra (Rectángulo)</MenuItem>
                    <MenuItem value="circle">Planta/Árbol (Círculo)</MenuItem>
                  </Select>
                </FormControl>
                <TextField 
                  fullWidth 
                  label="Etiqueta (Opcional)" 
                  value={modalInput} 
                  onChange={(e) => setModalInput(e.target.value)}
                />
              </Stack>
            )}
            {modalState === 'CREATE_TABLE' && (
              <TextField 
                fullWidth 
                label="Número de mesa" 
                type="number" 
                value={modalInput} 
                onChange={(e) => setModalInput(e.target.value)}
                autoFocus
              />
            )}
            {modalState === 'TRANSFER' && secondaryTables.length > 0 ? (
              <Typography variant="body1" sx={{ p: 2, textAlign: 'center' }}>
                ¿Seguro que quieres transferir esta mesa? <br/>
                <strong style={{ fontSize: '1.2em' }}>{selectedTable?.number} &rarr; {secondaryTables[0].number}</strong>
              </Typography>
            ) : modalState === 'TRANSFER' && (
              <TextField 
                fullWidth 
                label="Número de mesa destino" 
                type="number" 
                value={modalInput} 
                onChange={(e) => setModalInput(e.target.value)}
                autoFocus
              />
            )}
            {modalState === 'MERGE' && secondaryTables.length > 0 ? (
              <Typography variant="body1" sx={{ p: 2, textAlign: 'center' }}>
                ¿Seguro que quieres juntar estas mesas? <br/>
                <strong style={{ fontSize: '1.2em' }}>
                  {selectedTable?.number} {secondaryTables.length === 1 ? 'y' : ','} {secondaryTables.map(t => t.number).join(', ').replace(/, ([^,]*)$/, ' y $1')}
                </strong>
              </Typography>
            ) : modalState === 'MERGE' && (
              <TextField 
                fullWidth 
                label="Número de mesa destino" 
                type="number" 
                value={modalInput} 
                onChange={(e) => setModalInput(e.target.value)}
                autoFocus
              />
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setModalState(null)}>Cancelar</Button>
          <Button onClick={handleModalSubmit} variant="contained" color="primary">Confirmar</Button>
        </DialogActions>
      </Dialog>

      {/* Split Bill Advanced Dialog */}
      <SplitBillDialog 
        open={modalState === 'SPLIT'} 
        onClose={() => setModalState(null)} 
        tableId={selectedTable?.id || ''} 
        tableName={selectedTable ? `Mesa ${selectedTable.number}` : ''} 
      />

      {/* Payment Method Modal */}
      <Dialog 
        open={paymentModalOpen} 
        onClose={() => setPaymentModalOpen(false)} 
        maxWidth="xs" 
        fullWidth
      >
        <DialogTitle>
          <Stack direction="row" alignItems="center" spacing={1}>
            <PaymentIcon color="success" />
            <span>Cobrar Mesa</span>
          </Stack>
        </DialogTitle>
        <DialogContent>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2, mt: 1 }}>
            Selecciona el medio de pago para cerrar esta mesa.
          </Typography>
          <Stack spacing={1}>
            {paymentMethods.map((method) => (
              <Button
                key={method.value}
                variant={paymentMethod === method.value ? 'contained' : 'outlined'}
                fullWidth
                color={paymentMethod === method.value ? 'success' : 'primary'}
                onClick={() => setPaymentMethod(method.value)}
                sx={{
                  justifyContent: 'flex-start',
                  py: 1.5,
                  textTransform: 'none',
                  fontSize: '0.95rem'
                }}
              >
                {method.label}
                {method.value === defaultPaymentMethod && (
                  <Chip label="Default" size="small" sx={{ ml: 'auto', height: 20, fontSize: '0.7rem' }} />
                )}
              </Button>
            ))}
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setPaymentModalOpen(false)}>
            Cancelar
          </Button>
          <Button 
            variant="contained" 
            color="success"
            onClick={() => paymentTableId && handlePayTable(paymentTableId, paymentMethod)}
          >
            Confirmar Pago
          </Button>
        </DialogActions>
      </Dialog>
    </Stack>
  );
}
