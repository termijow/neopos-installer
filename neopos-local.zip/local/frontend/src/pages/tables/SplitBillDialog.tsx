import React, { useState, useEffect } from 'react';
import { 
  Dialog, DialogTitle, DialogContent, DialogActions, 
  Button, Typography, Stack, Divider, 
  List, ListItem, ListItemText, ListItemSecondaryAction, 
  TextField, IconButton, Tab, Tabs, Box, Chip
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import PaymentIcon from '@mui/icons-material/Payment';
import { posService } from '../../services/posService';
import { useNotificationStore } from '../../stores/notificationStore';
import { useSettingsStore } from '../../stores/settingsStore';
import { useAuthStore } from '../../stores/authStore';
import { printTicket } from '../../utils/printTicket';
import type { Order } from '../../types/domain';

interface SplitBillDialogProps {
  open: boolean;
  onClose: () => void;
  tableId: string;
  tableName: string;
}

interface SelectedItem {
  index: number;
  name: string;
  unit_price: number;
  product_id: string;
  quantity: number;
  maxQuantity: number;
}

export function SplitBillDialog({ open, onClose, tableId, tableName }: SplitBillDialogProps) {
  const showNotification = useNotificationStore(state => state.showNotification);
  const { defaultPaymentMethod } = useSettingsStore();
  const { user } = useAuthStore();

  const [tab, setTab] = useState(0); // 0: By Items, 1: Equal Parts
  const [order, setOrder] = useState<Order | null>(null);
  const [selectedItems, setSelectedItems] = useState<Record<number, SelectedItem>>({});
  const [equalParts, setEqualParts] = useState<number>(2);
  const [loading, setLoading] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState(defaultPaymentMethod);

  const paymentMethods = [
    { value: 'CASH', label: 'Efectivo' },
    { value: 'CREDIT_CARD', label: 'Tarjeta Crédito' },
    { value: 'DEBIT_CARD', label: 'Tarjeta Débito' },
    { value: 'TRANSFER', label: 'Transferencia' },
    { value: 'QR', label: 'QR / Nequi' },
  ] as const;

  useEffect(() => {
    if (open && tableId) {
      loadOrder();
    } else {
      setOrder(null);
      setSelectedItems({});
      setEqualParts(2);
    }
  }, [open, tableId]);

  const loadOrder = async () => {
    try {
      const activeOrder = await posService.getActiveOrderByTable(tableId);
      setOrder(activeOrder);
      
      // Initialize selected items to 0
      const initial: Record<number, SelectedItem> = {};
      activeOrder.items?.forEach((item, idx) => {
        initial[idx] = {
          index: idx,
          name: item.name,
          unit_price: item.unit_price,
          product_id: item.product_id,
          quantity: 0,
          maxQuantity: item.quantity
        };
      });
      setSelectedItems(initial);
    } catch (error: any) {
      showNotification('No hay orden activa en esta mesa.', 'error');
      onClose();
    }
  };

  const handleQtyChange = (index: number, delta: number) => {
    setSelectedItems(prev => {
      const item = prev[index];
      const newQty = Math.max(0, Math.min(item.maxQuantity, item.quantity + delta));
      return { ...prev, [index]: { ...item, quantity: newQty } };
    });
  };

  const selectedTotal = Object.values(selectedItems).reduce((sum, item) => sum + (item.quantity * item.unit_price), 0);
  const total = order?.total || 0;
  
  const handlePayPartial = async () => {
    if (!order) return;
    
    // 1. Determine what is being paid
    let saleItems = [];
    let saleTotal = 0;
    
    if (tab === 0) {
      // By items
      saleItems = Object.values(selectedItems)
        .filter(i => i.quantity > 0)
        .map(i => ({
          product_id: i.product_id,
          name: i.name,
          quantity: i.quantity,
          unit_price: i.unit_price,
        }));
      
      // Calculate selected total by looking at actual selection
      saleTotal = saleItems.reduce((acc, curr) => acc + (curr.quantity * curr.unit_price), 0);
      if (saleItems.length === 0) {
        showNotification("Seleccione al menos un producto", "warning");
        return;
      }
      if (saleTotal <= 0) {
        showNotification("El monto a cobrar debe ser mayor a 0", "warning");
        return;
      }
    } else {
      // Equal parts
      if (equalParts <= 1) return;
      saleTotal = Math.round(total / equalParts);
      saleItems = [{
        product_id: "00000000-0000-0000-0000-000000000000",
        name: `Pago parcial (1/${equalParts})`,
        quantity: 1,
        unit_price: saleTotal
      }];
    }

    try {
      setLoading(true);
      const cashSession = await posService.getActiveCashSession();
      if (!cashSession) throw new Error("No hay caja abierta.");

      // Register partial sale
      await posService.registerSale({
        branch_id: user?.branch_id || '',
        order_id: order.id,
        cash_session_id: cashSession.id,
        payment_method: paymentMethod,
        discount: 0,
        tip: 0,
        items: saleItems,
      });

      // Update remaining order
      if (tab === 0) {
        // Subtract paid items from order
        const remainingItems = [];
        for (const [idx, item] of Object.entries(selectedItems)) {
          const remainingQty = item.maxQuantity - item.quantity;
          if (remainingQty > 0) {
            remainingItems.push({
              product_id: item.product_id,
              name: item.name,
              quantity: remainingQty,
              unit_price: item.unit_price,
              notes: ""
            });
          }
        }

        if (remainingItems.length === 0) {
          // Everything is paid
          await posService.updateOrder(order.id, { status: 'BILLED' });
          await posService.closeTable(tableId);
          showNotification("Mesa cobrada en su totalidad", "success");
          onClose();
        } else {
          // Update order with remaining items
          await posService.updateOrder(order.id, { 
            status: 'PENDING',
            items: remainingItems 
          });
          showNotification(`Pago parcial de $${saleTotal.toLocaleString()} registrado`, "success");
          await loadOrder(); // Reload to reflect changes
        }
      } else {
        // Equal parts logic: just deduct the amount from the total
        // The best way for a "partial payment" that isn't itemized is just to 
        // add a negative line item to the order for the remaining bill.
        const remainingItems = [...(order.items || [])];
        remainingItems.push({
          product_id: "00000000-0000-0000-0000-000000000000",
          name: `Pago parcial abonado`,
          quantity: 1,
          unit_price: -saleTotal,
          total: -saleTotal,
          notes: "Abono de cuenta dividida"
        });
        
        await posService.updateOrder(order.id, { 
          status: 'PENDING',
          items: remainingItems.map(i => ({
            product_id: i.product_id,
            name: i.name,
            quantity: i.quantity,
            unit_price: i.unit_price,
            notes: ""
          }))
        });
        showNotification(`Pago de $${saleTotal.toLocaleString()} registrado`, "success");
        await loadOrder();
      }
      
      // Print the partial ticket
      printTicket({
        id: order.id,
        created_at: new Date().toISOString(),
        payment_method: paymentMethod,
        subtotal: saleTotal,
        discount: 0,
        tip: 0,
        total: saleTotal,
        items: saleItems.map(item => ({
          name: item.name,
          quantity: item.quantity,
          unit_price: item.unit_price,
          total: item.quantity * item.unit_price
        })),
        is_mesa: true,
        table_name: tableName
      });
      
    } catch (err: any) {
      showNotification(err.message || "Error al procesar pago", "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>Dividir Cuenta - {tableName}</DialogTitle>
      
      <Tabs value={tab} onChange={(_, v) => setTab(v)} variant="fullWidth">
        <Tab label="Por Ítems (Pago Parcial)" />
        <Tab label="Partes Iguales" />
      </Tabs>
      
      <DialogContent dividers>
        <Typography variant="h6" align="center" gutterBottom>
          Total Restante: ${total.toLocaleString()}
        </Typography>
        
        {tab === 0 && (
          <>
            <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2, mb: 1 }}>
              <Button 
                variant="outlined" 
                size="small" 
                onClick={() => {
                  setSelectedItems(prev => {
                    const next = { ...prev };
                    Object.keys(next).forEach(k => {
                      next[Number(k)].quantity = next[Number(k)].maxQuantity;
                    });
                    return next;
                  });
                }}
              >
                Seleccionar Todo
              </Button>
              <Button 
                variant="outlined" 
                size="small" 
                color="error"
                onClick={() => {
                  setSelectedItems(prev => {
                    const next = { ...prev };
                    Object.keys(next).forEach(k => {
                      next[Number(k)].quantity = 0;
                    });
                    return next;
                  });
                }}
              >
                Deseleccionar Todo
              </Button>
            </Box>
            <List>
              {Object.values(selectedItems).map((item, idx) => {
              if (item.unit_price < 0) {
                return (
                  <ListItem key={idx} divider sx={{ bgcolor: '#f1f5f9' }}>
                    <ListItemText 
                      primary={item.name} 
                      secondary={<span style={{ color: '#059669', fontWeight: 'bold' }}>Abono descontado: -$${Math.abs(item.unit_price).toLocaleString()}</span>} 
                    />
                  </ListItem>
                );
              }
              return (
                <ListItem key={idx} divider>
                  <ListItemText 
                    primary={item.name} 
                    secondary={`Restante: ${item.maxQuantity} x $${item.unit_price.toLocaleString()}`} 
                  />
                  <ListItemSecondaryAction>
                    <Stack direction="row" alignItems="center" spacing={1}>
                      <IconButton size="small" onClick={() => handleQtyChange(idx, -1)} disabled={item.quantity === 0}>
                        <RemoveIcon />
                      </IconButton>
                      <Typography fontWeight="bold" sx={{ minWidth: 20, textAlign: 'center' }}>
                        {item.quantity}
                      </Typography>
                      <IconButton size="small" onClick={() => handleQtyChange(idx, 1)} disabled={item.quantity === item.maxQuantity}>
                        <AddIcon />
                      </IconButton>
                    </Stack>
                  </ListItemSecondaryAction>
                </ListItem>
              );
            })}
          </List>
          </>
        )}
        
        {tab === 1 && (
          <Box sx={{ mt: 3, textAlign: 'center' }}>
            <Typography gutterBottom>¿Entre cuántas personas dividir el total?</Typography>
            <Stack direction="row" alignItems="center" justifyContent="center" spacing={2} sx={{ mb: 3 }}>
              <IconButton color="primary" onClick={() => setEqualParts(Math.max(2, equalParts - 1))}>
                <RemoveIcon />
              </IconButton>
              <Typography variant="h4">{equalParts}</Typography>
              <IconButton color="primary" onClick={() => setEqualParts(equalParts + 1)}>
                <AddIcon />
              </IconButton>
            </Stack>
            
            <Card variant="outlined" sx={{ p: 2, bgcolor: '#f8fafc' }}>
              <Typography variant="subtitle1">Cada parte a pagar:</Typography>
              <Typography variant="h3" color="primary" fontWeight="bold">
                ${Math.round(total / equalParts).toLocaleString()}
              </Typography>
            </Card>
          </Box>
        )}
        
        <Box sx={{ mt: 3 }}>
          <Typography variant="subtitle2" gutterBottom>Medio de pago para esta fracción:</Typography>
          <Stack direction="row" flexWrap="wrap" gap={1}>
            {paymentMethods.map(m => (
              <Chip 
                key={m.value}
                label={m.label}
                color={paymentMethod === m.value ? 'primary' : 'default'}
                onClick={() => setPaymentMethod(m.value as any)}
                variant={paymentMethod === m.value ? 'filled' : 'outlined'}
                clickable
              />
            ))}
          </Stack>
        </Box>
        
      </DialogContent>
      
      <DialogActions sx={{ p: 2, justifyContent: 'space-between' }}>
        <Typography variant="h6">
          A cobrar ahora: ${tab === 0 ? selectedTotal.toLocaleString() : Math.round(total / equalParts).toLocaleString()}
        </Typography>
        <Stack direction="row" spacing={2}>
          <Button onClick={onClose} disabled={loading}>Cerrar</Button>
          <Button 
            variant="contained" 
            color="success" 
            startIcon={<PaymentIcon />}
            onClick={handlePayPartial}
            disabled={loading || (tab === 0 && selectedTotal === 0)}
          >
            Pagar Parte
          </Button>
        </Stack>
      </DialogActions>
    </Dialog>
  );
}

// Sub-component used in Tab 1
const Card = ({ children, ...props }: any) => <Box {...props}>{children}</Box>;
