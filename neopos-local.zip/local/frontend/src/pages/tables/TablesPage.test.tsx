import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { TablesPage } from './TablesPage';
import { useNotificationStore } from '../../stores/notificationStore';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useTableStore } from '../../stores/tableStore';
vi.mock('../../services/posService', () => {
  const localMockTables = Array.from({ length: 120 }, (_, index) => {
    const statuses = ['FREE', 'OCCUPIED', 'RESERVED', 'CLEANING'];
    return {
      id: `table-${index + 1}`,
      number: index + 1,
      capacity: index % 5 === 0 ? 8 : index % 3 === 0 ? 6 : 4,
      status: statuses[index % statuses.length]
    };
  });
  return {
    posService: {
      tables: vi.fn().mockResolvedValue(localMockTables),
      createTable: vi.fn().mockResolvedValue({ id: 'new-table', number: 10, capacity: 4, status: 'FREE' }),
      openTable: vi.fn().mockResolvedValue({}),
      closeTable: vi.fn().mockResolvedValue({}),
      transferTable: vi.fn().mockResolvedValue({}),
      mergeTables: vi.fn().mockResolvedValue({}),
      splitBill: vi.fn().mockResolvedValue({})
    }
  };
});

const queryClient = new QueryClient();

describe('TablesPage', () => {
  beforeEach(() => {
    useNotificationStore.setState({ open: false, message: '', severity: 'info' });
    queryClient.clear();
    const store: Record<string, string> = {};
    Object.defineProperty(window, 'localStorage', {
      value: {
        getItem: (key: string) => store[key] || null,
        setItem: (key: string, value: string) => { store[key] = value; },
        removeItem: (key: string) => { delete store[key]; },
        clear: () => { for (const k in store) { delete store[k]; } },
        length: 0,
        key: (index: number) => Object.keys(store)[index] || null
      },
      writable: true,
      configurable: true
    });
  });

  it('triggers notification on Nueva mesa button click with valid input', () => {
    render(
      <MemoryRouter>
        <QueryClientProvider client={queryClient}>
          <TablesPage />
        </QueryClientProvider>
      </MemoryRouter>
    );
    // Toggle edit mode to show "Nueva mesa"
    const editBtn = screen.getByText("Editar mesas");
    fireEvent.click(editBtn);

    const btn = screen.getByText("Nueva mesa");
    fireEvent.click(btn);

    const input = screen.getByLabelText(/Número de mesa/i);
    fireEvent.change(input, { target: { value: '10' } });

    const confirmBtn = screen.getByText("Confirmar");
    fireEvent.click(confirmBtn);

    const store = useNotificationStore.getState();
    expect(store.open).toBe(true);
    expect(store.message).toContain('Creando mesa');
  });

  it('triggers notification on Transferir mesa with selected table', () => {
    // Set a selected table in the store
    useTableStore.setState({ selectedTable: { id: 't1', number: 1, capacity: 4, status: 'FREE' } });
    
    render(
      <MemoryRouter>
        <QueryClientProvider client={queryClient}>
          <TablesPage />
        </QueryClientProvider>
      </MemoryRouter>
    );
    const btn = screen.getByText("Transferir mesa");
    fireEvent.click(btn);

    const input = screen.getByLabelText(/Número de mesa destino/i);
    fireEvent.change(input, { target: { value: '5' } });

    const confirmBtn = screen.getByText("Confirmar");
    fireEvent.click(confirmBtn);

    const store = useNotificationStore.getState();
    expect(store.open).toBe(true);
    expect(store.message).toContain('Transfiriendo mesa...');
  });

  it('triggers notification on Unir mesas button click', () => {
    useTableStore.setState({ selectedTable: { id: 't1', number: 1, capacity: 4, status: 'FREE' } });
    render(
      <MemoryRouter>
        <QueryClientProvider client={queryClient}>
          <TablesPage />
        </QueryClientProvider>
      </MemoryRouter>
    );
    const btn = screen.getByText("Unir mesas");
    fireEvent.click(btn);

    const input = screen.getByLabelText(/Número de mesa destino/i);
    fireEvent.change(input, { target: { value: '2' } });

    const confirmBtn = screen.getByText("Confirmar");
    fireEvent.click(confirmBtn);

    const store = useNotificationStore.getState();
    expect(store.open).toBe(true);
    expect(store.message).toContain('Uniendo mesas...');
  });

  it('triggers notification on Dividir cuenta button click', () => {
    useTableStore.setState({ selectedTable: { id: 't1', number: 1, capacity: 4, status: 'FREE' } });
    render(
      <MemoryRouter>
        <QueryClientProvider client={queryClient}>
          <TablesPage />
        </QueryClientProvider>
      </MemoryRouter>
    );
    const btn = screen.getByText("Dividir cuenta");
    fireEvent.click(btn);

    const input = screen.getByLabelText(/Monto a dividir o ID de orden/i);
    fireEvent.change(input, { target: { value: '50000' } });

    const confirmBtn = screen.getByText("Confirmar");
    fireEvent.click(confirmBtn);

    const store = useNotificationStore.getState();
    expect(store.open).toBe(true);
    expect(store.message).toContain('Dividiendo cuenta...');
  });
});
