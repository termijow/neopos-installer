import {
  Box,
  Button,
  Chip,
  CircularProgress,
  Grid,
  InputAdornment,
  MenuItem,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from '@mui/material';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import SearchIcon from '@mui/icons-material/Search';
import { useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import type { Client } from '../../types/domain';
import { PageHeader } from '../../components/PageHeader';
import { AppPagination } from '../../components/AppPagination';
import { posService } from '../../services/posService';
import { useNotificationStore } from '../../stores/notificationStore';

type ClientFormValues = Omit<Client, 'id'>;

const DEFAULT_FORM: ClientFormValues = {
  document_type: 'CC',
  document: '',
  name: '',
  email: '',
  phone: '',
};

export function ClientsPage() {
  const queryClient = useQueryClient();
  const showNotification = useNotificationStore((state) => state.showNotification);

  // ── Pagination & search state ────────────────────────────────────────────
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [search, setSearch] = useState('');

  // ── Form ─────────────────────────────────────────────────────────────────
  const { register, handleSubmit, reset, watch } = useForm<ClientFormValues>({
    defaultValues: DEFAULT_FORM,
  });
  const documentTypeValue = watch('document_type');

  // ── Fetch clients ─────────────────────────────────────────────────────────
  const {
    data: clients = [],
    isLoading,
  } = useQuery<Client[]>({
    queryKey: ['clients'],
    queryFn: () => posService.clients(),
  });

  // ── Create client mutation ────────────────────────────────────────────────
  const createMutation = useMutation<Client, Error, ClientFormValues>({
    mutationFn: (payload) => posService.createClient(payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clients'] });
      reset(DEFAULT_FORM);
      showNotification('Cliente creado correctamente', 'success');
    },
    onError: (err) => {
      showNotification(err.message ?? 'Error al crear cliente', 'error');
    },
  });

  // ── Client-side filtering ─────────────────────────────────────────────────
  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    if (!q) return clients;
    return clients.filter((c) =>
      `${c.document} ${c.name}`.toLowerCase().includes(q)
    );
  }, [clients, search]);

  // ── Pagination slice ──────────────────────────────────────────────────────
  const paginated = useMemo(
    () => filtered.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage),
    [filtered, page, rowsPerPage]
  );

  const handlePageChange = (newPage: number) => setPage(newPage);
  const handleRowsPerPageChange = (newRowsPerPage: number) => {
    setRowsPerPage(newRowsPerPage);
    setPage(0);
  };

  const onSubmit = (values: ClientFormValues) => {
    createMutation.mutate(values);
  };

  return (
    <Stack spacing={3}>
      <PageHeader title="Clientes" subtitle="Datos para facturación POS y electrónica." />

      <Grid container spacing={2}>
        {/* ── Create form ─────────────────────────────────────────────── */}
        <Grid item xs={12} md={4}>
          <Paper
            component="form"
            sx={{ p: 2 }}
            onSubmit={handleSubmit(onSubmit)}
          >
            <Stack spacing={2}>
              <Typography variant="h6">Crear cliente</Typography>

              <TextField
                label="Tipo documento"
                select
                value={documentTypeValue}
                {...register('document_type')}
              >
                <MenuItem value="CC">Cédula (CC)</MenuItem>
                <MenuItem value="NIT">NIT</MenuItem>
                <MenuItem value="CE">Cédula Extranjería (CE)</MenuItem>
                <MenuItem value="PASSPORT">Pasaporte</MenuItem>
              </TextField>

              <TextField
                label="Documento"
                {...register('document', { required: true })}
              />
              <TextField
                label="Nombre"
                {...register('name', { required: true })}
              />
              <TextField
                label="Correo"
                type="email"
                {...register('email')}
              />
              <TextField
                label="Teléfono"
                {...register('phone')}
              />

              <Button
                type="submit"
                variant="contained"
                startIcon={<PersonAddIcon />}
                disabled={createMutation.isPending}
              >
                {createMutation.isPending ? 'Guardando…' : 'Crear cliente'}
              </Button>
            </Stack>
          </Paper>
        </Grid>

        {/* ── Client list ──────────────────────────────────────────────── */}
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 2 }}>
            <Stack spacing={2}>
              {/* Search + count */}
              <Stack direction="row" spacing={2} alignItems="center">
                <TextField
                  label="Buscar cliente"
                  value={search}
                  onChange={(e) => {
                    setSearch(e.target.value);
                    setPage(0);
                  }}
                  fullWidth
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchIcon sx={{ color: 'text.secondary' }} />
                      </InputAdornment>
                    ),
                  }}
                />
                <Chip
                  label={`${filtered.length} cliente${filtered.length !== 1 ? 's' : ''}`}
                  color="primary"
                  variant="outlined"
                  sx={{ whiteSpace: 'nowrap' }}
                />
              </Stack>

              {/* Loading state */}
              {isLoading && (
                <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
                  <CircularProgress />
                </Box>
              )}

              {/* Empty state */}
              {!isLoading && filtered.length === 0 && (
                <Box sx={{ textAlign: 'center', py: 6 }}>
                  <Typography color="text.secondary">
                    {search
                      ? 'No se encontraron clientes con esa búsqueda.'
                      : 'Aún no hay clientes registrados.'}
                  </Typography>
                </Box>
              )}

              {/* Table */}
              {!isLoading && filtered.length > 0 && (
                <>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Tipo / Doc.</TableCell>
                        <TableCell>Nombre</TableCell>
                        <TableCell>Correo</TableCell>
                        <TableCell>Teléfono</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {paginated.map((client) => (
                        <TableRow key={client.id} hover>
                          <TableCell>
                            {client.document_type} {client.document}
                          </TableCell>
                          <TableCell>{client.name}</TableCell>
                          <TableCell>{client.email}</TableCell>
                          <TableCell>{client.phone}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>

                  <AppPagination
                    count={filtered.length}
                    page={page}
                    rowsPerPage={rowsPerPage}
                    onPageChange={handlePageChange}
                    onRowsPerPageChange={handleRowsPerPageChange}
                    labelRowsPerPage="Clientes por página:"
                    rowsPerPageOptions={[5, 10, 25, 50]}
                  />
                </>
              )}
            </Stack>
          </Paper>
        </Grid>
      </Grid>
    </Stack>
  );
}
