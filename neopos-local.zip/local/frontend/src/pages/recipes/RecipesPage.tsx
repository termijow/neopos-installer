import { zodResolver } from '@hookform/resolvers/zod';
import { Button, Grid, IconButton, Paper, Stack, Table, TableBody, TableCell, TableHead, TableRow, TextField, Typography, Autocomplete, MenuItem, Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import SearchIcon from '@mui/icons-material/Search';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { useForm, useFieldArray, Controller } from 'react-hook-form';
import { z } from 'zod';
import { PageHeader } from '../../components/PageHeader';
import { AppPagination } from '../../components/AppPagination';
import { posService } from '../../services/posService';
import { useSnackbar } from 'notistack';
import type { Recipe } from '../../types/domain';

const itemSchema = z.object({
  inventory_item_id: z.string().min(1, "Requerido"),
  quantity: z.coerce.number().min(0.01, "Mínimo 0.01"),
  unit: z.string().min(1, "Requerido"),
});

const schema = z.object({
  id: z.string().optional(),
  product_id: z.string().min(1, "Producto principal requerido"),
  description: z.string().optional(),
  yield: z.coerce.number().min(1, "Mínimo 1 porción"),
  items: z.array(itemSchema).min(1, "Debe agregar al menos un insumo"),
});

type RecipeForm = z.infer<typeof schema>;

export function RecipesPage() {
  const queryClient = useQueryClient();
  const { enqueueSnackbar } = useSnackbar();
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  
  const { data: prodData } = useQuery({ queryKey: ['products'], queryFn: () => posService.products(1, 1000) });
  const isServerPaginatedProd = prodData && !Array.isArray(prodData) && 'data' in prodData;
  const products: any[] = (isServerPaginatedProd ? (prodData as any).data : (Array.isArray(prodData) ? prodData : [])) || [];
  
  const { data: catData } = useQuery({ queryKey: ['categories'], queryFn: posService.categories });
  const categoriesList = Array.isArray(catData) ? catData : [];
  const insumosCatId = categoriesList.find((c: any) => c.name.toUpperCase() === 'INSUMOS')?.id;
  const insumosProducts = products.filter(p => p.category_id === insumosCatId || p.category?.name?.toUpperCase() === 'INSUMOS' || (typeof p.category === 'string' && p.category.toUpperCase() === 'INSUMOS'));

  const { data: recipesData } = useQuery({ queryKey: ['recipes'], queryFn: () => posService.recipes(1, 1000) });
  
  const recipesList: Recipe[] = (recipesData && !Array.isArray(recipesData) && 'data' in (recipesData as any)) 
    ? (recipesData as any).data 
    : (Array.isArray(recipesData) ? recipesData : []);

  const allFilteredRecipes = recipesList.filter((r: Recipe) => {
    const prodName = products.find((p: any) => p.id === r.product_id)?.name || '';
    return prodName.toLowerCase().includes(search.toLowerCase()) || r.description?.toLowerCase().includes(search.toLowerCase());
  });

  const displayRecipes = allFilteredRecipes.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);


  const [duplicateRecipeFound, setDuplicateRecipeFound] = useState<Recipe | null>(null);

  const { register, control, handleSubmit, reset, getValues, formState: { errors } } = useForm<RecipeForm>({
    resolver: zodResolver(schema),
    defaultValues: { product_id: '', description: '', yield: 1, items: [{ inventory_item_id: '', quantity: 1, unit: 'g' }] }
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: "items"
  });

  const saveMutation = useMutation({ 
    mutationFn: async (data: RecipeForm) => {
      if (data.id) {
        return posService.updateRecipe(data.id, data);
      }
      return posService.createRecipe(data);
    }, 
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recipes'] });
      enqueueSnackbar('Receta guardada exitosamente', { variant: 'success' });
      reset({ product_id: '', description: '', yield: 1, items: [{ inventory_item_id: '', quantity: 1, unit: 'g' }] });
    },
    onError: (err: any) => {
      enqueueSnackbar(err.message || 'Error al guardar receta', { variant: 'error' });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => posService.deleteRecipe(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recipes'] });
      enqueueSnackbar('Receta eliminada', { variant: 'success' });
    },
    onError: (err: any) => {
      enqueueSnackbar(err.message || 'Error al eliminar', { variant: 'error' });
    }
  });

  const handleEdit = (recipe: Recipe) => {
    reset({
      id: recipe.id,
      product_id: recipe.product_id,
      description: recipe.description,
      yield: recipe.yield,
      items: recipe.items.map(i => ({
        inventory_item_id: i.inventory_item_id,
        quantity: i.quantity,
        unit: i.unit
      }))
    });
  };


  const onSubmit = (values: RecipeForm) => {
    if (!values.id) {
      const existing = recipesList.find((r: Recipe) => r.product_id === values.product_id);
      if (existing) {
        setDuplicateRecipeFound(existing);
        return;
      }
    }
    saveMutation.mutate(values);
  };


  return (
    <>
    <Stack spacing={3}>
      <PageHeader title="Recetas" subtitle="Configuración de recetas y cálculo de insumos." />
      <Grid container spacing={2}>
        <Grid item xs={12} lg={4}>
          <Paper component="form" sx={{ p: 2 }} onSubmit={handleSubmit(onSubmit)}>
            <Stack spacing={2}>
              <Typography variant="h6">Crear / Editar Receta</Typography>
              
              <Controller
                name="product_id"
                control={control}
                render={({ field }) => (
                  <Autocomplete
                    options={products}
                    getOptionLabel={(option) => option.name}
                    value={products.find(p => p.id === field.value) || null}
                    onChange={(_, newValue) => field.onChange(newValue ? newValue.id : '')}
                    renderInput={(params) => (
                      <TextField {...params} label="Producto Principal" error={!!errors.product_id} helperText={errors.product_id?.message} />
                    )}
                  />
                )}
              />

              <TextField label="Descripción (Opcional)" {...register('description')} />
              <TextField label="Rendimiento (Porciones)" type="number" {...register('yield')} error={!!errors.yield} helperText={errors.yield?.message} />
              
              <Typography variant="subtitle2" sx={{ mt: 2 }}>Insumos (Ingredientes)</Typography>
              {fields.map((field, index) => (
                <Stack direction="row" spacing={1} key={field.id} alignItems="flex-start">
                  <Controller
                    name={`items.${index}.inventory_item_id`}
                    control={control}
                    render={({ field: selectField }) => (
                      <Autocomplete
                        options={insumosProducts}
                        getOptionLabel={(option) => option.name}
                        value={insumosProducts.find(p => p.id === selectField.value) || null}
                        onChange={(_, newValue) => selectField.onChange(newValue ? newValue.id : '')}
                        sx={{ flexGrow: 1 }}
                        renderInput={(params) => (
                          <TextField 
                            {...params} 
                            label="Buscar Insumo" 
                            size="small"
                            error={!!errors.items?.[index]?.inventory_item_id} 
                          />
                        )}
                      />
                    )}
                  />
                  
                  <TextField 
                    size="small" 
                    type="number" 
                    label="Cant" 
                    inputProps={{ step: "0.01" }}
                    {...register(`items.${index}.quantity`)} 
                    error={!!errors.items?.[index]?.quantity}
                    sx={{ width: '80px' }} 
                  />
                  <TextField 
                    select
                    size="small" 
                    label="Und" 
                    {...register(`items.${index}.unit`)} 
                    error={!!errors.items?.[index]?.unit}
                    sx={{ width: '80px' }} 
                    defaultValue="g"
                  >
                    <MenuItem value="g">g</MenuItem>
                    <MenuItem value="kg">kg</MenuItem>
                    <MenuItem value="ml">ml</MenuItem>
                    <MenuItem value="L">L</MenuItem>
                    <MenuItem value="und">und</MenuItem>
                    <MenuItem value="oz">oz</MenuItem>
                    <MenuItem value="lb">lb</MenuItem>
                  </TextField>
                  <IconButton size="small" color="error" onClick={() => remove(index)} sx={{ mt: 0.5 }}>
                    <DeleteIcon />
                  </IconButton>
                </Stack>
              ))}
              
              <Button size="small" variant="outlined" startIcon={<AddIcon />} onClick={() => append({ inventory_item_id: '', quantity: 1, unit: 'g' })}>
                Agregar Insumo
              </Button>

              <Button type="submit" variant="contained" sx={{ mt: 2 }} disabled={saveMutation.isPending}>
                {saveMutation.isPending ? 'Guardando...' : 'Guardar Receta'}
              </Button>
              <Button type="button" variant="text" onClick={() => reset({ product_id: '', description: '', yield: 1, items: [{ inventory_item_id: '', quantity: 1, unit: 'g' }] })}>
                Limpiar Formulario
              </Button>
            </Stack>
          </Paper>
        </Grid>
        <Grid item xs={12} lg={8}>
          <Paper sx={{ p: 2 }}>
            <Stack spacing={2}>
              <TextField 
                label="Buscar receta por producto o descripción" 
                value={search} 
                onChange={(event) => {
                  setSearch(event.target.value);
                  setPage(0);
                }} 
                InputProps={{ startAdornment: <SearchIcon sx={{ mr: 1, color: 'text.secondary' }} /> }} 
              />
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Producto Principal</TableCell>
                    <TableCell>Descripción</TableCell>
                    <TableCell>Rendimiento</TableCell>
                    <TableCell>Insumos</TableCell>
                    <TableCell align="right">Acciones</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {displayRecipes.map((recipe) => (
                    <TableRow key={recipe.id}>
                      <TableCell>{products.find(p => p.id === recipe.product_id)?.name || 'Desconocido'}</TableCell>
                      <TableCell>{recipe.description}</TableCell>
                      <TableCell>{recipe.yield}</TableCell>
                      <TableCell>{recipe.items?.length || 0} items</TableCell>
                      <TableCell align="right">
                        <IconButton onClick={() => handleEdit(recipe)}><EditIcon /></IconButton>
                        <IconButton color="error" onClick={() => { if(window.confirm('¿Eliminar receta?')) deleteMutation.mutate(recipe.id) }}><DeleteIcon /></IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                  {displayRecipes.length === 0 && (
                     <TableRow>
                       <TableCell colSpan={5} align="center">No hay recetas guardadas.</TableCell>
                     </TableRow>
                  )}
                </TableBody>
              </Table>
              <AppPagination
                count={allFilteredRecipes.length}
                page={page}
                onPageChange={(newPage) => setPage(newPage)}
                rowsPerPage={rowsPerPage}
                onRowsPerPageChange={(newRowsPerPage) => {
                  setRowsPerPage(newRowsPerPage);
                  setPage(0);
                }}
                labelRowsPerPage="Recetas por página:"
              />

            </Stack>
          </Paper>
        </Grid>
      </Grid>
    </Stack>

      <Dialog open={!!duplicateRecipeFound} onClose={() => setDuplicateRecipeFound(null)}>
        <DialogTitle>Receta Existente</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Este producto ya tiene una receta configurada. ¿Deseas cargar la receta existente para editarla?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDuplicateRecipeFound(null)}>Cancelar</Button>
          <Button variant="contained" onClick={() => {
            if (duplicateRecipeFound) handleEdit(duplicateRecipeFound);
            setDuplicateRecipeFound(null);
          }}>
            Editar Receta
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
