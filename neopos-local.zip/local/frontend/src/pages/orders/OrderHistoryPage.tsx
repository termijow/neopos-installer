import { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { posService } from '../../services/posService';
import { useNavigate } from 'react-router-dom';
import { 
  Box, 
  Card, 
  CardContent, 
  Chip, 
  Grid, 
  Paper, 
  Stack, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow, 
  Typography,
  TextField,
  InputAdornment,
  IconButton,
  Button,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Divider,
  List,
  ListItem,
  ListItemText
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import ReceiptLongIcon from '@mui/icons-material/ReceiptLong';
import FilterListIcon from '@mui/icons-material/FilterList';
import VisibilityIcon from '@mui/icons-material/Visibility';
import PrintIcon from '@mui/icons-material/Print';
import DocumentScannerIcon from '@mui/icons-material/DocumentScanner';
import { PageHeader } from '../../components/PageHeader';
import { AppPagination } from '../../components/AppPagination';
import { cop } from '../../utils/format';
import { printReceipt } from '../../utils/printReceipt';
import { useSettingsStore } from '../../stores/settingsStore';

const formatPaymentMethod = (method: string) => {
  switch (method?.toUpperCase()) {
    case 'CASH':
    case 'EFECTIVO':
      return { label: 'Efectivo', color: '#16a34a', bg: 'rgba(22, 163, 74, 0.1)' };
    case 'CREDIT_CARD':
      return { label: 'T. Crédito', color: '#2563eb', bg: 'rgba(37, 99, 235, 0.1)' };
    case 'DEBIT_CARD':
      return { label: 'T. Débito', color: '#0891b2', bg: 'rgba(8, 145, 178, 0.1)' };
    case 'TRANSFER':
      return { label: 'Transferencia', color: '#8b5cf6', bg: 'rgba(139, 92, 246, 0.1)' };
    case 'QR':
      return { label: 'QR / Nequi', color: '#d946ef', bg: 'rgba(217, 70, 239, 0.1)' };
    default:
      return { label: method || 'N/A', color: '#64748b', bg: 'rgba(100, 116, 139, 0.1)' };
  }
};

export function OrderHistoryPage() {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(50);
  const [selectedInvoice, setSelectedInvoice] = useState<any>(null);
  const { autoFocusSearch } = useSettingsStore();
  const navigate = useNavigate();

  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [elecInvoiceDialog, setElecInvoiceDialog] = useState<{open: boolean, type: 'success' | 'error', message: string}>({open: false, type: 'success', message: ''});
  const [elecInvoiceModalOpen, setElecInvoiceModalOpen] = useState(false);

  const { data: sales = [], isLoading } = useQuery({
    queryKey: ['salesHistory'],
    queryFn: posService.salesHistory,
    refetchInterval: 15000
  });

  const filteredInvoices = useMemo(() => {
    return sales.filter((inv: any) => 
      (inv.id && inv.id.toLowerCase().includes(search.toLowerCase())) || 
      (inv.payment_method && inv.payment_method.toLowerCase().includes(search.toLowerCase()))
    );
  }, [sales, search]);

  const electronicInvoices = useMemo(() => {
    return sales.filter((inv: any) => inv.is_electronic);
  }, [sales]);

  const paginatedInvoices = useMemo(() => {
    return filteredInvoices.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);
  }, [filteredInvoices, page, rowsPerPage]);

  const totalSales = sales.reduce((sum: number, sale: any) => sum + (sale.total || 0), 0);
  const avgTicket = sales.length > 0 ? totalSales / sales.length : 0;

  const handleOpenDetail = (inv: any) => {
    setSelectedInvoice(inv);
    setIsDetailOpen(true);
  };

  const handleCloseDetail = () => {
    setIsDetailOpen(false);
    setSelectedInvoice(null);
  };

  const handlePrint = (inv: any) => {
    printReceipt(inv);
  };

  const handleElectronicInvoice = async (inv: any) => {
    try {
      await posService.markAsElectronicInvoice(inv.id);
      setElecInvoiceDialog({
        open: true,
        type: 'success',
        message: 'Factura marcada para emisión electrónica. Se sincronizará con la nube pronto.'
      });
    } catch (e: any) {
      setElecInvoiceDialog({
        open: true,
        type: 'error',
        message: `Error al procesar la factura electrónica: ${e.message || 'Error del servidor'}`
      });
    }
  };

  return (
    <Stack spacing={3}>
      <Box onDoubleClick={() => navigate('/debug')} sx={{ cursor: 'default' }}>
        <PageHeader 
          title="Historial de Pedidos" 
          subtitle="Registro de las facturas y pedidos recientes del día." 
        />
      </Box>

      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Card sx={{ bgcolor: 'primary.main', color: 'white', borderRadius: 3 }}>
            <CardContent>
              <Typography variant="body2" sx={{ opacity: 0.8, mb: 1, fontWeight: 'bold' }}>
                Ventas del Día
              </Typography>
              <Typography variant="h4" sx={{ fontWeight: 800 }}>
                {cop(totalSales)}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card sx={{ bgcolor: '#0f172a', color: 'white', borderRadius: 3 }}>
            <CardContent>
              <Typography variant="body2" sx={{ opacity: 0.8, mb: 1, fontWeight: 'bold' }}>
                Total Facturas
              </Typography>
              <Typography variant="h4" sx={{ fontWeight: 800 }}>
                {sales.length}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card sx={{ bgcolor: '#0891b2', color: 'white', borderRadius: 3 }}>
            <CardContent>
              <Typography variant="body2" sx={{ opacity: 0.8, mb: 1, fontWeight: 'bold' }}>
                Ticket Promedio
              </Typography>
              <Typography variant="h4" sx={{ fontWeight: 800 }}>
                {cop(avgTicket)}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Paper sx={{ p: 0, borderRadius: 3, overflow: 'hidden', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.05)' }}>
        <Box sx={{ p: 2, display: 'flex', gap: 2, alignItems: 'center', bgcolor: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
          <TextField
            size="small"
            placeholder="Buscar por # factura o mesa..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            autoFocus={autoFocusSearch}
            sx={{ width: 300, bgcolor: 'white', borderRadius: 1.5, '& fieldset': { borderRadius: 1.5 } }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ color: '#94a3b8' }} />
                </InputAdornment>
              ),
            }}
          />
          <Button variant="outlined" startIcon={<FilterListIcon />} sx={{ bgcolor: 'white' }}>
            Filtrar
          </Button>
        </Box>

        <TableContainer>
          <Table>
            <TableHead sx={{ bgcolor: '#f1f5f9' }}>
              <TableRow>
                <TableCell sx={{ fontWeight: 'bold', color: '#475569' }}># Factura</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#475569' }}>Hora</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#475569' }}>Origen</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#475569' }}>Método</TableCell>
                <TableCell align="right" sx={{ fontWeight: 'bold', color: '#475569' }}>Total</TableCell>
                <TableCell align="center" sx={{ fontWeight: 'bold', color: '#475569' }}>Acciones</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={6} align="center" sx={{ py: 6 }}>
                    <CircularProgress />
                  </TableCell>
                </TableRow>
              ) : paginatedInvoices.length > 0 ? (
                paginatedInvoices.map((inv: any) => {
                  const displayId = inv.id ? inv.id.split('-')[0].toUpperCase() : 'UNKNOWN';
                  const dateStr = inv.created_at ? new Date(inv.created_at).toLocaleString() : 'N/A';
                  const isMesa = inv.order_id && inv.order_id !== '00000000-0000-0000-0000-000000000000';
                  
                  return (
                  <TableRow key={inv.id} hover sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                    <TableCell>
                      <Stack direction="row" alignItems="center" gap={1}>
                        <ReceiptLongIcon sx={{ color: '#94a3b8', fontSize: 20 }} />
                        <Typography variant="body2" fontWeight="bold" color="primary.main">
                          {displayId}
                        </Typography>
                      </Stack>
                    </TableCell>
                    <TableCell>{dateStr}</TableCell>
                    <TableCell>
                      <Chip 
                        label={isMesa ? 'Mesa' : 'Caja Rápida'} 
                        size="small" 
                        sx={{ 
                          bgcolor: isMesa ? 'rgba(8, 145, 178, 0.1)' : 'rgba(245, 158, 11, 0.1)',
                          color: isMesa ? '#0891b2' : '#d97706',
                          fontWeight: 'bold',
                          borderRadius: 1.5
                        }} 
                      />
                    </TableCell>
                    <TableCell>
                      {(() => {
                        const pm = formatPaymentMethod(inv.payment_method);
                        return (
                          <Chip 
                            label={pm.label} 
                            size="small" 
                            sx={{ 
                              bgcolor: pm.bg,
                              color: pm.color,
                              fontWeight: 'bold',
                              borderRadius: 1.5
                            }} 
                          />
                        );
                      })()}
                    </TableCell>
                    <TableCell align="right">
                      <Typography variant="body2" fontWeight="bold" sx={{ color: '#0f172a' }}>
                        {cop(inv.total)}
                      </Typography>
                    </TableCell>
                    <TableCell align="center">
                      <IconButton size="small" sx={{ color: '#0f172a' }} onClick={() => handleOpenDetail(inv)} title="Ver Detalles">
                        <VisibilityIcon fontSize="small" />
                      </IconButton>
                      <IconButton size="small" sx={{ color: '#0891b2' }} onClick={() => handlePrint(inv)} title="Imprimir Recibo">
                        <PrintIcon fontSize="small" />
                      </IconButton>
                      <IconButton size="small" sx={{ color: '#d97706' }} onClick={() => handleElectronicInvoice(inv)} title="Generar Factura Electrónica">
                        <DocumentScannerIcon fontSize="small" />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                  );
                })
              ) : (
                <TableRow>
                  <TableCell colSpan={6} align="center" sx={{ py: 6 }}>
                    <Typography color="text.secondary">
                      {search ? `No se encontraron facturas con "${search}"` : "No se encontraron facturas"}
                    </Typography>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
              {filteredInvoices.length > 0 && (
                <AppPagination
                  count={filteredInvoices.length}
                  page={page}
                  onPageChange={(newPage) => setPage(newPage)}
                  rowsPerPage={rowsPerPage}
                  onRowsPerPageChange={(newRowsPerPage) => {
                    setRowsPerPage(newRowsPerPage);
                    setPage(0);
                  }}
                  labelRowsPerPage="Facturas por página:"
                />
              )}
        </TableContainer>
      </Paper>

      <Dialog open={isDetailOpen} onClose={handleCloseDetail} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ fontWeight: 'bold', borderBottom: '1px solid #e2e8f0' }}>
          Detalles de la Factura
        </DialogTitle>
        <DialogContent sx={{ mt: 2 }}>
          {selectedInvoice && (
            <Stack spacing={2}>
              <Box>
                <Typography variant="caption" color="text.secondary">Factura ID</Typography>
                <Typography variant="body1" fontWeight="bold">{selectedInvoice.id.split('-')[0].toUpperCase()}</Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">Fecha y Hora</Typography>
                <Typography variant="body1">{new Date(selectedInvoice.created_at).toLocaleString()}</Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">Método de Pago</Typography>
                <Typography variant="body1">{selectedInvoice.payment_method}</Typography>
              </Box>

              <Divider sx={{ my: 1 }} />
              
              <Typography variant="subtitle2" fontWeight="bold" sx={{ mb: 1 }}>Productos</Typography>
              <List disablePadding>
                {selectedInvoice.items && selectedInvoice.items.length > 0 ? (
                  selectedInvoice.items.map((item: any, idx: number) => (
                    <ListItem key={idx} sx={{ px: 0, py: 0.5 }}>
                      <ListItemText 
                        primary={`${item.quantity}x ${item.name}`} 
                        secondary={`$${cop(item.unit_price)} c/u`} 
                      />
                      <Typography variant="body2" fontWeight="bold">
                        {cop(item.total)}
                      </Typography>
                    </ListItem>
                  ))
                ) : (
                  <Typography variant="body2" color="text.secondary">No hay productos registrados.</Typography>
                )}
              </List>

              <Divider sx={{ my: 1 }} />

              <Stack spacing={1}>
                <Stack direction="row" justifyContent="space-between">
                  <Typography variant="body2" color="text.secondary">Subtotal</Typography>
                  <Typography variant="body2">{cop(selectedInvoice.subtotal || 0)}</Typography>
                </Stack>
                {selectedInvoice.discount > 0 && (
                  <Stack direction="row" justifyContent="space-between">
                    <Typography variant="body2" color="text.secondary">Descuento</Typography>
                    <Typography variant="body2" color="error">-{cop(selectedInvoice.discount)}</Typography>
                  </Stack>
                )}
                {selectedInvoice.tip > 0 && (
                  <Stack direction="row" justifyContent="space-between">
                    <Typography variant="body2" color="text.secondary">Propina</Typography>
                    <Typography variant="body2">{cop(selectedInvoice.tip)}</Typography>
                  </Stack>
                )}
                <Stack direction="row" justifyContent="space-between" sx={{ mt: 1 }}>
                  <Typography variant="subtitle1" fontWeight="bold">Total</Typography>
                  <Typography variant="subtitle1" fontWeight="bold">{cop(selectedInvoice.total)}</Typography>
                </Stack>
              </Stack>
            </Stack>
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2, borderTop: '1px solid #e2e8f0' }}>
          <Button onClick={handleCloseDetail} color="inherit">Cerrar</Button>
          <Button 
            variant="outlined" 
            color="secondary"
            onClick={() => {
              if (selectedInvoice) handleElectronicInvoice(selectedInvoice);
            }} 
            startIcon={<DocumentScannerIcon />}
          >
            F. Electrónica
          </Button>
          <Button 
            variant="contained" 
            onClick={() => {
              if (selectedInvoice) handlePrint(selectedInvoice);
            }} 
            startIcon={<PrintIcon />}
          >
            Imprimir
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog 
        open={elecInvoiceDialog.open} 
        onClose={() => setElecInvoiceDialog({ ...elecInvoiceDialog, open: false })}
        maxWidth="xs"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: 3,
            borderTop: `4px solid ${elecInvoiceDialog.type === 'success' ? '#16a34a' : '#dc2626'}`,
            boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1)'
          }
        }}
      >
        <DialogTitle sx={{ fontWeight: 'bold', color: elecInvoiceDialog.type === 'success' ? '#16a34a' : '#dc2626' }}>
          {elecInvoiceDialog.type === 'success' ? 'Éxito' : 'Error'}
        </DialogTitle>
        <DialogContent>
          <Typography>{elecInvoiceDialog.message}</Typography>
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button 
            onClick={() => setElecInvoiceDialog({ ...elecInvoiceDialog, open: false })} 
            variant="contained" 
            sx={{ bgcolor: '#0f172a', color: 'white', '&:hover': { bgcolor: '#1e293b' }, borderRadius: 2 }}
          >
            Aceptar
          </Button>
        </DialogActions>
      </Dialog>
    </Stack>
  );
}
