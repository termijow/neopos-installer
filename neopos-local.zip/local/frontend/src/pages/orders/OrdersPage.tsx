import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Box, 
  Button, 
  Card, 
  CardActionArea, 
  CardContent, 
  Divider, 
  Grid, 
  IconButton, 
  Paper, 
  Stack, 
  TextField, 
  Typography, 
  InputAdornment, 
  Chip, 
  Tooltip,
  List,
  ListItemButton,
  ListItemText,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import DeleteIcon from '@mui/icons-material/Delete';
import SendIcon from '@mui/icons-material/Send';
import SearchIcon from '@mui/icons-material/Search';
import LockIcon from '@mui/icons-material/Lock';
import LockOpenIcon from '@mui/icons-material/LockOpen';
import RestaurantIcon from '@mui/icons-material/Restaurant';
import CloseIcon from '@mui/icons-material/Close';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { PageHeader } from '../../components/PageHeader';
import { AppPagination } from '../../components/AppPagination';
import { posService } from '../../services/posService';
import { useOrderStore } from '../../stores/orderStore';
import { useTableStore } from '../../stores/tableStore';
import { useNotificationStore } from '../../stores/notificationStore';
import { useAuthStore } from '../../stores/authStore';
import { useSettingsStore } from '../../stores/settingsStore';
import { cop } from '../../utils/format';
import { mockCategories, mockProducts, mockTables } from '../../utils/mockData';
import type { RestaurantTable } from '../../types/domain';
import { OverrideDialog } from '../../components/OverrideDialog';
import { CheckoutDialog } from '../../components/CheckoutDialog';

export function OrdersPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { role } = useAuthStore();
  const isCashier = role === 'cashier';
  const { selectedTable, setSelectedTable } = useTableStore();
  const { items, notes, addProduct, removeItem, updateQuantity, updatePrice, setNotes, clear } = useOrderStore();
  const { autoFocusSearch, showProductImages, showNegativeInventoryWarning } = useSettingsStore();

  const [activeTab, setActiveTab] = useState<'new' | 'account'>(
    selectedTable?.status === 'OCCUPIED' ? 'account' : 'new'
  );
  const defaultTipPercent = useSettingsStore(state => state.defaultTipPercent);
  const [tipType, setTipType] = useState<'disabled' | 'percent' | 'fixed'>(defaultTipPercent > 0 ? 'percent' : 'disabled');
  const [tipValue, setTipValue] = useState<number>(defaultTipPercent > 0 ? defaultTipPercent : 10);

  useEffect(() => {
    setActiveTab(selectedTable?.status === 'OCCUPIED' ? 'account' : 'new');
  }, [selectedTable]);

  const totalQuantity = items.reduce((sum, item) => sum + item.quantity, 0);
  const prevTotalQuantityRef = useRef(totalQuantity);

  useEffect(() => {
    if (totalQuantity > prevTotalQuantityRef.current && totalQuantity > 0) {
      setActiveTab('new');
    }
    prevTotalQuantityRef.current = totalQuantity;
  }, [totalQuantity]);

  const { data: activeOrder, refetch: refetchActiveOrder } = useQuery({
    queryKey: ['activeOrder', selectedTable?.id],
    queryFn: () => selectedTable ? posService.getActiveOrderByTable(selectedTable.id) : null,
    enabled: !!selectedTable,
    retry: false
  });

  const closeTableMutation = useMutation({
    mutationFn: async () => {
      if (!selectedTable) return;
      if (activeOrder) {
        await posService.updateOrder(activeOrder.id, { status: 'BILLED' });
      }
      await posService.closeTable(selectedTable.id);
    },
    onSuccess: () => {
      showNotification("Cuenta cerrada con éxito", "success");
      queryClient.invalidateQueries({ queryKey: ['tables'] });
      setSelectedTable(undefined);
      navigate('/tables');
    },
    onError: (err: any) => {
      showNotification(err.message || "Error al cerrar la cuenta", "error");
    }
  });

  const [checkoutOpen, setCheckoutOpen] = useState(false);

  const handleCloseAccount = () => {
    setCheckoutOpen(true);
  };

  const [unlockedItems, setUnlockedItems] = useState<Set<string>>(new Set());
  const [overrideOpen, setOverrideOpen] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(25);

  useEffect(() => {
    setPage(0);
  }, [search, selectedCategory]);

  const showNotification = useNotificationStore(state => state.showNotification);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Redireccionar si no hay mesa seleccionada
  useEffect(() => {
    if (!selectedTable) {
      showNotification("Por favor, selecciona una mesa para tomar un pedido", "warning");
      navigate('/tables', { replace: true });
    }
  }, []);

  // Enfoque automático de la barra de búsqueda si está habilitado
  useEffect(() => {
    if (selectedTable && autoFocusSearch && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [selectedTable, autoFocusSearch]);

  const handleLockClick = (productId: string) => {
    if (unlockedItems.has(productId)) {
      const next = new Set(unlockedItems);
      next.delete(productId);
      setUnlockedItems(next);
      showNotification("Item bloqueado para edición de precio", "info");
    } else {
      setSelectedProductId(productId);
      setOverrideOpen(true);
    }
  };

  const handleOverrideSuccess = (supervisorName: string) => {
    if (selectedProductId) {
      const next = new Set(unlockedItems);
      next.add(selectedProductId);
      setUnlockedItems(next);
      showNotification(`Edición de precio autorizada por ${supervisorName}`, "success");
    }
  };

  const { data: allCategories = mockCategories } = useQuery({ queryKey: ['categories'], queryFn: posService.categories });
  const categories = allCategories.filter((c: any) => !c.is_hidden);
  const { data: responseData } = useQuery({ queryKey: ['products'], queryFn: () => posService.products(1, 1000) });
  const isServerPaginated = responseData && !Array.isArray(responseData) && 'data' in responseData;
  const products = isServerPaginated ? (responseData as any).data : (Array.isArray(responseData) ? responseData : mockProducts);
  const { data: tables = mockTables } = useQuery({ queryKey: ['tables'], queryFn: posService.tables });
  const { data: stockData } = useQuery({ queryKey: ['inventory-stock'], queryFn: posService.inventoryStock });
  const { data: recipesData } = useQuery({ queryKey: ['recipes'], queryFn: () => posService.recipes(1, 1000) });
  const isServerPaginatedRecipes = recipesData && !Array.isArray(recipesData) && 'data' in (recipesData as any);
  const recipes = isServerPaginatedRecipes ? (recipesData as any).data : (Array.isArray(recipesData) ? recipesData : []);

  const [pendingProductAction, setPendingProductAction] = useState<{ product: any, action: 'add' | 'update', qty?: number } | null>(null);

  const getProductAvailableStock = (product: any) => {
    const recipe = recipes?.find((r: any) => r.product_id === product.id);
    if (recipe && recipe.items && recipe.items.length > 0) {
      let maxPossible = Infinity;
      for (const item of recipe.items) {
        const stock = stockData?.[item.inventory_item_id] || 0;
        const possible = Math.floor(stock / item.quantity);
        if (possible < maxPossible) {
          maxPossible = possible;
        }
      }
      return maxPossible === Infinity ? 0 : Math.max(0, maxPossible);
    }
    return Math.max(0, stockData?.[product.id] || 0);
  };

  const handleProductClick = (product: any) => {
    const existingItem = items.find(i => i.product_id === product.id);
    const requestedQty = (existingItem?.quantity || 0) + 1;
    const available = getProductAvailableStock(product);
    
    if (requestedQty > available) {
      if (showNegativeInventoryWarning) {
        setPendingProductAction({ product, action: 'add' });
        return;
      }
    }
    addProduct(product);
  };

  const handleUpdateQuantityClick = (product_id: string, newQty: number) => {
    const product = products.find((p: any) => p.id === product_id);
    if (!product) return;
    
    const available = getProductAvailableStock(product);
    if (newQty > available) {
      if (showNegativeInventoryWarning) {
        setPendingProductAction({ product, action: 'update', qty: newQty });
        return;
      }
    }
    updateQuantity(product_id, newQty);
  };
  
  const confirmPendingAction = () => {
    if (!pendingProductAction) return;
    if (pendingProductAction.action === 'add') {
      addProduct(pendingProductAction.product);
    } else if (pendingProductAction.action === 'update' && pendingProductAction.qty) {
      updateQuantity(pendingProductAction.product.id, pendingProductAction.qty);
    }
    setPendingProductAction(null);
  };
  
  const createOrder = useMutation({
    mutationFn: posService.createOrder,
    onSuccess: () => {
      showNotification("Pedido enviado a cocina", "success");
      clear();
      queryClient.invalidateQueries({ queryKey: ['tables'] });
      queryClient.invalidateQueries({ queryKey: ['activeOrder', selectedTable?.id] });
    },
    onError: () => {
      showNotification("Error al enviar el pedido", "error");
    }
  });

  const handleSendOrder = (skipKitchen: boolean) => {
    if (!selectedTable) return;
    const targetTableId = selectedTable.id;
    
    // Construir nota enriquecida para que KDS procese mesa e ítems correctamente
    const formattedItems = items.map(item => `• ${item.quantity}x ${item.name}${item.notes ? ` (${item.notes})` : ''}`).join('\n');
    const richNotes = `Mesa: ${selectedTable.number}\n\nDetalle:\n${formattedItems}${notes ? `\n\nNotas Cocina: ${notes}` : ''}`;

    createOrder.mutate({
      table_id: targetTableId,
      skip_kitchen: skipKitchen,
      items: items.map(i => ({
        product_id: i.product_id,
        name: i.name,
        quantity: i.quantity,
        unit_price: i.unit_price,
        notes: i.notes || ''
      })),
      notes: skipKitchen ? '' : richNotes
    });
  };

  const total = items.reduce((sum, item) => sum + item.total, 0);

  // Cálculos para la cuenta activa de la mesa
  const subtotalAccount = activeOrder?.items?.reduce((sum, item) => sum + item.total, 0) ?? 0;
  const tipAmount = tipType === 'disabled' 
    ? 0 
    : tipType === 'percent' 
      ? Math.round(subtotalAccount * (tipValue / 100)) 
      : tipValue;
  const totalAccount = subtotalAccount + tipAmount;

  const filteredProducts = products.filter((p: any) => {
    const category = allCategories.find((c: any) => c.id === p.category_id);
    if (category?.is_hidden) return false;

    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase()) || (p.code || '').toLowerCase().includes(search.toLowerCase());
    if (selectedCategory && p.category_id !== selectedCategory) return false;
    return matchesSearch;
  });

  const paginatedProducts = filteredProducts.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  if (!selectedTable) {
    return null; // Omitir render mientras se hace redirect
  }

  return (
    <Stack spacing={3} sx={{ height: 'calc(100vh - 48px)' }}>
      <Grid container spacing={3} alignItems="stretch">
        {/* Columna 1: Categorías */}
        <Grid item xs={12} lg={2.5}>
          <Paper 
            sx={{ 
              p: 2.5, 
              height: '100%', 
              borderRadius: 3, 
              boxShadow: '0 4px 20px -2px rgba(0,0,0,0.05)',
              border: '1px solid #e2e8f0'
            }}
          >
            <Typography variant="subtitle1" fontWeight="bold" sx={{ mb: 2, color: '#0f172a', display: 'flex', alignItems: 'center', gap: 1 }}>
              <RestaurantIcon sx={{ color: '#0891b2' }} /> Categorías
            </Typography>
            <Stack gap={1}>
              <ListItemButton 
                selected={selectedCategory === null} 
                onClick={() => setSelectedCategory(null)}
                sx={{
                  borderRadius: 2,
                  py: 1.5,
                  color: selectedCategory === null ? '#ffffff' : '#475569',
                  bgcolor: selectedCategory === null ? '#0f172a' : 'transparent',
                  fontWeight: selectedCategory === null ? 600 : 500,
                  transition: 'all 0.2s',
                  '&.Mui-selected': {
                    bgcolor: '#0f172a',
                    '&:hover': { bgcolor: '#1e293b' }
                  },
                  '&:hover': {
                    bgcolor: selectedCategory === null ? '#1e293b' : 'rgba(15, 23, 42, 0.04)',
                    transform: 'translateX(4px)'
                  }
                }}
              >
                <ListItemText primary="Todas" slotProps={{ primary: { style: { fontWeight: 'inherit' } } }} />
              </ListItemButton>

              {categories.map((category) => (
                <ListItemButton 
                  key={category.id} 
                  selected={selectedCategory === category.id} 
                  onClick={() => setSelectedCategory(category.id)}
                  sx={{
                    borderRadius: 2,
                    py: 1.5,
                    color: selectedCategory === category.id ? '#ffffff' : '#475569',
                    bgcolor: selectedCategory === category.id ? '#0f172a' : 'transparent',
                    fontWeight: selectedCategory === category.id ? 600 : 500,
                    transition: 'all 0.2s',
                    '&.Mui-selected': {
                      bgcolor: '#0f172a',
                      '&:hover': { bgcolor: '#1e293b' }
                    },
                    '&:hover': {
                      bgcolor: selectedCategory === category.id ? '#1e293b' : 'rgba(15, 23, 42, 0.04)',
                      transform: 'translateX(4px)'
                    }
                  }}
                >
                  <ListItemText primary={category.name} slotProps={{ primary: { style: { fontWeight: 'inherit' } } }} />
                </ListItemButton>
              ))}
            </Stack>
          </Paper>
        </Grid>

        {/* Columna 2: Buscador y Menú de Productos */}
        <Grid item xs={12} lg={5.5}>
          <Stack spacing={2} sx={{ height: '100%' }}>
            <TextField 
              fullWidth 
              inputRef={searchInputRef}
              placeholder="Búsqueda rápida de productos (nombre o código)..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon sx={{ color: '#94a3b8' }} />
                  </InputAdornment>
                ),
                endAdornment: search && (
                  <InputAdornment position="end">
                    <IconButton size="small" onClick={() => setSearch('')}>
                      <CloseIcon fontSize="small" />
                    </IconButton>
                  </InputAdornment>
                )
              }}
              sx={{
                bgcolor: 'background.paper',
                borderRadius: 2.5,
                boxShadow: '0 4px 10px -2px rgba(0,0,0,0.03)',
                '& .MuiOutlinedInput-root': {
                  borderRadius: 2.5,
                  '& fieldset': { borderColor: '#e2e8f0' },
                  '&:hover fieldset': { borderColor: '#cbd5e1' },
                  '&.Mui-focused fieldset': { borderColor: '#0f172a', borderWidth: 1 }
                }
              }}
            />
            
            <Box 
              sx={{ 
                flexGrow: 1, 
                maxHeight: 'calc(100vh - 280px)', 
                overflowY: 'auto', 
                pr: 0.5,
                scrollbarWidth: 'thin',
                '&::-webkit-scrollbar': { width: 6 },
                '&::-webkit-scrollbar-thumb': { bgcolor: '#cbd5e1', borderRadius: 3 }
              }}
            >
              {filteredProducts.length === 0 ? (
                <Paper sx={{ p: 5, textAlign: 'center', color: 'text.secondary', borderRadius: 3, border: '1px dashed #cbd5e1' }}>
                  No se encontraron productos coincidentes.
                </Paper>
              ) : (
                <Grid container spacing={2}>
                  {paginatedProducts.map((product: any) => (
                    <Grid item xs={12} sm={6} md={4} key={product.id}>
                      <Card 
                        sx={{ 
                          height: '100%', 
                          borderRadius: 3, 
                          boxShadow: '0 2px 8px rgba(0,0,0,0.03)',
                          border: '1px solid #e2e8f0',
                          transition: 'all 0.2s',
                          '&:hover': {
                            transform: 'translateY(-3px)',
                            boxShadow: '0 8px 24px -4px rgba(15, 23, 42, 0.08)',
                            borderColor: '#94a3b8'
                          }
                        }}
                      >
                        <CardActionArea 
                          onClick={() => handleProductClick(product)} 
                          sx={{ 
                            height: '100%', 
                            p: showProductImages && product.image ? 0 : 2, 
                            display: 'flex', 
                            flexDirection: 'column', 
                            alignItems: 'flex-start',
                            justifyContent: 'flex-start',
                            textAlign: 'left'
                          }}
                        >
                          {showProductImages && product.image && (
                            <Box
                              component="img"
                              src={product.image}
                              alt={product.name}
                              sx={{
                                width: '100%',
                                height: 80,
                                objectFit: 'cover',
                                borderTopLeftRadius: 'inherit',
                                borderTopRightRadius: 'inherit',
                              }}
                            />
                          )}
                          <Box sx={{ width: '100%', mb: 1, p: showProductImages && product.image ? 1.5 : 0, pt: showProductImages && product.image ? 1 : 0 }}>
                            <Typography variant="caption" sx={{ color: '#0891b2', fontWeight: 600, textTransform: 'uppercase', fontSize: '0.68rem', letterSpacing: 0.5 }}>
                              {typeof product.category === 'object' && product.category
                                ? (product.category as any).name
                                : (product.category || 'General')}
                            </Typography>
                            <Typography variant="body1" fontWeight="bold" sx={{ color: '#1e293b', mt: 0.5, lineHeight: 1.2, height: 38, overflow: 'hidden', textOverflow: 'ellipsis', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' }}>
                              {product.name}
                            </Typography>
                          </Box>
                          <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ width: '100%', px: showProductImages && product.image ? 1.5 : 0, pb: showProductImages && product.image ? 1.5 : 0 }}>
                            <Typography variant="h6" sx={{ color: 'primary.main', fontWeight: 'bold', fontVariantNumeric: 'tabular-nums' }}>
                              {cop(product.price)}
                            </Typography>
                            <Box sx={{ bgcolor: getProductAvailableStock(product) > 0 ? '#dcfce7' : '#fee2e2', color: getProductAvailableStock(product) > 0 ? '#166534' : '#991b1b', px: 1, py: 0.25, borderRadius: 1 }}>
                              <Typography variant="caption" fontWeight="bold">Stock: {getProductAvailableStock(product)}</Typography>
                            </Box>
                          </Stack>
                        </CardActionArea>
                      </Card>
                    </Grid>
                  ))}
                </Grid>
              )}
              
              {filteredProducts.length > 0 && (
                <AppPagination
                  count={filteredProducts.length}
                  page={page}
                  onPageChange={(newPage) => setPage(newPage)}
                  rowsPerPage={rowsPerPage}
                  onRowsPerPageChange={(newRowsPerPage) => {
                    setRowsPerPage(newRowsPerPage);
                    setPage(0);
                  }}
                  labelRowsPerPage="Productos por página:"
                  rowsPerPageOptions={[10, 25, 50, 100]}
                />
              )}
            </Box>
          </Stack>
        </Grid>

        {/* Columna 3: Ticket del Pedido Actual / Cuenta */}
        <Grid item xs={12} lg={4}>
          <Paper 
            elevation={0}
            sx={{ 
              p: 3, 
              height: 'calc(100vh - 48px)',
              display: 'flex',
              flexDirection: 'column',
              borderRadius: 3, 
              border: '1px solid #e2e8f0',
              boxShadow: '0 10px 30px -5px rgba(15, 23, 42, 0.05)',
              background: '#ffffff'
            }}
          >
            {/* Cabecera del Ticket */}
            <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
              <Stack direction="row" spacing={1.5} alignItems="center">
                <Typography variant="h6" fontWeight="bold" color="#0f172a">
                  {activeTab === 'new' ? 'Pedido Actual' : 'Cuenta de la Mesa'}
                </Typography>
                <Chip 
                  label={`Mesa ${selectedTable.number}`} 
                  color="secondary" 
                  sx={{ fontWeight: 'bold', borderRadius: 1.5, bgcolor: '#0f172a', color: '#ffffff' }} 
                />
              </Stack>
              {activeTab === 'new' && items.length > 0 && (
                <Tooltip title="Vaciar pedido">
                  <IconButton color="error" size="small" onClick={() => clear()} sx={{ '&:hover': { bgcolor: 'rgba(220, 38, 38, 0.05)' } }}>
                    <DeleteIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
              )}
            </Stack>

            {/* Selector de pestañas */}
            <Stack direction="row" spacing={1} sx={{ mb: 2 }}>
              <Button 
                variant={activeTab === 'new' ? 'contained' : 'outlined'}
                onClick={() => setActiveTab('new')}
                size="small"
                fullWidth
                sx={{ 
                  textTransform: 'none', 
                  borderRadius: 2, 
                  bgcolor: activeTab === 'new' ? '#0f172a' : 'transparent',
                  color: activeTab === 'new' ? '#ffffff' : '#0f172a',
                  borderColor: '#0f172a',
                  fontWeight: 600,
                  '&:hover': {
                    bgcolor: activeTab === 'new' ? '#1e293b' : 'rgba(0,0,0,0.02)',
                    borderColor: '#0f172a'
                  }
                }}
              >
                Nuevo Pedido
              </Button>
              <Button 
                variant={activeTab === 'account' ? 'contained' : 'outlined'}
                onClick={() => setActiveTab('account')}
                size="small"
                fullWidth
                sx={{ 
                  textTransform: 'none', 
                  borderRadius: 2,
                  bgcolor: activeTab === 'account' ? '#0f172a' : 'transparent',
                  color: activeTab === 'account' ? '#ffffff' : '#0f172a',
                  borderColor: '#0f172a',
                  fontWeight: 600,
                  '&:hover': {
                    bgcolor: activeTab === 'account' ? '#1e293b' : 'rgba(0,0,0,0.02)',
                    borderColor: '#0f172a'
                  }
                }}
              >
                Ver Cuenta / Cerrar
              </Button>
            </Stack>

            <Divider sx={{ mb: 2, borderStyle: 'dashed' }} />

            {activeTab === 'new' ? (
              <>
                {/* Listado de Productos (Nuevo Pedido) */}
                <Stack 
                  spacing={2} 
                  sx={{ 
                    flexGrow: 1,
                    overflowY: 'auto', 
                    mb: 2, 
                    pr: 0.5,
                    scrollbarWidth: 'thin',
                    '&::-webkit-scrollbar': { width: 4 },
                    '&::-webkit-scrollbar-thumb': { bgcolor: '#e2e8f0', borderRadius: 2 }
                  }}
                >
                  {items.length === 0 ? (
                    <Box sx={{ py: 6, textAlign: 'center', color: 'text.secondary' }}>
                      <Typography variant="body2" sx={{ fontStyle: 'italic' }}>El pedido está vacío.</Typography>
                      <Typography variant="caption" display="block" sx={{ mt: 0.5 }}>Toca los productos del menú de la izquierda para agregarlos.</Typography>
                    </Box>
                  ) : (
                    items.map((item) => (
                      <Box 
                        key={item.product_id} 
                        sx={{ 
                          p: 1.5, 
                          borderRadius: 2, 
                          bgcolor: '#f8fafc', 
                          border: '1px solid #f1f5f9',
                          display: 'flex', 
                          flexDirection: 'column', 
                          gap: 1 
                        }}
                      >
                        <Stack direction="row" justifyContent="space-between" alignItems="flex-start">
                          <Box sx={{ flex: 1, pr: 1 }}>
                            <Typography fontWeight="bold" variant="body2" sx={{ color: '#1e293b', lineHeight: 1.2 }}>
                              {item.name}
                            </Typography>
                          </Box>
                          <Typography fontWeight="bold" variant="body2" sx={{ color: '#0f172a', fontVariantNumeric: 'tabular-nums' }}>
                            {cop(item.total)}
                          </Typography>
                        </Stack>

                        <Stack direction="row" justifyContent="space-between" alignItems="center">
                          {/* Control de cantidad */}
                          <Stack 
                            direction="row" 
                            alignItems="center" 
                            sx={{ 
                              bgcolor: 'background.paper', 
                              border: '1px solid #cbd5e1', 
                              borderRadius: 2,
                              px: 0.5
                            }}
                          >
                            <IconButton 
                              size="small" 
                              onClick={() => updateQuantity(item.product_id, Math.max(1, item.quantity - 1))}
                              sx={{ p: 0.5, color: '#475569' }}
                            >
                              <RemoveIcon fontSize="small" />
                            </IconButton>
                            <Typography sx={{ px: 1.5, fontWeight: 'bold', fontSize: '0.9rem', color: '#0f172a' }}>
                              {item.quantity}
                            </Typography>
                            <IconButton 
                              size="small" 
                              onClick={() => handleUpdateQuantityClick(item.product_id, item.quantity + 1)}
                              sx={{ p: 0.5, color: '#475569' }}
                            >
                              <AddIcon fontSize="small" />
                            </IconButton>
                          </Stack>

                          {/* Edición de precio */}
                          <Stack direction="row" spacing={1} alignItems="center">
                            <TextField
                              size="small"
                              type="number"
                              value={item.unit_price}
                              onChange={(e) => updatePrice(item.product_id, Number(e.target.value))}
                              slotProps={{
                                input: {
                                  startAdornment: <InputAdornment position="start" sx={{ '& p': { fontSize: '0.75rem' } }}>$</InputAdornment>,
                                  endAdornment: isCashier ? (
                                    <InputAdornment position="end">
                                      <IconButton 
                                        size="small"
                                        onClick={() => handleLockClick(item.product_id)}
                                        color={unlockedItems.has(item.product_id) ? "success" : "default"}
                                        sx={{ p: 0.25 }}
                                      >
                                        {unlockedItems.has(item.product_id) ? <LockOpenIcon sx={{ fontSize: '0.95rem' }} /> : <LockIcon sx={{ fontSize: '0.95rem' }} />}
                                      </IconButton>
                                    </InputAdornment>
                                  ) : undefined,
                                  readOnly: isCashier && !unlockedItems.has(item.product_id)
                                }
                              }}
                              sx={{ 
                                width: 100, 
                                '& .MuiOutlinedInput-root': {
                                  height: 28,
                                  fontSize: '0.8rem',
                                  borderRadius: 1.5,
                                  p: 0.5
                                }
                              }}
                            />
                            <IconButton 
                              color="error" 
                              size="small" 
                              onClick={() => removeItem(item.product_id)}
                              sx={{ p: 0.5, '&:hover': { bgcolor: 'rgba(220, 38, 38, 0.08)' } }}
                            >
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </Stack>
                        </Stack>
                      </Box>
                    ))
                  )}
                </Stack>

                <Divider sx={{ my: 2, borderStyle: 'dashed' }} />

                {/* Observaciones y Totales (Nuevo Pedido) */}
                <Stack gap={2}>
                  <TextField 
                    label="Observaciones para la cocina" 
                    multiline 
                    minRows={1} 
                    maxRows={2} 
                    value={notes} 
                    onChange={(event) => setNotes(event.target.value)} 
                    fullWidth
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        borderRadius: 2,
                        fontSize: '0.85rem'
                      }
                    }}
                  />
                  
                  <Box 
                    sx={{ 
                      p: 2, 
                      borderRadius: 2.5, 
                      bgcolor: '#0f172a', 
                      color: '#ffffff',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center'
                    }}
                  >
                    <Typography variant="body1" sx={{ color: '#cbd5e1', fontWeight: 500 }}>Total Adición</Typography>
                    <Typography variant="h5" sx={{ color: 'primary.main', fontWeight: 800, fontVariantNumeric: 'tabular-nums' }}>
                      {cop(total)}
                    </Typography>
                  </Box>

                  <Stack direction="row" spacing={1.5}>
                    <Button 
                      variant="outlined" 
                      size="large" 
                      fullWidth
                      disabled={!items.length || createOrder.isPending} 
                      onClick={() => handleSendOrder(true)}
                      sx={{ 
                        py: 1.5, 
                        borderRadius: 2.5,
                        fontWeight: 'bold',
                        textTransform: 'none',
                        fontSize: '0.9rem',
                        borderColor: '#0f172a',
                        color: '#0f172a',
                        '&:hover': {
                          bgcolor: 'rgba(15, 23, 42, 0.04)',
                          borderColor: '#0f172a'
                        }
                      }}
                    >
                      Solo a Cuenta
                    </Button>
                    <Button 
                      variant="contained" 
                      size="large" 
                      fullWidth
                      startIcon={createOrder.isPending ? null : <SendIcon />} 
                      disabled={!items.length || createOrder.isPending} 
                      onClick={() => handleSendOrder(false)}
                      sx={{ 
                        py: 1.5, 
                        borderRadius: 2.5,
                        bgcolor: 'primary.main',
                        fontWeight: 'bold',
                        textTransform: 'none',
                        fontSize: '0.9rem',
                        boxShadow: '0 8px 16px -4px rgba(15, 23, 42, 0.3)',
                        transition: 'transform 0.15s',
                        '&:hover': {
                          bgcolor: 'primary.dark',
                          boxShadow: '0 8px 20px -2px rgba(15, 23, 42, 0.4)'
                        },
                        '&:active': { transform: 'scale(0.97)' }
                      }}
                    >
                      {createOrder.isPending ? 'Enviando...' : 'Enviar a Cocina'}
                    </Button>
                  </Stack>
                </Stack>
              </>
            ) : (
              <>
                {/* Listado de Consumos Previos (Ver Cuenta) */}
                <Stack 
                  spacing={1.5} 
                  sx={{ 
                    flexGrow: 1,
                    overflowY: 'auto', 
                    mb: 2, 
                    pr: 0.5,
                    scrollbarWidth: 'thin',
                    '&::-webkit-scrollbar': { width: 4 },
                    '&::-webkit-scrollbar-thumb': { bgcolor: '#e2e8f0', borderRadius: 2 }
                  }}
                >
                  {!activeOrder || !activeOrder.items || activeOrder.items.length === 0 ? (
                    <Box sx={{ py: 6, textAlign: 'center', color: 'text.secondary' }}>
                      <Typography variant="body2" sx={{ fontStyle: 'italic' }}>No hay consumos previos.</Typography>
                      <Typography variant="caption" display="block" sx={{ mt: 0.5 }}>Crea un pedido en la pestaña de "Nuevo Pedido" para esta mesa.</Typography>
                    </Box>
                  ) : (
                    activeOrder.items.map((item) => (
                      <Box 
                        key={item.id} 
                        sx={{ 
                          p: 1.25, 
                          borderRadius: 2, 
                          bgcolor: '#f8fafc', 
                          border: '1px solid #f1f5f9',
                          display: 'flex', 
                          justifyContent: 'space-between',
                          alignItems: 'center'
                        }}
                      >
                        <Box>
                          <Typography fontWeight="bold" variant="body2" sx={{ color: '#1e293b', lineHeight: 1.2 }}>
                            {item.name}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {item.quantity} x {cop(item.unit_price)}
                          </Typography>
                        </Box>
                        <Typography fontWeight="bold" variant="body2" sx={{ color: '#0f172a', fontVariantNumeric: 'tabular-nums' }}>
                          {cop(item.total)}
                        </Typography>
                      </Box>
                    ))
                  )}
                </Stack>

                {activeOrder && activeOrder.items && activeOrder.items.length > 0 && (
                  <Stack spacing={2} sx={{ mt: 'auto' }}>
                    {/* Panel de Propina Sugerida */}
                    <Paper variant="outlined" sx={{ p: 2, borderRadius: 2.5, bgcolor: '#f8fafc', border: '1px solid #e2e8f0' }}>
                      <Stack spacing={1.5}>
                        <Typography variant="body2" fontWeight="bold" color="#475569">Propina Sugerida</Typography>
                        
                        <Stack direction="row" spacing={1}>
                          <Button 
                            size="small" 
                            variant={tipType === 'percent' && tipValue === 10 ? 'contained' : 'outlined'}
                            onClick={() => { setTipType('percent'); setTipValue(10); }}
                            sx={{ 
                              flex: 1, 
                              textTransform: 'none', 
                              borderRadius: 1.5, 
                              fontSize: '0.75rem',
                              bgcolor: tipType === 'percent' && tipValue === 10 ? '#0f172a' : 'transparent',
                              color: tipType === 'percent' && tipValue === 10 ? '#ffffff' : '#0f172a',
                              borderColor: '#0f172a'
                            }}
                          >
                            10%
                          </Button>
                          <Button 
                            size="small" 
                            variant={tipType === 'percent' && tipValue === 15 ? 'contained' : 'outlined'}
                            onClick={() => { setTipType('percent'); setTipValue(15); }}
                            sx={{ 
                              flex: 1, 
                              textTransform: 'none', 
                              borderRadius: 1.5, 
                              fontSize: '0.75rem',
                              bgcolor: tipType === 'percent' && tipValue === 15 ? '#0f172a' : 'transparent',
                              color: tipType === 'percent' && tipValue === 15 ? '#ffffff' : '#0f172a',
                              borderColor: '#0f172a'
                            }}
                          >
                            15%
                          </Button>
                          <Button 
                            size="small" 
                            variant={tipType === 'fixed' ? 'contained' : 'outlined'}
                            onClick={() => {
                              const val = prompt("Ingrese el valor personalizado de propina ($ COP):");
                              if (val !== null) {
                                const num = parseInt(val.replace(/[$,.]/g, ''), 10);
                                if (!isNaN(num) && num >= 0) {
                                  setTipType('fixed');
                                  setTipValue(num);
                                }
                              }
                            }}
                            sx={{ 
                              flex: 1.5, 
                              textTransform: 'none', 
                              borderRadius: 1.5, 
                              fontSize: '0.75rem',
                              bgcolor: tipType === 'fixed' ? '#0f172a' : 'transparent',
                              color: tipType === 'fixed' ? '#ffffff' : '#0f172a',
                              borderColor: '#0f172a'
                            }}
                          >
                            Personalizado
                          </Button>
                          <Button 
                            size="small" 
                            color="error"
                            variant={tipType === 'disabled' ? 'contained' : 'outlined'}
                            onClick={() => setTipType('disabled')}
                            sx={{ 
                              flex: 1, 
                              textTransform: 'none', 
                              borderRadius: 1.5, 
                              fontSize: '0.75rem',
                              borderColor: '#ef4444',
                              color: tipType === 'disabled' ? '#ffffff' : '#ef4444',
                              bgcolor: tipType === 'disabled' ? '#ef4444' : 'transparent',
                              '&:hover': {
                                bgcolor: tipType === 'disabled' ? '#dc2626' : 'rgba(239, 68, 68, 0.04)',
                                borderColor: '#dc2626'
                              }
                            }}
                          >
                            Sin Propina
                          </Button>
                        </Stack>

                        {tipType !== 'disabled' && (
                          <Stack direction="row" justifyContent="space-between" alignItems="center">
                            <Typography variant="caption" color="text.secondary">
                              {tipType === 'percent' ? `Valor propina (${tipValue}%):` : 'Valor propina fijado:'}
                            </Typography>
                            <Typography variant="body2" fontWeight="bold" color="#16a34a" sx={{ fontVariantNumeric: 'tabular-nums' }}>
                              {cop(tipAmount)}
                            </Typography>
                          </Stack>
                        )}
                      </Stack>
                    </Paper>

                    {/* Resumen de Cierre de Cuenta */}
                    <Stack spacing={1} sx={{ mt: 1 }}>
                      <Stack direction="row" justifyContent="space-between">
                        <Typography variant="body2" color="text.secondary">Subtotal Consumos:</Typography>
                        <Typography variant="body2" fontWeight="bold" sx={{ fontVariantNumeric: 'tabular-nums' }}>{cop(subtotalAccount)}</Typography>
                      </Stack>
                      {tipType !== 'disabled' && (
                        <Stack direction="row" justifyContent="space-between">
                          <Typography variant="body2" color="text.secondary">Propina Voluntaria:</Typography>
                          <Typography variant="body2" fontWeight="bold" color="#16a34a" sx={{ fontVariantNumeric: 'tabular-nums' }}>{cop(tipAmount)}</Typography>
                        </Stack>
                      )}
                      <Divider />
                      <Box 
                        sx={{ 
                          p: 2, 
                          borderRadius: 2.5, 
                          bgcolor: '#0f172a', 
                          color: '#ffffff',
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center',
                          mt: 0.5
                        }}
                      >
                        <Typography variant="body1" sx={{ color: '#cbd5e1', fontWeight: 500 }}>Total Cuenta</Typography>
                        <Typography variant="h5" sx={{ color: 'primary.main', fontWeight: 800, fontVariantNumeric: 'tabular-nums' }}>
                          {cop(totalAccount)}
                        </Typography>
                      </Box>

                      <Button 
                        variant="contained" 
                        size="large" 
                        fullWidth
                        disabled={closeTableMutation.isPending}
                        onClick={handleCloseAccount}
                        sx={{ 
                          py: 1.5, 
                          borderRadius: 2.5,
                          bgcolor: '#10b981',
                          fontWeight: 'bold',
                          textTransform: 'none',
                          fontSize: '1rem',
                          boxShadow: '0 8px 16px -4px rgba(16, 185, 129, 0.3)',
                          transition: 'transform 0.15s',
                          '&:hover': {
                            bgcolor: '#059669',
                            boxShadow: '0 8px 20px -2px rgba(16, 185, 129, 0.4)'
                          },
                          '&:active': { transform: 'scale(0.97)' }
                        }}
                      >
                        {closeTableMutation.isPending ? 'Cerrando cuenta...' : 'Cerrar Cuenta / Facturar'}
                      </Button>
                    </Stack>
                  </Stack>
                )}
              </>
            )}
          </Paper>
        </Grid>
      </Grid>
      
      <OverrideDialog
        open={overrideOpen}
        onClose={() => { setOverrideOpen(false); setSelectedProductId(null); }}
        onSuccess={handleOverrideSuccess}
      />
      {selectedTable && activeOrder && (
        <CheckoutDialog 
          open={checkoutOpen}
          onClose={() => setCheckoutOpen(false)}
          onSuccess={() => {
            setCheckoutOpen(false);
            queryClient.invalidateQueries({ queryKey: ['tables'] });
            setSelectedTable(undefined);
            navigate('/tables');
          }}
          orderId={activeOrder.id}
          tableId={selectedTable.id}
          total={totalAccount}
          subtotal={subtotalAccount}
          tip={tipAmount}
          items={activeOrder.items || []}
        />
      )}

      <Dialog open={!!pendingProductAction} onClose={() => setPendingProductAction(null)}>
        <DialogTitle>Inventario Insuficiente</DialogTitle>
        <DialogContent>
          <DialogContentText>
            No hay suficiente inventario disponible para <strong>{pendingProductAction?.product?.name}</strong>. 
            El stock actual registrado es bajo. ¿Deseas agregar este producto a la orden de todas formas (generando inventario negativo)?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setPendingProductAction(null)}>Cancelar</Button>
          <Button variant="contained" color="warning" onClick={confirmPendingAction}>
            Sí, agregar producto
          </Button>
        </DialogActions>
      </Dialog>
    </Stack>
  );
}
