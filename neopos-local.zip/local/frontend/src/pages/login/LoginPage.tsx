import { zodResolver } from '@hookform/resolvers/zod';
import { Alert, Box, Button, Checkbox, FormControlLabel, Link, Paper, Stack, TextField, Typography } from '@mui/material';
import LockIcon from '@mui/icons-material/Lock';
import { useMutation } from '@tanstack/react-query';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Navigate, useNavigate } from 'react-router-dom';
import { z } from 'zod';
import { login } from '../../services/authService';
import { useAuthStore } from '../../stores/authStore';
import { getHomePath } from '../../utils/permissions';

const schema = z.object({
  email: z.string().email('Correo invalido'),
  password: z.string().min(6, 'Minimo 6 caracteres'),
  remember: z.boolean()
});

type FormValues = z.infer<typeof schema>;

export function LoginPage() {
  const navigate = useNavigate();
  const { accessToken, role, setSession } = useAuthStore();
  const [recover, setRecover] = useState(false);
  const { register, handleSubmit, setValue, formState: { errors } } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { email: 'admin@pos.local', password: 'ChangeMe123!', remember: true }
  });

  const mutation = useMutation({
    mutationFn: login,
    onSuccess: (tokens, variables) => {
      const userRole = variables.email.includes('admin') ? 'admin' : 'cashier';
      setSession(tokens.access_token, tokens.refresh_token, variables.remember ?? false, userRole);
      navigate(getHomePath(userRole));
    }
  });

  const handleDebugLogin = (email: string, pass: string) => {
    setValue('email', email);
    setValue('password', pass);
    mutation.mutate({ email, password: pass, remember: true });
  };

  if (accessToken) return <Navigate to={getHomePath(role)} replace />;

  return (
    <Box sx={{ minHeight: '100vh', display: 'grid', placeItems: 'center', bgcolor: '#0f172a', p: 2 }}>
      <Paper sx={{ width: '100%', maxWidth: 430, p: 4 }}>
        <Stack spacing={3}>
          <Stack spacing={1} alignItems="center">
            <Box sx={{ width: 58, height: 58, borderRadius: 2, bgcolor: 'secondary.main', color: 'white', display: 'grid', placeItems: 'center' }}>
              <LockIcon fontSize="large" />
            </Box>
            <Typography variant="h4">NeoPOS</Typography>
            <Typography color="text.secondary">Ingreso seguro al POS</Typography>
          </Stack>
          {mutation.isError ? <Alert severity="error">{String(mutation.error.message)}</Alert> : null}
          {recover ? <Alert severity="info">Solicitud de recuperacion lista para conectar con `/auth/forgot-password`.</Alert> : null}
          <Stack component="form" spacing={2} onSubmit={handleSubmit((values) => mutation.mutate(values))}>
            <TextField label="Usuario" autoComplete="email" {...register('email')} error={!!errors.email} helperText={errors.email?.message} />
            <TextField label="Contrasena" type="password" autoComplete="current-password" {...register('password')} error={!!errors.password} helperText={errors.password?.message} />
            <Stack direction="row" justifyContent="space-between" alignItems="center">
              <FormControlLabel control={<Checkbox {...register('remember')} defaultChecked />} label="Recordar sesion" />
              <Link component="button" type="button" onClick={() => setRecover(true)}>
                Recuperar
              </Link>
            </Stack>
            <Button type="submit" variant="contained" size="large" disabled={mutation.isPending}>
              Ingresar
            </Button>
            <Stack direction="row" spacing={1} justifyContent="center" sx={{ mt: 1 }}>
              <Button
                type="button"
                variant="outlined"
                size="small"
                onClick={() => handleDebugLogin('admin@pos.local', 'NeoPOS_Local_S3cur3Admin!_2026')}
              >
                Entrar como Admin
              </Button>
              <Button
                type="button"
                variant="outlined"
                size="small"
                onClick={() => handleDebugLogin('cajero@neopos.com', 'cajero123')}
              >
                Entrar como Cajero
              </Button>
            </Stack>
          </Stack>
        </Stack>
      </Paper>
    </Box>
  );
}
