import { Button, Grid, Paper, Stack, TextField, Typography, Alert, AlertTitle, Chip, Box, Dialog, DialogTitle, DialogContent, DialogActions, DialogContentText, Table, TableHead, TableRow, TableCell, TableBody } from '@mui/material';
import LockOpenIcon from '@mui/icons-material/LockOpen';
import LockIcon from '@mui/icons-material/Lock';
import { PageHeader } from '../../components/PageHeader';
import { StatCard } from '../../components/StatCard';
import { useCashStore } from '../../stores/cashStore';
import { useNotificationStore } from '../../stores/notificationStore';
import { cop } from '../../utils/format';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { posService } from '../../services/posService';
import { useState, useEffect } from 'react';
import { useAuthStore } from '../../stores/authStore';
import { BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer, Legend } from 'recharts';
import { ApiError } from '../../services/api';

export function CashPage() {
  const queryClient = useQueryClient();
  const { summary } = useCashStore();
  const showNotification = useNotificationStore(state => state.showNotification);
  const { role } = useAuthStore();
  
  const { data: historyData } = useQuery({ queryKey: ['cash-history'], queryFn: posService.cashHistory });
  
  const cashHistory = historyData ? (Object.values(historyData.reduce((acc: any, h: any) => {
    const date = new Date(h.created_at).toLocaleDateString();
    if (!acc[date]) {
      acc[date] = { date, base_cash: 0, deposits: 0, withdrawals: 0, _opening: 0 };
    }
    acc[date].base_cash += (h.cash_sales || 0);
    // As historyData is DESC (newest first), the last processed item for a day is the first chronologically.
    acc[date]._opening = (h.opening_amount || 0);
    acc[date].deposits += (h.deposits || 0);
    acc[date].withdrawals -= (h.withdrawals || 0);
    return acc;
  }, {})).map((acc: any) => {
    acc.base_cash += acc._opening;
    return acc;
  }) as any[]).reverse() : [];
  
  const [initialAmount, setInitialAmount] = useState(summary.opening_amount);
  const [openNotes, setOpenNotes] = useState('');
  const [finalAmount, setFinalAmount] = useState('');
  const [closeNotes, setCloseNotes] = useState('');
  const [cashSession, setCashSession] = useState<{ id: string; status: string; opening_amount: number } | null>(null);
  const [isCloseModalOpen, setIsCloseModalOpen] = useState(false);
  const [isMovementModalOpen, setIsMovementModalOpen] = useState(false);
  const [movementAmount, setMovementAmount] = useState('');
  const [movementReason, setMovementReason] = useState('');
  const [movementType, setMovementType] = useState('WITHDRAWAL');
  const [negativeItems, setNegativeItems] = useState<{name: string, missing: number}[]>([]);

  useEffect(() => {
    const isCurrentlyOpen = cashSession?.status === 'OPEN';
    if (cashHistory && cashHistory.length > 0 && !isCurrentlyOpen && summary.opening_amount === 0 && initialAmount === 0) {
      setInitialAmount(cashHistory[cashHistory.length - 1]?.closing_amount || 0);
    }
  }, [cashHistory, cashSession, summary, initialAmount]);

  const { data: activeSession, isError, error } = useQuery({
    queryKey: ['cashActive'],
    queryFn: posService.getActiveCashSession,
    refetchInterval: 30000,
    retry: 3,
    retryDelay: 1000,
  });

  const openCash = useMutation({ 
    mutationFn: posService.openCash, 
    onSuccess: (data) => { 
      queryClient.invalidateQueries({ queryKey: ['cash'] })
      queryClient.invalidateQueries({ queryKey: ['cashActive'] })
      queryClient.refetchQueries({ queryKey: ['cashActive'] })
      showNotification("Caja abierta exitosamente", "success");
      if (data?.license?.Warning) {
        showNotification(data.license.Warning, "warning");
      }
    },
    onError: (err: Error) => showNotification(err.message || "Error al abrir caja", "error"),
  });

  const closeCash = useMutation({ 
    mutationFn: posService.closeCash, 
    onSuccess: (data) => { 
      queryClient.invalidateQueries({ queryKey: ['cash'] })
      queryClient.invalidateQueries({ queryKey: ['cashActive'] })
      queryClient.invalidateQueries({ queryKey: ['cashHistory'] })
      queryClient.refetchQueries({ queryKey: ['cashActive'] })
      showNotification("Caja cerrada exitosamente", "success");
      if (data?.license?.Warning) {
        showNotification(data.license.Warning, "warning");
      }
    },
    onError: (err: any) => {
      if (err instanceof ApiError && err.data?.error === 'INVENTORY_NEGATIVE') {
        setIsCloseModalOpen(false);
        setNegativeItems(err.data.items || []);
      } else {
        showNotification(err.message || "Error al cerrar caja", "error");
      }
    },
  });

  const registerMovement = useMutation({
    mutationFn: posService.cashMovement,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cashHistory'] })
      showNotification("Movimiento registrado", "success");
      setIsMovementModalOpen(false);
      setMovementAmount('');
      setMovementReason('');
    },
    onError: (err: Error) => showNotification(err.message || "Error al registrar movimiento", "error"),
  });

  useEffect(() => {
    if (activeSession) {
      setCashSession(activeSession as any);
      
      const session = activeSession as any;
      const cash_sales = session.cash_sales || 0;
      const card_sales = session.card_sales || 0;
      const transfers = session.transfers || 0;
      const tips = session.tips || 0;
      const opening_amount = session.opening_amount || 0;
      const withdrawals = session.withdrawals || 0;
      const deposits = session.deposits || 0;

      useCashStore.getState().setSummary({
        opening_amount,
        cash_sales,
        card_sales,
        transfers,
        tips,
        // Total EN CAJA (efectivo físico): apertura + ventas efectivo + depósitos - retiros
        total: opening_amount + cash_sales + deposits - withdrawals
      });
      // Store deposits/withdrawals separately for display
      (useCashStore.getState() as any)._deposits = deposits;
      (useCashStore.getState() as any)._withdrawals = withdrawals;
    } else {
      setCashSession(null);
      useCashStore.getState().setSummary({
        opening_amount: 0,
        cash_sales: 0,
        card_sales: 0,
        transfers: 0,
        tips: 0,
        total: 0
      });
    }
  }, [activeSession]);

  const isOpen = cashSession?.status === 'OPEN';

  if (isError) {
    return (
      <Stack spacing={3}>
        <PageHeader title="Caja" subtitle="Apertura, cierre y arqueo de caja." />
        <Alert severity="error" sx={{ width: '100%' }}>
          <AlertTitle>Error al verificar estado de caja</AlertTitle>
          {error instanceof Error ? error.message : 'Error desconocido'}
        </Alert>
      </Stack>
    );
  }

  const handleOpenCash = () => {
    openCash.mutate({ opening_amount: initialAmount, notes: openNotes });
  };

  const handleCloseCash = () => {
    const amount = finalAmount || String(summary.total);
    closeCash.mutate({ 
      closing_amount: Number(amount),
      expected_amount: summary.total,
      notes: closeNotes
    });
    setFinalAmount('');
    setCloseNotes('');
  };

  const handleMovement = () => {
    if (!movementAmount || isNaN(Number(movementAmount))) return;
    registerMovement.mutate({
      type: movementType,
      amount: Number(movementAmount),
      reason: movementReason
    });
  };

  return (
    <Stack spacing={3}>
      <PageHeader title="Caja" subtitle="Apertura, cierre y arqueo de caja." />
      
      {/* Cash Register Status */}
      <Paper sx={{ p: 2, mb: 1 }}>
        <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" alignItems={{ sm: 'center' }} gap={2}>
          <Stack spacing={1}>
            <Typography variant="h6" gutterBottom>Estado de Caja</Typography>
            <Stack direction="row" gap={1} alignItems="center" flexWrap="wrap">
              <Chip 
                label={isOpen ? 'Caja ABIERTA' : 'Caja CERRADA'} 
                color={isOpen ? 'success' : 'default'}
                size="medium"
                icon={isOpen ? <LockOpenIcon fontSize="small" /> : <LockIcon fontSize="small" />}
              />
              {isOpen && cashSession && (
                <Typography variant="body2" color="text.secondary">
                  Abierta con ${cop(cashSession.opening_amount)} | Sesión: {cashSession.id.substring(0, 8)}...
                </Typography>
              )}
            </Stack>
          </Stack>
          
          {isOpen ? (
            <Typography variant="body2" color="text.secondary">
              Puede cobrar mesas y registrar ventas
            </Typography>
          ) : (
            <Alert severity="info" sx={{ minWidth: 280 }}>
              <AlertTitle>Caja cerrada</AlertTitle>
              Debe abrir caja antes de cobrar mesas
            </Alert>
          )}
        </Stack>
      </Paper>

      <Grid container spacing={2}>
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 2 }}>
            <Stack spacing={2}>
              <Typography variant="h6">Apertura de Caja</Typography>
              <TextField 
                label="Monto inicial" 
                value={initialAmount} 
                onChange={(e) => setInitialAmount(Number(e.target.value))} 
                type="number"
                disabled={isOpen}
              />
              <TextField 
                label="Observaciones" 
                value={openNotes}
                onChange={(e) => setOpenNotes(e.target.value)}
                multiline 
                minRows={3} 
                disabled={isOpen}
              />
              <Button 
                variant="contained" 
                startIcon={<LockOpenIcon />} 
                onClick={handleOpenCash}
                disabled={isOpen}
                fullWidth
                size="large"
              >
                Abrir Caja
              </Button>
            </Stack>
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={8}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <StatCard label="Ventas efectivo" value={cop(summary.cash_sales)} icon={<LockIcon />} />
              </Grid>
              <Grid item xs={12} sm={6}>
                <StatCard label="Ventas tarjeta/débito" value={cop(summary.card_sales)} icon={<LockIcon />} />
              </Grid>
              <Grid item xs={12} sm={6}>
                <StatCard label="Transferencias" value={cop(summary.transfers)} icon={<LockIcon />} />
              </Grid>
              <Grid item xs={12} sm={6}>
                <StatCard label="Propinas" value={cop(summary.tips)} icon={<LockIcon />} />
              </Grid>
            </Grid>

            <Paper sx={{ p: 2, mt: 2, bgcolor: '#f0fdf4', border: '1px solid #bbf7d0' }}>
              <Typography variant="body2" color="text.secondary" gutterBottom>Desglose del efectivo en caja</Typography>
              <Stack spacing={0.5}>
                <Stack direction="row" justifyContent="space-between">
                  <Typography variant="body2">Apertura de caja</Typography>
                  <Typography variant="body2" fontWeight="bold">{cop(summary.opening_amount)}</Typography>
                </Stack>
                <Stack direction="row" justifyContent="space-between">
                  <Typography variant="body2">+ Ventas en efectivo</Typography>
                  <Typography variant="body2" fontWeight="bold" color="success.main">{cop(summary.cash_sales)}</Typography>
                </Stack>
                <Stack direction="row" justifyContent="space-between">
                  <Typography variant="body2">+ Depósitos</Typography>
                  <Typography variant="body2" fontWeight="bold" color="success.main">{cop((useCashStore.getState() as any)._deposits || 0)}</Typography>
                </Stack>
                <Stack direction="row" justifyContent="space-between">
                  <Typography variant="body2">- Retiros</Typography>
                  <Typography variant="body2" fontWeight="bold" color="error.main">{cop((useCashStore.getState() as any)._withdrawals || 0)}</Typography>
                </Stack>
              </Stack>
            </Paper>
          
          <Paper sx={{ p: 2, mt: 2 }}>
            <Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" alignItems={{ md: 'center' }} gap={2}>
              <Box>
                <Typography variant="body2" color="text.secondary" gutterBottom>Total en caja (efectivo físico)</Typography>
                <Typography variant="h5">Total: <strong>{cop(summary.total)}</strong></Typography>
                <Typography variant="caption" color="text.secondary">
                  = Apertura {cop(summary.opening_amount)} + Ventas efectivo {cop(summary.cash_sales)}
                </Typography>
              </Box>
              
              {isOpen && (
                <Stack direction="row" spacing={2}>
                  <Button 
                    variant="outlined" 
                    color="primary" 
                    onClick={() => setIsMovementModalOpen(true)}
                    size="large"
                  >
                    Movimiento de Efectivo
                  </Button>
                  <Button 
                    variant="contained" 
                    color="error" 
                    startIcon={<LockIcon />} 
                    onClick={() => setIsCloseModalOpen(true)}
                    size="large"
                  >
                    Cerrar Caja
                  </Button>
                </Stack>
              )}
            </Stack>
          </Paper>
        </Grid>
      </Grid>

      {role === 'admin' && (
        <Paper sx={{ p: 2, mt: 2, height: 400 }}>
          <Typography variant="h6" gutterBottom>Historial de apertura de caja (30 días)</Typography>
          <ResponsiveContainer width="100%" height="85%">
            <BarChart data={cashHistory}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip formatter={(value) => cop(Math.abs(Number(value)))} />
              <Legend />
              <Bar dataKey="base_cash" stackId="a" fill="#10b981" name="Caja (Apertura + Ventas)" />
              <Bar dataKey="deposits" stackId="a" fill="#3b82f6" name="Ingresos Extra" />
              <Bar dataKey="withdrawals" stackId="a" fill="#ef4444" name="Retiros (Propietario)" />
            </BarChart>
          </ResponsiveContainer>
        </Paper>
      )}

      {/* Close Cash Dialog */}
      <Dialog open={isCloseModalOpen} onClose={() => setIsCloseModalOpen(false)}>
        <DialogTitle>Confirmar Cierre de Caja</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ mb: 2 }}>
            El sistema calculó un total en caja de <strong>{cop(summary.total)}</strong>.
            Por favor ingrese el monto final contado.
          </DialogContentText>
          <TextField
            autoFocus
            fullWidth
            label="Monto final contado"
            value={finalAmount}
            onChange={(e) => setFinalAmount(e.target.value)}
            type="number"
            placeholder={String(summary.total)}
            InputProps={{
              startAdornment: <Box sx={{ pl: 1, display: 'flex', alignItems: 'center' }}>$</Box>
            }}
          />
          <TextField
            fullWidth
            label="Observaciones (Opcional)"
            value={closeNotes}
            onChange={(e) => setCloseNotes(e.target.value)}
            multiline
            rows={2}
            sx={{ mt: 2 }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setIsCloseModalOpen(false)}>Cancelar</Button>
          <Button 
            onClick={() => {
              handleCloseCash();
              setIsCloseModalOpen(false);
            }} 
            color="error" 
            variant="contained"
          >
            Confirmar Cierre
          </Button>
        </DialogActions>
      </Dialog>

      {/* Movement Dialog */}
      <Dialog open={isMovementModalOpen} onClose={() => setIsMovementModalOpen(false)}>
        <DialogTitle>Registrar Movimiento de Efectivo</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ mb: 2 }}>
            Registre si hubo un retiro (dueño, proveedor) o ingreso de efectivo a la caja.
          </DialogContentText>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField
              select
              fullWidth
              label="Tipo de Movimiento"
              value={movementType}
              onChange={(e) => setMovementType(e.target.value)}
              SelectProps={{ native: true }}
            >
              <option value="WITHDRAWAL">Retiro</option>
              <option value="DEPOSIT">Ingreso</option>
            </TextField>
            <TextField
              fullWidth
              label="Monto"
              value={movementAmount}
              onChange={(e) => setMovementAmount(e.target.value)}
              type="number"
              InputProps={{
                startAdornment: <Box sx={{ pl: 1, display: 'flex', alignItems: 'center' }}>$</Box>
              }}
            />
            <TextField
              fullWidth
              label="Motivo (Ej. Retiro de dueño)"
              value={movementReason}
              onChange={(e) => setMovementReason(e.target.value)}
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setIsMovementModalOpen(false)}>Cancelar</Button>
          <Button 
            onClick={handleMovement} 
            color="primary" 
            variant="contained"
            disabled={!movementAmount}
          >
            Registrar
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* Negative Inventory Dialog */}
      <Dialog open={negativeItems.length > 0} onClose={() => setNegativeItems([])}>
        <DialogTitle>Diferencias de Inventario</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ mb: 2 }}>
            No se puede cerrar la caja. Existen insumos con stock negativo que deben regularizarse (registrar entradas).
          </DialogContentText>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Producto/Insumo</TableCell>
                <TableCell align="right">Faltante</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {negativeItems.map((item, index) => (
                <TableRow key={index}>
                  <TableCell>{item.name}</TableCell>
                  <TableCell align="right" sx={{ color: 'error.main', fontWeight: 'bold' }}>{item.missing}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setNegativeItems([])} variant="contained" color="primary">Entendido</Button>
        </DialogActions>
      </Dialog>
    </Stack>
  );
}