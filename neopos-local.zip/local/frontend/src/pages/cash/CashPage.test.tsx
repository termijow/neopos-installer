import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import { CashPage } from './CashPage';
import { useNotificationStore } from '../../stores/notificationStore';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useCashStore } from '../../stores/cashStore';

const queryClient = new QueryClient();

describe('CashPage', () => {
  beforeEach(() => {
    useNotificationStore.setState({ open: false, message: '', severity: 'info' });
    useCashStore.setState({
      summary: { opening_amount: 250000, cash_sales: 1280000, card_sales: 840000, transfers: 310000, tips: 95000, total: 2525000 }
    });
    vi.clearAllMocks();
  });

  it('renders cash page with open/close state', () => {
    render(
      <QueryClientProvider client={queryClient}>
        <CashPage />
      </QueryClientProvider>
    );
    expect(screen.getByText('Caja')).toBeInTheDocument();
    expect(screen.getByText('Apertura, cierre y arqueo de caja.')).toBeInTheDocument();
  });

  it('shows open cash button when closed', () => {
    render(
      <QueryClientProvider client={queryClient}>
        <CashPage />
      </QueryClientProvider>
    );
    const btn = screen.getByRole('button', { name: /Abrir Caja/i });
    expect(btn).toBeInTheDocument();
  });

  it('shows cash status chip', () => {
    render(
      <QueryClientProvider client={queryClient}>
        <CashPage />
      </QueryClientProvider>
    );
    expect(screen.getByText('Caja CERRADA')).toBeInTheDocument();
  });

  it('shows summary cards', () => {
    render(
      <QueryClientProvider client={queryClient}>
        <CashPage />
      </QueryClientProvider>
    );
    expect(screen.getByText('Ventas efectivo')).toBeInTheDocument();
    expect(screen.getByText('Ventas tarjeta')).toBeInTheDocument();
    expect(screen.getByText('Transferencias')).toBeInTheDocument();
    expect(screen.getByText('Propinas')).toBeInTheDocument();
  });
});