import { useState } from 'react';
import { Button, Grid, Paper, Stack, Table, TableBody, TableCell, TableHead, TableRow, TextField, Typography, ToggleButton, ToggleButtonGroup, Autocomplete, InputAdornment, MenuItem } from '@mui/material';
import AddBoxIcon from '@mui/icons-material/AddBox';
import TuneIcon from '@mui/icons-material/Tune';
import SearchIcon from '@mui/icons-material/Search';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { PageHeader } from '../../components/PageHeader';
import { AppPagination } from '../../components/AppPagination';
import { posService } from '../../services/posService';
import { dateTime } from '../../utils/format';
import { mockInventory } from '../../utils/mockData';

interface MovementForm {
  product_id: string;
  quantity: number;
  reason: string;
}

export function InventoryPage() {
  const queryClient = useQueryClient();
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const { data: responseData } = useQuery({ queryKey: ['inventory', page + 1, rowsPerPage], queryFn: () => posService.inventory(page + 1, rowsPerPage) });
  const { data: stockData } = useQuery({ queryKey: ['inventory-stock'], queryFn: posService.inventoryStock });

  const inventoryList = (responseData && !Array.isArray(responseData) && 'data' in (responseData as any)) ? (responseData as any).data : (Array.isArray(responseData) ? responseData : mockInventory);
  const totalHistory = (responseData && !Array.isArray(responseData) && 'meta' in (responseData as any)) ? ((responseData as any).meta?.total || 0) : inventoryList.length;
  
  const displayHistory = inventoryList;

  const entry = useMutation({ mutationFn: posService.inventoryIn, onSuccess: () => queryClient.invalidateQueries({ queryKey: ['inventory'] }) });
  const adjustment = useMutation({ mutationFn: posService.inventoryAdjustment, onSuccess: () => queryClient.invalidateQueries({ queryKey: ['inventory'] }) });
  const createProductMut = useMutation({ mutationFn: posService.createProduct, onSuccess: () => queryClient.invalidateQueries({ queryKey: ['products'] }) });

  const { register, handleSubmit, reset, setValue } = useForm<MovementForm>({ defaultValues: { product_id: '', quantity: 1, reason: '' } });
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [productSearch, setProductSearch] = useState('');

  const { data: catData } = useQuery({ queryKey: ['categories'], queryFn: posService.categories });
  const categoriesList = Array.isArray(catData) ? catData : [];
  const insumosCategory = categoriesList.find((c: any) => c.name.toUpperCase() === 'INSUMOS');
  const showInsumosOption = insumosCategory ? !insumosCategory.is_hidden : false;

  const { data: prodData } = useQuery({ queryKey: ['products'], queryFn: () => posService.products(1, 1000) });
  const isProdPaginated = prodData && !Array.isArray(prodData) && 'data' in prodData;
  const products = isProdPaginated ? (prodData as any).data : (Array.isArray(prodData) ? prodData : []);

  const getProductName = (idOrObj: any) => {
    if (typeof idOrObj === 'object' && idOrObj !== null && idOrObj.name) {
      return idOrObj.name;
    }
    const p = products.find((p: any) => p.id === idOrObj);
    return p ? p.name : idOrObj;
  };

  const { data: predictionData } = useQuery({ queryKey: ['inventory-prediction'], queryFn: posService.inventoryPrediction });
  
  const [view, setView] = useState<'stock' | 'prediction' | 'history'>('stock');

  const filteredProducts = products.filter((p: any) => p.name.toLowerCase().includes(productSearch.toLowerCase()));
  
  const groupedProducts = Object.values(filteredProducts.reduce((acc: any, p: any) => {
    const name = p.name.trim().toLowerCase();
    if (!acc[name]) {
      acc[name] = { ...p, stock: 0 };
    }
    acc[name].stock += stockData?.[p.id] || 0;
    return acc;
  }, {}));

  const sortedProducts = (groupedProducts as any[]).sort((a: any, b: any) => {
    return b.stock - a.stock;
  });

  const displayProducts = sortedProducts.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  return (
    <Stack spacing={3}>
      <PageHeader title="Inventario" subtitle="Movimientos, entradas, salidas, ajustes y proyecciones automáticas." />
      
      <Stack direction="row" justifyContent="center">
        <ToggleButtonGroup
          color="primary"
          value={view}
          exclusive
          onChange={(_, val) => { if (val) { setView(val); setPage(0); } }}
          aria-label="Vistas de inventario"
        >
          <ToggleButton value="stock">Inventario Actual (Stock)</ToggleButton>
          <ToggleButton value="prediction">Predicción de Pedidos (7 días)</ToggleButton>
          <ToggleButton value="history">Historial de Movimientos</ToggleButton>
        </ToggleButtonGroup>
      </Stack>

      <Grid container spacing={2}>
        <Grid item xs={12} md={4}>
          <Paper component="form" sx={{ p: 2 }} onSubmit={handleSubmit(async (values) => { 
            let finalProductId = values.product_id;
            if (typeof selectedProduct === 'string') {
              const existing = products.find((p: any) => p.name.toLowerCase() === (selectedProduct as string).toLowerCase());
              if (existing) {
                finalProductId = existing.id;
              } else {
                const newProduct = await createProductMut.mutateAsync({ name: selectedProduct, active: true, price: 0, category_id: insumosCategory?.id });
                finalProductId = newProduct.id;
              }
            }
            entry.mutate({ ...values, product_id: finalProductId }); 
            reset(); 
            setSelectedProduct(null); 
          })}>
            <Stack spacing={2}>
              <Typography variant="h6">Registrar entrada</Typography>
              
              <Autocomplete
                freeSolo
                options={products}
                getOptionLabel={(p: any) => typeof p === 'string' ? p : `${p.name} (Stock: ${stockData?.[p.id] || 0})`}
                value={selectedProduct}
                onChange={(_, newValue) => {
                  setSelectedProduct(newValue);
                  if (typeof newValue === 'string') {
                    setValue('product_id', newValue);
                  } else {
                    setValue('product_id', newValue ? newValue.id : '');
                  }
                }}
                renderInput={(params) => (
                  <TextField {...params} label="Buscar Producto (Escribe aquí)" />
                )}
              />

              <TextField label="Cantidad" type="number" {...register('quantity', { valueAsNumber: true })} />
              <TextField 
                select
                label="Motivo" 
                defaultValue=""
                inputProps={register('reason')} 
              >
                <MenuItem value="Compra">Compra</MenuItem>
                <MenuItem value="Devolución">Devolución</MenuItem>
                <MenuItem value="Ajuste">Ajuste</MenuItem>
                {showInsumosOption && <MenuItem value="Insumo">Insumo</MenuItem>}
              </TextField>
              <Button type="submit" variant="contained" startIcon={<AddBoxIcon />}>Entrada</Button>
              <Button type="button" variant="outlined" startIcon={<TuneIcon />} onClick={handleSubmit((values) => { adjustment.mutate(values); reset(); setSelectedProduct(null); })}>Ajustar stock</Button>
            </Stack>
          </Paper>
        </Grid>
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 2 }}>
            
            {view === 'history' && (
              <>
                <Typography variant="h6" gutterBottom>Historial de Movimientos</Typography>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Fecha</TableCell>
                      <TableCell>Producto</TableCell>
                      <TableCell>Cantidad</TableCell>
                      <TableCell>Tipo</TableCell>
                      <TableCell>Usuario</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {displayHistory.map((movement: any) => (
                      <TableRow key={movement.id}>
                        <TableCell>{movement.created_at ? dateTime.format(new Date(movement.created_at)) : '-'}</TableCell>
                        <TableCell>{getProductName(movement.product ?? movement.product_id)}</TableCell>
                        <TableCell>{movement.quantity}</TableCell>
                        <TableCell>{movement.type}</TableCell>
                        <TableCell>Administrador</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                <AppPagination
                  count={totalHistory}
                  page={page}
                  onPageChange={(newPage) => setPage(newPage)}
                  rowsPerPage={rowsPerPage}
                  onRowsPerPageChange={(newRowsPerPage) => {
                    setRowsPerPage(newRowsPerPage);
                    setPage(0);
                  }}
                  labelRowsPerPage="Movimientos por página:"
                />
              </>
            )}

            {view === 'stock' && (
              <>
                <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
                  <Typography variant="h6">Inventario Actual</Typography>
                  <TextField
                    size="small"
                    placeholder="Buscar producto..."
                    value={productSearch}
                    onChange={(e) => { setProductSearch(e.target.value); setPage(0); }}
                    InputProps={{
                      startAdornment: <InputAdornment position="start"><SearchIcon /></InputAdornment>
                    }}
                  />
                </Stack>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Producto</TableCell>
                      <TableCell>Stock Disponible</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {displayProducts.map((p: any) => (
                      <TableRow key={p.id}>
                        <TableCell>{p.name}</TableCell>
                        <TableCell sx={{ fontWeight: 'bold', color: p.stock < 5 ? 'error.main' : 'success.main' }}>
                          {p.stock}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                <AppPagination
                  count={sortedProducts.length}
                  page={page}
                  onPageChange={(newPage) => setPage(newPage)}
                  rowsPerPage={rowsPerPage}
                  onRowsPerPageChange={(newRowsPerPage) => {
                    setRowsPerPage(newRowsPerPage);
                    setPage(0);
                  }}
                  labelRowsPerPage="Productos por página:"
                />
              </>
            )}

            {view === 'prediction' && (
              <>
                <Typography variant="h6" gutterBottom>Predicción de Pedidos (próximos 7 días)</Typography>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  Basado en el consumo promedio de los últimos 28 días, con un margen de seguridad del 20%. Solo se muestran insumos que necesitan reabastecimiento.
                </Typography>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Producto / Insumo</TableCell>
                      <TableCell>Stock Actual</TableCell>
                      <TableCell>Consumo diario prom.</TableCell>
                      <TableCell sx={{ fontWeight: 'bold', color: 'primary.main' }}>🛒 Pedir para la semana</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {displayProducts.map((p: any) => {
                      const stock = p.stock;
                      const orderQty = predictionData?.[p.id] || 0;
                      if (orderQty <= 0) return null; // Only show items that need ordering
                      return (
                        <TableRow key={p.id}>
                          <TableCell>{p.name}</TableCell>
                          <TableCell sx={{ color: stock <= 0 ? 'error.main' : 'text.primary', fontWeight: stock <= 0 ? 'bold' : 'normal' }}>{stock}</TableCell>
                          <TableCell sx={{ color: 'text.secondary' }}>~{((orderQty / 1.2 + stock) / 7).toFixed(1)} / día</TableCell>
                          <TableCell sx={{ fontWeight: 'bold', color: 'primary.main' }}>
                            Pedir {orderQty} unds
                          </TableCell>
                        </TableRow>
                      );
                    })}
                    {displayProducts.every((p: any) => (predictionData?.[p.id] || 0) <= 0) && (
                      <TableRow>
                        <TableCell colSpan={4} align="center" sx={{ py: 4, color: 'text.secondary', fontStyle: 'italic' }}>
                          ✅ Todos los insumos tienen stock suficiente para la próxima semana.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
                <AppPagination
                  count={products.length}
                  page={page}
                  onPageChange={(newPage) => setPage(newPage)}
                  rowsPerPage={rowsPerPage}
                  onRowsPerPageChange={(newRowsPerPage) => {
                    setRowsPerPage(newRowsPerPage);
                    setPage(0);
                  }}
                  labelRowsPerPage="Productos por página:"
                />
              </>
            )}

          </Paper>
        </Grid>
      </Grid>
    </Stack>
  );
}
