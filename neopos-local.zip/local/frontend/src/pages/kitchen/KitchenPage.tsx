import { useState, useEffect } from 'react';
import { Button, Card, CardContent, Stack, Typography, Box, IconButton, Paper } from '@mui/material';
import SoupKitchenIcon from '@mui/icons-material/SoupKitchen';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import DragIndicatorIcon from '@mui/icons-material/DragIndicator';
import DoneAllIcon from '@mui/icons-material/DoneAll';
import HourglassEmptyIcon from '@mui/icons-material/HourglassEmpty';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { PageHeader } from '../../components/PageHeader';
import { posService } from '../../services/posService';
import type { KitchenOrder } from '../../types/domain';
import { mockKitchenOrders } from '../../utils/mockData';

type KitchenStatus = 'PENDING' | 'COOKING' | 'READY' | 'SERVED';

function formatRelativeTime(dateStr?: string) {
  if (!dateStr) return "Hace un momento";
  const date = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  
  if (diffMins < 1) return "Hace un momento";
  if (diffMins === 1) return "Hace 1 min";
  return `Hace ${diffMins} min`;
}

function parseKitchenNotes(notes: string) {
  const tableMatch = notes.match(/^Mesa:\s*(\d+)/i);
  const tableNum = tableMatch ? tableMatch[1] : (notes.match(/Mesa\s*(\d+)/i)?.[1] ?? notes.match(/\d+/)?.[0] ?? '12');
  
  let cleanNotes = notes;
  let itemsList: string[] = [];
  
  if (notes.startsWith('Mesa:')) {
    const detailIndex = notes.indexOf('Detalle:\n');
    if (detailIndex !== -1) {
      const notesIndex = notes.indexOf('\n\nNotas Cocina:');
      const itemsText = notesIndex !== -1 
        ? notes.substring(detailIndex + 9, notesIndex) 
        : notes.substring(detailIndex + 9);
      
      itemsList = itemsText.split('\n').map(line => line.trim()).filter(line => line.length > 0);
      
      cleanNotes = notesIndex !== -1 ? notes.substring(notesIndex + 15).trim() : '';
    }
  } else if (notes.includes(' - ')) {
    const parts = notes.split(' - ');
    if (parts.length >= 2) {
      cleanNotes = parts.slice(1).join(' - ').trim();
    }
  } else {
    cleanNotes = notes.replace(/^Mesa\s*\d+\s*/i, '').trim();
  }
  
  return { tableNum, itemsList, cleanNotes };
}

export function KitchenPage() {
  const queryClient = useQueryClient();
  const { data = mockKitchenOrders } = useQuery({ 
    queryKey: ['kitchen'], 
    queryFn: posService.kitchenOrders, 
    refetchInterval: 5000 
  });

  const update = useMutation({
    mutationFn: ({ id, status }: { id: string; status: KitchenStatus }) => 
      posService.updateKitchenStatus(id, status),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['kitchen'] })
  });

  // Track dragging state to style columns visually when dragging over them
  const [draggedOverColumn, setDraggedOverColumn] = useState<KitchenStatus | null>(null);

  // Force periodic re-renders every 30s to recalculate elapsed time for auto-clearing SERVED orders
  const [_tick, setTick] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => setTick(t => t + 1), 30000);
    return () => clearInterval(timer);
  }, []);

  const handleDragStart = (e: React.DragEvent, id: string) => {
    e.dataTransfer.setData('text/plain', id);
  };

  const handleDragOver = (e: React.DragEvent, columnStatus: KitchenStatus) => {
    e.preventDefault();
    if (draggedOverColumn !== columnStatus) {
      setDraggedOverColumn(columnStatus);
    }
  };

  const handleDragLeave = () => {
    setDraggedOverColumn(null);
  };

  const handleDrop = (e: React.DragEvent, targetStatus: KitchenStatus) => {
    e.preventDefault();
    setDraggedOverColumn(null);
    const orderId = e.dataTransfer.getData('text/plain');
    if (orderId) {
      update.mutate({ id: orderId, status: targetStatus });
    }
  };

  const moveOrder = (id: string, currentStatus: KitchenStatus, direction: 'forward' | 'backward') => {
    const statuses: KitchenStatus[] = ['PENDING', 'COOKING', 'READY', 'SERVED'];
    const currentIndex = statuses.indexOf(currentStatus);
    let nextIndex = currentIndex;

    if (direction === 'forward' && currentIndex < statuses.length - 1) {
      nextIndex = currentIndex + 1;
    } else if (direction === 'backward' && currentIndex > 0) {
      nextIndex = currentIndex - 1;
    }

    if (nextIndex !== currentIndex) {
      update.mutate({ id, status: statuses[nextIndex] });
    }
  };

  const getColumnConfig = (status: KitchenStatus) => {
    switch (status) {
      case 'PENDING':
        return {
          color: '#e28743',
          bg: '#fffbf5',
          headerBg: 'rgba(226, 135, 67, 0.1)',
          icon: <HourglassEmptyIcon sx={{ color: '#e28743' }} />
        };
      case 'COOKING':
        return {
          color: '#3b82f6',
          bg: '#f8fafc',
          headerBg: 'rgba(59, 130, 246, 0.1)',
          icon: <SoupKitchenIcon sx={{ color: '#3b82f6' }} />
        };
      case 'READY':
        return {
          color: '#10b981',
          bg: '#f0fdf4',
          headerBg: 'rgba(16, 185, 129, 0.1)',
          icon: <CheckCircleIcon sx={{ color: '#10b981' }} />
        };
      case 'SERVED':
        return {
          color: '#6b7280',
          bg: '#f9fafb',
          headerBg: 'rgba(107, 114, 128, 0.1)',
          icon: <DoneAllIcon sx={{ color: '#6b7280' }} />
        };
    }
  };

  const columns: { status: KitchenStatus; label: string }[] = [
    { status: 'PENDING', label: 'Pendientes' },
    { status: 'COOKING', label: 'En Preparación' },
    { status: 'READY', label: 'Listos' },
    { status: 'SERVED', label: 'Entregados' }
  ];

  return (
    <Stack spacing={3} sx={{ height: '100%' }}>
      <PageHeader 
        title="Tablero de Cocina" 
        subtitle="Arrastra las comandas entre columnas o utiliza los controles rápidos para actualizar el estado del servicio." 
      />

      <Box sx={{ flexGrow: 1, overflowX: 'auto', pb: 2 }}>
        <Stack direction="row" spacing={2} sx={{ minWidth: 1000, height: '70vh' }}>
          {columns.map((column) => {
            const config = getColumnConfig(column.status);
            const columnOrders = data.filter(order => {
              if (order.status !== column.status) return false;
              if (column.status === 'SERVED') {
                const timeReference = order.updated_at || order.created_at;
                if (timeReference) {
                  const elapsedMs = new Date().getTime() - new Date(timeReference).getTime();
                  if (elapsedMs > 3 * 60 * 1000) {
                    return false;
                  }
                }
              }
              return true;
            });
            const isDraggingOver = draggedOverColumn === column.status;

            return (
              <Paper
                key={column.status}
                onDragOver={(e: React.DragEvent) => handleDragOver(e, column.status)}
                onDragLeave={handleDragLeave}
                onDrop={(e: React.DragEvent) => handleDrop(e, column.status)}
                elevation={isDraggingOver ? 4 : 0}
                sx={{
                  flex: 1,
                  display: 'flex',
                  flexDirection: 'column',
                  bgcolor: isDraggingOver ? 'action.hover' : '#f4f6f8',
                  border: isDraggingOver ? `2px dashed ${config.color}` : '1px solid #e2e8f0',
                  borderRadius: 3,
                  overflow: 'hidden',
                  transition: 'all 0.2s ease',
                  maxHeight: '100%'
                }}
              >
                <Stack sx={{ width: '100%', height: '100%' }}>
                  {/* Column Header */}
                  <Box
                    sx={{
                      p: 2,
                      bgcolor: config.headerBg,
                      borderBottom: `3px solid ${config.color}`,
                      display: 'flex',
                      alignItems: 'center',
                    }}
                  >
                    <Stack direction="row" spacing={1.5} alignItems="center" sx={{ width: '100%' }} justifyContent="space-between">
                      <Stack direction="row" spacing={1} alignItems="center">
                        {config.icon}
                        <Typography variant="subtitle1" fontWeight="bold" sx={{ color: 'text.primary' }}>
                          {column.label}
                        </Typography>
                      </Stack>
                      <Box
                        sx={{
                          px: 1.5,
                          py: 0.25,
                          bgcolor: 'white',
                          border: `1px solid ${config.color}`,
                          color: config.color,
                          borderRadius: '12px',
                          fontSize: '0.75rem',
                          fontWeight: 'bold'
                        }}
                      >
                        {columnOrders.length}
                      </Box>
                    </Stack>
                  </Box>

                  {/* Orders Scrollable List */}
                  <Stack
                    spacing={2}
                    sx={{
                      p: 2,
                      flexGrow: 1,
                      overflowY: 'auto',
                      '&::-webkit-scrollbar': { width: '6px' },
                      '&::-webkit-scrollbar-thumb': { bgcolor: '#cbd5e1', borderRadius: '3px' }
                    }}
                  >
                    {columnOrders.length === 0 ? (
                      <Box
                        sx={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          height: 100,
                          border: '1px dashed #cbd5e1',
                          borderRadius: 2,
                          color: 'text.secondary',
                          bgcolor: 'white',
                          opacity: 0.6
                        }}
                      >
                        <Typography variant="body2" color="text.secondary">
                          Sin pedidos
                        </Typography>
                      </Box>
                    ) : (
                      columnOrders.map((order) => {
                        const { tableNum, itemsList, cleanNotes } = parseKitchenNotes(order.notes || '');
                        const displayId = order.order_id.length > 8 ? order.order_id.substring(0, 8) : order.order_id;

                        return (
                          <Card
                            key={order.id}
                            draggable
                            onDragStart={(e) => handleDragStart(e, order.id)}
                            sx={{
                              borderLeft: `5px solid ${config.color}`,
                              transition: 'box-shadow 0.2s, transform 0.2s',
                              cursor: 'grab',
                              borderRadius: 2.5,
                              flexShrink: 0,
                              '&:hover': {
                                boxShadow: 3,
                                transform: 'translateY(-1px)'
                              },
                              '&:active': {
                                cursor: 'grabbing'
                              }
                            }}
                          >
                            <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                              <Stack spacing={1.5}>
                                {/* Header (ID + Time) */}
                                <Stack direction="row" justifyContent="space-between" alignItems="center">
                                  <Stack direction="row" spacing={0.5} alignItems="center">
                                    <DragIndicatorIcon sx={{ color: 'text.secondary', fontSize: '1rem', cursor: 'grab' }} />
                                    <Typography variant="subtitle2" fontWeight="bold">
                                      Pedido #{displayId}
                                    </Typography>
                                  </Stack>
                                  <Stack direction="row" spacing={0.5} alignItems="center" sx={{ color: 'text.secondary' }}>
                                    <AccessTimeIcon sx={{ fontSize: '0.85rem' }} />
                                    <Typography variant="caption">
                                      {formatRelativeTime(order.created_at)}
                                    </Typography>
                                  </Stack>
                                </Stack>

                                {/* Table Indicator */}
                                <Box sx={{ display: 'flex' }}>
                                  <Box
                                    sx={{
                                      px: 1.25,
                                      py: 0.35,
                                      bgcolor: config.headerBg,
                                      color: config.color,
                                      borderRadius: 1.5,
                                      fontSize: '0.75rem',
                                      fontWeight: 'bold'
                                    }}
                                  >
                                    Mesa {tableNum}
                                  </Box>
                                </Box>

                                {/* Notes / Products */}
                                {itemsList.length > 0 ? (
                                  <Stack spacing={0.5} sx={{ my: 0.5 }}>
                                    {itemsList.map((item, idx) => {
                                      const itemMatch = item.match(/^•\s*(\d+x)\s+(.+)$/);
                                      const qty = itemMatch ? itemMatch[1] : '';
                                      const name = itemMatch ? itemMatch[2] : item;
                                      return (
                                        <Box key={idx} sx={{ display: 'flex', gap: 1, py: 0.5, borderBottom: '1px solid #f1f5f9' }}>
                                          {qty && (
                                            <Typography variant="body2" fontWeight="bold" color="secondary.main" sx={{ fontVariantNumeric: 'tabular-nums' }}>
                                              {qty}
                                            </Typography>
                                          )}
                                          <Typography variant="body2" sx={{ color: 'text.primary', fontWeight: 500 }}>
                                            {name}
                                          </Typography>
                                        </Box>
                                      );
                                    })}
                                  </Stack>
                                ) : (
                                  <Typography variant="body2" sx={{ color: 'text.primary', whiteSpace: 'pre-line', fontSize: '0.88rem' }}>
                                    {cleanNotes || order.notes}
                                  </Typography>
                                )}

                                {/* Special Instructions alert box */}
                                {itemsList.length > 0 && cleanNotes && (
                                  <Box 
                                    sx={{ 
                                      p: 1.25, 
                                      borderRadius: 1.5, 
                                      bgcolor: '#fff7ed', 
                                      border: '1px solid #ffedd5',
                                      display: 'flex',
                                      flexDirection: 'column',
                                      gap: 0.5,
                                      mt: 1
                                    }}
                                  >
                                    <Typography variant="caption" fontWeight="bold" color="#0f172a" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                                      ⚠️ Notas Cocina:
                                    </Typography>
                                    <Typography variant="caption" sx={{ color: '#c2410c', fontWeight: 600 }}>
                                      {cleanNotes}
                                    </Typography>
                                  </Box>
                                )}
                              </Stack>
                            </CardContent>
                          </Card>
                        );
                      })
                    )}
                  </Stack>
                </Stack>
              </Paper>
            );
          })}
        </Stack>
      </Box>
    </Stack>
  );
}
