import React, { useState, useEffect } from 'react';
import { Box, Typography, Paper, Tabs, Tab, Alert, AlertTitle, Button, CircularProgress, LinearProgress, Grid, Card, CardContent, CardActions, TextField, MenuItem } from '@mui/material';
import BugReportIcon from '@mui/icons-material/BugReport';
import { api } from '../../services/api';
import PrintIcon from '@mui/icons-material/Print';

export function DebugPage() {
  const [tabIndex, setTabIndex] = useState(0);
  
  const [seederStatus, setSeederStatus] = useState<any>(null);
  const [licenseLoading, setLicenseLoading] = useState(false);
  const [licenseResult, setLicenseResult] = useState<any>(null);

  const [testPrinterLoading, setTestPrinterLoading] = useState(false);
  const [testPrinterType, setTestPrinterType] = useState('usb');
  const [testPrinterAddress, setTestPrinterAddress] = useState('USB001');

  const [syncStatus, setSyncStatus] = useState<any>(null);
  const [syncLogs, setSyncLogs] = useState<any[]>([]);
  const [cloudLogs, setCloudLogs] = useState<string>('');
  const [cloudLogsLoading, setCloudLogsLoading] = useState(false);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabIndex(newValue);
  };

  const fetchCloudLogs = async () => {
    try {
      setCloudLogsLoading(true);
      const data = await api<any>('/debug/cloud-logs', { method: 'GET' });
      setCloudLogs(data?.logs || "No se pudieron obtener los logs de la nube");
    } catch (err: any) {
      setCloudLogs(err.message || "Error obteniendo logs de la nube");
    } finally {
      setCloudLogsLoading(false);
    }
  };

  useEffect(() => {
    if (tabIndex === 3) {
      fetchCloudLogs();
    }
  }, [tabIndex]);

  const checkSeederStatus = async () => {
    try {
      const data = await api<any>('/debug/seed/status', { method: 'GET' });
      setSeederStatus(data);
    } catch (err) {
      console.error(err);
    }
  };

  const checkSyncStatus = async () => {
    try {
      const statusData = await api<any>('/sync/status', { method: 'GET' });
      setSyncStatus(statusData);
      const logsData = await api<any>('/sync/logs', { method: 'GET' });
      setSyncLogs(logsData?.logs || []);
    } catch (err) {
      console.error(err);
    }
  };

  const handleForceSync = async () => {
    try {
      await api<any>('/sync/trigger', { method: 'POST' });
      alert("Sincronización forzada iniciada. Revisa el estado en unos segundos.");
      checkSyncStatus();
    } catch (err: any) {
      alert("Error al forzar la sincronización: " + (err.message || err));
    }
  };

  useEffect(() => {
    // Initial check
    checkSeederStatus();
    checkSyncStatus();
    
    // Poll every 2 seconds if running
    const interval = setInterval(() => {
      if (seederStatus?.is_running) {
        checkSeederStatus();
      }
    }, 2000);
    
    return () => clearInterval(interval);
  }, [seederStatus?.is_running]);

  const handleSeed = async (level: string) => {
    try {
      await api<any>('/debug/seed', { 
        method: 'POST',
        body: JSON.stringify({ level })
      });
      checkSeederStatus();
    } catch (err: any) {
      alert(err.message || "Error al iniciar el seeder");
    }
  };

  const handleLicenseAction = async (endpoint: string) => {
    setLicenseLoading(true);
    try {
      const data = await api<any>(`/debug/${endpoint}`, { method: 'POST' });
      setLicenseResult(data.new_state || data);
      window.location.reload();
    } catch (err) {
      console.error(err);
    } finally {
      setLicenseLoading(false);
    }
  };

  const handleTestPrinter = async () => {
    if (testPrinterType === 'bluetooth') {
      try {
        setTestPrinterLoading(true);
        const nav: any = navigator;
        if (!nav.bluetooth) {
          throw new Error("API Web Bluetooth no soportada en este navegador (usa Chrome o Edge)");
        }
        
        // Pide permisos para vincular CUALQUIER dispositivo Bluetooth (el usuario debe elegir la Jaltech)
        const device = await nav.bluetooth.requestDevice({
          acceptAllDevices: true,
          optionalServices: ['000018f0-0000-1000-8000-00805f9b34fb', 'e7810a71-73ae-499d-8c15-faa9aef0c3f2'] // UUIDs comunes de impresoras
        });
        
        const server = await device.gatt.connect();
        
        // Obtenemos los servicios, normalmente es el primero custom o alguno de los UUID opcionales
        const services = await server.getPrimaryServices();
        if (services.length === 0) throw new Error("No se encontraron servicios Bluetooth en el dispositivo");
        
        const service = services[0];
        const characteristics = await service.getCharacteristics();
        if (characteristics.length === 0) throw new Error("No se encontraron características para escribir");
        
        const characteristic = characteristics[0]; // Usamos la primera característica disponible para escritura

        // Comandos ESC/POS básicos
        const init = new Uint8Array([0x1B, 0x40]); // Reset
        const alignCenter = new Uint8Array([0x1B, 0x61, 0x01]); // Align center
        const boldOn = new Uint8Array([0x1B, 0x45, 0x01]);
        const boldOff = new Uint8Array([0x1B, 0x45, 0x00]);
        const encoder = new TextEncoder();
        const text = encoder.encode("NeoPOS Test\n¡Conexión Bluetooth Exitosa!\n\n------------------------\nImpresora: Jaltech POS\n\n\n\n\n\n");
        const cut = new Uint8Array([0x1D, 0x56, 0x00]); // Full Cut

        await characteristic.writeValueWithoutResponse(init);
        await characteristic.writeValueWithoutResponse(alignCenter);
        await characteristic.writeValueWithoutResponse(boldOn);
        await characteristic.writeValueWithoutResponse(text);
        await characteristic.writeValueWithoutResponse(boldOff);
        await characteristic.writeValueWithoutResponse(cut);

        alert("¡Ticket de prueba enviado por Bluetooth exitosamente!");
      } catch (err: any) {
        console.error(err);
        alert(`Error conectando por Bluetooth: ${err.message}`);
      } finally {
        setTestPrinterLoading(false);
      }
    } else {
      setTestPrinterLoading(true);
      // Simulate sending a test print job to the backend API (since backend printer worker is used for network/usb)
      setTimeout(() => {
        setTestPrinterLoading(false);
        alert(`Ticket de prueba simulado para la impresora (${testPrinterType}): ${testPrinterAddress}. Falta conectar al backend.`);
      }, 1500);
    }
  };

  const seederOptions = [
    { id: 'pequeño', title: 'Pequeño', desc: '5k Ventas, 500 Clientes, 100 Productos' },
    { id: 'mediano', title: 'Mediano', desc: '50k Ventas, 5k Clientes, 1k Productos' },
    { id: 'grande', title: 'Grande', desc: '250k Ventas, 15k Clientes, 5k Productos' },
    { id: 'apocalipsis', title: 'APOCALIPSIS 💀', desc: '1M Ventas, 30k Clientes, 15k Productos, 2M Logs', color: 'error' }
  ];

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 4 }}>
        <BugReportIcon sx={{ fontSize: 40, color: 'text.secondary' }} />
        <Typography variant="h4" component="h1" fontWeight="bold">
          Debug & Sistema
        </Typography>
      </Box>

      <Paper sx={{ width: '100%', mb: 3 }}>
        <Tabs value={tabIndex} onChange={handleTabChange} sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tab label="Logs del Sync Worker" />
          <Tab label="Base de Datos (Seeder)" />
          <Tab label="Impresoras (Pruebas)" />
          <Tab label="Sincronización a la Nube" />
        </Tabs>

        {tabIndex === 0 && (
          <Box sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>Registro de sincronización de licencias</Typography>
            <Alert severity="info" sx={{ mb: 3 }}>
              <AlertTitle>Información del Worker</AlertTitle>
              Estos son los registros recientes del Sync Worker (Validación de Licencias).
            </Alert>
            
            <Box sx={{ mb: 3, display: 'flex', gap: 2, flexWrap: 'wrap' }}>
              <Button 
                variant="contained" 
                color="success" 
                disabled={licenseLoading}
                onClick={() => handleLicenseAction('license-valid')}
              >
                Simular Licencia Válida
              </Button>
              <Button 
                variant="contained" 
                color="warning" 
                disabled={licenseLoading}
                onClick={() => handleLicenseAction('license-expire-soon')}
              >
                Simular Licencia por Vencer
              </Button>
              <Button 
                variant="contained" 
                color="error" 
                disabled={licenseLoading}
                onClick={() => handleLicenseAction('license-invalid')}
              >
                Simular Licencia Expirada
              </Button>
              <Button 
                variant="contained" 
                sx={{ bgcolor: 'error.dark', color: 'white' }}
                disabled={licenseLoading}
                onClick={() => handleLicenseAction('license-fraud')}
              >
                Simular Fraude
              </Button>
            </Box>

            {licenseResult && (
              <Alert severity={licenseResult.valid ? "success" : "error"} sx={{ mb: 3 }}>
                <AlertTitle>Estado de Licencia Modificado</AlertTitle>
                Válida: {licenseResult.valid ? 'Sí' : 'No'} | Tipo: {licenseResult.license_type} | Expira: {licenseResult.expires_at}
                {licenseResult.error && <div>Error: {licenseResult.error}</div>}
              </Alert>
            )}
          </Box>
        )}

        {tabIndex === 1 && (
          <Box sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>Estado de PostgreSQL</Typography>
            
            {seederStatus && seederStatus.is_running ? (
              <Box sx={{ mb: 4, p: 3, border: '1px solid', borderColor: 'primary.main', borderRadius: 2 }}>
                <Typography variant="h6" color="primary" gutterBottom>
                  Seeder en ejecución (Nivel: {seederStatus.level})
                </Typography>
                <Typography variant="body2" sx={{ mb: 2 }}>
                  {seederStatus.status_message}
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
                  <Box sx={{ width: '100%' }}>
                    <LinearProgress variant="determinate" value={seederStatus.progress} />
                  </Box>
                  <Typography variant="body2" color="text.secondary">
                    {seederStatus.progress}%
                  </Typography>
                </Box>
                
                <Grid container spacing={2}>
                  <Grid item xs={6} md={3}>
                    <Paper sx={{ p: 2, textAlign: 'center' }} elevation={0} variant="outlined">
                      <Typography variant="body2" color="text.secondary">Ventas</Typography>
                      <Typography variant="h6">{seederStatus.sales_created.toLocaleString()}</Typography>
                    </Paper>
                  </Grid>
                  <Grid item xs={6} md={3}>
                    <Paper sx={{ p: 2, textAlign: 'center' }} elevation={0} variant="outlined">
                      <Typography variant="body2" color="text.secondary">Items / Inv</Typography>
                      <Typography variant="h6">{seederStatus.sale_items_created.toLocaleString()}</Typography>
                    </Paper>
                  </Grid>
                  <Grid item xs={6} md={3}>
                    <Paper sx={{ p: 2, textAlign: 'center' }} elevation={0} variant="outlined">
                      <Typography variant="body2" color="text.secondary">Clientes</Typography>
                      <Typography variant="h6">{seederStatus.customers_created.toLocaleString()}</Typography>
                    </Paper>
                  </Grid>
                  <Grid item xs={6} md={3}>
                    <Paper sx={{ p: 2, textAlign: 'center' }} elevation={0} variant="outlined">
                      <Typography variant="body2" color="text.secondary">Auditoría</Typography>
                      <Typography variant="h6">{seederStatus.audit_logs_created.toLocaleString()}</Typography>
                    </Paper>
                  </Grid>
                </Grid>
              </Box>
            ) : (
              <>
                <Alert severity="success" sx={{ mb: 3 }}>
                  <AlertTitle>Seeder Inactivo</AlertTitle>
                  Selecciona el tamaño de datos que deseas sembrar para probar el rendimiento del sistema.
                </Alert>

                {seederStatus && seederStatus.progress === 100 && (
                  <Alert severity="info" sx={{ mb: 3 }}>
                    Última ejecución completada: {seederStatus.sales_created.toLocaleString()} ventas generadas.
                  </Alert>
                )}

                <Grid container spacing={2}>
                  {seederOptions.map((opt) => (
                    <Grid item xs={12} sm={6} md={3} key={opt.id}>
                      <Card variant="outlined" sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                        <CardContent sx={{ flexGrow: 1 }}>
                          <Typography variant="h6" color={opt.color || "text.primary"} gutterBottom>
                            {opt.title}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            {opt.desc}
                          </Typography>
                        </CardContent>
                        <CardActions>
                          <Button 
                            fullWidth 
                            variant="contained" 
                            color={(opt.color as any) || "primary"}
                            onClick={() => handleSeed(opt.id)}
                          >
                            Ejecutar
                          </Button>
                        </CardActions>
                      </Card>
                    </Grid>
                  ))}
                </Grid>
              </>
            )}

          </Box>
        )}

        {tabIndex === 2 && (
          <Box sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>Compatibilidad con Impresoras de Terceross</Typography>
            <Alert severity="info" sx={{ mb: 3 }}>
              <AlertTitle>Compatibilidad Universal (ESC/POS)</AlertTitle>
              NeoPOS es compatible con cualquier impresora térmica que soporte comandos ESC/POS estándar (80mm o 58mm). No es necesario adquirir un modelo específico o marca en particular.
            </Alert>

            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Paper variant="outlined" sx={{ p: 3 }}>
                  <Typography variant="subtitle1" fontWeight="bold" gutterBottom>Prueba de Impresión Directa</Typography>
                  <Typography variant="body2" color="text.secondary" paragraph>
                    Seleccione el tipo de conexión y el identificador de su impresora (nombre del sistema operativo o dirección IP) para enviar un ticket de prueba.
                  </Typography>

                  <Grid container spacing={2} sx={{ mb: 3 }}>
                    <Grid item xs={12} sm={6}>
                      <TextField 
                        select 
                        label="Tipo de Conexión" 
                        value={testPrinterType}
                        onChange={(e) => setTestPrinterType(e.target.value)}
                        fullWidth
                      >
                        <MenuItem value="usb">USB (Nombre Sistema)</MenuItem>
                        <MenuItem value="network">Red (Dirección IP)</MenuItem>
                        <MenuItem value="bluetooth">Bluetooth / COM</MenuItem>
                      </TextField>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <TextField 
                        label={testPrinterType === 'network' ? 'IP (ej. 192.168.1.50)' : 'Nombre (ej. USB001, COM3)'}
                        value={testPrinterAddress}
                        onChange={(e) => setTestPrinterAddress(e.target.value)}
                        fullWidth
                      />
                    </Grid>
                  </Grid>

                  <Button 
                    variant="contained" 
                    color="primary" 
                    startIcon={testPrinterLoading ? <CircularProgress size={20} color="inherit" /> : <PrintIcon />}
                    onClick={handleTestPrinter}
                    disabled={testPrinterLoading || !testPrinterAddress}
                    fullWidth
                  >
                    {testPrinterLoading ? 'Enviando...' : 'Imprimir Ticket de Prueba'}
                  </Button>
                </Paper>
              </Grid>
            </Grid>
          </Box>
        )}

        {tabIndex === 3 && (
          <Box sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>Estado de Conexión a la Nube (NeoPOS Cloud)</Typography>
            
            {syncStatus && syncStatus.last_error ? (
              <Alert severity="error" sx={{ mb: 3 }}>
                <AlertTitle>Error de Sincronización Reciente</AlertTitle>
                <strong>Último Intento:</strong> {new Date(syncStatus.last_attempt).toLocaleString()}<br/>
                <strong>Error:</strong> {syncStatus.last_error}
              </Alert>
            ) : syncStatus && syncStatus.is_running ? (
              <Alert severity="info" sx={{ mb: 3 }}>
                <AlertTitle>Sincronización en Progreso</AlertTitle>
                El worker está sincronizando datos con la nube en este momento...
              </Alert>
            ) : syncStatus ? (
              <Alert severity="success" sx={{ mb: 3 }}>
                <AlertTitle>Conexión Establecida</AlertTitle>
                La sincronización con la nube está operando normalmente. Último intento exitoso: {new Date(syncStatus.last_attempt).toLocaleString()}
              </Alert>
            ) : null}

            <Typography variant="subtitle1" fontWeight="bold" sx={{ mt: 4, mb: 2 }}>
              Logs de NeoPOS Cloud
            </Typography>
            <Paper variant="outlined" sx={{ bgcolor: '#1e1e1e', color: '#a9b7c6', p: 2, maxHeight: 400, overflow: 'auto', mb: 2, fontFamily: 'monospace', fontSize: '0.85rem' }}>
              {cloudLogsLoading ? "Cargando logs de la nube..." : <pre style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{cloudLogs || 'No hay logs disponibles.'}</pre>}
            </Paper>
            <Button variant="outlined" size="small" onClick={fetchCloudLogs} sx={{ mb: 4 }}>
              Refrescar Logs de la Nube
            </Button>

            <Typography variant="subtitle1" fontWeight="bold" sx={{ mt: 4, mb: 2 }}>
              Últimas 10 Conexiones Exitosas
            </Typography>
            
            {syncLogs.length === 0 ? (
              <Typography color="text.secondary">No hay registros de sincronizaciones exitosas aún.</Typography>
            ) : (
              <Paper variant="outlined" sx={{ overflow: 'hidden' }}>
                <Grid container sx={{ bgcolor: 'grey.100', p: 2, borderBottom: '1px solid', borderColor: 'divider' }}>
                  <Grid item xs={6}><Typography fontWeight="bold">Fecha/Hora</Typography></Grid>
                  <Grid item xs={6}><Typography fontWeight="bold">Registros Sincronizados</Typography></Grid>
                </Grid>
                {syncLogs.map((log) => (
                  <Grid container key={log.id} sx={{ p: 2, borderBottom: '1px solid', borderColor: 'divider', '&:last-child': { borderBottom: 0 } }}>
                    <Grid item xs={6}>
                      <Typography>{new Date(log.created_at).toLocaleString()}</Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography>{log.synced_records} registros enviados</Typography>
                    </Grid>
                  </Grid>
                ))}
              </Paper>
            )}
            
            <Box sx={{ mt: 3, display: 'flex', gap: 2 }}>
              <Button variant="contained" onClick={handleForceSync}>
                Forzar Sincronización Ahora
              </Button>
              <Button variant="outlined" onClick={checkSyncStatus}>
                Actualizar Estado
              </Button>
            </Box>
          </Box>
        )}
      </Paper>
    </Box>
  );
}
