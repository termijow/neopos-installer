import { useMemo, useState, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  Box, 
  Stack, 
  Paper, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow, 
  Typography, 
  Chip, 
  useTheme, 
  Card,
  CardContent,
  Grid,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Divider
} from '@mui/material';
import ReceiptLongIcon from '@mui/icons-material/ReceiptLong';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';
import SyncIcon from '@mui/icons-material/Sync';
import DownloadIcon from '@mui/icons-material/Download';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';

import { posService } from '../../services/posService';
import { PageHeader } from '../../components/PageHeader';
import { cop } from '../../utils/format';
import { useNotificationStore } from '../../stores/notificationStore';
import { mockClients, mockProducts } from '../../utils/mockData';

export function InvoicesPage() {
  const theme = useTheme();
  const showNotification = useNotificationStore(state => state.showNotification);
  const [manualInvoiceOpen, setManualInvoiceOpen] = useState(false);

  const { data: sales = [], isLoading } = useQuery({
    queryKey: ['salesHistory'],
    queryFn: posService.salesHistory,
    refetchInterval: 15000
  });

  const electronicInvoices = useMemo(() => {
    return (sales as any[]).filter((inv: any) => inv.is_electronic);
  }, [sales]);

  const stats = useMemo(() => {
    let generated = 0;
    let pending = 0;
    let error = 0;
    electronicInvoices.forEach((inv: any) => {
      if (inv.electronic_status === 'GENERATED' || inv.electronic_status === 'ACCEPTED') generated++;
      else if (inv.electronic_status === 'ERROR' || inv.electronic_status === 'REJECTED') error++;
      else if (inv.electronic_status === 'PENDING') pending++;
    });
    return { generated, pending, error, total: electronicInvoices.length };
  }, [electronicInvoices]);

  const handleDownload = (type: string) => {
    showNotification(`Descargando ${type}...`, 'success');
  };

  // Dummy logic for the manual invoice modal
  const items = mockProducts.slice(0, 3).map((product, index) => ({ ...product, quantity: index + 1, total: product.price * (index + 1) }));
  const subtotal = items.reduce((sum, item) => sum + item.total, 0);
  const tax = Math.round(subtotal * 0.19);
  const total = subtotal + tax;

  return (
    <Stack spacing={4} sx={{ maxWidth: 1200, margin: '0 auto', pb: 4, px: 2 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center">
        <PageHeader 
          title="Facturación Electrónica" 
          subtitle="Gestión, emisión y consulta de comprobantes fiscales DIAN." 
        />
        <Button 
          variant="contained" 
          color="primary" 
          startIcon={<AddCircleOutlineIcon />}
          onClick={() => setManualInvoiceOpen(true)}
        >
          Nueva Factura Manual
        </Button>
      </Stack>

      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)', md: 'repeat(4, 1fr)' }, gap: 3 }}>
        <Card elevation={0} sx={{ 
          border: '1px solid',
          borderColor: 'divider',
          borderRadius: 3,
          height: '100%'
        }}>
          <CardContent>
            <Typography color="text.secondary" variant="subtitle2" fontWeight="bold" gutterBottom>TOTAL EMITIDAS</Typography>
            <Typography variant="h4" fontWeight="bold" color="text.primary">{stats.total}</Typography>
          </CardContent>
        </Card>
        <Card elevation={0} sx={{ 
          border: '1px solid',
          borderColor: 'divider',
          borderRadius: 3,
          height: '100%'
        }}>
          <CardContent>
            <Typography color="text.secondary" variant="subtitle2" fontWeight="bold" gutterBottom>GENERADAS (DIAN)</Typography>
            <Typography variant="h4" fontWeight="bold" color="text.primary">{stats.generated}</Typography>
          </CardContent>
        </Card>
        <Card elevation={0} sx={{ 
          border: '1px solid',
          borderColor: 'divider',
          borderRadius: 3,
          height: '100%'
        }}>
          <CardContent>
            <Typography color="text.secondary" variant="subtitle2" fontWeight="bold" gutterBottom>PENDIENTES SYNC</Typography>
            <Typography variant="h4" fontWeight="bold" color="text.primary">{stats.pending}</Typography>
          </CardContent>
        </Card>
        <Card elevation={0} sx={{ 
          border: '1px solid',
          borderColor: 'divider',
          borderRadius: 3,
          height: '100%'
        }}>
          <CardContent>
            <Typography color="text.secondary" variant="subtitle2" fontWeight="bold" gutterBottom>CON ERRORES</Typography>
            <Typography variant="h4" fontWeight="bold" color="text.primary">{stats.error}</Typography>
          </CardContent>
        </Card>
      </Box>

      <Paper elevation={0} sx={{ 
        borderRadius: 3, 
        overflow: 'hidden',
        border: '1px solid',
        borderColor: 'divider',
        background: theme.palette.background.paper
      }}>
        <TableContainer sx={{ maxHeight: '60vh' }}>
          <Table stickyHeader>
            <TableHead>
              <TableRow>
                <TableCell sx={{ fontWeight: 'bold' }}>ID Factura</TableCell>
                <TableCell sx={{ fontWeight: 'bold' }}>Fecha y Hora</TableCell>
                <TableCell sx={{ fontWeight: 'bold' }}>Total</TableCell>
                <TableCell sx={{ fontWeight: 'bold' }}>Estado DIAN</TableCell>
                <TableCell align="right" sx={{ fontWeight: 'bold' }}>Acciones</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={5} align="center" sx={{ py: 5 }}>
                    <Typography color="text.secondary">Cargando comprobantes...</Typography>
                  </TableCell>
                </TableRow>
              ) : electronicInvoices.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} align="center" sx={{ py: 8 }}>
                    <ReceiptLongIcon sx={{ fontSize: 60, color: 'text.disabled', mb: 2 }} />
                    <Typography variant="h6" color="text.secondary">
                      No hay facturas electrónicas emitidas.
                    </Typography>
                    <Typography variant="body2" color="text.disabled">
                      Para emitir una factura, ve al Historial de Pedidos o crea una manual.
                    </Typography>
                  </TableCell>
                </TableRow>
              ) : (
                electronicInvoices.map((inv: any) => (
                  <TableRow key={inv.id} hover>
                    <TableCell sx={{ fontFamily: 'monospace', fontWeight: 600 }}>{inv.id.substring(0, 8).toUpperCase()}</TableCell>
                    <TableCell>{new Date(inv.created_at).toLocaleString()}</TableCell>
                    <TableCell>{cop(inv.total)}</TableCell>
                    <TableCell>
                      <Chip
                        icon={inv.electronic_status === 'GENERATED' || inv.electronic_status === 'ACCEPTED'
                          ? <CheckCircleIcon />
                          : inv.electronic_status === 'ERROR' || inv.electronic_status === 'REJECTED'
                            ? <ErrorIcon />
                            : <SyncIcon />}
                        label={inv.electronic_status === 'GENERATED' || inv.electronic_status === 'ACCEPTED'
                          ? 'Generada DIAN'
                          : inv.electronic_status === 'ERROR' || inv.electronic_status === 'REJECTED'
                            ? 'Rechazada'
                            : inv.electronic_status === 'UPLOADED'
                              ? 'Subida'
                              : inv.electronic_status === 'SENT'
                                ? 'Enviada'
                                : 'Sincronizando'}
                        color={inv.electronic_status === 'GENERATED' || inv.electronic_status === 'ACCEPTED'
                          ? 'success'
                          : inv.electronic_status === 'ERROR' || inv.electronic_status === 'REJECTED'
                            ? 'error'
                            : inv.electronic_status === 'UPLOADED' || inv.electronic_status === 'SENT'
                              ? 'info'
                              : 'warning'}
                        variant={inv.electronic_status === 'GENERATED' || inv.electronic_status === 'ACCEPTED' ? 'filled' : 'outlined'}
                        size="small"
                        sx={{ fontWeight: 'bold' }}
                      />
                    </TableCell>
                    <TableCell align="right">
                      <Stack direction="row" spacing={1} justifyContent="flex-end">
                        <Button 
                          size="small" 
                          variant="outlined" 
                          disabled={inv.electronic_status !== 'GENERATED' && inv.electronic_status !== 'ACCEPTED'}
                          startIcon={<DownloadIcon />}
                          onClick={() => handleDownload('PDF')}
                        >
                          PDF
                        </Button>
                        <Button 
                          size="small" 
                          variant="outlined" 
                          disabled={inv.electronic_status !== 'GENERATED'}
                          startIcon={<DownloadIcon />}
                          onClick={() => handleDownload('XML')}
                        >
                          XML
                        </Button>
                      </Stack>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Dialog open={manualInvoiceOpen} onClose={() => setManualInvoiceOpen(false)} maxWidth="lg" fullWidth>
        <DialogTitle sx={{ fontWeight: 'bold' }}>Emisión Manual de Factura Electrónica</DialogTitle>
        <DialogContent dividers>
          <Grid container spacing={4}>
            <Grid item xs={12} md={4}>
              <Stack spacing={3}>
                <Typography variant="h6">Datos del Cliente</Typography>
                <TextField label="NIT o Cédula" defaultValue={mockClients[0].document} fullWidth />
                <TextField label="Nombre/Razón Social" defaultValue={mockClients[0].name} fullWidth />
                <TextField label="Correo Electrónico" defaultValue={mockClients[0].email} fullWidth />
                
                <Box sx={{ pt: 2 }}>
                  <Button 
                    variant="contained" 
                    fullWidth
                    size="large"
                    startIcon={<CloudUploadIcon />} 
                    onClick={() => {
                      showNotification("Factura emitida exitosamente", "success");
                      setManualInvoiceOpen(false);
                    }}
                  >
                    Emitir a la DIAN
                  </Button>
                </Box>
              </Stack>
            </Grid>
            <Grid item xs={12} md={8}>
              <Typography variant="h6">Previsualización de Factura</Typography>
              <Typography color="text.secondary" gutterBottom>Proveedor FE: Siigo / Alegra / Carvajal</Typography>
              <Divider sx={{ my: 2 }} />
              <TableContainer component={Paper} elevation={0} sx={{ border: '1px solid', borderColor: 'divider' }}>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>Producto / Servicio</TableCell>
                      <TableCell>Cantidad</TableCell>
                      <TableCell>Impuesto</TableCell>
                      <TableCell align="right">Total</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {items.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell>{item.name}</TableCell>
                        <TableCell>{item.quantity}</TableCell>
                        <TableCell>19% IVA</TableCell>
                        <TableCell align="right">{cop(item.total)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
              <Stack alignItems="flex-end" spacing={1} sx={{ mt: 3, p: 2, bgcolor: 'background.default', borderRadius: 2 }}>
                <Typography variant="body2" color="text.secondary">Subtotal: {cop(subtotal)}</Typography>
                <Typography variant="body2" color="text.secondary">IVA (19%): {cop(tax)}</Typography>
                <Typography variant="h6" fontWeight="bold">Total a Pagar: {cop(total)}</Typography>
              </Stack>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button onClick={() => setManualInvoiceOpen(false)} variant="outlined" color="primary">
            Cancelar
          </Button>
        </DialogActions>
      </Dialog>
    </Stack>
  );
}
