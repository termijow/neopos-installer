import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { InvoicesPage } from './InvoicesPage';
import { useNotificationStore } from '../../stores/notificationStore';

// Mock react-to-print to prevent errors during test
vi.mock('react-to-print', () => ({
  useReactToPrint: () => vi.fn()
}));

describe('InvoicesPage', () => {
  beforeEach(() => {
    useNotificationStore.setState({ open: false, message: '', severity: 'info' });
  });

  it('triggers notification on Emitir button click', () => {
    render(<InvoicesPage />);
    const btn = screen.getByRole('button', { name: /Emitir/i });
    fireEvent.click(btn);
    const store = useNotificationStore.getState();
    expect(store.open).toBe(true);
    expect(store.message).toContain("Factura emitida exitosamente");
  });

  it('triggers notification on Reenviar button click', () => {
    render(<InvoicesPage />);
    const btn = screen.getByRole('button', { name: /Reenviar/i });
    fireEvent.click(btn);
    const store = useNotificationStore.getState();
    expect(store.open).toBe(true);
    expect(store.message).toContain("Factura reenviada exitosamente");
  });

  it('triggers notification on Descargar PDF button click', () => {
    render(<InvoicesPage />);
    const btn = screen.getByRole('button', { name: /Descargar PDF/i });
    fireEvent.click(btn);
    const store = useNotificationStore.getState();
    expect(store.open).toBe(true);
    expect(store.message).toContain("Descargando PDF...");
  });

  it('triggers notification on Descargar XML button click', () => {
    render(<InvoicesPage />);
    const btn = screen.getByRole('button', { name: /Descargar XML/i });
    fireEvent.click(btn);
    const store = useNotificationStore.getState();
    expect(store.open).toBe(true);
    expect(store.message).toContain("Descargando XML...");
  });
});
