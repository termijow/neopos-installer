import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import { ReportsPage } from './ReportsPage';
import { useAuthStore } from '../../stores/authStore';

vi.mock('../../services/api', () => ({
  downloadReport: vi.fn().mockResolvedValue(undefined),
}));

describe('ReportsPage', () => {
  beforeEach(() => {
    useAuthStore.setState({
      user: { id: '1', name: 'Test', email: 'test@test.com', role_name: 'manager', branch_id: 'branch-1' },
      accessToken: 'token',
      role: 'manager'
    });
    vi.clearAllMocks();
  });

  it('renders report types', () => {
    render(<ReportsPage />);
    expect(screen.getByText('Ventas Diarias')).toBeInTheDocument();
    expect(screen.getByText('Ventas Mensuales')).toBeInTheDocument();
    expect(screen.getByText('Libro de Ventas')).toBeInTheDocument();
  });

  it('shows date inputs', () => {
    render(<ReportsPage />);
    expect(screen.getByLabelText('Fecha desde')).toBeInTheDocument();
    expect(screen.getByLabelText('Fecha hasta')).toBeInTheDocument();
  });

  it('renders pending reports with disabled buttons', () => {
    render(<ReportsPage />);
    expect(screen.getByText('IVA')).toBeInTheDocument();
    expect(screen.getByText('Caja')).toBeInTheDocument();
    expect(screen.getByText('Inventario')).toBeInTheDocument();
    expect(screen.getAllByText('Funcionalidad pendiente')).toHaveLength(3);
  });

  it('Excel button is enabled with valid date range', () => {
    render(<ReportsPage />);
    const btns = screen.getAllByRole('button', { name: /Excel/i });
    expect(btns[0]).not.toBeDisabled();
  });
});