import { useState } from 'react';
import { Button, Grid, Paper, Stack, Typography, TextField, Alert, AlertTitle, Box } from '@mui/material';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import TableViewIcon from '@mui/icons-material/TableView';
import { PageHeader } from '../../components/PageHeader';
import { downloadReport, api } from '../../services/api';
import { useNotificationStore } from '../../stores/notificationStore';
import { generatePDF } from '../../utils/pdfGenerator';
import { generateCSV } from '../../utils/csvGenerator';
import { useAuthStore } from '../../stores/authStore';
const REPORT_TYPES = [
  { id: 'daily', label: 'Ventas Diarias', filename: 'ventas-diarias.xlsx' },
  { id: 'monthly', label: 'Ventas Mensuales', filename: 'ventas-mensuales.xlsx' },
  { id: 'ledger', label: 'Libro de Ventas', filename: 'libro-ventas.xlsx' },
  { id: 'tax', label: 'IVA e Impoconsumo', filename: 'impuestos.xlsx' },
  { id: 'cash', label: 'Caja', filename: 'caja.xlsx' },
  { id: 'inventory', label: 'Inventario', filename: 'inventario.xlsx' },
] as const;

function getDefaultDateRange(type: string) {
  const today = new Date();
  const to = today.toISOString().split('T')[0];
  if (type === 'daily') {
    return { from: to, to };
  }
  if (type === 'monthly') {
    const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
    return { from: firstDay.toISOString().split('T')[0], to };
  }
  const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
  return { from: firstDay.toISOString().split('T')[0], to };
}

export function ReportsPage() {
  const showNotification = useNotificationStore(state => state.showNotification);
  const user = useAuthStore(state => state.user);

  const [from, setFrom] = useState(() => getDefaultDateRange('daily').from);
  const [to, setTo] = useState(() => getDefaultDateRange('daily').to);
  const [loading, setLoading] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleExport = async (type: string, label: string) => {
    if (!from || !to) {
      showNotification('Selecciona rango de fechas', 'error');
      return;
    }
    if (new Date(from) > new Date(to)) {
      showNotification('La fecha inicial debe ser anterior a la final', 'error');
      return;
    }
    setLoading(type);
    setError(null);
    try {
      const filename = `${label.toLowerCase().replace(/\s+/g, '-')}-${from}-a-${to}.xlsx`;
      await downloadReport(type, { from, to }, filename);
      showNotification(`${label} exportado correctamente`, 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Error al exportar';
      setError(msg);
      showNotification(msg, 'error');
    } finally {
      setLoading(null);
    }
  };

  const handleExportPDF = async (type: string, label: string) => {
    if (!from || !to) {
      showNotification('Selecciona rango de fechas', 'error');
      return;
    }
    if (new Date(from) > new Date(to)) {
      showNotification('La fecha inicial debe ser anterior a la final', 'error');
      return;
    }
    setLoading(type + '_pdf');
    setError(null);
    try {
      const data = await api<any>(`/reports/${type}?from=${from}&to=${to}&format=json`);
      generatePDF({
        type,
        label,
        from,
        to,
        data,
        userName: user?.name,
        companyName: data?.CompanyName || 'NeoPOS',
        companyNIT: data?.CompanyNIT || '',
        branchName: data?.BranchName || ''
      });
      showNotification(`${label} PDF generado correctamente`, 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Error al generar PDF';
      setError(msg);
      showNotification(msg, 'error');
    } finally {
      setLoading(null);
    }
  };

  const handleExportCSV = async (type: string, label: string) => {
    if (!from || !to) {
      showNotification('Selecciona rango de fechas', 'error');
      return;
    }
    if (new Date(from) > new Date(to)) {
      showNotification('La fecha inicial debe ser anterior a la final', 'error');
      return;
    }
    setLoading(type + '_csv');
    setError(null);
    try {
      const data = await api<any>(`/reports/${type}?from=${from}&to=${to}&format=json`);
      generateCSV({
        type,
        label,
        from,
        to,
        data
      });
      showNotification(`${label} CSV generado correctamente`, 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Error al generar CSV';
      setError(msg);
      showNotification(msg, 'error');
    } finally {
      setLoading(null);
    }
  };

  const isDateRangeValid = from && to && new Date(from) <= new Date(to);

  return (
    <Stack spacing={3}>
      <PageHeader title="Reportes" subtitle="Ventas, IVA, caja e inventario con exportaciones Excel, PDF y CSV." />
      
      <Paper sx={{ p: 3, mb: 2 }}>
        <Stack spacing={2} direction={{ xs: 'column', sm: 'row' }} alignItems={{ xs: 'stretch', sm: 'center' }}>
          <TextField
            label="Fecha desde"
            type="date"
            value={from}
            onChange={e => setFrom(e.target.value)}
            size="small"
            sx={{ minWidth: 180 }}
          />
          <TextField
            label="Fecha hasta"
            type="date"
            value={to}
            onChange={e => setTo(e.target.value)}
            size="small"
            sx={{ minWidth: 180 }}
          />
        </Stack>
        {!isDateRangeValid && (
          <Alert severity="error" sx={{ mt: 1 }}>
            <AlertTitle>Rango inválido</AlertTitle>
            La fecha inicial debe ser anterior o igual a la fecha final.
          </Alert>
        )}
      </Paper>

      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(2, 1fr)', xl: 'repeat(3, 1fr)' }, gap: 2 }}>
        {REPORT_TYPES.map((report) => (
          <Paper sx={{ p: 2 }} key={report.id}>
            <Stack spacing={2}>
              <Typography variant="h6">{report.label}</Typography>
              <Stack direction="row" gap={1} flexWrap="wrap">
                <Button
                  variant="contained"
                  startIcon={<TableViewIcon />}
                  onClick={() => handleExport(report.id, report.label)}
                  disabled={loading !== null || !isDateRangeValid}
                  loading={loading === report.id}
                >
                  Excel
                </Button>
                <Button
                  variant="outlined"
                  startIcon={<PictureAsPdfIcon />}
                  onClick={() => handleExportPDF(report.id, report.label)}
                  disabled={loading !== null || !isDateRangeValid}
                  loading={loading === report.id + '_pdf'}
                >
                  PDF
                </Button>
                <Button
                  variant="outlined"
                  startIcon={<FileDownloadIcon />}
                  onClick={() => handleExportCSV(report.id, report.label)}
                  disabled={loading !== null || !isDateRangeValid}
                  loading={loading === report.id + '_csv'}
                >
                  CSV
                </Button>
              </Stack>
            </Stack>
          </Paper>
        ))}
      </Box>

      {error && (
        <Alert severity="error" sx={{ mt: 2 }}>
          <AlertTitle>Error</AlertTitle>
          {error}
        </Alert>
      )}
    </Stack>
  );
}