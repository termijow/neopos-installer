import { AppRoutes } from '../routes/AppRoutes';
import { LicenseGuard } from '../components/LicenseGuard';

export function App() {
  return (
    <LicenseGuard>
      <AppRoutes />
    </LicenseGuard>
  );
}
