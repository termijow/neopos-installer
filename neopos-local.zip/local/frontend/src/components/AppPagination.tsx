import { TablePagination } from '@mui/material';

export interface AppPaginationProps {
  count: number;
  page: number;
  onPageChange: (newPage: number) => void;
  rowsPerPage: number;
  onRowsPerPageChange: (newRowsPerPage: number) => void;
  labelRowsPerPage?: string;
  rowsPerPageOptions?: number[];
}

export function AppPagination({
  count,
  page,
  onPageChange,
  rowsPerPage,
  onRowsPerPageChange,
  labelRowsPerPage = "Items por página:",
  rowsPerPageOptions = [5, 10, 25, 50, 100]
}: AppPaginationProps) {
  return (
    <TablePagination
      component="div"
      count={count}
      page={page}
      onPageChange={(_, newPage) => onPageChange(newPage)}
      rowsPerPage={rowsPerPage}
      onRowsPerPageChange={(event) => onRowsPerPageChange(parseInt(event.target.value, 10))}
      rowsPerPageOptions={rowsPerPageOptions}
      labelRowsPerPage={labelRowsPerPage}
      labelDisplayedRows={({ from, to, count }) => `${from}-${to} de ${count !== -1 ? count : `más de ${to}`}`}
    />
  );
}
