import { Snackbar, Alert } from '@mui/material';
import { useNotificationStore } from '../stores/notificationStore';

export function NotificationSnackbar() {
  const { open, message, severity, hideNotification } = useNotificationStore();

  return (
    <Snackbar open={open} autoHideDuration={3000} onClose={hideNotification} anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}>
      <Alert onClose={hideNotification} severity={severity} sx={{ width: '100%' }}>
        {message}
      </Alert>
    </Snackbar>
  );
}
