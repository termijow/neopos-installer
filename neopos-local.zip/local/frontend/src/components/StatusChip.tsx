import { Chip } from '@mui/material';
import type { TableStatus } from '../types/domain';

const statusMap: Record<TableStatus, { label: string; color: 'success' | 'error' | 'warning' | 'info' }> = {
  FREE: { label: 'Libre', color: 'success' },
  OCCUPIED: { label: 'Ocupada', color: 'error' },
  RESERVED: { label: 'Reservada', color: 'warning' },
  CLEANING: { label: 'Limpieza', color: 'info' }
};

export function StatusChip({ status }: { status: TableStatus }) {
  const meta = statusMap[status];
  return <Chip size="small" label={meta.label} color={meta.color} />;
}
