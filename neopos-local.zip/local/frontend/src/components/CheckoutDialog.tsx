import { useState } from 'react';
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, Stack, Typography, Select, MenuItem, FormControl, InputLabel, TextField, Box } from '@mui/material';
import { cop } from '../utils/format';
import { posService } from '../services/posService';
import { useMutation } from '@tanstack/react-query';
import { useNotificationStore } from '../stores/notificationStore';
import { api } from '../services/api';
import { printReceipt } from '../utils/printReceipt';

interface Props {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
  orderId: string;
  tableId: string;
  total: number;
  subtotal: number;
  tip: number;
  items: any[];
}

export function CheckoutDialog({ open, onClose, onSuccess, orderId, tableId, total, subtotal, tip, items }: Props) {
  const [paymentMethod, setPaymentMethod] = useState('efectivo');
  const [discount, setDiscount] = useState(0);
  const showNotification = useNotificationStore(state => state.showNotification);

  const checkoutMutation = useMutation({
    mutationFn: async (isElectronic: boolean = false) => {
      // 1. Obtener la sesión de caja activa
      const cashSession = await posService.getActiveCashSession();
      if (!cashSession) {
        throw new Error("No hay caja abierta. Abre la caja primero.");
      }

      // 2. Registrar la venta
      const sale = await posService.registerSale({
        branch_id: cashSession.branch_id,
        order_id: orderId,
        cash_session_id: cashSession.id,
        payment_method: paymentMethod,
        discount: discount,
        tip: tip,
        items: items.map(i => ({
          product_id: i.product_id || i.id,
          name: i.name,
          quantity: i.quantity,
          unit_price: i.unit_price
        })),
        is_electronic: isElectronic
      });

      // 3. Imprimir ticket usando la utilidad de formato térmico
      try {
        printReceipt(sale);
      } catch (printErr) {
        console.error("Error al imprimir:", printErr);
      }

      // 4. Cerrar Mesa
      await posService.updateOrder(orderId, { status: 'BILLED' });
      await posService.closeTable(tableId);
    },
    onSuccess: () => {
      showNotification("Venta registrada y mesa cerrada con éxito", "success");
      onSuccess();
    },
    onError: (err: any) => {
      showNotification(err.message || "Error al facturar", "error");
    }
  });

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle fontWeight="bold">Facturar y Cerrar Mesa</DialogTitle>
      <DialogContent>
        <Stack spacing={3} sx={{ mt: 1 }}>
          <Box sx={{ p: 2, bgcolor: '#f8fafc', borderRadius: 2, border: '1px solid #e2e8f0' }}>
            <Stack direction="row" justifyItems="space-between">
              <Typography>Subtotal:</Typography>
              <Typography fontWeight="bold">{cop(subtotal)}</Typography>
            </Stack>
            <Stack direction="row" justifyItems="space-between">
              <Typography>Propina:</Typography>
              <Typography fontWeight="bold">{cop(tip)}</Typography>
            </Stack>
            <Stack direction="row" justifyItems="space-between" sx={{ mt: 1, pt: 1, borderTop: '1px dashed #cbd5e1' }}>
              <Typography variant="h6">Total a Pagar:</Typography>
              <Typography variant="h6" color="primary.main" fontWeight="bold">{cop(total)}</Typography>
            </Stack>
          </Box>

          <FormControl fullWidth>
            <InputLabel>Método de Pago</InputLabel>
            <Select value={paymentMethod} label="Método de Pago" onChange={e => setPaymentMethod(e.target.value)}>
              <MenuItem value="efectivo">Efectivo</MenuItem>
              <MenuItem value="tarjeta">Tarjeta (Datafono)</MenuItem>
              <MenuItem value="transferencia">Transferencia (Nequi/Daviplata)</MenuItem>
            </Select>
          </FormControl>
        </Stack>
      </DialogContent>
      <DialogActions sx={{ p: 2, pt: 0 }}>
        <Button onClick={onClose} disabled={checkoutMutation.isPending}>Cancelar</Button>
        <Button 
          variant="outlined" 
          color="secondary"
          onClick={() => checkoutMutation.mutate(true)} 
          disabled={checkoutMutation.isPending}
        >
          {checkoutMutation.isPending ? 'Procesando...' : 'Factura Electrónica'}
        </Button>
        <Button 
          variant="contained" 
          onClick={() => checkoutMutation.mutate(false)} 
          disabled={checkoutMutation.isPending}
        >
          {checkoutMutation.isPending ? 'Procesando...' : 'Cobrar e Imprimir'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
