import React, { useEffect, useState } from 'react';
import { Box, Button, Typography, Paper, TextField, Alert, CircularProgress, IconButton } from '@mui/material';
import LockIcon from '@mui/icons-material/Lock';
import CloseIcon from '@mui/icons-material/Close';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import { posService } from '../services/posService';

interface LicenseStatus {
  valid: boolean;
  type?: string;
  days_left?: number;
  message?: string;
}

export function LicenseGuard({ children }: { children: React.ReactNode }) {
  const [status, setStatus] = useState<LicenseStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [licenseCode, setLicenseCode] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [branchId, setBranchId] = useState('');
  const [activating, setActivating] = useState(false);
  const [error, setError] = useState('');
  const [showWarning, setShowWarning] = useState(false);

  useEffect(() => {
    checkLicense();
  }, []);

  const checkLicense = async () => {
    try {
      setLoading(true);
      const res = await posService.licenseStatus();
      setStatus(res);

      if (res && res.valid && res.type && res.days_left !== undefined) {
        const isNearAnnual = res.type === 'annual' && res.days_left <= 7;
        const isNearMonthly = res.type === 'monthly' && res.days_left <= 5;
        
        if (isNearAnnual || isNearMonthly) {
          const today = new Date().toISOString().split('T')[0];
          const dismissedDate = localStorage.getItem('neopos_license_warning_dismissed');
          if (dismissedDate !== today) {
            setShowWarning(true);
          }
        }
      }
    } catch (err: any) {
      setStatus({ valid: false, message: err.message || 'Error checking license' });
    } finally {
      setLoading(false);
    }
  };

  const handleActivate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!licenseCode.trim()) return;
    
    try {
      setActivating(true);
      setError('');
      const res = await posService.activateLicense({ 
        code: licenseCode.trim(), 
        business_name: businessName.trim(), 
        branch_id: branchId.trim() 
      });
      if (res && res.valid) {
        window.location.reload();
      } else {
        setError('Invalid license code');
      }
    } catch (err: any) {
      setError(err.message || 'Activation failed');
    } finally {
      setActivating(false);
    }
  };

  const dismissWarning = () => {
    const today = new Date().toISOString().split('T')[0];
    localStorage.setItem('neopos_license_warning_dismissed', today);
    setShowWarning(false);
  };

  if (loading) {
    return (
      <Box sx={{ minHeight: '100vh', display: 'grid', placeItems: 'center', bgcolor: '#0f172a' }}>
        <CircularProgress color="primary" />
      </Box>
    );
  }

  if (status && status.message === 'fraud_detected') {
    return (
      <Box sx={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', bgcolor: 'error.main', p: 3 }}>
        <Paper elevation={24} sx={{ p: 5, maxWidth: 500, width: '100%', borderRadius: 3, boxShadow: '0 25px 50px -12px rgba(0,0,0,0.5)' }}>
          <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', mb: 4 }}>
            <Box sx={{ width: 64, height: 64, borderRadius: 2, bgcolor: 'error.main', color: 'white', display: 'grid', placeItems: 'center', mb: 2 }}>
              <WarningAmberIcon fontSize="large" />
            </Box>
            <Typography variant="h5" fontWeight="bold" color="error.main" textAlign="center">
              Fraude Detectado
            </Typography>
            <Typography color="text.secondary" align="center" mt={1}>
              Se detectó un intento de movimiento fraudulento y se bloqueó la app. Si eres parte del staff de NeoPOS, ingresa una licencia válida para restaurar el sistema.
            </Typography>
          </Box>

          <Box component="form" onSubmit={handleActivate} sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <TextField
              label="Nombre del Cliente (Negocio) *"
              variant="outlined"
              fullWidth
              required
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              placeholder="Ej: Restaurante Demo"
            />
            <TextField
              label="Sucursal *"
              variant="outlined"
              fullWidth
              required
              value={branchId}
              onChange={(e) => setBranchId(e.target.value)}
              placeholder="Ej: Sede Demo"
            />
            <TextField
              label="Código de Licencia (Restauración) *"
              variant="outlined"
              fullWidth
              required
              value={licenseCode}
              onChange={(e) => setLicenseCode(e.target.value)}
              placeholder="NEO-XXXX-XXXX-XXXX-XXXX"
            />

            {error && (
              <Alert severity="error">{error}</Alert>
            )}

            <Button
              type="submit"
              variant="contained"
              color="error"
              size="large"
              disabled={activating || !licenseCode.trim() || !businessName.trim() || !branchId.trim()}
              sx={{ mt: 1, fontWeight: 'bold' }}
            >
              {activating ? 'Verificando con la nube...' : 'Restaurar Sistema'}
            </Button>
          </Box>
        </Paper>
      </Box>
    );
  }

  if (status && !status.valid) {
    return (
      <Box sx={{ minHeight: '100vh', display: 'grid', placeItems: 'center', bgcolor: '#0f172a', p: 2 }}>
        <Paper sx={{ width: '100%', maxWidth: 430, p: 4 }}>
          <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', mb: 3 }}>
            <Box sx={{ width: 58, height: 58, borderRadius: 2, bgcolor: 'error.main', color: 'white', display: 'grid', placeItems: 'center', mb: 2 }}>
              <LockIcon fontSize="large" />
            </Box>
            <Typography variant="h5" fontWeight="bold">Activación de Licencia Requerida</Typography>
            <Typography color="text.secondary" align="center" mt={1}>
              {status.message || 'Tu licencia es inválida o ha expirado.'}
            </Typography>
          </Box>

          <Box component="form" onSubmit={handleActivate} sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <TextField
              label="Nombre del Cliente (Negocio) *"
              variant="outlined"
              fullWidth
              required
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              placeholder="Ej: Restaurante Demo"
            />
            <TextField
              label="Sucursal *"
              variant="outlined"
              fullWidth
              required
              value={branchId}
              onChange={(e) => setBranchId(e.target.value)}
              placeholder="Ej: Sede Demo"
            />
            <TextField
              label="Código de Licencia *"
              variant="outlined"
              fullWidth
              required
              value={licenseCode}
              onChange={(e) => setLicenseCode(e.target.value)}
              placeholder="NEO-XXXX-XXXX-XXXX-XXXX"
            />

            {error && (
              <Alert severity="error">{error}</Alert>
            )}

            <Button
              type="submit"
              variant="contained"
              size="large"
              disabled={activating || !licenseCode.trim() || !businessName.trim() || !branchId.trim()}
              sx={{ mt: 1 }}
            >
              {activating ? 'Activando...' : 'Activar Licencia'}
            </Button>
          </Box>
        </Paper>
      </Box>
    );
  }

  return (
    <>
      {showWarning && status && (
        <Alert 
          severity="warning" 
          icon={<WarningAmberIcon />}
          action={
            <IconButton
              aria-label="close"
              color="inherit"
              size="small"
              onClick={dismissWarning}
            >
              <CloseIcon fontSize="inherit" />
            </IconButton>
          }
          sx={{ position: 'sticky', top: 0, zIndex: 9999, borderRadius: 0, '& .MuiAlert-message': { width: '100%', textAlign: 'center' } }}
        >
          Tu licencia <strong>{status.type === 'annual' ? 'anual' : status.type === 'monthly' ? 'mensual' : status.type}</strong> expira en <strong>{status.days_left}</strong> días. Por favor renueva para evitar interrupciones.
        </Alert>
      )}
      {children}
    </>
  );
}
