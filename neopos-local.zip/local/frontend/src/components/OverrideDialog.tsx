import React, { useState } from 'react';
import { Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions, TextField, Button, Alert, Box, CircularProgress } from '@mui/material';
import LockPersonIcon from '@mui/icons-material/LockPerson';
import { override } from '../services/authService';

interface OverrideDialogProps {
  open: boolean;
  onClose: () => void;
  onSuccess: (supervisorName: string) => void;
  actionDescription?: string;
}

export function OverrideDialog({ open, onClose, onSuccess, actionDescription = 'realizar esta acción' }: OverrideDialogProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const data = await override({ email, password });
      onSuccess(data.supervisor_name);
      setEmail('');
      setPassword('');
      onClose();
    } catch (err: any) {
      setError(err.message || 'Error de autenticación');
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    setEmail('');
    setPassword('');
    setError('');
    onClose();
  };

  return (
    <Dialog open={open} onClose={handleCancel} maxWidth="xs" fullWidth>
      <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <LockPersonIcon color="warning" />
        Autorización Requerida
      </DialogTitle>
      <form onSubmit={handleSubmit}>
        <DialogContent>
          <DialogContentText sx={{ mb: 2 }}>
            Esta acción requiere privilegios de supervisor (Administrador o Gerente). Por favor, solicita a un supervisor que ingrese sus credenciales para autorizar <strong>{actionDescription}</strong>.
          </DialogContentText>
          {error ? (
            <Alert severity="error" sx={{ mb: 2 }}>
              {error}
            </Alert>
          ) : null}
          <Box sx={{ display: 'flex', gap: 2, flexDirection: 'column' }}>
            <TextField
              label="Email de Supervisor"
              type="email"
              fullWidth
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={loading}
              autoFocus
            />
            <TextField
              label="Contraseña"
              type="password"
              fullWidth
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={loading}
            />
          </Box>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3 }}>
          <Button onClick={handleCancel} disabled={loading}>
            Cancelar
          </Button>
          <Button
            type="submit"
            variant="contained"
            color="warning"
            disabled={loading || !email || !password}
            startIcon={loading ? <CircularProgress size={20} color="inherit" /> : null}
          >
            {loading ? 'Validando...' : 'Autorizar'}
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  );
}
