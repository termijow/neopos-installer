import { queueRequest, replaceQueue, getQueue } from '../utils/offlineQueue';
import { useAuthStore } from '../stores/authStore';
import type { ApiEnvelope } from '../types/domain';

const API_URL = import.meta.env.VITE_API_URL ?? '/api/v1';

export class ApiError extends Error {
  public data: any;
  constructor(message: string, data?: any) {
    super(message);
    this.data = data;
    this.name = 'ApiError';
  }
}

export async function api<T>(path: string, options: RequestInit = {}, offline = true): Promise<T> {
  const token = useAuthStore.getState().accessToken;
  const headers = new Headers(options.headers);
  headers.set('Content-Type', 'application/json');
  if (token) headers.set('Authorization', `Bearer ${token}`);

  try {
    const response = await fetch(`${API_URL}${path}`, { ...options, headers });
    if (response.status === 401) {
      if (path !== '/auth/login') {
        useAuthStore.getState().clear();
        throw new Error('Sesión expirada. Por favor, inicia sesión de nuevo.');
      }
    }
    if (!response.ok) {
      const errorData = (await response.json().catch(() => ({ error: response.statusText }))) as any;
      throw new ApiError(errorData.message || errorData.error || response.statusText, errorData);
    }
    if (response.status === 204) return undefined as T;
    const envelope = (await response.json()) as ApiEnvelope<T>;
    return envelope.data;
  } catch (error) {
    const method = options.method ?? 'GET';
    if (offline && method !== 'GET' && !navigator.onLine) {
      queueRequest({ url: path, method, body: options.body ? JSON.parse(String(options.body)) : undefined });
      return undefined as T;
    }
    throw error;
  }
}

export async function apiPaginated<T>(path: string, options: RequestInit = {}): Promise<ApiEnvelope<T>> {
  const token = useAuthStore.getState().accessToken;
  const headers = new Headers(options.headers);
  headers.set('Content-Type', 'application/json');
  if (token) headers.set('Authorization', `Bearer ${token}`);

  const response = await fetch(`${API_URL}${path}`, { ...options, headers });
  if (response.status === 401) {
    if (path !== '/auth/login') {
      useAuthStore.getState().clear();
      throw new Error('Sesión expirada. Por favor, inicia sesión de nuevo.');
    }
  }
  if (!response.ok) {
    const errorData = (await response.json().catch(() => ({ error: response.statusText }))) as any;
    throw new ApiError(errorData.message || errorData.error || response.statusText, errorData);
  }
  return (await response.json()) as ApiEnvelope<T>;
}

export async function syncOfflineQueue() {
  if (!navigator.onLine) return;
  const remaining = [];
  for (const request of getQueue()) {
    try {
      await api(request.url, {
        method: request.method,
        body: request.body ? JSON.stringify(request.body) : undefined
      }, false);
    } catch {
      remaining.push(request);
    }
  }
  replaceQueue(remaining);
}

export async function downloadReport(reportType: string, params: { from: string; to: string }, filename: string) {
  const token = useAuthStore.getState().accessToken;
  const query = new URLSearchParams({ from: params.from, to: params.to }).toString();
  const response = await fetch(`${API_URL}/reports/${reportType}?${query}`, {
    headers: { 'Authorization': `Bearer ${token}` }
  });
  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: response.statusText }));
    throw new Error(error.error ?? response.statusText);
  }
  const blob = await response.blob();
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(url);
  document.body.removeChild(a);
}
