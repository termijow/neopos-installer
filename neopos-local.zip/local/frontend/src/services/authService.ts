import { api } from './api';
import type { AuthTokens } from '../types/domain';

export interface LoginPayload {
  email: string;
  password: string;
  remember?: boolean;
}

export function login(payload: LoginPayload) {
  return api<AuthTokens>('/auth/login', { method: 'POST', body: JSON.stringify(payload) }, false);
}

export function logout(refreshToken: string) {
  return api<void>('/auth/logout', { method: 'POST', body: JSON.stringify({ refresh_token: refreshToken }) }, false);
}

export interface OverridePayload {
  email: string;
  password: string;
}

export interface OverrideResponse {
  supervisor_name: string;
  role: string;
}

export function override(payload: OverridePayload) {
  return api<OverrideResponse>('/auth/override', { method: 'POST', body: JSON.stringify(payload) }, false);
}
