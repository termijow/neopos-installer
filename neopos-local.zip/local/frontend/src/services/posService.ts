import { api, apiPaginated } from './api';
import { useAuthStore } from '../stores/authStore';
import type {
  Category,
  Client,
  InventoryMovement,
  KitchenOrder,
  Order,
  Product,
  RestaurantTable,
  Recipe
} from '../types/domain';

export const posService = {
  tables: () => api<RestaurantTable[]>('/tables'),
  createTable: (payload: Partial<RestaurantTable>) => api<RestaurantTable>('/tables', { method: 'POST', body: JSON.stringify(payload) }),
  openTable: (id: string) => api<RestaurantTable>(`/tables/${id}/open`, { method: 'PUT' }),
  closeTable: (id: string) => api<RestaurantTable>(`/tables/${id}/close`, { method: 'PUT' }),
  transferTable: (id: string, targetTableId: string) =>
    api<RestaurantTable>(`/tables/${id}/transfer`, { method: 'PUT', body: JSON.stringify({ target_table_id: targetTableId }) }),
  mergeTables: (id: string, targetTableId: string) =>
    api<RestaurantTable>(`/tables/${id}/merge`, { method: 'PUT', body: JSON.stringify({ target_table_id: targetTableId }) }),
  splitBill: (orderId: string, payload: unknown) => 
    api<Order>(`/orders/${orderId}/split`, { method: 'POST', body: JSON.stringify(payload) }),
  products: (page = 1, limit = 50) => apiPaginated<Product[]>(`/products?page=${page}&limit=${limit}`),

  categories: () => api<Category[]>('/categories'),
  createCategory: (payload: Partial<Category>) => api<Category>('/categories', { method: 'POST', body: JSON.stringify(payload) }),
  updateCategory: (id: string, payload: Partial<Category>) => api<Category>(`/categories/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  deleteCategory: (id: string) => api<void>(`/categories/${id}`, { method: 'DELETE' }),
  createProduct: (payload: Partial<Product>) => api<Product>('/products', { method: 'POST', body: JSON.stringify(payload) }),
  updateProduct: (id: string, payload: Partial<Product>) => api<Product>(`/products/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  deleteProduct: (id: string) => api<void>(`/products/${id}`, { method: 'DELETE' }),
  
  downloadImportTemplate: async () => {
    const token = useAuthStore.getState().accessToken;
    const response = await fetch(`${import.meta.env.VITE_API_URL ?? '/api/v1'}/products/import/template`, {
      headers: token ? { 'Authorization': `Bearer ${token}` } : {}
    });
    if (!response.ok) throw new Error('Error al descargar la plantilla');
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'plantilla_productos.csv';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  },
  uploadImportCSV: async (file: File) => {
    const token = useAuthStore.getState().accessToken;
    const formData = new FormData();
    formData.append('file', file);
    const response = await fetch(`${import.meta.env.VITE_API_URL ?? '/api/v1'}/products/import`, {
      method: 'POST',
      headers: token ? { 'Authorization': `Bearer ${token}` } : {},
      body: formData
    });
    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.message || err.error || 'Error al subir el archivo');
    }
    return response.json();
  },
  getImportPreview: (importId: string) => api<any>(`/products/import/${importId}`),
  executeImport: (importId: string, overrides: Record<string, string>) => 
    api<any>(`/products/import/${importId}/execute`, { method: 'POST', body: JSON.stringify({ rows_overrides: overrides }) }),
  downloadExportCSV: async () => {
    const token = useAuthStore.getState().accessToken;
    const response = await fetch(`${import.meta.env.VITE_API_URL ?? '/api/v1'}/products/export`, {
      headers: token ? { 'Authorization': `Bearer ${token}` } : {}
    });
    if (!response.ok) throw new Error('Error al descargar la exportación');
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'exportacion_productos.csv';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  },

  createOrder: (payload: unknown) => api<Order>('/orders', { method: 'POST', body: JSON.stringify(payload) }),
  getOrder: (id: string) => api<Order>(`/orders/${id}`),
  getActiveOrderByTable: (tableId: string) => api<Order>(`/orders/active/table/${tableId}`),
  updateOrder: (id: string, payload: unknown) => api<Order>(`/orders/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  kitchenOrders: () => api<KitchenOrder[]>('/kitchen/orders'),
  updateKitchenStatus: (id: string, status: KitchenOrder['status']) =>
    api<KitchenOrder>(`/kitchen/orders/${id}/status`, { method: 'PUT', body: JSON.stringify({ status }) }),
  inventory: (page = 1, limit = 50) => apiPaginated<InventoryMovement[]>(`/inventory?page=${page}&limit=${limit}`),
  inventoryIn: (payload: unknown) => api<InventoryMovement>('/inventory/in', { method: 'POST', body: JSON.stringify(payload) }),
  inventoryAdjustment: (payload: unknown) => api<InventoryMovement>('/inventory/adjustment', { method: 'POST', body: JSON.stringify(payload) }),
  inventoryStock: () => api<Record<string, number>>('/inventory/stock'),
  inventoryPrediction: () => api<Record<string, number>>('/inventory/prediction'),
  openCash: (payload: { opening_amount: number; notes?: string }) => api<{ session: unknown, license: { Warning: string } }>('/cash/open', { method: 'POST', body: JSON.stringify(payload) }),
  closeCash: (payload: { closing_amount: number; expected_amount: number; notes?: string }) => api<{ session: unknown, license: { Warning: string } }>('/cash/close', { method: 'POST', body: JSON.stringify(payload) }),
  cashMovement: (payload: { type: string; amount: number; reason: string }) => api<unknown>('/cash/movement', { method: 'POST', body: JSON.stringify(payload) }),
  getActiveCashSession: async () => {
    try {
      return await api<{ id: string; branch_id: string; status: string; opening_amount: number }>('/cash/active');
    } catch (err: any) {
      if (err instanceof Error && (err.message === 'No hay caja abierta' || err.message.includes('Not Found') || err.message.includes('404'))) {
        return null;
      }
      throw err;
    }
  },
  registerSale: (payload: { branch_id: string; order_id: string; cash_session_id: string; payment_method: string; discount: number; tip: number; items: Array<{ product_id: string; name: string; quantity: number; unit_price: number }>; is_electronic?: boolean }) =>
    api<unknown>('/sales', { method: 'POST', body: JSON.stringify(payload) }),
  aiChat: (message: string) => api<any>('/ai/chat', { method: 'POST', body: JSON.stringify({ message }) }),
  getUsageLimits: () => api<{
    ai_monthly_limit: number;
    electronic_invoice_monthly_limit: number;
    ai_used: number;
    electronic_invoice_used: number;
    month: string;
  }>('/usage-limits'),
  updateUsageLimits: (payload: { ai_monthly_limit: number; electronic_invoice_monthly_limit: number }) =>
    api<any>('/usage-limits', { method: 'POST', body: JSON.stringify(payload) }),
  recipes: (page = 1, limit = 50) => apiPaginated<Recipe[]>(`/recipes?page=${page}&limit=${limit}`),
  createRecipe: (payload: Partial<Recipe>) => api<Recipe>('/recipes', { method: 'POST', body: JSON.stringify(payload) }),
  updateRecipe: (id: string, payload: Partial<Recipe>) => api<Recipe>(`/recipes/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  deleteRecipe: (id: string) => api<void>(`/recipes/${id}`, { method: 'DELETE' }),
  licenseStatus: () => api<{ valid: boolean; type?: string; days_left?: number; message?: string }>('/license/status'),
  activateLicense: (payload: { code: string; business_name: string; branch_id: string }) => 
    api<{ valid: boolean; message?: string }>('/license/activate', { method: 'POST', body: JSON.stringify(payload) }),
  cashHistory: () => api<any[]>('/cash/history'),
  dashboardReports: () => api<any>('/reports/dashboard'),
  salesHistory: () => api<any[]>('/sales'),
  markAsElectronicInvoice: (id: string) => api<any>(`/sales/${id}/electronic`, { method: 'POST' }),
  triggerSync: () => api<any>('/sync/trigger', { method: 'POST' }),
  checkForUpdates: () => api<any>('/updates/check', { method: 'POST' }),
  syncStatus: () => api<any>('/sync/status'),
  clients: () => api<Client[]>('/clients'),
  createClient: (payload: Omit<Client, 'id'>) => api<Client>('/clients', { method: 'POST', body: JSON.stringify(payload) }),
  updateClient: (id: string, payload: Partial<Omit<Client, 'id'>>) => api<Client>(`/clients/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  deleteClient: (id: string) => api<void>(`/clients/${id}`, { method: 'DELETE' }),
};
