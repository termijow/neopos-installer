import { Navigate, Outlet } from 'react-router-dom';
import { useAuthStore } from '../stores/authStore';
import { canAccess, getHomePath } from '../utils/permissions';

export function ProtectedRoute({ permission }: { permission?: string }) {
  const { accessToken, role } = useAuthStore();
  if (!accessToken) return <Navigate to="/login" replace />;
  if (permission && !canAccess(role, permission)) return <Navigate to={getHomePath(role)} replace />;
  return <Outlet />;
}
