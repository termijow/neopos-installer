import { Navigate, Route, Routes } from 'react-router-dom';
import { MainLayout } from '../layouts/MainLayout';
import { LoginPage } from '../pages/login/LoginPage';
import { DashboardPage } from '../pages/dashboard/DashboardPage';
import { TablesPage } from '../pages/tables/TablesPage';
import { OrdersPage } from '../pages/orders/OrdersPage';
import { OrderHistoryPage } from '../pages/orders/OrderHistoryPage';
import { KitchenPage } from '../pages/kitchen/KitchenPage';
import { ProductsPage } from '../pages/products/ProductsPage';
import { RecipesPage } from '../pages/recipes/RecipesPage';
import { InventoryPage } from '../pages/inventory/InventoryPage';
import { ClientsPage } from '../pages/clients/ClientsPage';
import { CashPage } from '../pages/cash/CashPage';
import { InvoicesPage } from '../pages/invoices/InvoicesPage';
import { ReportsPage } from '../pages/reports/ReportsPage';
import { SettingsPage } from '../pages/settings/SettingsPage';
import { AiAssistantPage } from '../pages/ai-assistant/AiAssistantPage';
import { DebugPage } from '../pages/debug/DebugPage';
import { SetupWizardPage } from '../pages/setup/SetupWizardPage';
import { ProtectedRoute } from './ProtectedRoute';
import { useAuthStore } from '../stores/authStore';
import { useSettingsStore } from '../stores/settingsStore';
import { getHomePath } from '../utils/permissions';

export function AppRoutes() {
  const { role } = useAuthStore();
  const { isSetupComplete } = useSettingsStore();

  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/setup" element={<SetupWizardPage />} />
      
      <Route element={<ProtectedRoute />}>
        {/* If setup is not complete, enforce it before accessing the app */}
        {!isSetupComplete && (
          <Route path="*" element={<Navigate to="/setup" replace />} />
        )}

        {isSetupComplete && (
          <Route element={<MainLayout />}>
            <Route index element={<Navigate to={getHomePath(role)} replace />} />
            <Route element={<ProtectedRoute permission="dashboard" />}>
              <Route path="/dashboard" element={<DashboardPage />} />
              <Route path="/debug" element={<DebugPage />} />
            </Route>
            <Route element={<ProtectedRoute permission="tables" />}>
              <Route path="/tables" element={<TablesPage />} />
            </Route>
            <Route element={<ProtectedRoute permission="orders" />}>
              <Route path="/orders" element={<OrdersPage />} />
              <Route path="/order-history" element={<OrderHistoryPage />} />
            </Route>
            <Route element={<ProtectedRoute permission="kitchen" />}>
              <Route path="/kitchen" element={<KitchenPage />} />
            </Route>
            <Route element={<ProtectedRoute permission="products" />}>
              <Route path="/products" element={<ProductsPage />} />
              <Route path="/recipes" element={<RecipesPage />} />
            </Route>
            <Route element={<ProtectedRoute permission="inventory" />}>
              <Route path="/inventory" element={<InventoryPage />} />
            </Route>
            <Route element={<ProtectedRoute permission="cash" />}>
              <Route path="/clients" element={<ClientsPage />} />
              <Route path="/cash" element={<CashPage />} />
            </Route>
            <Route element={<ProtectedRoute permission="invoices" />}>
              <Route path="/invoices" element={<InvoicesPage />} />
            </Route>
            <Route element={<ProtectedRoute permission="reports" />}>
              <Route path="/reports" element={<ReportsPage />} />
            </Route>
            <Route element={<ProtectedRoute permission="settings" />}>
              <Route path="/settings" element={<SettingsPage />} />
            </Route>
            <Route element={<ProtectedRoute permission="ai-assistant" />}>
              <Route path="/ai-assistant" element={<AiAssistantPage />} />
            </Route>
            <Route path="*" element={<Navigate to={getHomePath(role)} replace />} />
          </Route>
        )}
      </Route>
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}
