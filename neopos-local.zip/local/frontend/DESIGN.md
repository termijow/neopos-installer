# Documentación de Diseño Frontend (NeoPOS)

Este documento detalla la arquitectura, el sistema de diseño, el enrutamiento, la gestión de estados y los flujos operativos clave de la aplicación frontend de **NeoPOS**.

---

## 1. Arquitectura del Proyecto

El frontend está desarrollado bajo una arquitectura moderna de SPA (Single Page Application) utilizando:
- **Build Tool:** [Vite](https://vite.dev) con TypeScript.
- **UI Library:** [Material-UI (MUI v6)](https://mui.com) para componentes accesibles y consistentes.
- **Data Fetching & Cache:** [React Query (TanStack Query v5)](https://tanstack.com/query) para peticiones asíncronas y sincronización de caché con el backend.
- **State Management:** [Zustand](https://github.com/pmndrs/zustand) para almacenamiento global ligero y persistente.
- **Form Handling:** [React Hook Form](https://react-hook-form.com) combinado con validaciones esquematizadas vía [Zod](https://zod.dev).

### Estructura de Directorios

- `src/app/`: Configuración principal de la aplicación y proveedores de contexto.
- `src/components/`: Componentes comunes reutilizables (ej. [PageHeader](file:///home/termihoe/Documents/NeoPOS/local/frontend/src/components/PageHeader.tsx)).
- `src/layouts/`: Estructuras de layout (ej. [MainLayout](file:///home/termihoe/Documents/NeoPOS/local/frontend/src/layouts/MainLayout.tsx)).
- `src/pages/`: Componentes de páginas y vistas organizadas por módulos.
- `src/stores/`: Definición de almacenes globales de Zustand.
- `src/types/`: Interfaces y definiciones de dominio en TypeScript (ej. [domain.ts](file:///home/termihoe/Documents/NeoPOS/local/frontend/src/types/domain.ts)).
- `src/services/`: Capa de servicios API (ej. [posService.ts](file:///home/termihoe/Documents/NeoPOS/local/frontend/src/services/posService.ts)).

---

## 2. Sistema de Layout y Enrutamiento

### Layout Principal (`MainLayout`)
El archivo [MainLayout.tsx](file:///home/termihoe/Documents/NeoPOS/local/frontend/src/layouts/MainLayout.tsx) define la estructura visual central de la aplicación:
- **Barra de Navegación Lateral (Sidebar):** Contiene enlaces a los distintos módulos operativos filtrados dinámicamente según el rol del usuario actual.
- **Buscador Global (Command Palette):** Activado mediante el atajo `Ctrl+K`. Permite buscar rápidamente páginas, productos y mesas mediante navegación por teclado (`↑`/`↓` y `Enter`) y cuenta con un resalte visual de selección utilizando un borde sólido de `2px solid #ea580c` sin alterar los colores del texto original.

### Enrutamiento
Implementado con `react-router-dom` definiendo rutas jerárquicas y restricciones basadas en permisos de roles de usuario (`admin`, `manager`, `cashier`, etc.).

---

## 3. Gestión de Estado Global (Zustand)

La aplicación implementa tiendas independientes para segmentar la reactividad del estado:

1. **Autenticación ([authStore.ts](file:///home/termihoe/Documents/NeoPOS/local/frontend/src/stores/authStore.ts)):**
   - Maneja el token de acceso (`accessToken`), token de refresco (`refreshToken`), rol del usuario y datos de sesión persistidos localmente.
2. **Mesas ([tableStore.ts](file:///home/termihoe/Documents/NeoPOS/local/frontend/src/stores/tableStore.ts)):**
   - Rastrea y almacena la mesa de restaurante actualmente seleccionada (`selectedTable`) para asociar pedidos activos.
3. **Configuraciones ([settingsStore.ts](file:///home/termihoe/Documents/NeoPOS/local/frontend/src/stores/settingsStore.ts)):**
   - Almacena variables de entorno local como `branchId`, `companyName` y configuraciones UX como `autoFocusSearch` y `showProductImages` (Habilitar imágenes de productos).
4. **Pedido Activo ([orderStore.ts](file:///home/termihoe/Documents/NeoPOS/local/frontend/src/stores/orderStore.ts)):**
   - Administra el carrito de compra del servicio en curso. Permite agregar productos, removerlos, modificar cantidades, alterar precios (según rol) e ingresar notas generales de cocina.

---

## 4. Paleta de Colores y Estilos UI

La aplicación emplea una paleta de colores premium con un fuerte enfoque en legibilidad, contraste y estilización vidriada:

- **Slate Primary:** `#0f172a` (utilizado para textos primarios, encabezados principales y fondos del sidebar).
- **Dark Charcoal:** `#1e293b` (color para hover y estados de selección del sidebar).
- **Electric Cyan:** `#0891b2` (empleado para indicadores visuales de mesas y chips informativos).
- **Amber Accent (Naranja):** `#ea580c` (para llamadas a la acción principales, alertas de notas y el borde del buscador).
- **Gris de Descripción:** `#475569` (para textos secundarios y descripciones).

### Estilo Premium "Liquid Glass Tint"
Aplicado en modales clave (como edición y confirmación de eliminación de productos en [ProductsPage.tsx](file:///home/termihoe/Documents/NeoPOS/local/frontend/src/pages/products/ProductsPage.tsx)):
- **Fondo:** `rgba(210, 222, 236, 0.86)`
- **Efecto de Desenfoque:** `backdropFilter: 'blur(16px)'`
- **Bordes:** Sin borde visible (`border: 'none'`)
- **Sombras:** `boxShadow: '0 25px 50px -12px rgba(15, 23, 42, 0.15), 0 0 14px 2px rgba(255, 255, 255, 0.6), inset 0 2px 4px rgba(255, 255, 255, 0.7), inset 0 -2px 4px rgba(15, 23, 42, 0.03)'`
- **Inputs:** Para mantener el contraste sobre el fondo translúcido, los campos de entrada dentro de estos modales usan un fondo blanco opaco (`#ffffff`), borde sutil `1px solid rgba(15,23,42,0.1)`, y texto oscuro en contraste.

---

## 5. Diseño del Tablero de Cocina (KDS)

El Kitchen Display System ([KitchenPage.tsx](file:///home/termihoe/Documents/NeoPOS/local/frontend/src/pages/kitchen/KitchenPage.tsx)) organiza las comandas activas utilizando un tablero Kanban interactivo:

- **Estados (Columnas):** 
  - `PENDING` (Pendientes)
  - `COOKING` (En Preparación)
  - `READY` (Listos)
  - `SERVED` (Entregados - ocultados automáticamente tras 3 minutos)
- **Interacciones:**
  - **Drag and Drop:** Soporte completo para arrastrar y soltar tarjetas entre columnas actualizando el estado de forma inmediata mediante mutaciones.
  - **Controles Rápidos:** Botones de avance y retroceso en cada tarjeta para operación ágil en dispositivos táctiles sin necesidad de arrastre.
- **Procesamiento de Comandas:** 
  - Las notas recibidas del pedido son parseadas dinámicamente para extraer el número de mesa (`Mesa X`), descomponer los ítems del plato y destacar notas especiales de alergias o adiciones en un recuadro de alerta.

---

## 6. Flujo de Pedidos Activos y Propinas

### Flujo de Pedidos
1. **Selección de Mesa:** El cajero selecciona una mesa en [TablesPage](file:///home/termihoe/Documents/NeoPOS/local/frontend/src/pages/tables/TablesPage.tsx), lo cual actualiza el `tableStore`.
2. **Creación del Carrito:** Desde [OrdersPage](file:///home/termihoe/Documents/NeoPOS/local/frontend/src/pages/orders/OrdersPage.tsx), se seleccionan platos del menú, agregándose al `orderStore`.
3. **Envío a Cocina:** Al confirmar el pedido, las comandas se envían al backend, creándose el registro KDS en estado `PENDING`.

### Flujo de Propinas (Facturación)
Durante el proceso de pago/facturación:
- Se presenta al cajero o cliente el panel de selección de propina voluntaria sugerida (ej. sin propina, 5%, 10%, 15% o un valor fijo personalizado).
- El valor calculado se añade al total facturado.
- El monto ingresado bajo concepto de propina impacta directamente los reportes del arqueo de caja visible en [CashPage](file:///home/termihoe/Documents/NeoPOS/local/frontend/src/pages/cash/CashPage.tsx).
