//go:build tools

package main

import (
	"fmt"
	"log"

	"restaurant-pos-api/internal/platform/database"
	"restaurant-pos-api/internal/sales"

	"go.uber.org/zap"
)

func main() {

	logger, _ := zap.NewDevelopment()
	defer logger.Sync()

	db, err := database.Connect("postgresql://pos:pos@localhost:5433/pos?sslmode=disable", logger)
	if err != nil {
		log.Fatal("database connection failed", err)
	}

	repo := sales.NewRepository(db)
	items, err := repo.List("")
	if err != nil {
		log.Fatal("Error listing sales:", err)
	}
	fmt.Printf("Got %d sales\n", len(items))
}
