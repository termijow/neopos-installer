package response

import "github.com/gofiber/fiber/v2"

type Meta struct {
	Page       int `json:"page"`
	Limit      int `json:"limit"`
	Total      int `json:"total"`
	TotalPages int `json:"total_pages"`
}

type Body struct {
	Data    any    `json:"data,omitempty"`
	Meta    *Meta  `json:"meta,omitempty"`
	Message string `json:"message,omitempty"`
	Error   string `json:"error,omitempty"`
}

func OK(c *fiber.Ctx, data any) error {
	return c.Status(fiber.StatusOK).JSON(Body{Data: data})
}

func Paginated(c *fiber.Ctx, data any, page, limit, total int) error {
	totalPages := total / limit
	if total%limit != 0 {
		totalPages++
	}
	return c.Status(fiber.StatusOK).JSON(Body{
		Data: data,
		Meta: &Meta{
			Page:       page,
			Limit:      limit,
			Total:      total,
			TotalPages: totalPages,
		},
	})
}

func Created(c *fiber.Ctx, data any) error {
	return c.Status(fiber.StatusCreated).JSON(Body{Data: data})
}

func NoContent(c *fiber.Ctx) error {
	return c.SendStatus(fiber.StatusNoContent)
}

func Error(c *fiber.Ctx, status int, message string) error {
	return c.Status(status).JSON(Body{Error: message})
}
