package main

import (
	"log"

	"restaurant-pos-api/internal/platform/config"
	"restaurant-pos-api/internal/platform/database"
	"restaurant-pos-api/internal/platform/middleware"
	"restaurant-pos-api/internal/printers"
	"restaurant-pos-api/pkg/response"

	"github.com/gofiber/fiber/v2"
	"go.uber.org/zap"
)

func main() {
	cfg := config.Load()
	logger, err := zap.NewProduction()
	if cfg.AppEnv == "local" {
		logger, err = zap.NewDevelopment()
	}
	if err != nil {
		log.Fatal(err)
	}
	defer logger.Sync()

	db, err := database.Connect(cfg.DatabaseURL, logger)
	if err != nil {
		logger.Fatal("database connection failed", zap.Error(err))
	}
	if err := database.Migrate(db, &printers.PrintJob{}); err != nil {
		logger.Fatal("printer migration failed", zap.Error(err))
	}

	app := fiber.New(fiber.Config{AppName: cfg.AppName + "-printer"})
	app.Use(middleware.RequestLogger(logger))
	app.Get("/health", func(c *fiber.Ctx) error {
		return response.OK(c, fiber.Map{"status": "ok"})
	})
	repo := printers.NewRepository(db)
	printers.RegisterRoutes(app.Group("/api/v1"), db)

	go printers.StartWorker(repo, cfg.PrinterType, cfg.PrinterAddress, cfg.PrinterPort)

	logger.Info("printer api listening", zap.String("port", cfg.AppPort))
	if err := app.Listen(":" + cfg.AppPort); err != nil {
		logger.Fatal("printer api stopped", zap.Error(err))
	}
}
