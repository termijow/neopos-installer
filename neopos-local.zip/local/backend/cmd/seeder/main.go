package main

import (
	"math/rand"
	"time"

	"restaurant-pos-api/internal/branches"
	"restaurant-pos-api/internal/cash_register"
	"restaurant-pos-api/internal/inventory"
	"restaurant-pos-api/internal/platform/config"
	"restaurant-pos-api/internal/platform/database"
	"restaurant-pos-api/internal/products"
	"restaurant-pos-api/internal/sales"

	"github.com/google/uuid"
	"go.uber.org/zap"
)

func main() {
	cfg := config.Load()
	logger, _ := zap.NewDevelopment()
	defer logger.Sync()

	db, err := database.Connect(cfg.DatabaseURL, logger)
	if err != nil {
		logger.Fatal("database connection failed", zap.Error(err))
	}

	var branch branches.Branch
	if err := db.First(&branch).Error; err != nil {
		logger.Fatal("No branch found. Please run the API first to seed admin/branch.")
	}

	var allProducts []products.Product
	if err := db.Where("branch_id = ?", branch.ID).Find(&allProducts).Error; err != nil || len(allProducts) == 0 {
		logger.Fatal("No products found.")
	}

	logger.Info("Starting massive seeder for 4 years...")

	startDate := time.Now().AddDate(-4, 0, 0)
	endDate := time.Now()

	// Parameters
	salesPerDayMin := 20
	salesPerDayMax := 100

	r := rand.New(rand.NewSource(time.Now().UnixNano()))

	var salesBatch []sales.Sale
	var saleItemsBatch []sales.SaleItem
	var invBatch []inventory.InventoryMovement

	days := int(endDate.Sub(startDate).Hours() / 24)

	paymentMethods := []string{sales.PaymentCash, sales.PaymentCreditCard, sales.PaymentDebitCard, sales.PaymentTransfer}

	for i := 0; i < days; i++ {
		currentDate := startDate.AddDate(0, 0, i)
		numSales := r.Intn(salesPerDayMax-salesPerDayMin+1) + salesPerDayMin

		// Create one cash session for the day
		dailyCashSessionID := uuid.New()
		closingTime := currentDate.Add(time.Hour * 23)
		cashSession := cash_register.CashRegisterSession{
			OpeningAmount:  150000, // Fixed opening amount for mock
			ExpectedAmount: 150000, // Will add total sales below
			ClosingAmount:  150000,
			Difference:     0,
			Status:         "closed",
			OpenedBy:       uuid.Nil,
			ClosedBy:       uuid.Nil,
			ClosedAt:       &closingTime,
		}
		cashSession.ID = dailyCashSessionID
		cashSession.BranchID = branch.ID
		cashSession.CreatedAt = currentDate.Add(time.Hour * 8)
		cashSession.UpdatedAt = closingTime

		var dailyTotal int64 = 0

		for j := 0; j < numSales; j++ {
			// random time in the day
			saleTime := currentDate.Add(time.Duration(r.Intn(14*60)) * time.Minute).Add(time.Hour * 8) // 8am to 10pm

			saleID := uuid.New()
			sale := sales.Sale{
				PaymentMethod: paymentMethods[r.Intn(len(paymentMethods))],
				CashSessionID: dailyCashSessionID,
			}
			sale.ID = saleID
			sale.CreatedAt = saleTime
			sale.UpdatedAt = saleTime
			sale.BranchID = branch.ID

			numItems := r.Intn(4) + 1
			var subtotal int64
			for k := 0; k < numItems; k++ {
				prod := allProducts[r.Intn(len(allProducts))]
				qty := r.Intn(3) + 1
				itemTotal := prod.Price * int64(qty)
				subtotal += itemTotal

				saleItem := sales.SaleItem{
					SaleID:    saleID,
					ProductID: prod.ID,
					Name:      prod.Name,
					Quantity:  qty,
					UnitPrice: prod.Price,
					Total:     itemTotal,
				}
				saleItem.ID = uuid.New()
				saleItem.CreatedAt = saleTime
				saleItem.UpdatedAt = saleTime
				saleItemsBatch = append(saleItemsBatch, saleItem)

				invMov := inventory.InventoryMovement{
					ProductID: prod.ID,
					Type:      inventory.MovementOut,
					Quantity:  qty,
					Reason:    "Sale",
				}
				invMov.ID = uuid.New()
				invMov.BranchID = branch.ID
				invMov.CreatedAt = saleTime
				invMov.UpdatedAt = saleTime
				invBatch = append(invBatch, invMov)
			}

			sale.Subtotal = subtotal
			sale.Total = subtotal
			dailyTotal += subtotal
			salesBatch = append(salesBatch, sale)
		}

		cashSession.ExpectedAmount += dailyTotal
		cashSession.ClosingAmount += dailyTotal
		// Insert cash session
		db.Create(&cashSession)

		// Insert in batches every 30 days to avoid huge memory usage
		if (i+1)%30 == 0 || i == days-1 {
			if len(salesBatch) > 0 {
				db.CreateInBatches(salesBatch, 1000)
				salesBatch = nil
			}
			if len(saleItemsBatch) > 0 {
				db.CreateInBatches(saleItemsBatch, 1000)
				saleItemsBatch = nil
			}
			if len(invBatch) > 0 {
				db.CreateInBatches(invBatch, 1000)
				invBatch = nil
			}
			logger.Info("Seeded up to", zap.Time("date", currentDate))
		}
	}

	logger.Info("Seeding local database complete!")
}
