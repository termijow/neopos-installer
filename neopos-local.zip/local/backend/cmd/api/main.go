package main

import (
	"log"
	"time"

	"restaurant-pos-api/internal/ai"
	"restaurant-pos-api/internal/audit"
	"restaurant-pos-api/internal/auth"
	"restaurant-pos-api/internal/branches"
	"restaurant-pos-api/internal/cash_register"
	"restaurant-pos-api/internal/categories"
	"restaurant-pos-api/internal/clients"
	"restaurant-pos-api/internal/company"
	"restaurant-pos-api/internal/electronic_invoicing"
	"restaurant-pos-api/internal/inventory"
	"restaurant-pos-api/internal/invoices"
	"restaurant-pos-api/internal/kitchen"
	"restaurant-pos-api/internal/orders"
	"restaurant-pos-api/internal/platform/config"
	"restaurant-pos-api/internal/platform/database"
	httpserver "restaurant-pos-api/internal/platform/http"
	"restaurant-pos-api/internal/printers"
	"restaurant-pos-api/internal/products"
	"restaurant-pos-api/internal/purchases"
	"restaurant-pos-api/internal/recipes"
	"restaurant-pos-api/internal/reports"
	"restaurant-pos-api/internal/roles"
	"restaurant-pos-api/internal/sales"
	"restaurant-pos-api/internal/settings"
	"restaurant-pos-api/internal/storage"
	"restaurant-pos-api/internal/suppliers"
	syncqueue "restaurant-pos-api/internal/sync"
	"restaurant-pos-api/internal/tables"
	"restaurant-pos-api/internal/users"
	"restaurant-pos-api/pkg/security"

	"go.uber.org/zap"
	"gorm.io/gorm"
)

func main() {
	cfg := config.Load()
	logger, err := zap.NewProduction()
	if cfg.AppEnv == "local" {
		logger, err = zap.NewDevelopment()
	}
	if err != nil {
		log.Fatal(err)
	}
	defer logger.Sync()

	db, err := database.Connect(cfg.DatabaseURL, logger)
	if err != nil {
		logger.Fatal("database connection failed", zap.Error(err))
	}

	if err := database.Migrate(db,
		&auth.RefreshToken{},
		&roles.Role{},
		&users.User{},
		&company.Company{},
		&branches.Branch{},
		&tables.Table{},
		&categories.Category{},
		&clients.Client{},
		&products.Product{},
		&recipes.Recipe{},
		&recipes.RecipeItem{},
		&suppliers.Supplier{},
		&purchases.Purchase{},
		&purchases.PurchaseItem{},
		&orders.Order{},
		&orders.OrderItem{},
		&kitchen.KitchenOrder{},
		&inventory.InventoryMovement{},
		&cash_register.CashRegisterSession{},
		&cash_register.CashMovement{},
		&sales.Sale{},
		&sales.SaleItem{},
		&invoices.Invoice{},
		&electronic_invoicing.ElectronicInvoice{},
		&electronic_invoicing.CreditNote{},
		&printers.PrintJob{},
		&reports.ReportJob{},
		&syncqueue.SyncQueue{},
		&syncqueue.SyncLog{},
		&audit.AuditLog{},
		&settings.Setting{},
	); err != nil {
		logger.Fatal("database migration failed", zap.Error(err))
	}

	if err := seedAdmin(db, cfg); err != nil {
		logger.Fatal("admin seed failed", zap.Error(err))
	}

	storage.Connect()

	syncqueue.RegisterCallbacks(db)
	audit.RegisterCallbacks(db)

	syncRepo := syncqueue.NewRepository(db)
	syncSvc := syncqueue.NewService(syncRepo)
	go func() {
		syncqueue.StartWorker(db, syncSvc, cfg.SyncRemoteURL, cfg.LicenseKey, 1*time.Hour)
	}()

	aiSvc := ai.NewAIService(db, cfg)

	app := httpserver.New(cfg, db, logger, aiSvc)
	logger.Info("api listening", zap.String("port", cfg.AppPort))
	if err := app.Listen(":" + cfg.AppPort); err != nil {
		logger.Fatal("api stopped", zap.Error(err))
	}
}

func seedAdmin(db *gorm.DB, cfg config.Config) error {
	// Sync existing admin password with configuration if it exists
	var existingAdmin users.User
	if err := db.Where("email = ?", cfg.AdminEmail).First(&existingAdmin).Error; err == nil {
		hash, err := security.HashPassword(cfg.AdminPassword)
		if err != nil {
			return err
		}
		// Verify if hash changed to avoid unnecessary db writes on every startup
		if !security.VerifyPassword(existingAdmin.PasswordHash, cfg.AdminPassword) {
			existingAdmin.PasswordHash = hash
			if err := db.Save(&existingAdmin).Error; err != nil {
				return err
			}
			log.Printf("Admin user %s password synchronized with configuration", cfg.AdminEmail)
		}
	}

	var comp company.Company
	if err := db.First(&comp).Error; err != nil {
		// 1. Create a default Company
		comp = company.Company{
			Name:   "Restaurante Local",
			NIT:    "900.123.456-7",
			Active: true,
		}
		if err := db.Create(&comp).Error; err != nil {
			return err
		}
	}

	var branch branches.Branch
	if err := db.First(&branch).Error; err != nil {
		// 2. Create a default Branch
		branch = branches.Branch{
			CompanyID: comp.ID,
			Name:      "Sede Principal",
			Code:      "SEDE-001",
			Active:    true,
		}
		if err := db.Create(&branch).Error; err != nil {
			return err
		}
	}

	var userCount int64
	db.Model(&users.User{}).Count(&userCount)
	if userCount == 0 {
		// 3. Create default Admin user
		hash, err := security.HashPassword(cfg.AdminPassword)
		if err != nil {
			return err
		}
		adminUser := users.User{
			Name:         "Administrador",
			Email:        cfg.AdminEmail,
			PasswordHash: hash,
			RoleName:     "admin",
			Active:       true,
		}
		adminUser.BranchID = branch.ID
		if err := db.Create(&adminUser).Error; err != nil {
			return err
		}

		// Create default Cashier user
		cashierHash, err := security.HashPassword("cajero123")
		if err != nil {
			return err
		}
		cashierUser := users.User{
			Name:         "Cajero de Turno",
			Email:        "cajero@neopos.com",
			PasswordHash: cashierHash,
			RoleName:     "cajero",
			Active:       true,
		}
		cashierUser.BranchID = branch.ID
		if err := db.Create(&cashierUser).Error; err != nil {
			return err
		}
	}

	var tableCount int64
	db.Model(&tables.Table{}).Count(&tableCount)
	if tableCount == 0 {
		// 4. Create default Tables
		for i := 1; i <= 8; i++ {
			table := tables.Table{
				Number:   i,
				Capacity: 4,
				Status:   tables.StatusFree,
			}
			table.BranchID = branch.ID
			if err := db.Create(&table).Error; err != nil {
				return err
			}
		}
	}

	var catCount int64
	db.Model(&categories.Category{}).Count(&catCount)
	if catCount == 0 {
		// 5. Create default Categories
		catEntradas := categories.Category{Name: "Entradas", Active: true}
		catEntradas.BranchID = branch.ID
		if err := db.Create(&catEntradas).Error; err != nil {
			return err
		}

		catHamburguesas := categories.Category{Name: "Hamburguesas", Active: true}
		catHamburguesas.BranchID = branch.ID
		if err := db.Create(&catHamburguesas).Error; err != nil {
			return err
		}

		catBebidas := categories.Category{Name: "Bebidas", Active: true}
		catBebidas.BranchID = branch.ID
		if err := db.Create(&catBebidas).Error; err != nil {
			return err
		}

		catPostres := categories.Category{Name: "Postres", Active: true}
		catPostres.BranchID = branch.ID
		if err := db.Create(&catPostres).Error; err != nil {
			return err
		}

		// 6. Create default Products
		prods := []products.Product{
			{Name: "Hamburguesa Clasica", Price: 26000, CategoryID: catHamburguesas.ID, Active: true},
			{Name: "Hamburguesa Doble", Price: 34000, CategoryID: catHamburguesas.ID, Active: true},
			{Name: "Papas Rusticas", Price: 12000, CategoryID: catEntradas.ID, Active: true},
			{Name: "Coca Cola", Price: 6000, CategoryID: catBebidas.ID, Active: true},
			{Name: "Limonada Natural", Price: 9000, CategoryID: catBebidas.ID, Active: true},
			{Name: "Brownie con Helado", Price: 15000, CategoryID: catPostres.ID, Active: true},
		}
		for i := range prods {
			prods[i].BranchID = branch.ID
			if err := db.Create(&prods[i]).Error; err != nil {
				return err
			}
		}
	}

	return nil
}
