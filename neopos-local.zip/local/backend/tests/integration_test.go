package tests

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"testing"

	"github.com/gofiber/fiber/v2"
	"github.com/stretchr/testify/assert"
)

func setupTestApp() *fiber.App {
	app := fiber.New()
	
	// Mock endpoints
	app.Post("/api/v1/orders", func(c *fiber.Ctx) error {
		return c.Status(201).JSON(fiber.Map{"id": "order-123", "status": "sent_to_kitchen"})
	})
	app.Post("/api/v1/payments", func(c *fiber.Ctx) error {
		return c.Status(200).JSON(fiber.Map{"order_id": "order-123", "status": "paid"})
	})
	app.Post("/api/v1/invoices", func(c *fiber.Ctx) error {
		return c.Status(201).JSON(fiber.Map{"cufe": "ab12cd34", "qr_code": "data:image/png;base64,..."})
	})

	return app
}

func TestE2E_SalesFlow(t *testing.T) {
	app := setupTestApp()

	// 1. Take order
	orderPayload := map[string]interface{}{
		"table_id": "T1",
		"items": []map[string]interface{}{
			{"product_id": "P1", "quantity": 2, "price": 15000},
			{"product_id": "P2", "quantity": 1, "price": 5000},
		},
	}
	body, _ := json.Marshal(orderPayload)
	req1 := httptest.NewRequest("POST", "/api/v1/orders", bytes.NewReader(body))
	req1.Header.Set("Content-Type", "application/json")
	
	resp1, err := app.Test(req1, -1)
	assert.NoError(t, err)
	assert.Equal(t, 201, resp1.StatusCode)

	// 2. Process payment
	paymentPayload := map[string]interface{}{
		"order_id": "order-123",
		"amount": 35000,
		"method": "CREDIT_CARD",
	}
	body, _ = json.Marshal(paymentPayload)
	req2 := httptest.NewRequest("POST", "/api/v1/payments", bytes.NewReader(body))
	req2.Header.Set("Content-Type", "application/json")

	resp2, err := app.Test(req2, -1)
	assert.NoError(t, err)
	assert.Equal(t, 200, resp2.StatusCode)

	// 3. Generate electronic invoice
	invoicePayload := map[string]interface{}{
		"order_id": "order-123",
		"customer_email": "test@example.com",
	}
	body, _ = json.Marshal(invoicePayload)
	req3 := httptest.NewRequest("POST", "/api/v1/invoices", bytes.NewReader(body))
	req3.Header.Set("Content-Type", "application/json")

	resp3, err := app.Test(req3, -1)
	assert.NoError(t, err)
	assert.Equal(t, 201, resp3.StatusCode)
}
