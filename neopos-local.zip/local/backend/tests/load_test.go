package tests

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"sync"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestLoad_ConcurrentOrders(t *testing.T) {
	app := setupTestApp()

	var wg sync.WaitGroup
	workers := 100 // Simulate 100 concurrent orders
	
	errors := 0
	var mu sync.Mutex

	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func(workerID int) {
			defer wg.Done()
			
			orderPayload := map[string]interface{}{
				"table_id": "T1",
				"items": []map[string]interface{}{
					{"product_id": "P1", "quantity": 1, "price": 1000},
				},
			}
			body, _ := json.Marshal(orderPayload)
			req := httptest.NewRequest("POST", "/api/v1/orders", bytes.NewReader(body))
			req.Header.Set("Content-Type", "application/json")
			
			resp, err := app.Test(req, -1)
			if err != nil || resp.StatusCode != 201 {
				mu.Lock()
				errors++
				mu.Unlock()
			}
		}(i)
	}

	wg.Wait()
	assert.Equal(t, 0, errors, "There should be zero errors under high load")
}
