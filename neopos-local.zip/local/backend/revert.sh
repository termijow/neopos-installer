#!/bin/bash
cd /home/termihoe/Documents/NeoPOS/local/backend/internal

for d in */ ; do
  mod=$(basename "$d")
  echo "Reverting $mod"
  
  if [ -f "$d/domain/entity.go" ]; then
    mv "$d/domain/entity.go" "$d/"
    sed -i "s/package domain/package $mod/g" "$d/entity.go"
  fi
  
  if [ -f "$d/application/dto.go" ]; then
    mv "$d/application/dto.go" "$d/"
    sed -i "s/package application/package $mod/g" "$d/dto.go"
  fi
  
  if [ -f "$d/application/service.go" ]; then
    mv "$d/application/service.go" "$d/"
    sed -i "s/package application/package $mod/g" "$d/service.go"
  fi
  
  if [ -f "$d/infrastructure/http/controller.go" ]; then
    mv "$d/infrastructure/http/controller.go" "$d/"
    sed -i "s/package http/package $mod/g" "$d/controller.go"
  fi
  
  if [ -f "$d/infrastructure/http/routes.go" ]; then
    mv "$d/infrastructure/http/routes.go" "$d/"
    sed -i "s/package http/package $mod/g" "$d/routes.go"
  fi
  
  if [ -f "$d/infrastructure/persistence/repository.go" ]; then
    mv "$d/infrastructure/persistence/repository.go" "$d/"
    sed -i "s/package persistence/package $mod/g" "$d/repository.go"
  fi
  
  if [ -f "$d/infrastructure/persistence/callbacks.go" ]; then
    mv "$d/infrastructure/persistence/callbacks.go" "$d/"
    sed -i "s/package persistence/package $mod/g" "$d/callbacks.go"
  fi
  
  rm -rf "$d/domain" "$d/application" "$d/infrastructure"
done
