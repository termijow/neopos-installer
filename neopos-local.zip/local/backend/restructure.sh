#!/bin/bash
cd /home/termihoe/Documents/NeoPOS/local/backend/internal

for d in */ ; do
  mod=$(basename "$d")
  echo "Restructuring $mod"
  mkdir -p "$d/domain" "$d/application" "$d/infrastructure/http" "$d/infrastructure/persistence"
  
  if [ -f "$d/entity.go" ]; then
    mv "$d/entity.go" "$d/domain/"
    sed -i "s/package $mod/package domain/g" "$d/domain/entity.go"
  fi
  
  if [ -f "$d/dto.go" ]; then
    mv "$d/dto.go" "$d/application/"
    sed -i "s/package $mod/package application/g" "$d/application/dto.go"
  fi
  
  if [ -f "$d/service.go" ]; then
    mv "$d/service.go" "$d/application/"
    sed -i "s/package $mod/package application/g" "$d/application/service.go"
  fi
  
  if [ -f "$d/controller.go" ]; then
    mv "$d/controller.go" "$d/infrastructure/http/"
    sed -i "s/package $mod/package http/g" "$d/infrastructure/http/controller.go"
  fi
  
  if [ -f "$d/routes.go" ]; then
    mv "$d/routes.go" "$d/infrastructure/http/"
    sed -i "s/package $mod/package http/g" "$d/infrastructure/http/routes.go"
  fi
  
  if [ -f "$d/repository.go" ]; then
    mv "$d/repository.go" "$d/infrastructure/persistence/"
    sed -i "s/package $mod/package persistence/g" "$d/infrastructure/persistence/repository.go"
  fi
  
  if [ -f "$d/callbacks.go" ]; then
    mv "$d/callbacks.go" "$d/infrastructure/persistence/"
    sed -i "s/package $mod/package persistence/g" "$d/infrastructure/persistence/callbacks.go"
  fi
done
