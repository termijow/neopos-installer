//go:build tools

package main

import (
	"fmt"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func main() {
	db, _ := gorm.Open(postgres.Open("host=localhost user=pos password=pos dbname=pos port=5432 sslmode=disable"), &gorm.Config{
		DryRun: true,
	})

	db.Callback().Create().After("gorm:create").Register("pos:test", func(tx *gorm.DB) {
		newTx := tx.Session(&gorm.Session{})
		newTx.Statement.Dest = nil // clear Dest
		stmt := newTx.Table("sync_queue").Create(map[string]interface{}{"id": 1}).Statement
		fmt.Printf("SQL: %s\n", stmt.SQL.String())
	})

	type User struct{ ID int }
	db.Create(&User{ID: 1})
}
