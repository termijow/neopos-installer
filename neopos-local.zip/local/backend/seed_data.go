//go:build tools

package main

import (
	"fmt"
	"log"
	"math/rand"
	"time"

	"restaurant-pos-api/internal/branches"
	"restaurant-pos-api/internal/categories"
	"restaurant-pos-api/internal/platform/config"
	"restaurant-pos-api/internal/platform/database"
	"restaurant-pos-api/internal/products"
	"restaurant-pos-api/internal/users"

	"github.com/google/uuid"
	"go.uber.org/zap"
)

func main() {
	cfg := config.Load()
	logger, _ := zap.NewDevelopment()
	defer logger.Sync()

	db, err := database.Connect(cfg.DatabaseURL, logger)
	if err != nil {
		log.Fatal("database connection failed", err)
	}

	var branch branches.Branch
	if err := db.First(&branch).Error; err != nil {
		log.Fatal("No branch found. Please run the API first.")
	}

	var category categories.Category
	if err := db.First(&category).Error; err != nil {
		category = categories.Category{Name: "General"}
		category.BranchID = branch.ID
		category.ID = uuid.New()
		db.Create(&category)
	}

	r := rand.New(rand.NewSource(time.Now().UnixNano()))

	fmt.Println("Seeding 10000 products...")
	var batch []products.Product
	for i := 0; i < 10000; i++ {
		id := uuid.New()
		prod := products.Product{
			Name:       fmt.Sprintf("Producto %d", i+1),
			CategoryID: category.ID,
			Price:      int64(r.Intn(40000) + 5000),
			Code:       fmt.Sprintf("PROD-%s", id.String()[:8]),
		}
		prod.ID = id
		prod.BranchID = branch.ID
		batch = append(batch, prod)

		if len(batch) >= 1000 {
			db.CreateInBatches(batch, 1000)
			batch = nil
		}
	}
	if len(batch) > 0 {
		db.CreateInBatches(batch, 1000)
	}

	fmt.Println("Seeding 10000 customers...")
	var userBatch []users.User
	for i := 0; i < 10000; i++ {
		id := uuid.New()
		user := users.User{
			PasswordHash: "debug-hash",
			RoleID:       uuid.Nil,
			Name:         fmt.Sprintf("Cliente %d", i+1),
			Email:        fmt.Sprintf("cliente%d@test.com", i+1),
		}
		user.ID = id
		user.BranchID = branch.ID
		userBatch = append(userBatch, user)

		if len(userBatch) >= 1000 {
			db.CreateInBatches(userBatch, 1000)
			userBatch = nil
		}
	}
	if len(userBatch) > 0 {
		db.CreateInBatches(userBatch, 1000)
	}

	fmt.Println("Done seeding!")
}
