package electronic_invoicing

import (
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"restaurant-pos-api/internal/platform/config"
	"strings"
	"testing"

	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func newFactusService(repo Repository, db *gorm.DB, remoteURL string) Service {
	return NewService(repo, config.Config{
		ElectronicInvoiceProvider: "factus",
		SyncRemoteURL:             remoteURL,
		LicenseKey:                "test-license-token",
		LocalNodeID:               "test-node",
	}, db)
}

func TestFactusIntegration(t *testing.T) {
	// Create mock server
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/v1/invoice/validate" {
			w.WriteHeader(http.StatusNotFound)
			return
		}

		// Read body
		bodyBytes, _ := io.ReadAll(r.Body)
		body := string(bodyBytes)

		if strings.Contains(body, "888888888") {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte(`{"error": "Service Temporarily Unavailable"}`))
			return
		}

		if strings.Contains(body, "777777777") {
			w.WriteHeader(http.StatusBadRequest)
			_, _ = w.Write([]byte(`{"error": "Bad Request", "message": "Validation failed for field identification"}`))
			return
		}

		if strings.Contains(body, "999999999") {
			w.WriteHeader(http.StatusUnauthorized)
			_, _ = w.Write([]byte(`{"error": "Unauthorized", "message": "Invalid API token"}`))
			return
		}

		// Success
		w.WriteHeader(http.StatusCreated)
		_, _ = w.Write([]byte(`{"status": "OK", "data": {"is_validated": true, "cufe": "mock-cufe-123456", "qr": "https://mock-qr-url.com/123456", "number": "SETT-1002"}}`))
	}))
	defer server.Close()

	t.Run("Success Scenario", func(t *testing.T) {
		db, err := gorm.Open(sqlite.Open("file:success_test_"+uuid.NewString()+"?mode=memory&cache=shared"), &gorm.Config{})
		assert.NoError(t, err)
		err = db.AutoMigrate(&ElectronicInvoice{})
		assert.NoError(t, err)

		repo := NewRepository(db)
		svc := newFactusService(repo, db, server.URL)

		req := CreateElectronicInvoiceRequest{
			BranchID:  uuid.New(),
			InvoiceID: uuid.New(),
			Provider:  "factus",
			Payload:   `{"customer": "John Doe", "amount": 100}`,
		}

		invoice, err := svc.Generate(req)
		assert.NoError(t, err)
		assert.NotNil(t, invoice)

		// Assertions on returned item
		assert.Equal(t, ElectronicStatusAccepted, invoice.Status)
		assert.Equal(t, "mock-cufe-123456", invoice.CUFE)

		// Verify database state
		dbItem, err := repo.FindByID(invoice.ID)
		assert.NoError(t, err)
		assert.Equal(t, ElectronicStatusAccepted, dbItem.Status)
		assert.Equal(t, "mock-cufe-123456", dbItem.CUFE)

		// Check response metadata saved in Response column
		var responseMap map[string]interface{}
		err = json.Unmarshal([]byte(dbItem.Response), &responseMap)
		assert.NoError(t, err)
		dataMap, ok := responseMap["data"].(map[string]interface{})
		assert.True(t, ok)
		assert.Equal(t, true, dataMap["is_validated"])
		assert.Equal(t, "mock-cufe-123456", dataMap["cufe"])
		assert.Equal(t, "SETT-1002", dataMap["number"])
	})

	t.Run("Transient Error Scenario", func(t *testing.T) {
		db, err := gorm.Open(sqlite.Open("file:transient_test_"+uuid.NewString()+"?mode=memory&cache=shared"), &gorm.Config{})
		assert.NoError(t, err)
		err = db.AutoMigrate(&ElectronicInvoice{})
		assert.NoError(t, err)

		repo := NewRepository(db)
		svc := newFactusService(repo, db, server.URL)

		req := CreateElectronicInvoiceRequest{
			BranchID:  uuid.New(),
			InvoiceID: uuid.New(),
			Provider:  "factus",
			Payload:   `{"customer": "John Doe", "amount": 100, "temp_id": "888888888"}`,
		}

		invoice, err := svc.Generate(req)
		// It should return an error
		assert.Error(t, err)
		assert.NotNil(t, invoice)

		// Assert status is still PENDING
		assert.Equal(t, ElectronicStatusPending, invoice.Status)

		// Verify database state is PENDING
		dbItem, err := repo.FindByID(invoice.ID)
		assert.NoError(t, err)
		assert.Equal(t, ElectronicStatusPending, dbItem.Status)
		assert.Empty(t, dbItem.CUFE)

		// Check transient error details saved in Response column
		var responseMap map[string]interface{}
		err = json.Unmarshal([]byte(dbItem.Response), &responseMap)
		assert.NoError(t, err)
		assert.Equal(t, "Cloud rejected invoice", responseMap["error"])
		assert.Contains(t, responseMap["raw"], "Service Temporarily Unavailable")
	})

	t.Run("Validation/Hard Rejection Scenario", func(t *testing.T) {
		db, err := gorm.Open(sqlite.Open("file:validation_test_"+uuid.NewString()+"?mode=memory&cache=shared"), &gorm.Config{})
		assert.NoError(t, err)
		err = db.AutoMigrate(&ElectronicInvoice{})
		assert.NoError(t, err)

		repo := NewRepository(db)
		svc := newFactusService(repo, db, server.URL)

		req := CreateElectronicInvoiceRequest{
			BranchID:  uuid.New(),
			InvoiceID: uuid.New(),
			Provider:  "factus",
			Payload:   `{"customer": "John Doe", "amount": 100, "invalid_id": "777777777"}`,
		}

		invoice, err := svc.Generate(req)
		// It should return an error
		assert.Error(t, err)
		assert.NotNil(t, invoice)

		// Assert status is REJECTED
		assert.Equal(t, ElectronicStatusRejected, invoice.Status)

		// Verify database state is REJECTED
		dbItem, err := repo.FindByID(invoice.ID)
		assert.NoError(t, err)
		assert.Equal(t, ElectronicStatusRejected, dbItem.Status)

		// Check response metadata saved in Response column
		var responseMap map[string]interface{}
		err = json.Unmarshal([]byte(dbItem.Response), &responseMap)
		assert.NoError(t, err)
		assert.Equal(t, "Cloud rejected invoice", responseMap["error"])
		assert.Contains(t, responseMap["raw"], "Validation failed")
	})

	t.Run("Unauthorized/Hard Rejection Scenario", func(t *testing.T) {
		db, err := gorm.Open(sqlite.Open("file:auth_reject_test_"+uuid.NewString()+"?mode=memory&cache=shared"), &gorm.Config{})
		assert.NoError(t, err)
		err = db.AutoMigrate(&ElectronicInvoice{})
		assert.NoError(t, err)

		repo := NewRepository(db)
		svc := newFactusService(repo, db, server.URL)

		req := CreateElectronicInvoiceRequest{
			BranchID:  uuid.New(),
			InvoiceID: uuid.New(),
			Provider:  "factus",
			Payload:   `{"customer": "John Doe", "amount": 100, "invalid_id": "999999999"}`,
		}

		invoice, err := svc.Generate(req)
		assert.Error(t, err)
		assert.NotNil(t, invoice)

		assert.Equal(t, ElectronicStatusRejected, invoice.Status)

		dbItem, err := repo.FindByID(invoice.ID)
		assert.NoError(t, err)
		assert.Equal(t, ElectronicStatusRejected, dbItem.Status)

		var responseMap map[string]interface{}
		err = json.Unmarshal([]byte(dbItem.Response), &responseMap)
		assert.NoError(t, err)
		assert.Equal(t, "Cloud rejected invoice", responseMap["error"])
		assert.Contains(t, responseMap["raw"], "Unauthorized")
	})

	t.Run("Duplicate Prevention Scenario", func(t *testing.T) {
		db, err := gorm.Open(sqlite.Open("file:duplicate_test_"+uuid.NewString()+"?mode=memory&cache=shared"), &gorm.Config{})
		assert.NoError(t, err)
		err = db.AutoMigrate(&ElectronicInvoice{})
		assert.NoError(t, err)

		repo := NewRepository(db)
		svc := newFactusService(repo, db, server.URL)

		invoiceID := uuid.New()
		branchID := uuid.New()

		// 1. First emission: Transient error (status remains PENDING)
		req1 := CreateElectronicInvoiceRequest{
			BranchID:  branchID,
			InvoiceID: invoiceID,
			Provider:  "factus",
			Payload:   `{"customer": "John Doe", "amount": 100, "temp_id": "888888888"}`,
		}
		invoice1, err1 := svc.Generate(req1)
		assert.Error(t, err1)
		assert.Equal(t, ElectronicStatusPending, invoice1.Status)

		// Check there is 1 record in database
		var count int64
		db.Model(&ElectronicInvoice{}).Count(&count)
		assert.Equal(t, int64(1), count)

		// 2. Second emission: Retry the same invoiceID, this time with success
		req2 := CreateElectronicInvoiceRequest{
			BranchID:  branchID,
			InvoiceID: invoiceID,
			Provider:  "factus",
			Payload:   `{"customer": "John Doe", "amount": 100}`,
		}
		invoice2, err2 := svc.Generate(req2)
		assert.NoError(t, err2)
		assert.Equal(t, ElectronicStatusAccepted, invoice2.Status)

		// Check there is still only 1 record in database (reused and updated)
		db.Model(&ElectronicInvoice{}).Count(&count)
		assert.Equal(t, int64(1), count)

		// Verify database state is ACCEPTED
		dbItem, err := repo.FindByID(invoice2.ID)
		assert.NoError(t, err)
		assert.Equal(t, ElectronicStatusAccepted, dbItem.Status)
		assert.Equal(t, "mock-cufe-123456", dbItem.CUFE)

		// 3. Third emission: Call Generate again on an already ACCEPTED invoice. It should return it directly.
		invoice3, err3 := svc.Generate(req2)
		assert.NoError(t, err3)
		assert.Equal(t, ElectronicStatusAccepted, invoice3.Status)
		assert.Equal(t, invoice2.ID, invoice3.ID)

		// Check count is still 1
		db.Model(&ElectronicInvoice{}).Count(&count)
		assert.Equal(t, int64(1), count)
	})
}
