package electronic_invoicing

import (
	"restaurant-pos-api/internal/platform/config"
	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB, cfg config.Config) {
	controller := NewController(NewService(NewRepository(db), cfg, db))
	router.Post("/electronic-invoices", controller.Generate)
	router.Get("/electronic-invoices/:id", controller.Get)
	router.Post("/credit-notes", controller.CreditNote)
}
