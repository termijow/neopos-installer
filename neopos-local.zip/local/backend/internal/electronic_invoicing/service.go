package electronic_invoicing

import (
	"encoding/json"
	"errors"
	"restaurant-pos-api/internal/dian"
	"restaurant-pos-api/internal/platform/config"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Service interface {
	Generate(CreateElectronicInvoiceRequest) (*ElectronicInvoice, error)
	Get(uuid.UUID) (*ElectronicInvoice, error)
	CreditNote(CreateCreditNoteRequest) (*CreditNote, error)
}

type service struct {
	repo            Repository
	defaultProvider string
	factusClient    dian.TechProviderClient
}

func NewService(repo Repository, cfg config.Config, db *gorm.DB) Service {
	return &service{
		repo:            repo,
		defaultProvider: cfg.ElectronicInvoiceProvider,
		factusClient:    dian.NewCloudFactusClient(cfg, db),
	}
}

func (s *service) Generate(req CreateElectronicInvoiceRequest) (*ElectronicInvoice, error) {
	provider := req.Provider
	if provider == "" {
		provider = s.defaultProvider
	}

	var item *ElectronicInvoice
	existing, err := s.repo.FindByInvoiceID(req.InvoiceID)
	if err == nil && existing != nil {
		if existing.Status == ElectronicStatusAccepted {
			return existing, nil
		}
		item = existing
		item.Provider = provider
		item.Payload = req.Payload
		item.Status = ElectronicStatusPending
		item.BranchID = req.BranchID

		if err := s.repo.Update(item); err != nil {
			return nil, err
		}
	} else {
		// Keep status PENDING when initializing the electronic invoice.
		item = &ElectronicInvoice{
			InvoiceID: req.InvoiceID,
			Provider:  provider,
			Payload:   req.Payload,
			Status:    ElectronicStatusPending,
		}
		item.BranchID = req.BranchID

		if err := s.repo.Create(item); err != nil {
			return nil, err
		}
	}

	if provider == "factus" {
		respMap, err := s.factusClient.SendInvoice([]byte(item.Payload))
		if err != nil {
			var factusErr *dian.FactusError
			if errors.As(err, &factusErr) {
				statusCode := factusErr.StatusCode
				is4xx := statusCode >= 400 && statusCode < 500
				isTransient := statusCode == 408 || statusCode == 429
				if is4xx && !isTransient {
					// Hard rejection: Save error details in Response, update status to REJECTED
					item.Status = ElectronicStatusRejected
					errDetails := map[string]interface{}{
						"error":       factusErr.Message,
						"raw":         factusErr.RawResponse,
						"status_code": factusErr.StatusCode,
					}
					respBytes, _ := json.Marshal(errDetails)
					item.Response = string(respBytes)
					_ = s.repo.Update(item)
					return item, err
				}
			}

			// Transient failure: Save error details in Response, but keep status as PENDING (and save database update!)
			var errDetails map[string]interface{}
			if errors.As(err, &factusErr) {
				errDetails = map[string]interface{}{
					"error":       factusErr.Message,
					"raw":         factusErr.RawResponse,
					"status_code": factusErr.StatusCode,
				}
			} else {
				errDetails = map[string]interface{}{
					"error": err.Error(),
				}
			}
			respBytes, _ := json.Marshal(errDetails)
			item.Response = string(respBytes)
			_ = s.repo.Update(item)
			return item, err
		}

		// A successful HTTP response only means Factus received the document.
		// Use the provider's is_validated flag (or Cloud's normalized status) to
		// distinguish SENT from a document already accepted by DIAN.
		item.Status = ElectronicStatusSent
		if normalized, ok := respMap["electronic_status"].(string); ok && normalized == "ACCEPTED" {
			item.Status = ElectronicStatusAccepted
		} else if data, ok := respMap["data"].(map[string]interface{}); ok {
			if validated, ok := data["is_validated"].(bool); ok && validated {
				item.Status = ElectronicStatusAccepted
			}
		}
		if data, ok := respMap["data"].(map[string]interface{}); ok {
			if cufe, ok := data["cufe"].(string); ok {
				item.CUFE = cufe
			}
		}
		respBytes, _ := json.Marshal(respMap)
		item.Response = string(respBytes)
		if err := s.repo.Update(item); err != nil {
			return item, err
		}
		return item, nil
	}

	// For other/legacy providers, keep original behaviour (transition to SENT immediately)
	item.Status = ElectronicStatusSent
	if err := s.repo.Update(item); err != nil {
		return item, err
	}
	return item, nil
}

func (s *service) Get(id uuid.UUID) (*ElectronicInvoice, error) {
	return s.repo.FindByID(id)
}

func (s *service) CreditNote(req CreateCreditNoteRequest) (*CreditNote, error) {
	item := &CreditNote{
		ElectronicInvoiceID: req.ElectronicInvoiceID,
		Reason:              req.Reason,
		Status:              ElectronicStatusPending,
	}
	item.BranchID = req.BranchID
	return item, s.repo.CreateCreditNote(item)
}
