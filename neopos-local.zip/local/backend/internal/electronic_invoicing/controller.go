package electronic_invoicing

import (
	"restaurant-pos-api/pkg/response"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
)

type Controller struct{ service Service }
func NewController(service Service) *Controller { return &Controller{service: service} }
func (h *Controller) Generate(c *fiber.Ctx) error { var req CreateElectronicInvoiceRequest; if err := c.BodyParser(&req); err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; item, err := h.service.Generate(req); if err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; return response.Created(c, item) }
func (h *Controller) Get(c *fiber.Ctx) error { id, err := uuid.Parse(c.Params("id")); if err != nil { return response.Error(c, fiber.StatusBadRequest, "invalid electronic invoice id") }; item, err := h.service.Get(id); if err != nil { return response.Error(c, fiber.StatusNotFound, err.Error()) }; return response.OK(c, item) }
func (h *Controller) CreditNote(c *fiber.Ctx) error { var req CreateCreditNoteRequest; if err := c.BodyParser(&req); err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; item, err := h.service.CreditNote(req); if err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; return response.Created(c, item) }
