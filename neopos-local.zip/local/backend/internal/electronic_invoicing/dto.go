package electronic_invoicing

import "github.com/google/uuid"

type CreateElectronicInvoiceRequest struct {
	BranchID  uuid.UUID `json:"branch_id"`
	InvoiceID uuid.UUID `json:"invoice_id"`
	Provider  string    `json:"provider"`
	Payload   string    `json:"payload"`
}

type CreateCreditNoteRequest struct {
	BranchID            uuid.UUID `json:"branch_id"`
	ElectronicInvoiceID uuid.UUID `json:"electronic_invoice_id"`
	Reason              string    `json:"reason"`
}
