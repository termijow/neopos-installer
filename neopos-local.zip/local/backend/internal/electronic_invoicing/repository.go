package electronic_invoicing

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface {
	Create(*ElectronicInvoice) error
	FindByID(uuid.UUID) (*ElectronicInvoice, error)
	FindByInvoiceID(uuid.UUID) (*ElectronicInvoice, error)
	Update(*ElectronicInvoice) error
	CreateCreditNote(*CreditNote) error
}
type gormRepository struct{ db *gorm.DB }
func NewRepository(db *gorm.DB) Repository { return &gormRepository{db: db} }
func (r *gormRepository) Create(item *ElectronicInvoice) error { return r.db.Create(item).Error }
func (r *gormRepository) FindByID(id uuid.UUID) (*ElectronicInvoice, error) { var item ElectronicInvoice; if err := r.db.First(&item, "id = ?", id).Error; err != nil { return nil, err }; return &item, nil }
func (r *gormRepository) FindByInvoiceID(invoiceID uuid.UUID) (*ElectronicInvoice, error) { var item ElectronicInvoice; if err := r.db.First(&item, "invoice_id = ?", invoiceID).Error; err != nil { return nil, err }; return &item, nil }
func (r *gormRepository) Update(item *ElectronicInvoice) error { return r.db.Save(item).Error }
func (r *gormRepository) CreateCreditNote(item *CreditNote) error { return r.db.Create(item).Error }
