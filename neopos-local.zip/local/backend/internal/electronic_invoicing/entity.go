package electronic_invoicing

import (
	"restaurant-pos-api/pkg/model"

	"github.com/google/uuid"
)

const (
	ElectronicStatusPending  = "PENDING"
	ElectronicStatusSent     = "SENT"
	ElectronicStatusAccepted = "ACCEPTED"
	ElectronicStatusRejected = "REJECTED"
)

type ElectronicInvoice struct {
	model.Base
	model.BranchScoped
	InvoiceID uuid.UUID `json:"invoice_id" gorm:"type:uuid;index;not null"`
	Provider  string    `json:"provider" gorm:"size:80;not null"`
	CUFE      string    `json:"cufe" gorm:"size:255;index"`
	Status    string    `json:"status" gorm:"size:40;not null;default:PENDING;index"`
	Payload   string    `json:"payload" gorm:"type:jsonb;default:'{}'"`
	Response  string    `json:"response" gorm:"type:jsonb;default:'{}'"`
}

type CreditNote struct {
	model.Base
	model.BranchScoped
	ElectronicInvoiceID uuid.UUID `json:"electronic_invoice_id" gorm:"type:uuid;index;not null"`
	Reason              string    `json:"reason" gorm:"size:255;not null"`
	Status              string    `json:"status" gorm:"size:40;not null;default:PENDING"`
}
