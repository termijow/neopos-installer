package electronic_invoicing

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"

	"restaurant-pos-api/internal/dian"

	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

// TestFactusErrorParsing_NestedObjects checks how the Factus client parses nested error responses.
func TestFactusErrorParsing_NestedObjects(t *testing.T) {
	t.Run("Nested Message Object", func(t *testing.T) {
		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.WriteHeader(http.StatusBadRequest)
			// Return nested message object
			_, _ = w.Write([]byte(`{"message": {"errors": ["The identification field is required."]}}`))
		}))
		defer server.Close()

		client := &dian.FactusClient{
			BaseURL:    server.URL,
			Token:      "test-key",
			HTTPClient: &http.Client{Timeout: 5 * time.Second},
		}

		_, err := client.SendInvoice([]byte(`{}`))
		assert.Error(t, err)

		var factusErr *dian.FactusError
		if assert.ErrorAs(t, err, &factusErr) {
			assert.Equal(t, http.StatusBadRequest, factusErr.StatusCode)
			// BUG: Since "message" is a nested object, the type assertion to string fails.
			// The expected correct behavior is to either serialize the nested object or handle it.
			// The current code falls back to "status code 400".
			t.Logf("Observed parsed message: %q", factusErr.Message)
			assert.Equal(t, "status code 400", factusErr.Message, "Bug confirmed: type assertion failure causes details to be lost")
		}
	})

	t.Run("Nested Error Object", func(t *testing.T) {
		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.WriteHeader(http.StatusBadRequest)
			// Return nested error object
			_, _ = w.Write([]byte(`{"error": {"message": "Invalid customer tax ID", "code": "VAL_102"}}`))
		}))
		defer server.Close()

		client := &dian.FactusClient{
			BaseURL:    server.URL,
			Token:      "test-key",
			HTTPClient: &http.Client{Timeout: 5 * time.Second},
		}

		_, err := client.SendInvoice([]byte(`{}`))
		assert.Error(t, err)

		var factusErr *dian.FactusError
		if assert.ErrorAs(t, err, &factusErr) {
			assert.Equal(t, http.StatusBadRequest, factusErr.StatusCode)
			// BUG: Since "error" is a nested object, the type assertion to string fails.
			// The current code falls back to "status code 400".
			t.Logf("Observed parsed message: %q", factusErr.Message)
			assert.Equal(t, "status code 400", factusErr.Message, "Bug confirmed: type assertion failure causes details to be lost")
		}
	})
}

// TestFactusGenerate_ConcurrentDuplicates checks duplicate prevention under high concurrency.
func TestFactusGenerate_ConcurrentDuplicates(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file:concurrent_test_"+uuid.NewString()+"?mode=memory&cache=shared"), &gorm.Config{})
	assert.NoError(t, err)
	err = db.AutoMigrate(&ElectronicInvoice{})
	assert.NoError(t, err)

	repo := NewRepository(db)

	// Create a mock server that delays response to simulate processing time
	var callCount int32
	var mu sync.Mutex
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		callCount++
		mu.Unlock()

		time.Sleep(100 * time.Millisecond) // Simulating network lag
		w.WriteHeader(http.StatusCreated)
		_, _ = w.Write([]byte(`{"status": "OK", "data": {"cufe": "mock-cufe-9999", "qr": "https://mock-qr-url.com/9999"}}`))
	}))
	defer server.Close()

	svc := newFactusService(repo, db, server.URL)
	invoiceID := uuid.New()
	branchID := uuid.New()

	// Launch 5 concurrent calls to Generate for the same InvoiceID
	const concurrentRequests = 5
	var wg sync.WaitGroup
	wg.Add(concurrentRequests)

	invoices := make([]*ElectronicInvoice, concurrentRequests)
	errors := make([]error, concurrentRequests)

	for i := 0; i < concurrentRequests; i++ {
		go func(idx int) {
			defer wg.Done()
			req := CreateElectronicInvoiceRequest{
				BranchID:  branchID,
				InvoiceID: invoiceID,
				Provider:  "factus",
				Payload:   fmt.Sprintf(`{"customer": "John Doe %d", "amount": 100}`, idx),
			}
			invoices[idx], errors[idx] = svc.Generate(req)
		}(i)
	}
	wg.Wait()

	// Count number of records in database
	var count int64
	db.Model(&ElectronicInvoice{}).Count(&count)

	t.Logf("Total API calls made: %d", callCount)
	t.Logf("Total DB records created: %d", count)

	// In a robust system:
	// - Total DB records created should be 1.
	// - Total API calls should be 1 (or subsequent ones should wait/return the first's result).

	// Let's assert what actually happens based on static analysis:
	// Because there is no concurrency locking/synchronization, multiple records will be inserted and multiple API calls will be made.
	assert.True(t, count > 1 || callCount > 1,
		"BUG not reproduced: concurrent requests neither duplicated DB rows nor provider submissions")
}

// TestFactusGenerate_BoundaryAnalysis tests nil/empty values and extremely large payloads.
func TestFactusGenerate_BoundaryAnalysis(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file:boundary_test_"+uuid.NewString()+"?mode=memory&cache=shared"), &gorm.Config{})
	assert.NoError(t, err)
	err = db.AutoMigrate(&ElectronicInvoice{})
	assert.NoError(t, err)

	repo := NewRepository(db)

	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusCreated)
		_, _ = w.Write([]byte(`{"status": "OK", "data": {"cufe": "boundary-cufe"}}`))
	}))
	defer server.Close()

	svc := newFactusService(repo, db, server.URL)

	t.Run("Nil InvoiceID", func(t *testing.T) {
		req := CreateElectronicInvoiceRequest{
			BranchID:  uuid.New(),
			InvoiceID: uuid.Nil, // Nil UUID
			Provider:  "factus",
			Payload:   `{"customer": "Boundary Test"}`,
		}
		invoice, err := svc.Generate(req)
		assert.NoError(t, err)
		assert.NotNil(t, invoice)
		assert.Equal(t, uuid.Nil, invoice.InvoiceID)

		// Verify we can retrieve it
		dbItem, err := repo.FindByInvoiceID(uuid.Nil)
		assert.NoError(t, err)
		assert.Equal(t, uuid.Nil, dbItem.InvoiceID)
	})

	t.Run("Extremely Large Payload", func(t *testing.T) {
		// 2MB valid JSON payload, as required by CloudFactusClient.
		largePayload := `{"data":"` + strings.Repeat("A", 2*1024*1024-12) + `"}`

		req := CreateElectronicInvoiceRequest{
			BranchID:  uuid.New(),
			InvoiceID: uuid.New(),
			Provider:  "factus",
			Payload:   largePayload,
		}
		invoice, err := svc.Generate(req)
		// We expect this to run without crashing or DB errors
		assert.NoError(t, err)
		assert.NotNil(t, invoice)
	})
}

// TestFactusGenerate_TransientErrorDetails verifies database persistence of transient errors.
func TestFactusGenerate_TransientErrorDetails(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file:transient_details_test_"+uuid.NewString()+"?mode=memory&cache=shared"), &gorm.Config{})
	assert.NoError(t, err)
	err = db.AutoMigrate(&ElectronicInvoice{})
	assert.NoError(t, err)

	repo := NewRepository(db)

	t.Run("HTTP 503 Service Unavailable", func(t *testing.T) {
		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte(`{"message": "Server temporarily overloaded"}`))
		}))
		defer server.Close()

		svc := newFactusService(repo, db, server.URL)

		invoiceID := uuid.New()
		req := CreateElectronicInvoiceRequest{
			BranchID:  uuid.New(),
			InvoiceID: invoiceID,
			Provider:  "factus",
			Payload:   `{"item": "test"}`,
		}
		invoice, err := svc.Generate(req)
		assert.Error(t, err)
		assert.Equal(t, ElectronicStatusPending, invoice.Status)

		// Verify DB contains details
		dbItem, err := repo.FindByInvoiceID(invoiceID)
		assert.NoError(t, err)
		assert.Equal(t, ElectronicStatusPending, dbItem.Status)

		var responseDetails map[string]interface{}
		err = json.Unmarshal([]byte(dbItem.Response), &responseDetails)
		assert.NoError(t, err)
		assert.Equal(t, "Cloud rejected invoice", responseDetails["error"])
		assert.Contains(t, responseDetails["raw"], "Server temporarily overloaded")
		assert.Equal(t, float64(503), responseDetails["status_code"])
	})

	t.Run("Network Timeout / Connection Refused", func(t *testing.T) {
		// Use a non-routable or unused port to force a network level failure
		svc := newFactusService(repo, db, "http://127.0.0.1:49999")

		invoiceID := uuid.New()
		req := CreateElectronicInvoiceRequest{
			BranchID:  uuid.New(),
			InvoiceID: invoiceID,
			Provider:  "factus",
			Payload:   `{"item": "test"}`,
		}
		invoice, err := svc.Generate(req)
		assert.Error(t, err)
		assert.Equal(t, ElectronicStatusPending, invoice.Status)

		// Verify DB contains details
		dbItem, err := repo.FindByInvoiceID(invoiceID)
		assert.NoError(t, err)
		assert.Equal(t, ElectronicStatusPending, dbItem.Status)

		var responseDetails map[string]interface{}
		err = json.Unmarshal([]byte(dbItem.Response), &responseDetails)
		assert.NoError(t, err)
		assert.Contains(t, responseDetails["error"], "http request to cloud failed")
	})
}
