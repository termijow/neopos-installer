package settings

import (
	"encoding/json"
	"strings"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface {
	List() ([]Setting, error)
	Upsert(*Setting) error
	Delete(uuid.UUID) error
}
type gormRepository struct{ db *gorm.DB }

func NewRepository(db *gorm.DB) Repository { return &gormRepository{db: db} }

// EncodeValue makes sure values written to the jsonb column are valid JSON.
// Settings historically exposed Value as a string, so callers may still send
// either a JSON document or a plain string such as a license key.
func EncodeValue(value string) string {
	value = strings.TrimSpace(value)
	if json.Valid([]byte(value)) {
		return value
	}

	encoded, err := json.Marshal(value)
	if err != nil {
		return `""`
	}
	return string(encoded)
}

// DecodeValue preserves the old string-based settings API while reading JSONB.
// JSON objects, arrays, booleans and numbers remain JSON text; JSON strings are
// returned without their surrounding quotes.
func DecodeValue(value string) string {
	value = strings.TrimSpace(value)
	var decoded string
	if json.Unmarshal([]byte(value), &decoded) == nil {
		return decoded
	}
	return value
}

func (r *gormRepository) List() ([]Setting, error) {
	var items []Setting
	err := r.db.Order("key asc").Find(&items).Error
	if err != nil {
		return nil, err
	}
	for i := range items {
		items[i].Value = DecodeValue(items[i].Value)
	}
	return items, nil
}

func (r *gormRepository) Upsert(item *Setting) error {
	// Save a copy so callers continue seeing the public, unquoted string value.
	persisted := *item
	persisted.Value = EncodeValue(item.Value)
	return r.db.Save(&persisted).Error
}
func (r *gormRepository) Delete(id uuid.UUID) error {
	return r.db.Delete(&Setting{}, "id = ?", id).Error
}
