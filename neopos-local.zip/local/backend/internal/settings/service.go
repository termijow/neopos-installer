package settings

import "github.com/google/uuid"

type Service interface { List() ([]Setting, error); Upsert(UpsertSettingRequest) (*Setting, error); Delete(uuid.UUID) error }
type service struct{ repo Repository }
func NewService(repo Repository) Service { return &service{repo: repo} }
func (s *service) List() ([]Setting, error) { return s.repo.List() }
func (s *service) Upsert(req UpsertSettingRequest) (*Setting, error) {
	items, err := s.repo.List()
	if err == nil {
		for _, item := range items {
			if item.Key == req.Key && item.BranchID == req.BranchID {
				item.Value = req.Value
				return &item, s.repo.Upsert(&item)
			}
		}
	}
	item := &Setting{Key: req.Key, Value: req.Value}
	item.BranchID = req.BranchID
	return item, s.repo.Upsert(item)
}
func (s *service) Delete(id uuid.UUID) error { return s.repo.Delete(id) }
