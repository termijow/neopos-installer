package settings

import "github.com/google/uuid"

type UpsertSettingRequest struct {
	BranchID uuid.UUID `json:"branch_id"`
	Key      string    `json:"key"`
	Value    string    `json:"value"`
}
