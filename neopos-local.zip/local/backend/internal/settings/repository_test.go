package settings

import "testing"

func TestEncodeValueQuotesPlainStrings(t *testing.T) {
	if got := EncodeValue("DEMO-LICENSE-KEY-123456"); got != `"DEMO-LICENSE-KEY-123456"` {
		t.Fatalf("EncodeValue() = %q, want a JSON string", got)
	}
}

func TestEncodeValueKeepsJSONDocuments(t *testing.T) {
	input := `{"valid":true,"license_type":"standard"}`
	if got := EncodeValue(input); got != input {
		t.Fatalf("EncodeValue() = %q, want %q", got, input)
	}
}

func TestDecodeValueUnquotesJSONStrings(t *testing.T) {
	if got := DecodeValue(`"DEMO-LICENSE-KEY-123456"`); got != "DEMO-LICENSE-KEY-123456" {
		t.Fatalf("DecodeValue() = %q, want plain license key", got)
	}
}

func TestDecodeValueKeepsJSONDocuments(t *testing.T) {
	input := `{"valid":true}`
	if got := DecodeValue(input); got != input {
		t.Fatalf("DecodeValue() = %q, want %q", got, input)
	}
}
