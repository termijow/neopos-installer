package settings

import (
	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB) {
	controller := NewController(NewService(NewRepository(db)))
	router.Get("/settings", controller.List)
	router.Post("/settings", controller.Upsert)
	router.Delete("/settings/:id", controller.Delete)
}
