package settings

import "restaurant-pos-api/pkg/model"

type Setting struct {
	model.Base
	model.BranchScoped
	Key   string `json:"key" gorm:"size:120;not null;index"`
	Value string `json:"value" gorm:"type:jsonb;default:'{}'"`
}
