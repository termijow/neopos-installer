package settings

import (
	"restaurant-pos-api/pkg/response"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
)

type Controller struct{ service Service }
func NewController(service Service) *Controller { return &Controller{service: service} }
func (h *Controller) List(c *fiber.Ctx) error { items, err := h.service.List(); if err != nil { return response.Error(c, fiber.StatusInternalServerError, err.Error()) }; return response.OK(c, items) }
func (h *Controller) Upsert(c *fiber.Ctx) error { var req UpsertSettingRequest; if err := c.BodyParser(&req); err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; item, err := h.service.Upsert(req); if err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; return response.OK(c, item) }
func (h *Controller) Delete(c *fiber.Ctx) error { id, err := uuid.Parse(c.Params("id")); if err != nil { return response.Error(c, fiber.StatusBadRequest, "invalid setting id") }; if err := h.service.Delete(id); err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; return response.NoContent(c) }
