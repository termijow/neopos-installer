package httpserver

import (
	"restaurant-pos-api/internal/ai"
	"restaurant-pos-api/internal/audit"
	"restaurant-pos-api/internal/auth"
	"restaurant-pos-api/internal/branches"
	"restaurant-pos-api/internal/cash_register"
	"restaurant-pos-api/internal/categories"
	"restaurant-pos-api/internal/clients"
	"restaurant-pos-api/internal/cloud_limits"
	"restaurant-pos-api/internal/company"
	"restaurant-pos-api/internal/debug"
	"restaurant-pos-api/internal/electronic_invoicing"
	"restaurant-pos-api/internal/inventory"
	"restaurant-pos-api/internal/invoices"
	"restaurant-pos-api/internal/kitchen"
	"restaurant-pos-api/internal/license"
	"restaurant-pos-api/internal/orders"
	"restaurant-pos-api/internal/platform/config"
	"restaurant-pos-api/internal/platform/middleware"
	"restaurant-pos-api/internal/printers"
	"restaurant-pos-api/internal/products"
	"restaurant-pos-api/internal/purchases"
	"restaurant-pos-api/internal/recipes"
	"restaurant-pos-api/internal/reports"
	"restaurant-pos-api/internal/roles"
	"restaurant-pos-api/internal/sales"
	"restaurant-pos-api/internal/settings"
	"restaurant-pos-api/internal/suppliers"
	syncqueue "restaurant-pos-api/internal/sync"
	"restaurant-pos-api/internal/tables"
	"restaurant-pos-api/internal/users"
	"restaurant-pos-api/pkg/response"
	"restaurant-pos-api/pkg/security"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

func New(cfg config.Config, db *gorm.DB, log *zap.Logger, aiSvc *ai.AIService) *fiber.App {
	app := fiber.New(fiber.Config{
		AppName: cfg.AppName,
		ErrorHandler: func(c *fiber.Ctx, err error) error {
			return response.Error(c, fiber.StatusInternalServerError, err.Error())
		},
	})

	app.Use(cors.New(cors.Config{
		AllowOrigins: "http://localhost:5173, https://your-production-domain.com",
		AllowHeaders: "Origin, Content-Type, Accept, Authorization",
		AllowMethods: "GET, POST, PUT, DELETE, OPTIONS",
	}))

	app.Use(middleware.RequestLogger(log))
	app.Get("/health", func(c *fiber.Ctx) error {
		return response.OK(c, fiber.Map{"status": "ok"})
	})

	app.Static("/docs", "./public/docs")

	if cfg.AppEnv == "local" || cfg.AppEnv == "test" {
		app.Post("/mock-factus/v1/bills", func(c *fiber.Ctx) error {
			body := string(c.Body())
			if strings.Contains(body, "888888888") {
				return c.Status(fiber.StatusServiceUnavailable).JSON(fiber.Map{
					"error": "Service Temporarily Unavailable",
				})
			}
			if strings.Contains(body, "777777777") {
				return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
					"error":   "Bad Request",
					"message": "Validation failed for field identification",
				})
			}
			return c.Status(fiber.StatusCreated).JSON(fiber.Map{
				"status": "OK",
				"data": fiber.Map{
					"cufe":   "mock-cufe-123456",
					"qr":     "https://mock-qr-url.com/123456",
					"number": "SETT-1002",
				},
			})
		})
	}

	jwt := security.NewJWTManager(cfg.JWTSecret)
	api := app.Group("/api/v1")
	auth.RegisterRoutes(api, db, jwt, cfg.JWTAccessTTL, cfg.JWTRefreshTTL)
	license.RegisterRoutes(api, db, cfg)

	protected := api.Group("", middleware.Auth(jwt))

	adminOnly := protected.Group("", middleware.RequireRole("admin"))
	users.RegisterRoutes(adminOnly, db)
	roles.RegisterRoutes(adminOnly, db)
	company.RegisterRoutes(adminOnly, db)
	branches.RegisterRoutes(adminOnly, db)
	audit.RegisterRoutes(adminOnly, db)
	settings.RegisterRoutes(adminOnly, db)
	syncqueue.RegisterRoutes(adminOnly, db)
	cloud_limits.RegisterRoutes(protected, cfg, db)

	managerOrAdmin := protected.Group("", middleware.RequireRole("admin", "manager"))
	categories.RegisterRoutes(managerOrAdmin, db)
	products.RegisterRoutes(managerOrAdmin, db)
	suppliers.RegisterRoutes(managerOrAdmin, db)
	inventory.RegisterRoutes(managerOrAdmin, db)
	purchases.RegisterRoutes(managerOrAdmin, db)
	recipes.RegisterRoutes(managerOrAdmin, db)
	reports.RegisterRoutes(managerOrAdmin, db)

	tables.RegisterRoutes(protected, db)
	clients.SetupRoutes(protected, db)
	orders.RegisterRoutes(protected, db)
	kitchen.RegisterRoutes(protected, db)
	cash_register.RegisterRoutes(protected, db, cfg)
	sales.RegisterRoutes(protected, db)
	invoices.RegisterRoutes(protected, db)
	electronic_invoicing.RegisterRoutes(protected, db, cfg)
	printers.RegisterRoutes(protected, db)

	if cfg.AppEnv == "local" || cfg.AppEnv == "test" {
		debug.RegisterRoutes(api, db, cfg)
	}

	aiCtrl := ai.NewController(db, cfg)
	aiCtrl.SetAIService(aiSvc)
	protected.Post("/ai/chat", aiCtrl.Chat)

	return app
}
