package config

import (
	"os"
	"strconv"
	"time"

	"github.com/joho/godotenv"
)

type Config struct {
	AppEnv                    string
	AppName                   string
	AppPort                   string
	DatabaseURL               string
	JWTSecret                 string
	JWTAccessTTL              time.Duration
	JWTRefreshTTL             time.Duration
	AdminEmail                string
	AdminPassword             string
	LocalNodeID               string
	SyncRemoteURL             string
	ElectronicInvoiceProvider string
	PrinterType               string
	PrinterAddress            string
	PrinterPort               int
	LicenseKey                string

	FactusBaseURL      string
	FactusEmail        string
	FactusPassword     string
	FactusClientID     string
	FactusClientSecret string

	AIProvider         string
	OllamaBaseURL      string
	OllamaModel        string
	GroqAPIKey         string
	GroqModel          string
	AITemperature      float32
	AIMaxTokens        int
	AILicenseRequired  bool
}

func Load() Config {
	_ = godotenv.Load()
	return Config{
		AppEnv:                    env("APP_ENV", "local"),
		AppName:                   env("APP_NAME", "restaurant-pos-api"),
		AppPort:                   env("APP_PORT", "8080"),
		DatabaseURL:               env("DATABASE_URL", "postgres://pos:pos@localhost:5432/pos?sslmode=disable"),
		JWTSecret:                 env("JWT_SECRET", ""),
		JWTAccessTTL:              time.Duration(envInt("JWT_ACCESS_TTL_MINUTES", 30)) * time.Minute,
		JWTRefreshTTL:             time.Duration(envInt("JWT_REFRESH_TTL_HOURS", 168)) * time.Hour,
		AdminEmail:                env("ADMIN_EMAIL", "admin@pos.local"),
		AdminPassword:             env("ADMIN_PASSWORD", ""),
		LocalNodeID:               env("LOCAL_NODE_ID", ""),

		SyncRemoteURL:             env("SYNC_REMOTE_URL", ""),
		ElectronicInvoiceProvider: env("ELECTRONIC_INVOICE_PROVIDER", "factus"),
		PrinterType:               env("PRINTER_TYPE", "network"),
		PrinterAddress:            env("PRINTER_ADDRESS", "192.168.1.100"),
		PrinterPort:               envInt("PRINTER_PORT", 9100),
		LicenseKey:                env("LICENSE_KEY", "local-node-license-token-abc"),

		FactusBaseURL:      env("FACTUS_BASE_URL", "https://api-sandbox.factus.com.co"),
		FactusEmail:        env("FACTUS_EMAIL", ""),
		FactusPassword:     env("FACTUS_PASSWORD", ""),
		FactusClientID:     env("FACTUS_CLIENT_ID", ""),
		FactusClientSecret: env("FACTUS_CLIENT_SECRET", ""),

		AIProvider:         env("AI_PROVIDER", "ollama"),
		OllamaBaseURL:      env("OLLAMA_BASE_URL", "http://localhost:11434"),
		OllamaModel:        env("OLLAMA_MODEL", "nemotron3:8b"),
		GroqAPIKey:         env("GROQ_API_KEY", ""),
		GroqModel:          env("GROQ_MODEL", "llama-3.1-70b-versatile"),
		AITemperature:      float32(envFloat("AI_TEMPERATURE", 0.3)),
		AIMaxTokens:        envInt("AI_MAX_TOKENS", 2000),
		AILicenseRequired:  envBool("AI_LICENSE_REQUIRED", false),
	}
}

func env(key, fallback string) string {
	value := os.Getenv(key)
	if value == "" {
		return fallback
	}
	return value
}

func envInt(key string, fallback int) int {
	value, err := strconv.Atoi(os.Getenv(key))
	if err != nil {
		return fallback
	}
	return value
}

func envFloat(key string, fallback float64) float64 {
	value, err := strconv.ParseFloat(os.Getenv(key), 64)
	if err != nil {
		return fallback
	}
	return value
}

func envBool(key string, fallback bool) bool {
	value := os.Getenv(key)
	if value == "" {
		return fallback
	}
	return value == "true" || value == "1" || value == "yes"
}
