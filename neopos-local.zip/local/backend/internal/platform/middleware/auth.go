package middleware

import (
	"strings"

	"restaurant-pos-api/pkg/response"
	"restaurant-pos-api/pkg/security"

	"github.com/gofiber/fiber/v2"
)

func Auth(jwt *security.JWTManager) fiber.Handler {
	return func(c *fiber.Ctx) error {
		header := c.Get("Authorization")
		if !strings.HasPrefix(header, "Bearer ") {
			return response.Error(c, fiber.StatusUnauthorized, "missing bearer token")
		}

		claims, err := jwt.Parse(strings.TrimPrefix(header, "Bearer "))
		if err != nil {
			return response.Error(c, fiber.StatusUnauthorized, "invalid token")
		}

		c.Locals("user_id", claims.UserID)
		c.Locals("branch_id", claims.BranchID)
		c.Locals("role", claims.Role)
		return c.Next()
	}
}

// RequireRole checks if the authenticated user has one of the allowed roles
func RequireRole(allowedRoles ...string) fiber.Handler {
	return func(c *fiber.Ctx) error {
		userRole := c.Locals("role")
		if userRole == nil {
			return response.Error(c, fiber.StatusForbidden, "access denied")
		}

		roleStr, ok := userRole.(string)
		if !ok {
			return response.Error(c, fiber.StatusForbidden, "invalid role format")
		}

		for _, role := range allowedRoles {
			if roleStr == role {
				return c.Next()
			}
		}

		return response.Error(c, fiber.StatusForbidden, "insufficient permissions")
	}
}
