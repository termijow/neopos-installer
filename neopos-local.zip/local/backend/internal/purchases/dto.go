package purchases

import "github.com/google/uuid"

type CreatePurchaseRequest struct {
	BranchID   uuid.UUID                  `json:"branch_id"`
	SupplierID uuid.UUID                  `json:"supplier_id"`
	Items      []CreatePurchaseItemRequest `json:"items"`
}

type CreatePurchaseItemRequest struct {
	InventoryItem uuid.UUID `json:"inventory_item_id"`
	Quantity      float64   `json:"quantity"`
	UnitCost      float64   `json:"unit_cost"`
}
