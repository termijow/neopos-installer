package purchases

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface {
	Create(*Purchase) error
	List() ([]Purchase, error)
	FindByID(uuid.UUID) (*Purchase, error)
}

type repository struct {
	db *gorm.DB
}

func NewRepository(db *gorm.DB) Repository {
	return &repository{db: db}
}

func (r *repository) Create(item *Purchase) error {
	return r.db.Create(item).Error
}

func (r *repository) List() ([]Purchase, error) {
	var items []Purchase
	err := r.db.Preload("Items").Find(&items).Error
	return items, err
}

func (r *repository) FindByID(id uuid.UUID) (*Purchase, error) {
	var item Purchase
	err := r.db.Preload("Items").Where("id = ?", id).First(&item).Error
	return &item, err
}
