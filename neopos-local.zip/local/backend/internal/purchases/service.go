package purchases

import (
	"errors"
	"restaurant-pos-api/internal/inventory"

	"github.com/google/uuid"
)

type Service interface {
	List() ([]Purchase, error)
	Create(CreatePurchaseRequest) (*Purchase, error)
	Get(uuid.UUID) (*Purchase, error)
}

type service struct {
	repo      Repository
	inventory inventory.Service
}

func NewService(repo Repository, inv inventory.Service) Service {
	return &service{repo: repo, inventory: inv}
}

func (s *service) List() ([]Purchase, error) {
	return s.repo.List()
}

func (s *service) Get(id uuid.UUID) (*Purchase, error) {
	return s.repo.FindByID(id)
}

func (s *service) Create(req CreatePurchaseRequest) (*Purchase, error) {
	if len(req.Items) == 0 {
		return nil, errors.New("purchase requires at least one item")
	}

	purchase := &Purchase{
		SupplierID: req.SupplierID,
	}
	purchase.BranchID = req.BranchID

	var totalCost float64
	for _, itemReq := range req.Items {
		totalCost += itemReq.Quantity * itemReq.UnitCost
		purchase.Items = append(purchase.Items, PurchaseItem{
			InventoryItem: itemReq.InventoryItem,
			Quantity:      itemReq.Quantity,
			UnitCost:      itemReq.UnitCost,
		})
	}
	purchase.TotalCost = totalCost

	if err := s.repo.Create(purchase); err != nil {
		return nil, err
	}

	for _, item := range purchase.Items {
		_, _ = s.inventory.In(inventory.MovementRequest{
			BranchID:    purchase.BranchID,
			ProductID:   item.InventoryItem, // In this case ProductID is the inventory item id
			Quantity:    int(item.Quantity), // the entity only supports int
			Reason:      "purchase",
			ReferenceID: purchase.ID,
		})
	}

	return purchase, nil
}
