package purchases

import (
	"restaurant-pos-api/internal/inventory"

	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB) {
	inventoryService := inventory.NewService(inventory.NewRepository(db))
	controller := NewController(NewService(NewRepository(db), inventoryService))
	router.Post("/purchases", controller.Create)
	router.Get("/purchases", controller.List)
	router.Get("/purchases/:id", controller.Get)
}
