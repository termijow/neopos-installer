package purchases

import (
	"restaurant-pos-api/pkg/model"

	"github.com/google/uuid"
)

type Purchase struct {
	model.Base
	model.BranchScoped
	SupplierID uuid.UUID      `json:"supplier_id" gorm:"type:uuid;index;not null"`
	TotalCost  float64        `json:"total_cost"`
	Items      []PurchaseItem `json:"items" gorm:"foreignKey:PurchaseID"`
}

type PurchaseItem struct {
	model.Base
	PurchaseID    uuid.UUID `json:"purchase_id" gorm:"type:uuid;index;not null"`
	InventoryItem uuid.UUID `json:"inventory_item_id" gorm:"type:uuid;index;not null"`
	Quantity      float64   `json:"quantity" gorm:"not null"`
	UnitCost      float64   `json:"unit_cost" gorm:"not null"`
}
