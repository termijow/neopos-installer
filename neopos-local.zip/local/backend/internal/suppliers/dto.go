package suppliers

import "github.com/google/uuid"

type UpsertSupplierRequest struct {
	BranchID uuid.UUID `json:"branch_id"`
	Name     string    `json:"name"`
	NIT      string    `json:"nit"`
	Email    string    `json:"email"`
	Phone    string    `json:"phone"`
	Active   *bool     `json:"active"`
}
