package suppliers

import "restaurant-pos-api/pkg/model"

type Supplier struct {
	model.Base
	model.BranchScoped
	Name    string `json:"name" gorm:"size:180;not null"`
	NIT     string `json:"nit" gorm:"size:40;index"`
	Email   string `json:"email" gorm:"size:180"`
	Phone   string `json:"phone" gorm:"size:60"`
	Active  bool   `json:"active" gorm:"default:true"`
}
