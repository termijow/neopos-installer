package suppliers

import (
	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB) {
	controller := NewController(NewService(NewRepository(db)))
	router.Get("/suppliers", controller.List)
	router.Post("/suppliers", controller.Create)
	router.Put("/suppliers/:id", controller.Update)
	router.Delete("/suppliers/:id", controller.Delete)
}
