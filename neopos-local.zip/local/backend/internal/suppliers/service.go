package suppliers

import "github.com/google/uuid"

type Service interface { List() ([]Supplier, error); Create(UpsertSupplierRequest) (*Supplier, error); Update(uuid.UUID, UpsertSupplierRequest) (*Supplier, error); Delete(uuid.UUID) error }
type service struct{ repo Repository }
func NewService(repo Repository) Service { return &service{repo: repo} }
func (s *service) List() ([]Supplier, error) { return s.repo.List() }
func (s *service) Create(req UpsertSupplierRequest) (*Supplier, error) { active := true; if req.Active != nil { active = *req.Active }; item := &Supplier{Name: req.Name, NIT: req.NIT, Email: req.Email, Phone: req.Phone, Active: active}; item.BranchID = req.BranchID; return item, s.repo.Create(item) }
func (s *service) Update(id uuid.UUID, req UpsertSupplierRequest) (*Supplier, error) { item, err := s.repo.FindByID(id); if err != nil { return nil, err }; if req.Name != "" { item.Name = req.Name }; if req.BranchID != uuid.Nil { item.BranchID = req.BranchID }; item.NIT, item.Email, item.Phone = req.NIT, req.Email, req.Phone; if req.Active != nil { item.Active = *req.Active }; return item, s.repo.Update(item) }
func (s *service) Delete(id uuid.UUID) error { return s.repo.Delete(id) }
