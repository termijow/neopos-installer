package suppliers

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface { List() ([]Supplier, error); Create(*Supplier) error; FindByID(uuid.UUID) (*Supplier, error); Update(*Supplier) error; Delete(uuid.UUID) error }
type gormRepository struct{ db *gorm.DB }
func NewRepository(db *gorm.DB) Repository { return &gormRepository{db: db} }
func (r *gormRepository) List() ([]Supplier, error) { var items []Supplier; err := r.db.Order("name asc").Find(&items).Error; return items, err }
func (r *gormRepository) Create(item *Supplier) error { return r.db.Create(item).Error }
func (r *gormRepository) FindByID(id uuid.UUID) (*Supplier, error) { var item Supplier; if err := r.db.First(&item, "id = ?", id).Error; err != nil { return nil, err }; return &item, nil }
func (r *gormRepository) Update(item *Supplier) error { return r.db.Save(item).Error }
func (r *gormRepository) Delete(id uuid.UUID) error { return r.db.Delete(&Supplier{}, "id = ?", id).Error }
