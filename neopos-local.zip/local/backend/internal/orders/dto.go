package orders

import "github.com/google/uuid"

type CreateOrderRequest struct {
	BranchID     uuid.UUID                `json:"branch_id"`
	TableID      uuid.UUID                `json:"table_id"`
	CustomerName string                   `json:"customer_name"`
	Notes        string                   `json:"notes"`
	SkipKitchen  bool                     `json:"skip_kitchen"`
	Items        []CreateOrderItemRequest `json:"items"`
}

type CreateOrderItemRequest struct {
	ProductID uuid.UUID `json:"product_id"`
	Name      string    `json:"name"`
	Quantity  int       `json:"quantity"`
	UnitPrice int64     `json:"unit_price"`
	Notes     string    `json:"notes"`
}

type UpdateOrderRequest struct {
	Status string                   `json:"status"`
	Items  []CreateOrderItemRequest `json:"items"`
}
