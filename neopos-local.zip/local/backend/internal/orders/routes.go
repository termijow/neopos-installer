package orders

import (
	"restaurant-pos-api/internal/kitchen"

	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB) {
	kitchenService := kitchen.NewService(kitchen.NewRepository(db))
	controller := NewController(NewService(NewRepository(db), kitchenService))
	router.Post("/orders", controller.Create)
	router.Get("/orders/:id", controller.Get)
	router.Put("/orders/:id", controller.Update)
	router.Delete("/orders/:id", controller.Cancel)
	router.Post("/orders/:id/split", controller.Split)
	router.Get("/orders/active/table/:tableId", controller.GetActiveByTable)
}
