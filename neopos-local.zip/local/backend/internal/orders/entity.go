package orders

import (
	"restaurant-pos-api/pkg/model"

	"github.com/google/uuid"
)

const (
	StatusPending       = "PENDING"
	StatusInPreparation = "IN_PREPARATION"
	StatusReady         = "READY"
	StatusDelivered     = "DELIVERED"
	StatusBilled        = "BILLED"
	StatusCanceled      = "CANCELED"
)

type Order struct {
	model.Base
	model.BranchScoped
	TableID      uuid.UUID   `json:"table_id" gorm:"type:uuid;index;not null"`
	CustomerName string      `json:"customer_name" gorm:"size:160"`
	Status       string      `json:"status" gorm:"size:30;not null;default:PENDING;index"`
	Total        int64       `json:"total" gorm:"not null;default:0"`
	Items        []OrderItem `json:"items" gorm:"foreignKey:OrderID"`
}

type OrderItem struct {
	model.Base
	OrderID   uuid.UUID `json:"order_id" gorm:"type:uuid;index;not null"`
	ProductID uuid.UUID `json:"product_id" gorm:"type:uuid;index;not null"`
	Name      string    `json:"name" gorm:"size:180;not null"`
	Quantity  int       `json:"quantity" gorm:"not null"`
	UnitPrice int64     `json:"unit_price" gorm:"not null"`
	Total     int64     `json:"total" gorm:"not null"`
	Notes     string    `json:"notes" gorm:"size:500"`
}
