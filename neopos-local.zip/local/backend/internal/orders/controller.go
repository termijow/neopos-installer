package orders

import (
	"log"
	"restaurant-pos-api/pkg/response"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
)

type Controller struct{ service Service }
func NewController(service Service) *Controller { return &Controller{service: service} }
func (h *Controller) Create(c *fiber.Ctx) error {
	var req CreateOrderRequest
	if err := c.BodyParser(&req); err != nil {
		log.Printf("[Order Controller] failed to parse body: %v", err)
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}

	// Extract branch_id from token if not provided in the request body
	if req.BranchID == uuid.Nil {
		if branchIDLocal := c.Locals("branch_id"); branchIDLocal != nil {
			if bid, ok := branchIDLocal.(uuid.UUID); ok {
				req.BranchID = bid
			}
		}
	}

	log.Printf("[Order Controller] parsed request: %+v", req)

	item, err := h.service.Create(req)
	if err != nil {
		log.Printf("[Order Controller] failed to create order: %v", err)
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}

	log.Printf("[Order Controller] order created successfully: %s", item.ID)
	return response.Created(c, item)
}
func (h *Controller) Get(c *fiber.Ctx) error { id, err := uuid.Parse(c.Params("id")); if err != nil { return response.Error(c, fiber.StatusBadRequest, "invalid order id") }; item, err := h.service.Get(id); if err != nil { return response.Error(c, fiber.StatusNotFound, err.Error()) }; return response.OK(c, item) }
func (h *Controller) Update(c *fiber.Ctx) error { id, err := uuid.Parse(c.Params("id")); if err != nil { return response.Error(c, fiber.StatusBadRequest, "invalid order id") }; var req UpdateOrderRequest; if err := c.BodyParser(&req); err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; item, err := h.service.Update(id, req); if err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; return response.OK(c, item) }
func (h *Controller) Cancel(c *fiber.Ctx) error { id, err := uuid.Parse(c.Params("id")); if err != nil { return response.Error(c, fiber.StatusBadRequest, "invalid order id") }; if err := h.service.Cancel(id); err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; return response.NoContent(c) }
func (h *Controller) Split(c *fiber.Ctx) error { id, err := uuid.Parse(c.Params("id")); if err != nil { return response.Error(c, fiber.StatusBadRequest, "invalid order id") }; item, err := h.service.Get(id); if err != nil { return response.Error(c, fiber.StatusNotFound, err.Error()) }; return response.OK(c, item) }
func (h *Controller) GetActiveByTable(c *fiber.Ctx) error {
	tableID, err := uuid.Parse(c.Params("tableId"))
	if err != nil {
		return response.Error(c, fiber.StatusBadRequest, "invalid table id")
	}
	item, err := h.service.GetActiveByTable(tableID)
	if err != nil {
		return response.Error(c, fiber.StatusNotFound, err.Error())
	}
	return response.OK(c, item)
}
