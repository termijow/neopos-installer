package orders

import (
	"errors"

	"restaurant-pos-api/internal/kitchen"

	"github.com/google/uuid"
)

type Service interface {
	Create(CreateOrderRequest) (*Order, error)
	Get(uuid.UUID) (*Order, error)
	Update(uuid.UUID, UpdateOrderRequest) (*Order, error)
	Cancel(uuid.UUID) error
	GetActiveByTable(uuid.UUID) (*Order, error)
}

type service struct {
	repo    Repository
	kitchen kitchen.Service
}

func NewService(repo Repository, kitchen kitchen.Service) Service {
	return &service{repo: repo, kitchen: kitchen}
}

func (s *service) GetActiveByTable(tableID uuid.UUID) (*Order, error) {
	return s.repo.FindActiveByTableID(tableID)
}

func (s *service) Create(req CreateOrderRequest) (*Order, error) {
	if len(req.Items) == 0 {
		return nil, errors.New("order requires at least one item")
	}
	order := &Order{TableID: req.TableID, CustomerName: req.CustomerName, Status: StatusPending}
	order.BranchID = req.BranchID
	for _, reqItem := range req.Items {
		if reqItem.Quantity <= 0 {
			return nil, errors.New("item quantity must be greater than zero")
		}
		total := int64(reqItem.Quantity) * reqItem.UnitPrice
		order.Total += total
		order.Items = append(order.Items, OrderItem{
			ProductID: reqItem.ProductID,
			Name: reqItem.Name,
			Quantity: reqItem.Quantity,
			UnitPrice: reqItem.UnitPrice,
			Total: total,
			Notes: reqItem.Notes,
		})
	}
	if err := s.repo.Create(order); err != nil {
		return nil, err
	}
	var err error
	if !req.SkipKitchen {
		_, err = s.kitchen.Create(kitchen.CreateKitchenOrderRequest{BranchID: req.BranchID, OrderID: order.ID, Notes: req.Notes})
	}
	return order, err
}

func (s *service) Get(id uuid.UUID) (*Order, error) {
	return s.repo.FindByID(id)
}

func (s *service) Update(id uuid.UUID, req UpdateOrderRequest) (*Order, error) {
	order, err := s.repo.FindByID(id)
	if err != nil {
		return nil, err
	}
	if req.Status != "" {
		order.Status = req.Status
	}
	if len(req.Items) > 0 {
		order.Total = 0
		order.Items = nil
		for _, reqItem := range req.Items {
			total := int64(reqItem.Quantity) * reqItem.UnitPrice
			order.Total += total
			order.Items = append(order.Items, OrderItem{OrderID: order.ID, ProductID: reqItem.ProductID, Name: reqItem.Name, Quantity: reqItem.Quantity, UnitPrice: reqItem.UnitPrice, Total: total, Notes: reqItem.Notes})
		}
		
		// If we are updating the items, the UI has merged all items from all active orders on this table.
		// Therefore, we must cancel any other active orders on the same table so they don't double count!
		_ = s.repo.CancelOtherActiveOrders(order.TableID, order.ID)
	}
	if req.Status == StatusBilled {
		if err := s.repo.MarkAllActiveAsBilled(order.TableID); err != nil {
			return nil, err
		}
	}
	return order, s.repo.Update(order)
}

func (s *service) Cancel(id uuid.UUID) error {
	return s.repo.Cancel(id)
}
