package orders

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface {
	Create(*Order) error
	FindByID(uuid.UUID) (*Order, error)
	Update(*Order) error
	Cancel(uuid.UUID) error
	FindActiveByTableID(uuid.UUID) (*Order, error)
	MarkAllActiveAsBilled(uuid.UUID) error
	CancelOtherActiveOrders(tableID uuid.UUID, excludeOrderID uuid.UUID) error
}

type gormRepository struct{ db *gorm.DB }
func NewRepository(db *gorm.DB) Repository { return &gormRepository{db: db} }
func (r *gormRepository) Create(item *Order) error { return r.db.Create(item).Error }
func (r *gormRepository) FindByID(id uuid.UUID) (*Order, error) { var item Order; if err := r.db.Preload("Items").First(&item, "id = ?", id).Error; err != nil { return nil, err }; return &item, nil }
func (r *gormRepository) Update(item *Order) error { 
	if len(item.Items) > 0 {
		// Explicitly delete old items before saving new ones to avoid duplication
		r.db.Where("order_id = ?", item.ID).Delete(&OrderItem{})
	}
	return r.db.Session(&gorm.Session{FullSaveAssociations: true}).Save(item).Error 
}
func (r *gormRepository) Cancel(id uuid.UUID) error { return r.db.Model(&Order{}).Where("id = ?", id).Update("status", StatusCanceled).Error }
func (r *gormRepository) FindActiveByTableID(tableID uuid.UUID) (*Order, error) {
	var activeOrders []Order
	err := r.db.Preload("Items").Where("table_id = ? AND status NOT IN ('BILLED', 'CANCELED')", tableID).Order("created_at desc").Find(&activeOrders).Error
	if err != nil {
		return nil, err
	}
	if len(activeOrders) == 0 {
		return nil, gorm.ErrRecordNotFound
	}
	for i := 1; i < len(activeOrders); i++ {
		activeOrders[0].Items = append(activeOrders[0].Items, activeOrders[i].Items...)
		activeOrders[0].Total += activeOrders[i].Total
	}
	return &activeOrders[0], nil
}
func (r *gormRepository) MarkAllActiveAsBilled(tableID uuid.UUID) error {
	return r.db.Model(&Order{}).Where("table_id = ? AND status NOT IN ('BILLED', 'CANCELED')", tableID).Update("status", StatusBilled).Error
}
func (r *gormRepository) CancelOtherActiveOrders(tableID uuid.UUID, excludeOrderID uuid.UUID) error {
	return r.db.Model(&Order{}).Where("table_id = ? AND id != ? AND status NOT IN ('BILLED', 'CANCELED')", tableID, excludeOrderID).Update("status", StatusCanceled).Error
}
