package reports

import (
	"restaurant-pos-api/pkg/response"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
)

type Controller struct{ service Service }
func NewController(service Service) *Controller { return &Controller{service: service} }
func (h *Controller) Daily(c *fiber.Ctx) error { return h.export(c, "ventas-diarias.xlsx", h.service.Daily, h.service.DailyData) }
func (h *Controller) Monthly(c *fiber.Ctx) error { return h.export(c, "ventas-mensuales.xlsx", h.service.Monthly, h.service.MonthlyData) }
func (h *Controller) Ledger(c *fiber.Ctx) error { return h.export(c, "libro-ventas.xlsx", h.service.Ledger, h.service.LedgerData) }
func (h *Controller) Tax(c *fiber.Ctx) error { return h.export(c, "iva.xlsx", h.service.Tax, h.service.TaxData) }
func (h *Controller) Inventory(c *fiber.Ctx) error { return h.export(c, "inventario.xlsx", h.service.Inventory, h.service.InventoryData) }

func (h *Controller) Cash(c *fiber.Ctx) error {
	date := c.Query("to")
	if date == "" {
		date = "Hoy" // We'll let service handle missing date, but for filename use a default
	}
	filename := "Reporte_Caja_" + date + ".xlsx"
	return h.export(c, filename, h.service.Cash, h.service.CashData)
}

func (h *Controller) Dashboard(c *fiber.Ctx) error {
	branchID := c.Query("branch_id")
	if branchID == "" {
		if b := c.Locals("branch_id"); b != nil {
			switch v := b.(type) {
			case string:
				branchID = v
			case uuid.UUID:
				branchID = v.String()
			}
		}
	}
	data, err := h.service.Dashboard(branchID)
	if err != nil {
		return response.Error(c, fiber.StatusInternalServerError, err.Error())
	}
	return response.OK(c, data)
}

func (h *Controller) export(c *fiber.Ctx, name string, fn func(ReportQuery) ([]byte, error), dataFn func(ReportQuery) (any, error)) error {
	branchID := c.Query("branch_id")
	if branchID == "" {
		if b := c.Locals("branch_id"); b != nil {
			switch v := b.(type) {
			case string:
				branchID = v
			case uuid.UUID:
				branchID = v.String()
			}
		}
	}
	
	// Try to get user_id from token
	userID := ""
	if uid := c.Locals("user_id"); uid != nil {
		switch v := uid.(type) {
		case string:
			userID = v
		case uuid.UUID:
			userID = v.String()
		}
	}

	query := ReportQuery{BranchID: branchID, From: c.Query("from"), To: c.Query("to"), User: userID}

	if c.Query("format") == "json" {
		data, err := dataFn(query)
		if err != nil { return response.Error(c, fiber.StatusInternalServerError, err.Error()) }
		return response.OK(c, data)
	}

	data, err := fn(query)
	if err != nil { return response.Error(c, fiber.StatusInternalServerError, err.Error()) }
	c.Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	c.Set("Content-Disposition", "attachment; filename="+name)
	return c.Send(data)
}
