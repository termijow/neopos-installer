package reports

import (
	"sort"
	"strings"
	"time"

	"gorm.io/gorm"
)

type Repository interface {
	SalesSummary() ([][]any, error)
	InventorySummary() ([][]any, error)
	GetDailySales(branchID string, from, to time.Time) ([]SaleDetail, error)
	GetMonthlySales(branchID string, year, month int) ([]SaleDetail, error)
	GetSalesBook(branchID string, from, to time.Time) ([]SaleDetail, error)
	GetProductsWithPrices(branchID string) ([]ProductPrice, error)
	GetCashHistory(branchID string, from, to time.Time) ([]CashSessionDetail, error)
	Dashboard(branchID string) (map[string]any, error)
	GetCashReportData(branchID string, from, to time.Time, user string) (*CashReportData, error)
	GetInventoryReportData(branchID string, user string) (*InventoryReportData, error)
}

type gormRepository struct{ db *gorm.DB }

func NewRepository(db *gorm.DB) Repository { return &gormRepository{db: db} }

func (r *gormRepository) SalesSummary() ([][]any, error) {
	rows := [][]any{{"Fecha", "Ventas", "Total"}}
	return rows, nil
}
func (r *gormRepository) InventorySummary() ([][]any, error) {
	rows := [][]any{{"Producto", "Movimiento", "Cantidad"}}
	return rows, nil
}

type SaleDetail struct {
	Date        time.Time
	InvoiceNum  string
	ClientName  string
	ProductName string
	Quantity    int
	UnitPrice   int64
	Subtotal    int64
	Tax         int64
	Total       int64
}

type ProductPrice struct {
	ProductID string
	Name      string
	Code      string
	Price     int64
	Category  string
}

func (r *gormRepository) GetDailySales(branchID string, from, to time.Time) ([]SaleDetail, error) {
	var details []SaleDetail
	err := r.db.Table("sales s").
		Select(`
			s.created_at as date,
			COALESCE(i.number, '') as invoice_num,
			COALESCE(o.customer_name, 'Consumidor Final') as client_name,
			si.name as product_name,
			si.quantity,
			si.unit_price,
			(si.quantity * si.unit_price) as subtotal,
			ROUND((si.quantity * si.unit_price) * 0.19) as tax,
			ROUND((si.quantity * si.unit_price) * 1.19) as total
		`).
		Joins("LEFT JOIN sale_items si ON si.sale_id = s.id").
		Joins("LEFT JOIN invoices i ON i.sale_id = s.id").
		Joins("LEFT JOIN orders o ON o.id = s.order_id").
		Where("s.branch_id = ? AND s.created_at BETWEEN ? AND ?", branchID, from, to).
		Order("s.created_at DESC").
		Scan(&details).Error
	return details, err
}

func (r *gormRepository) GetMonthlySales(branchID string, year, month int) ([]SaleDetail, error) {
	from := time.Date(year, time.Month(month), 1, 0, 0, 0, 0, time.UTC)
	to := from.AddDate(0, 1, 0).Add(-time.Second)
	return r.GetDailySales(branchID, from, to)
}

func (r *gormRepository) GetSalesBook(branchID string, from, to time.Time) ([]SaleDetail, error) {
	return r.GetDailySales(branchID, from, to)
}

func (r *gormRepository) GetProductsWithPrices(branchID string) ([]ProductPrice, error) {
	var products []ProductPrice
	err := r.db.Table("products p").
		Select("p.id as product_id, p.name, p.code, p.price, cat.name as category").
		Joins("LEFT JOIN categories cat ON cat.id = p.category_id").
		Where("p.branch_id = ? AND p.active = true", branchID).
		Order("cat.name, p.name").
		Scan(&products).Error
	return products, err
}

func (r *gormRepository) Dashboard(branchID string) (map[string]any, error) {
	today := time.Now().Truncate(24 * time.Hour)
	var salesToday int64
	r.db.Table("sales").Where("branch_id = ? AND created_at >= ? AND deleted_at IS NULL", branchID, today).Select("COALESCE(SUM(total), 0)").Scan(&salesToday)

	var invoicesCount int64
	r.db.Table("sales").Where("branch_id = ? AND created_at >= ? AND deleted_at IS NULL", branchID, today).Count(&invoicesCount)

	var tablesCount int64
	r.db.Table("tables").Where("branch_id = ? AND status = 'OCCUPIED' AND deleted_at IS NULL", branchID).Count(&tablesCount)

	var totalTables int64
	r.db.Table("tables").Where("branch_id = ? AND deleted_at IS NULL", branchID).Count(&totalTables)

	var pendingOrders int64
	r.db.Table("orders").Where("branch_id = ? AND status IN ('PENDING', 'IN_PREPARATION', 'OPEN') AND deleted_at IS NULL", branchID).Count(&pendingOrders)

	var topProducts []map[string]any
	r.db.Raw(`
		SELECT p.name as name, COALESCE(SUM(si.quantity), 0) as ventas
		FROM sale_items si
		JOIN products p ON si.product_id = p.id
		JOIN sales s ON si.sale_id = s.id
		WHERE s.branch_id = ?
		GROUP BY p.name
		ORDER BY ventas DESC
		LIMIT 5
	`, branchID).Scan(&topProducts)

	var salesMonthly []map[string]any
	r.db.Raw(`
		SELECT TRIM(TO_CHAR(created_at, 'Mon')) as name, COALESCE(SUM(total), 0) as ventas
		FROM sales
		WHERE branch_id = ? AND created_at >= NOW() - INTERVAL '6 months'
		GROUP BY TO_CHAR(created_at, 'Mon'), DATE_TRUNC('month', created_at)
		ORDER BY DATE_TRUNC('month', created_at)
	`, branchID).Scan(&salesMonthly)

	var peakHours []map[string]any
	r.db.Raw(`
		SELECT TRIM(TO_CHAR(created_at, 'HH24:00')) as time, COUNT(*) as pedidos
		FROM sales
		WHERE branch_id = ?
		GROUP BY TO_CHAR(created_at, 'HH24:00')
		ORDER BY time
	`, branchID).Scan(&peakHours)

	var profitability []map[string]any
	r.db.Raw(`
		SELECT TRIM(TO_CHAR(created_at, 'Mon')) as name, 
		       COALESCE(SUM(total), 0) as ingresos,
		       COALESCE(SUM(total)*0.4, 0) as costos,
		       COALESCE(SUM(total)*0.6, 0) as utilidad
		FROM sales
		WHERE branch_id = ? AND created_at >= NOW() - INTERVAL '6 months'
		GROUP BY TO_CHAR(created_at, 'Mon'), DATE_TRUNC('month', created_at)
		ORDER BY DATE_TRUNC('month', created_at)
	`, branchID).Scan(&profitability)

	var chartData []map[string]any
	r.db.Raw(`
		SELECT TRIM(TO_CHAR(created_at, 'Day')) as label, COALESCE(SUM(total), 0) as value
		FROM sales
		WHERE branch_id = ? AND created_at >= NOW() - INTERVAL '7 days'
		GROUP BY TO_CHAR(created_at, 'Day'), DATE_TRUNC('day', created_at)
		ORDER BY DATE_TRUNC('day', created_at)
	`, branchID).Scan(&chartData)

	return map[string]any{
		"sales_today":           salesToday,
		"recent_invoices_count": invoicesCount,
		"occupied_tables":       tablesCount,
		"total_tables":          totalTables,
		"pending_orders":        pendingOrders,
		"chart_data":            chartData,
		"salesMonthly":          salesMonthly,
		"topProducts":           topProducts,
		"peakHours":             peakHours,
		"profitability":         profitability,
	}, nil
}

type CashSessionDetail struct {
	ID             string     `json:"id"`
	OpenedAt       time.Time  `json:"opened_at"`
	ClosedAt       *time.Time `json:"closed_at"`
	Status         string     `json:"status"`
	OpeningAmount  int64      `json:"opening_amount"`
	ExpectedAmount int64      `json:"expected_amount"`
	ClosingAmount  int64      `json:"closing_amount"`
	Difference     int64      `json:"difference"`
	Notes          string     `json:"notes"`
}

func (r *gormRepository) GetCashHistory(branchID string, from, to time.Time) ([]CashSessionDetail, error) {
	var sessions []CashSessionDetail
	err := r.db.Table("cash_register_sessions").
		Select("id, created_at as opened_at, closed_at, status, opening_amount, expected_amount, closing_amount, difference, notes").
		Where("branch_id = ? AND created_at BETWEEN ? AND ?", branchID, from, to).
		Order("created_at desc").
		Find(&sessions).Error
	return sessions, err
}

type CashReportData struct {
	CompanyName    string
	CompanyNIT     string
	BranchName     string
	GeneratedAt    time.Time
	GeneratedBy    string
	DateRange      string
	Summary        CashSummary
	PaymentMethods []PaymentMethodSummary
	Sales          []CashSaleDetail
	Products       []CashProductDetail
	Movements      []CashMovementDetail
}

type CashSummary struct {
	OpeningAmount   int64
	GrossSales      int64
	Discounts       int64
	TaxCollected    int64
	Tips            int64
	ManualDeposits  int64
	ManualWithdraws int64
	Refunds         int64
	NetTotal        int64
	CashSales       int64
	OtherSales      int64
	ClosingAmount   int64
	ExpectedClose   int64
	Difference      int64
	Notes           string
}

type PaymentMethodSummary struct {
	Method string
	Count  int
	Total  int64
}

type paymentMethodRow struct {
	Method string
	Count  int64
	Total  int64
}

// cashPaymentMethodName keeps the cash report consistent with the payment
// method values accepted by the POS. Older local data may contain Spanish
// labels, while newer sales use the enum-like values from sales.PaymentMethod.
func cashPaymentMethodName(method string) string {
	switch strings.ToUpper(strings.TrimSpace(method)) {
	case "CASH", "EFECTIVO":
		return "Efectivo"
	case "CREDIT_CARD", "CREDIT CARD", "TARJETA CREDITO", "TARJETA DE CREDITO":
		return "Tarjeta de crédito"
	case "DEBIT_CARD", "DEBIT CARD", "TARJETA DEBITO", "TARJETA DE DÉBITO", "TARJETA DE DEBITO":
		return "Tarjeta débito"
	case "TARJETA", "CARD":
		return "Tarjeta"
	case "TRANSFER", "TRANSFERENCIA", "BANK_TRANSFER", "BANK TRANSFER":
		return "Transferencia"
	case "QR":
		return "QR"
	case "":
		return "Sin especificar"
	default:
		return strings.TrimSpace(method)
	}
}

func summarizePaymentMethods(rows []paymentMethodRow) []PaymentMethodSummary {
	byMethod := make(map[string]PaymentMethodSummary, len(rows))
	for _, row := range rows {
		method := cashPaymentMethodName(row.Method)
		current := byMethod[method]
		current.Method = method
		current.Count += int(row.Count)
		current.Total += row.Total
		byMethod[method] = current
	}

	result := make([]PaymentMethodSummary, 0, len(byMethod))
	for _, summary := range byMethod {
		result = append(result, summary)
	}

	order := map[string]int{
		"Efectivo":           0,
		"Tarjeta de crédito": 1,
		"Tarjeta débito":     2,
		"Tarjeta":            3,
		"Transferencia":      4,
		"QR":                 5,
		"Sin especificar":    6,
	}
	sort.SliceStable(result, func(i, j int) bool {
		left, leftKnown := order[result[i].Method]
		right, rightKnown := order[result[j].Method]
		if leftKnown && rightKnown && left != right {
			return left < right
		}
		if leftKnown != rightKnown {
			return leftKnown
		}
		return result[i].Method < result[j].Method
	})
	return result
}

type CashSaleDetail struct {
	InvoiceNum    string
	Date          time.Time
	CustomerName  string
	CashierName   string
	PaymentMethod string
	Subtotal      int64
	Tax           int64
	Discount      int64
	Total         int64
	Status        string
}

type CashProductDetail struct {
	ProductName  string
	CategoryName string
	Quantity     int
	UnitPrice    int64
	TotalSold    int64
}

type CashMovementDetail struct {
	Time    time.Time
	Type    string
	Concept string
	User    string
	Value   int64
}

func (r *gormRepository) GetCashReportData(branchID string, from, to time.Time, user string) (*CashReportData, error) {
	var data CashReportData
	data.GeneratedAt = time.Now()
	data.GeneratedBy = user
	data.DateRange = from.Format("02/01/2006") + " a " + to.Format("02/01/2006")

	// Get Company and Branch
	var branch struct {
		Name        string
		CompanyName string
		CompanyNIT  string
	}
	r.db.Table("branches b").
		Select("b.name, c.name as company_name, c.nit as company_nit").
		Joins("JOIN companies c ON c.id = b.company_id").
		Where("b.id = ? AND b.deleted_at IS NULL", branchID).
		Scan(&branch)
	data.BranchName = branch.Name
	data.CompanyName = branch.CompanyName
	data.CompanyNIT = branch.CompanyNIT

	// Summaries
	var sessions []CashSessionDetail
	r.db.Table("cash_register_sessions").
		Select("id, opening_amount, closing_amount, expected_amount, difference, notes").
		Where("branch_id = ? AND created_at BETWEEN ? AND ?", branchID, from, to).
		Scan(&sessions)

	var sessionIDs []string
	for _, s := range sessions {
		sessionIDs = append(sessionIDs, s.ID)
		data.Summary.OpeningAmount += s.OpeningAmount
		data.Summary.ClosingAmount += s.ClosingAmount
		data.Summary.ExpectedClose += s.ExpectedAmount
		data.Summary.Difference += s.Difference
		if s.Notes != "" {
			if data.Summary.Notes != "" {
				data.Summary.Notes += "\n"
			}
			data.Summary.Notes += s.Notes
		}
	}

	if len(sessionIDs) == 0 {
		return &data, nil
	}

	// Sales details (filtered by exact session IDs to perfectly match cash register logic)
	r.db.Table("sales s").
		Select(`
			COALESCE(i.number, '') as invoice_num,
			s.created_at as date,
			COALESCE(o.customer_name, 'Consumidor Final') as customer_name,
			COALESCE(u.name, 'Sistema') as cashier_name,
			s.payment_method,
			s.subtotal,
			s.discount,
			(s.total - s.subtotal + s.discount - COALESCE(s.tip, 0)) as tax,
			s.total,
			'Pagada' as status
		`).
		Joins("LEFT JOIN invoices i ON i.sale_id = s.id").
		Joins("LEFT JOIN orders o ON o.id = s.order_id").
		Joins("LEFT JOIN cash_register_sessions crs ON crs.id = s.cash_session_id").
		Joins("LEFT JOIN users u ON u.id = crs.opened_by").
		Where("s.cash_session_id IN ? AND s.deleted_at IS NULL", sessionIDs).
		Order("s.created_at asc").
		Scan(&data.Sales)

	var tipSum int64
	r.db.Table("sales").Where("cash_session_id IN ? AND deleted_at IS NULL", sessionIDs).
		Select("COALESCE(SUM(tip), 0)").Scan(&tipSum)
	data.Summary.Tips = tipSum

	for _, s := range data.Sales {
		data.Summary.GrossSales += s.Subtotal
		data.Summary.TaxCollected += s.Tax
		data.Summary.Discounts += s.Discount
		data.Summary.NetTotal += s.Total
		if cashPaymentMethodName(s.PaymentMethod) == "Efectivo" {
			data.Summary.CashSales += s.Total
		} else {
			data.Summary.OtherSales += s.Total
		}
	}

	// Payment methods
	var paymentMethodRows []paymentMethodRow
	if err := r.db.Table("sales").
		Select("payment_method as method, COUNT(*) as count, COALESCE(SUM(total), 0) as total").
		Where("cash_session_id IN ? AND deleted_at IS NULL", sessionIDs).
		Group("payment_method").
		Scan(&paymentMethodRows).Error; err != nil {
		return nil, err
	}
	data.PaymentMethods = summarizePaymentMethods(paymentMethodRows)

	// Sold Products
	r.db.Table("sale_items si").
		Select(`
			p.name as product_name,
			COALESCE(c.name, 'Sin categoría') as category_name,
			SUM(si.quantity) as quantity,
			si.unit_price as unit_price,
			SUM(si.total) as total_sold
		`).
		Joins("JOIN sales s ON s.id = si.sale_id").
		Joins("JOIN products p ON p.id = si.product_id").
		Joins("LEFT JOIN categories c ON c.id = p.category_id").
		Where("s.cash_session_id IN ? AND s.deleted_at IS NULL", sessionIDs).
		Group("p.name, c.name, si.unit_price").
		Order("total_sold DESC").
		Scan(&data.Products)

	// Cash Movements
	r.db.Table("cash_movements cm").
		Select(`
			cm.created_at as time,
			cm.type,
			cm.reason as concept,
			COALESCE(u.name, 'Sistema') as user,
			cm.amount as value
		`).
		Joins("JOIN cash_register_sessions crs ON crs.id = cm.session_id").
		Joins("LEFT JOIN users u ON u.id = crs.opened_by").
		Where("cm.session_id IN ? AND cm.deleted_at IS NULL", sessionIDs).
		Order("cm.created_at asc").
		Scan(&data.Movements)

	for _, m := range data.Movements {
		if m.Type == "DEPOSIT" {
			data.Summary.ManualDeposits += m.Value
		} else if m.Type == "WITHDRAWAL" {
			data.Summary.ManualWithdraws += m.Value
		}
	}

	return &data, nil
}

type InventoryReportData struct {
	CompanyName string
	CompanyNIT  string
	GeneratedAt time.Time
	GeneratedBy string
	BranchName  string
	Products    []InventoryProductData
	Movements   []InventoryMovementData
}

type InventoryProductData struct {
	Code     string
	Name     string
	Category string
	Stock    int
	MinStock int
	Cost     int64
	Price    int64
	LastSale string
}

type InventoryMovementData struct {
	Date        time.Time
	ProductName string
	Type        string
	Quantity    int
	StockBefore int
	StockAfter  int
	User        string
}

func (r *gormRepository) GetInventoryReportData(branchID string, user string) (*InventoryReportData, error) {
	data := &InventoryReportData{
		CompanyName: "NeoPOS Restaurante",
		CompanyNIT:  "900.123.456-7",
		GeneratedAt: time.Now(),
		GeneratedBy: user,
		BranchName:  branchID,
	}

	// 1. Fetch all active products
	type ProdRes struct {
		ID       string
		Code     string
		Name     string
		Price    int64
		Category string
	}
	var prods []ProdRes
	r.db.Table("products").
		Select("products.id, products.code, products.name, products.price, categories.name as category").
		Joins("left join categories on categories.id = products.category_id").
		Where("products.branch_id = ? AND products.deleted_at IS NULL AND products.active = true", branchID).
		Scan(&prods)

	// 2. Fetch stock for each product
	type StockRes struct {
		ProductID string
		Total     int
	}
	var stocks []StockRes
	r.db.Table("inventory_movements").
		Select("product_id, SUM(CASE WHEN type = 'IN' THEN quantity WHEN type = 'OUT' THEN -quantity ELSE quantity END) as total").
		Where("branch_id = ?", branchID).
		Group("product_id").
		Scan(&stocks)

	stockMap := make(map[string]int)
	for _, s := range stocks {
		stockMap[s.ProductID] = s.Total
	}

	// 3. Fetch last sale date for each product
	type LastSaleRes struct {
		ProductID string
		LastDate  time.Time
	}
	var lastSales []LastSaleRes
	r.db.Table("sale_items").
		Select("sale_items.product_id, MAX(sales.created_at) as last_date").
		Joins("join sales on sales.id = sale_items.sale_id").
		Where("sales.branch_id = ?", branchID).
		Group("sale_items.product_id").
		Scan(&lastSales)

	lastSaleMap := make(map[string]time.Time)
	for _, ls := range lastSales {
		lastSaleMap[ls.ProductID] = ls.LastDate
	}

	for _, p := range prods {
		lastSaleStr := "Nunca"
		if ls, ok := lastSaleMap[p.ID]; ok {
			lastSaleStr = ls.Format("02/01/2006")
		}
		data.Products = append(data.Products, InventoryProductData{
			Code:     p.Code,
			Name:     p.Name,
			Category: p.Category,
			Stock:    stockMap[p.ID],
			MinStock: 10,
			Cost:     int64(float64(p.Price) * 0.4),
			Price:    p.Price,
			LastSale: lastSaleStr,
		})
	}

	// 4. Fetch movements (last 30 days or so, or all for the report)
	type MovRes struct {
		Date        time.Time
		ProductName string
		ProductID   string
		Type        string
		Quantity    int
		User        string
	}
	var movs []MovRes
	r.db.Table("inventory_movements").
		Select("inventory_movements.created_at as date, products.name as product_name, inventory_movements.product_id, inventory_movements.type, inventory_movements.quantity, 'Sistema' as user").
		Joins("join products on products.id = inventory_movements.product_id").
		Where("inventory_movements.branch_id = ?", branchID).
		Order("inventory_movements.created_at asc").
		Scan(&movs) // Note: ordered asc to calculate running stock

	runningStock := make(map[string]int)
	for _, m := range movs {
		before := runningStock[m.ProductID]
		after := before
		if m.Type == "IN" {
			after += m.Quantity
		} else if m.Type == "OUT" {
			after -= m.Quantity
		} else {
			after += m.Quantity // Adjustment
		}
		runningStock[m.ProductID] = after

		// Translate type
		t := "Entrada"
		if m.Type == "OUT" {
			t = "Salida"
		} else if m.Type == "ADJUSTMENT" {
			t = "Ajuste"
		}

		data.Movements = append(data.Movements, InventoryMovementData{
			Date:        m.Date,
			ProductName: m.ProductName,
			Type:        t,
			Quantity:    m.Quantity,
			StockBefore: before,
			StockAfter:  after,
			User:        "Administrador", // Hardcoded user for now
		})
	}

	// Reverse movements to show newest first in the report
	for i, j := 0, len(data.Movements)-1; i < j; i, j = i+1, j-1 {
		data.Movements[i], data.Movements[j] = data.Movements[j], data.Movements[i]
	}

	return data, nil
}
