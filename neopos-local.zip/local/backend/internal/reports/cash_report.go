package reports

import (
	"bytes"
	"fmt"
	"math"

	"github.com/xuri/excelize/v2"
)

func (s *service) buildCashReportExcel(data *CashReportData) ([]byte, error) {
	file := excelize.NewFile()
	file.SetSheetName("Sheet1", "Resumen")
	file.NewSheet("Detalle Ventas")
	file.NewSheet("Productos Vendidos")
	file.NewSheet("Movimientos Caja")
	file.NewSheet("Estadísticas")

	// Create reusable styles
	styles := createExcelStyles(file)

	// Build each sheet
	s.buildResumenSheet(file, "Resumen", data, styles)
	s.buildDetalleVentasSheet(file, "Detalle Ventas", data, styles)
	s.buildProductosVendidosSheet(file, "Productos Vendidos", data, styles)
	s.buildMovimientosCajaSheet(file, "Movimientos Caja", data, styles)
	s.buildEstadisticasSheet(file, "Estadísticas", data, styles)

	// Set active sheet to Resumen
	file.SetActiveSheet(0)

	var buf bytes.Buffer
	if err := file.Write(&buf); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

func (s *service) writeHeaderInfo(file *excelize.File, sheet string, data *CashReportData, styles ExcelStyles) int {
	return 8 // Header Info is now written globally by writeCorporateHeader
}

func (s *service) buildResumenSheet(file *excelize.File, sheet string, data *CashReportData, styles ExcelStyles) {
	writeCorporateHeader(file, sheet, "REPORTE DE CAJA", styles)
	setColWidths(file, sheet, 35, 25)

	// Conceptos Header
	row := 8
	file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Concepto")
	file.SetCellValue(sheet, fmt.Sprintf("B%d", row), "Valor")
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("B%d", row), styles.Header)

	// Rows data
	concepts := []struct{ name string; val int64 }{
		{"Apertura de Caja", data.Summary.OpeningAmount},
		{"Ventas Brutas", data.Summary.GrossSales},
		{"Descuentos", data.Summary.Discounts},
		{"IVA Recaudado", data.Summary.TaxCollected},
		{"Propinas", data.Summary.Tips},
		{"Entradas Manuales", data.Summary.ManualDeposits},
		{"Salidas de Caja", data.Summary.ManualWithdraws},
		{"Devoluciones", data.Summary.Refunds},
		{"Ventas en Efectivo", data.Summary.CashSales},
		{"Otras Ventas (Tarjetas, etc)", data.Summary.OtherSales},
	}

	for i, c := range concepts {
		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), c.name)
		file.SetCellValue(sheet, fmt.Sprintf("B%d", row), c.val)
		if i%2 == 0 {
			file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("A%d", row), styles.DataLight)
			file.SetCellStyle(sheet, fmt.Sprintf("B%d", row), fmt.Sprintf("B%d", row), styles.CurrencyLight)
		} else {
			file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("A%d", row), styles.DataDark)
			file.SetCellStyle(sheet, fmt.Sprintf("B%d", row), fmt.Sprintf("B%d", row), styles.CurrencyDark)
		}
	}

	// Total Neto
	row++
	file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Total Neto")
	file.SetCellValue(sheet, fmt.Sprintf("B%d", row), data.Summary.NetTotal)
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("B%d", row), styles.TotalRow)

	// Cierre Esperado
	row++
	file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Cierre Esperado (Efectivo)")
	file.SetCellValue(sheet, fmt.Sprintf("B%d", row), data.Summary.ExpectedClose)
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("A%d", row), styles.DataLight)
	file.SetCellStyle(sheet, fmt.Sprintf("B%d", row), fmt.Sprintf("B%d", row), styles.CurrencyLight)

	// Cierre Declarado
	row++
	file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Cierre Declarado (Efectivo)")
	file.SetCellValue(sheet, fmt.Sprintf("B%d", row), data.Summary.ClosingAmount)
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("A%d", row), styles.DataDark)
	file.SetCellStyle(sheet, fmt.Sprintf("B%d", row), fmt.Sprintf("B%d", row), styles.CurrencyDark)

	// Diferencia
	row++
	file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Diferencia de Caja")
	file.SetCellValue(sheet, fmt.Sprintf("B%d", row), data.Summary.Difference)
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("A%d", row), styles.DataLight)
	
	diffAbs := math.Abs(float64(data.Summary.Difference))
	if data.Summary.Difference == 0 {
		file.SetCellStyle(sheet, fmt.Sprintf("B%d", row), fmt.Sprintf("B%d", row), styles.DiffGreen)
	} else if diffAbs <= 5000 {
		file.SetCellStyle(sheet, fmt.Sprintf("B%d", row), fmt.Sprintf("B%d", row), styles.DiffYellow)
	} else {
		file.SetCellStyle(sheet, fmt.Sprintf("B%d", row), fmt.Sprintf("B%d", row), styles.DiffRed)
	}

	// Observaciones
	if data.Summary.Notes != "" {
		row += 2
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Observaciones del Cierre")
		file.MergeCell(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("B%d", row))
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("B%d", row), styles.Subtitle)

		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), data.Summary.Notes)
		file.MergeCell(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("B%d", row))
		// We could use a word-wrapped style, but DataLight is okay.
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("B%d", row), styles.DataLight)
	}

	// Payment Methods Table
	row += 3
	file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Resumen por Método de Pago")
	file.MergeCell(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("C%d", row))
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("C%d", row), styles.Subtitle)

	row++
	file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Método")
	file.SetCellValue(sheet, fmt.Sprintf("B%d", row), "Cantidad de ventas")
	file.SetCellValue(sheet, fmt.Sprintf("C%d", row), "Total")
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("C%d", row), styles.Header)

	if len(data.PaymentMethods) == 0 {
		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Sin información para el período seleccionado")
		file.MergeCell(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("C%d", row))
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("C%d", row), styles.NoData)
	} else {
		var grandTotal int64
		for i, pm := range data.PaymentMethods {
			row++
			file.SetCellValue(sheet, fmt.Sprintf("A%d", row), pm.Method)
			file.SetCellValue(sheet, fmt.Sprintf("B%d", row), pm.Count)
			file.SetCellValue(sheet, fmt.Sprintf("C%d", row), pm.Total)
			
			dStyle, cStyle := styles.DataLight, styles.CurrencyLight
			if i%2 != 0 {
				dStyle, cStyle = styles.DataDark, styles.CurrencyDark
			}
			file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("B%d", row), dStyle)
			file.SetCellStyle(sheet, fmt.Sprintf("C%d", row), fmt.Sprintf("C%d", row), cStyle)
			grandTotal += pm.Total
		}
		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "TOTAL GENERAL")
		file.MergeCell(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("B%d", row))
		file.SetCellValue(sheet, fmt.Sprintf("C%d", row), grandTotal)
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("C%d", row), styles.TotalRow)
	}
}

func (s *service) buildDetalleVentasSheet(file *excelize.File, sheet string, data *CashReportData, styles ExcelStyles) {
	writeCorporateHeader(file, sheet, "DETALLE DE VENTAS", styles)

	headers := []string{"Factura", "Fecha", "Hora", "Cliente", "Método Pago", "Subtotal", "IVA", "Total", "Estado"}
	
	row := 8
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, row)
		file.SetCellValue(sheet, cell, h)
	}
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("I%d", row), styles.Header)
	
	setColWidths(file, sheet, 15, 12, 10, 25, 20, 15, 15, 15, 12)
	
	if len(data.Sales) == 0 {
		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Sin información para el período seleccionado")
		file.MergeCell(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("I%d", row))
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("I%d", row), styles.NoData)
		return
	}

	for i, sale := range data.Sales {
		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), sale.InvoiceNum)
		file.SetCellValue(sheet, fmt.Sprintf("B%d", row), sale.Date)
		file.SetCellValue(sheet, fmt.Sprintf("C%d", row), sale.Date) // Will be formatted as time
		file.SetCellValue(sheet, fmt.Sprintf("D%d", row), sale.CustomerName)
		file.SetCellValue(sheet, fmt.Sprintf("E%d", row), sale.PaymentMethod)
		file.SetCellValue(sheet, fmt.Sprintf("F%d", row), sale.Subtotal)
		file.SetCellValue(sheet, fmt.Sprintf("G%d", row), sale.Tax)
		file.SetCellValue(sheet, fmt.Sprintf("H%d", row), sale.Total)
		file.SetCellValue(sheet, fmt.Sprintf("I%d", row), sale.Status)

		dStyle, cStyle, dateStyle, timeStyle := styles.DataLight, styles.CurrencyLight, styles.DateStyleLight, styles.TimeStyleLight
		if i%2 != 0 {
			dStyle, cStyle, dateStyle, timeStyle = styles.DataDark, styles.CurrencyDark, styles.DateStyleDark, styles.TimeStyleDark
		}
		
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("A%d", row), dStyle)
		file.SetCellStyle(sheet, fmt.Sprintf("B%d", row), fmt.Sprintf("B%d", row), dateStyle)
		file.SetCellStyle(sheet, fmt.Sprintf("C%d", row), fmt.Sprintf("C%d", row), timeStyle)
		file.SetCellStyle(sheet, fmt.Sprintf("D%d", row), fmt.Sprintf("E%d", row), dStyle)
		file.SetCellStyle(sheet, fmt.Sprintf("F%d", row), fmt.Sprintf("H%d", row), cStyle)
		file.SetCellStyle(sheet, fmt.Sprintf("I%d", row), fmt.Sprintf("I%d", row), dStyle)
	}

	file.AutoFilter(sheet, "A8:I8", nil)
	file.SetPanes(sheet, &excelize.Panes{Freeze: true, Split: false, XSplit: 0, YSplit: 8, TopLeftCell: "A9", ActivePane: "bottomLeft"})
}

func (s *service) buildProductosVendidosSheet(file *excelize.File, sheet string, data *CashReportData, styles ExcelStyles) {
	writeCorporateHeader(file, sheet, "PRODUCTOS VENDIDOS", styles)

	headers := []string{"Producto", "Categoría", "Cantidad Vendida", "Precio Unitario", "Total Vendido"}
	row := 8
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, row)
		file.SetCellValue(sheet, cell, h)
	}
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("E%d", row), styles.Header)
	setColWidths(file, sheet, 35, 25, 20, 20, 20)

	if len(data.Products) == 0 {
		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Sin información para el período seleccionado")
		file.MergeCell(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("E%d", row))
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("E%d", row), styles.NoData)
		return
	}

	var totalQty int
	var totalVal int64
	var maxProdName string
	var maxProdQty int

	for i, p := range data.Products {
		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), p.ProductName)
		file.SetCellValue(sheet, fmt.Sprintf("B%d", row), p.CategoryName)
		file.SetCellValue(sheet, fmt.Sprintf("C%d", row), p.Quantity)
		file.SetCellValue(sheet, fmt.Sprintf("D%d", row), p.UnitPrice)
		file.SetCellValue(sheet, fmt.Sprintf("E%d", row), p.TotalSold)
		
		dStyle, cStyle := styles.DataLight, styles.CurrencyLight
		if i%2 != 0 {
			dStyle, cStyle = styles.DataDark, styles.CurrencyDark
		}
		
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("C%d", row), dStyle)
		file.SetCellStyle(sheet, fmt.Sprintf("D%d", row), fmt.Sprintf("E%d", row), cStyle)

		totalQty += p.Quantity
		totalVal += p.TotalSold
		if p.Quantity > maxProdQty {
			maxProdQty = p.Quantity
			maxProdName = p.ProductName
		}
	}

	file.AutoFilter(sheet, "A8:E8", nil)
	file.SetPanes(sheet, &excelize.Panes{Freeze: true, Split: false, XSplit: 0, YSplit: 8, TopLeftCell: "A9", ActivePane: "bottomLeft"})

	// Summary at the bottom
	row++
	file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Producto más vendido")
	file.SetCellValue(sheet, fmt.Sprintf("B%d", row), maxProdName)
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("B%d", row), styles.DataLight)
	
	row++
	file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Cantidad total de productos vendidos")
	file.SetCellValue(sheet, fmt.Sprintf("B%d", row), totalQty)
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("B%d", row), styles.DataDark)
	
	row++
	file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Valor total vendido")
	file.SetCellValue(sheet, fmt.Sprintf("B%d", row), totalVal)
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("A%d", row), styles.DataLight)
	file.SetCellStyle(sheet, fmt.Sprintf("B%d", row), fmt.Sprintf("B%d", row), styles.CurrencyLight)
}

func (s *service) buildMovimientosCajaSheet(file *excelize.File, sheet string, data *CashReportData, styles ExcelStyles) {
	writeCorporateHeader(file, sheet, "MOVIMIENTOS DE CAJA", styles)

	headers := []string{"Hora", "Tipo", "Concepto", "Usuario", "Valor"}
	row := 8
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, row)
		file.SetCellValue(sheet, cell, h)
	}
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("E%d", row), styles.Header)
	setColWidths(file, sheet, 15, 15, 30, 20, 15)

	if len(data.Movements) == 0 {
		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Sin información para el período seleccionado")
		file.MergeCell(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("E%d", row))
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("E%d", row), styles.NoData)
		return
	}

	var sumTotal int64
	for i, m := range data.Movements {
		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), m.Time)
		file.SetCellValue(sheet, fmt.Sprintf("B%d", row), m.Type)
		file.SetCellValue(sheet, fmt.Sprintf("C%d", row), m.Concept)
		file.SetCellValue(sheet, fmt.Sprintf("D%d", row), m.User)
		file.SetCellValue(sheet, fmt.Sprintf("E%d", row), m.Value)
		
		sumTotal = data.Summary.NetTotal + data.Summary.OpeningAmount

		dStyle, cStyle, timeStyle := styles.DataLight, styles.CurrencyLight, styles.TimeStyleLight
		if i%2 != 0 {
			dStyle, cStyle, timeStyle = styles.DataDark, styles.CurrencyDark, styles.TimeStyleDark
		}
		
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("A%d", row), timeStyle)
		file.SetCellStyle(sheet, fmt.Sprintf("B%d", row), fmt.Sprintf("D%d", row), dStyle)
		file.SetCellStyle(sheet, fmt.Sprintf("E%d", row), fmt.Sprintf("E%d", row), cStyle)
	}

	// Add Total General row
	row++
	file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "TOTAL GENERAL")
	file.MergeCell(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("D%d", row))
	file.SetCellValue(sheet, fmt.Sprintf("E%d", row), sumTotal)
	
	// Set the green bold style to the entire row (A to E)
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("E%d", row), styles.GeneralTotal)

	file.AutoFilter(sheet, "A8:E8", nil)
	file.SetPanes(sheet, &excelize.Panes{Freeze: true, Split: false, XSplit: 0, YSplit: 8, TopLeftCell: "A9", ActivePane: "bottomLeft"})
}

func (s *service) buildEstadisticasSheet(file *excelize.File, sheet string, data *CashReportData, styles ExcelStyles) {
	writeCorporateHeader(file, sheet, "ESTADÍSTICAS Y GRÁFICOS", styles)
	setColWidths(file, sheet, 35, 25)

	row := 8
	if len(data.Sales) == 0 {
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Sin información para el período seleccionado")
		file.MergeCell(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("B%d", row))
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("B%d", row), styles.NoData)
		return
	}

	// Calculate stats
	numInvoices := len(data.Sales)
	numClients := numInvoices // Rough approximation for customers served
	var avgTicket int64
	if numInvoices > 0 {
		avgTicket = data.Summary.NetTotal / int64(numInvoices)
	}

	// Peak hour calculation
	hourCounts := make(map[int]int)
	for _, sale := range data.Sales {
		hourCounts[sale.Date.Hour()]++
	}
	maxHour, maxCount := 0, 0
	for h, c := range hourCounts {
		if c > maxCount {
			maxHour, maxCount = h, c
		}
	}
	peakHourStr := fmt.Sprintf("%02d:00 - %02d:59", maxHour, maxHour)

	// Top payment method
	var topMethod string
	var maxMethodCount int
	for _, pm := range data.PaymentMethods {
		if pm.Count > maxMethodCount {
			maxMethodCount = pm.Count
			topMethod = pm.Method
		}
	}

	// Top product
	var topProduct string
	var maxProdQty int
	for _, p := range data.Products {
		if p.Quantity > maxProdQty {
			maxProdQty = p.Quantity
			topProduct = p.ProductName
		}
	}

	// Top user
	userSales := make(map[string]int)
	for _, sale := range data.Sales {
		userSales[sale.CashierName]++
	}
	var topUser string
	var maxUserSales int
	for u, c := range userSales {
		if c > maxUserSales {
			maxUserSales = c
			topUser = u
		}
	}

	stats := []struct{ name string; val any; isCurrency bool }{
		{"Número de facturas", numInvoices, false},
		{"Número de clientes atendidos", numClients, false},
		{"Ticket promedio", avgTicket, true},
		{"Venta promedio por factura", avgTicket, true}, // essentially same as ticket average in this context
		{"Hora con más ventas", peakHourStr, false},
		{"Método de pago más utilizado", topMethod, false},
		{"Producto más vendido", topProduct, false},
		{"Usuario con mayor cantidad de ventas", topUser, false},
		{"Valor promedio por cliente", avgTicket, true},
	}

	row++
	file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Estadística")
	file.SetCellValue(sheet, fmt.Sprintf("B%d", row), "Valor")
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("B%d", row), styles.Header)

	for i, st := range stats {
		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), st.name)
		file.SetCellValue(sheet, fmt.Sprintf("B%d", row), st.val)

		dStyle, cStyle := styles.DataLight, styles.CurrencyLight
		if i%2 != 0 {
			dStyle, cStyle = styles.DataDark, styles.CurrencyDark
		}
		
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("A%d", row), dStyle)
		if st.isCurrency {
			file.SetCellStyle(sheet, fmt.Sprintf("B%d", row), fmt.Sprintf("B%d", row), cStyle)
		} else {
			file.SetCellStyle(sheet, fmt.Sprintf("B%d", row), fmt.Sprintf("B%d", row), dStyle)
		}
	}
}
