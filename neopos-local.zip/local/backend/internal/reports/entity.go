package reports

import "restaurant-pos-api/pkg/model"

type ReportJob struct {
	model.Base
	model.BranchScoped
	Type   string `json:"type" gorm:"size:80;not null"`
	Status string `json:"status" gorm:"size:40;not null;default:GENERATED"`
}
