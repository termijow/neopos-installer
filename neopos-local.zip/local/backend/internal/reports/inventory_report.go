package reports

import (
	"bytes"
	"fmt"

	"github.com/xuri/excelize/v2"
)

func (s *service) buildInventoryReportExcel(data *InventoryReportData) ([]byte, error) {
	file := excelize.NewFile()
	file.SetSheetName("Sheet1", "Inventario Actual")
	file.NewSheet("Movimientos")
	file.NewSheet("Productos con Bajo Stock")
	file.NewSheet("Productos Agotados")

	styles := createExcelStyles(file)

	s.buildInventarioActualSheet(file, "Inventario Actual", data, styles)
	s.buildInventarioMovimientosSheet(file, "Movimientos", data, styles)
	s.buildBajoStockSheet(file, "Productos con Bajo Stock", data, styles)
	s.buildAgotadosSheet(file, "Productos Agotados", data, styles)

	file.SetActiveSheet(0)

	var buf bytes.Buffer
	if err := file.Write(&buf); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

func (s *service) buildInventarioActualSheet(file *excelize.File, sheet string, data *InventoryReportData, styles ExcelStyles) {
	writeCorporateHeader(file, sheet, "INVENTARIO ACTUAL", styles)

	headers := []string{"Código", "Producto", "Categoría", "Unidad", "Stock Actual", "Stock Mínimo", "Costo Unitario", "Valor Inventario"}
	row := 8
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, row)
		file.SetCellValue(sheet, cell, h)
	}
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("H%d", row), styles.Header)
	setColWidths(file, sheet, 15, 35, 20, 15, 15, 15, 18, 20)

	if len(data.Products) == 0 {
		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "No hay productos registrados")
		file.MergeCell(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("H%d", row))
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("H%d", row), styles.NoData)
		return
	}

	var totalItems int
	var totalValue int64

	for i, p := range data.Products {
		row++
		valInv := int64(p.Stock) * p.Cost
		if p.Stock > 0 {
			totalItems++
			totalValue += valInv
		} else {
			valInv = 0 // negative stock doesn't add to inventory value conceptually, but we can leave it or zero it.
		}

		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), p.Code)
		file.SetCellValue(sheet, fmt.Sprintf("B%d", row), p.Name)
		file.SetCellValue(sheet, fmt.Sprintf("C%d", row), p.Category)
		file.SetCellValue(sheet, fmt.Sprintf("D%d", row), "Unidad")
		file.SetCellValue(sheet, fmt.Sprintf("E%d", row), p.Stock)
		file.SetCellValue(sheet, fmt.Sprintf("F%d", row), p.MinStock)
		file.SetCellValue(sheet, fmt.Sprintf("G%d", row), p.Cost)
		file.SetCellValue(sheet, fmt.Sprintf("H%d", row), valInv)

		dStyle, cStyle := styles.DataLight, styles.CurrencyLight
		if i%2 != 0 {
			dStyle, cStyle = styles.DataDark, styles.CurrencyDark
		}

		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("F%d", row), dStyle)
		file.SetCellStyle(sheet, fmt.Sprintf("G%d", row), fmt.Sprintf("H%d", row), cStyle)
	}

	file.AutoFilter(sheet, "A8:H8", nil)
	file.SetPanes(sheet, &excelize.Panes{Freeze: true, Split: false, XSplit: 0, YSplit: 8, TopLeftCell: "A9", ActivePane: "bottomLeft"})

	// Totals
	row += 2
	file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Totales")
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("A%d", row), styles.Subtitle)

	row++
	file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Productos en stock")
	file.SetCellValue(sheet, fmt.Sprintf("B%d", row), totalItems)
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("A%d", row), styles.DataLight)
	file.SetCellStyle(sheet, fmt.Sprintf("B%d", row), fmt.Sprintf("B%d", row), styles.DataLight)

	row++
	file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "Valor Inventario")
	file.SetCellValue(sheet, fmt.Sprintf("B%d", row), totalValue)
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("A%d", row), styles.DataDark)
	file.SetCellStyle(sheet, fmt.Sprintf("B%d", row), fmt.Sprintf("B%d", row), styles.CurrencyDark)
}

func (s *service) buildInventarioMovimientosSheet(file *excelize.File, sheet string, data *InventoryReportData, styles ExcelStyles) {
	writeCorporateHeader(file, sheet, "MOVIMIENTOS DE INVENTARIO", styles)

	headers := []string{"Fecha", "Producto", "Tipo", "Cantidad", "Stock Antes", "Stock Después", "Usuario"}
	row := 8
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, row)
		file.SetCellValue(sheet, cell, h)
	}
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("G%d", row), styles.Header)
	setColWidths(file, sheet, 20, 35, 15, 15, 15, 15, 20)

	if len(data.Movements) == 0 {
		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "No hay movimientos registrados")
		file.MergeCell(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("G%d", row))
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("G%d", row), styles.NoData)
		return
	}

	for i, m := range data.Movements {
		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), m.Date)
		file.SetCellValue(sheet, fmt.Sprintf("B%d", row), m.ProductName)
		file.SetCellValue(sheet, fmt.Sprintf("C%d", row), m.Type)
		
		sign := ""
		if m.Type == "Entrada" {
			sign = "+"
		} else if m.Type == "Salida" {
			sign = "-"
		}
		file.SetCellValue(sheet, fmt.Sprintf("D%d", row), fmt.Sprintf("%s%d", sign, m.Quantity))
		file.SetCellValue(sheet, fmt.Sprintf("E%d", row), m.StockBefore)
		file.SetCellValue(sheet, fmt.Sprintf("F%d", row), m.StockAfter)
		file.SetCellValue(sheet, fmt.Sprintf("G%d", row), m.User)

		dStyle, dateStyle := styles.DataLight, styles.DateStyleLight
		if i%2 != 0 {
			dStyle, dateStyle = styles.DataDark, styles.DateStyleDark
		}

		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("A%d", row), dateStyle)
		file.SetCellStyle(sheet, fmt.Sprintf("B%d", row), fmt.Sprintf("G%d", row), dStyle)
	}

	file.AutoFilter(sheet, "A8:G8", nil)
	file.SetPanes(sheet, &excelize.Panes{Freeze: true, Split: false, XSplit: 0, YSplit: 8, TopLeftCell: "A9", ActivePane: "bottomLeft"})
}

func (s *service) buildBajoStockSheet(file *excelize.File, sheet string, data *InventoryReportData, styles ExcelStyles) {
	writeCorporateHeader(file, sheet, "PRODUCTOS CON BAJO STOCK", styles)

	headers := []string{"Producto", "Stock", "Mínimo", "Estado"}
	row := 8
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, row)
		file.SetCellValue(sheet, cell, h)
	}
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("D%d", row), styles.Header)
	setColWidths(file, sheet, 40, 15, 15, 20)

	var lowStockCount int
	for _, p := range data.Products {
		if p.Stock > p.MinStock {
			continue
		}
		
		// Determine status
		status := "AL LÍMITE"
		if p.Stock <= 5 {
			status = "CRÍTICO"
		} else if p.Stock <= 8 {
			status = "BAJO"
		}

		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), p.Name)
		file.SetCellValue(sheet, fmt.Sprintf("B%d", row), p.Stock)
		file.SetCellValue(sheet, fmt.Sprintf("C%d", row), p.MinStock)
		file.SetCellValue(sheet, fmt.Sprintf("D%d", row), status)

		dStyle := styles.DataLight
		if lowStockCount%2 != 0 {
			dStyle = styles.DataDark
		}
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("C%d", row), dStyle)

		// State colors
		statusStyle := styles.DiffGreen
		if status == "CRÍTICO" {
			statusStyle = styles.DiffRed
		} else if status == "BAJO" || status == "AL LÍMITE" {
			statusStyle = styles.DiffYellow
		}
		file.SetCellStyle(sheet, fmt.Sprintf("D%d", row), fmt.Sprintf("D%d", row), statusStyle)

		lowStockCount++
	}

	if lowStockCount == 0 {
		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "No hay productos con bajo stock")
		file.MergeCell(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("D%d", row))
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("D%d", row), styles.NoData)
	}

	file.AutoFilter(sheet, "A8:D8", nil)
	file.SetPanes(sheet, &excelize.Panes{Freeze: true, Split: false, XSplit: 0, YSplit: 8, TopLeftCell: "A9", ActivePane: "bottomLeft"})
}

func (s *service) buildAgotadosSheet(file *excelize.File, sheet string, data *InventoryReportData, styles ExcelStyles) {
	writeCorporateHeader(file, sheet, "PRODUCTOS AGOTADOS", styles)

	headers := []string{"Producto", "Categoría", "Última Venta"}
	row := 8
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, row)
		file.SetCellValue(sheet, cell, h)
	}
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("C%d", row), styles.Header)
	setColWidths(file, sheet, 40, 25, 20)

	var emptyCount int
	for _, p := range data.Products {
		if p.Stock > 0 {
			continue
		}
		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), p.Name)
		file.SetCellValue(sheet, fmt.Sprintf("B%d", row), p.Category)
		file.SetCellValue(sheet, fmt.Sprintf("C%d", row), p.LastSale)

		dStyle := styles.DataLight
		if emptyCount%2 != 0 {
			dStyle = styles.DataDark
		}
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("C%d", row), dStyle)

		emptyCount++
	}

	if emptyCount == 0 {
		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "No hay productos agotados")
		file.MergeCell(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("C%d", row))
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("C%d", row), styles.NoData)
	}

	file.AutoFilter(sheet, "A8:C8", nil)
	file.SetPanes(sheet, &excelize.Panes{Freeze: true, Split: false, XSplit: 0, YSplit: 8, TopLeftCell: "A9", ActivePane: "bottomLeft"})
}
