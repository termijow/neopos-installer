package reports

import (
	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB) {
	controller := NewController(NewService(NewRepository(db)))
	router.Get("/reports/daily", controller.Daily)
	router.Get("/reports/monthly", controller.Monthly)
	router.Get("/reports/ledger", controller.Ledger)
	router.Get("/reports/tax", controller.Tax)
	router.Get("/reports/inventory", controller.Inventory)
	router.Get("/reports/cash", controller.Cash)
	router.Get("/reports/dashboard", controller.Dashboard)
}
