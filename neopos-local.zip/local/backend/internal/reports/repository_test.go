package reports

import (
	"testing"

	"github.com/stretchr/testify/require"
)

func TestSummarizePaymentMethodsNormalizesLegacyValues(t *testing.T) {
	result := summarizePaymentMethods([]paymentMethodRow{
		{Method: "CASH", Count: 2, Total: 100000},
		{Method: "efectivo", Count: 1, Total: 50000},
		{Method: "CREDIT_CARD", Count: 1, Total: 125000},
		{Method: "TRANSFERENCIA", Count: 2, Total: 75000},
	})

	require.Equal(t, []PaymentMethodSummary{
		{Method: "Efectivo", Count: 3, Total: 150000},
		{Method: "Tarjeta de crédito", Count: 1, Total: 125000},
		{Method: "Transferencia", Count: 2, Total: 75000},
	}, result)
}

func TestCashPaymentMethodNameHandlesEmptyAndUnknownValues(t *testing.T) {
	require.Equal(t, "Sin especificar", cashPaymentMethodName(" "))
	require.Equal(t, "QR", cashPaymentMethodName("qr"))
	require.Equal(t, "PSE", cashPaymentMethodName("PSE"))
}
