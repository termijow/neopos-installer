package reports

import (
	"bytes"
	"fmt"
	"strconv"
	"time"

	"github.com/xuri/excelize/v2"
)

type Service interface {
	Daily(ReportQuery) ([]byte, error)
	DailyData(ReportQuery) (any, error)
	Monthly(ReportQuery) ([]byte, error)
	MonthlyData(ReportQuery) (any, error)
	Ledger(ReportQuery) ([]byte, error)
	LedgerData(ReportQuery) (any, error)
	Tax(ReportQuery) ([]byte, error)
	TaxData(ReportQuery) (any, error)
	Inventory(ReportQuery) ([]byte, error)
	InventoryData(ReportQuery) (any, error)
	Cash(ReportQuery) ([]byte, error)
	CashData(ReportQuery) (any, error)
	Dashboard(branchID string) (map[string]any, error)
}
type service struct{ repo Repository }
func NewService(repo Repository) Service { return &service{repo: repo} }

const (
	dateFormat      = "02/01/2006"
	dateTimeFormat  = "02/01/2006 15:04"
	refTableStartCol = 10 // Column J (1-indexed = 10)
)

var dayNames = []string{"Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"}

func (s *service) Daily(q ReportQuery) ([]byte, error) {
	branchID := q.BranchID
	from, _ := time.Parse("2006-01-02", q.From)
	to, _ := time.Parse("2006-01-02", q.To)
	to = to.Add(23*time.Hour + 59*time.Minute + 59*time.Second)

	sales, err := s.repo.GetDailySales(branchID, from, to)
	if err != nil {
		return nil, err
	}
	products, _ := s.repo.GetProductsWithPrices(branchID)
	return s.generateExcel("Ventas Diarias", sales, products, "daily", from, to)
}

func (s *service) DailyData(q ReportQuery) (any, error) {
	branchID := q.BranchID
	from, _ := time.Parse("2006-01-02", q.From)
	to, _ := time.Parse("2006-01-02", q.To)
	to = to.Add(23*time.Hour + 59*time.Minute + 59*time.Second)

	sales, err := s.repo.GetDailySales(branchID, from, to)
	if err != nil {
		return nil, err
	}
	products, _ := s.repo.GetProductsWithPrices(branchID)
	return SalesReportData{Sales: sales, Products: products}, nil
}

func (s *service) Monthly(q ReportQuery) ([]byte, error) {
	branchID := q.BranchID
	year, _ := strconv.Atoi(q.From[:4])
	month, _ := strconv.Atoi(q.From[5:7])

	sales, err := s.repo.GetMonthlySales(branchID, year, month)
	if err != nil {
		return nil, err
	}
	products, _ := s.repo.GetProductsWithPrices(branchID)
	from := time.Date(year, time.Month(month), 1, 0, 0, 0, 0, time.UTC)
	to := from.AddDate(0, 1, 0).Add(-time.Second)
	return s.generateExcel("Ventas Mensuales", sales, products, "monthly", from, to)
}

func (s *service) MonthlyData(q ReportQuery) (any, error) {
	branchID := q.BranchID
	year, _ := strconv.Atoi(q.From[:4])
	month, _ := strconv.Atoi(q.From[5:7])

	sales, err := s.repo.GetMonthlySales(branchID, year, month)
	if err != nil {
		return nil, err
	}
	products, _ := s.repo.GetProductsWithPrices(branchID)
	return SalesReportData{Sales: sales, Products: products}, nil
}

func (s *service) Ledger(q ReportQuery) ([]byte, error) {
	branchID := q.BranchID
	from, err := time.Parse("2006-01-02", q.From)
	if err != nil {
		now := time.Now()
		from = time.Date(now.Year(), now.Month(), 1, 0, 0, 0, 0, time.Local)
	}
	to, err := time.Parse("2006-01-02", q.To)
	if err != nil {
		to = from.AddDate(0, 1, 0).Add(-time.Second)
	} else {
		to = to.Add(23*time.Hour + 59*time.Minute + 59*time.Second)
	}

	sales, err := s.repo.GetSalesBook(branchID, from, to)
	if err != nil {
		return nil, err
	}
	products, _ := s.repo.GetProductsWithPrices(branchID)
	return s.generateExcel("Libro de Ventas", sales, products, "ledger", from, to)
}

func (s *service) LedgerData(q ReportQuery) (any, error) {
	branchID := q.BranchID
	from, err := time.Parse("2006-01-02", q.From)
	if err != nil {
		now := time.Now()
		from = time.Date(now.Year(), now.Month(), 1, 0, 0, 0, 0, time.Local)
	}
	to, err := time.Parse("2006-01-02", q.To)
	if err != nil {
		to = from.AddDate(0, 1, 0).Add(-time.Second)
	} else {
		to = to.Add(23*time.Hour + 59*time.Minute + 59*time.Second)
	}

	sales, err := s.repo.GetSalesBook(branchID, from, to)
	if err != nil {
		return nil, err
	}
	products, _ := s.repo.GetProductsWithPrices(branchID)
	return SalesReportData{Sales: sales, Products: products}, nil
}

func (s *service) Inventory(q ReportQuery) ([]byte, error) {
	data, err := s.repo.GetInventoryReportData(q.BranchID, "Administrador")
	if err != nil {
		return nil, err
	}
	return s.buildInventoryReportExcel(data)
}

func (s *service) InventoryData(q ReportQuery) (any, error) {
	return s.repo.GetInventoryReportData(q.BranchID, "Administrador")
}

func (s *service) Tax(q ReportQuery) ([]byte, error) {
	branchID := q.BranchID
	from, _ := time.Parse("2006-01-02", q.From)
	to, _ := time.Parse("2006-01-02", q.To)
	to = to.Add(23*time.Hour + 59*time.Minute + 59*time.Second)

	sales, err := s.repo.GetDailySales(branchID, from, to)
	if err != nil {
		return nil, err
	}
	// For IVA report, we just show the tax breakdown
	return s.generateExcel("IVA", sales, []ProductPrice{}, "daily", from, to)
}

func (s *service) TaxData(q ReportQuery) (any, error) {
	branchID := q.BranchID
	from, _ := time.Parse("2006-01-02", q.From)
	to, _ := time.Parse("2006-01-02", q.To)
	to = to.Add(23*time.Hour + 59*time.Minute + 59*time.Second)

	sales, err := s.repo.GetDailySales(branchID, from, to)
	if err != nil {
		return nil, err
	}
	return SalesReportData{Sales: sales, Products: []ProductPrice{}}, nil
}

func (s *service) generateExcel(sheetName string, sales []SaleDetail, products []ProductPrice, reportType string, from, to time.Time) ([]byte, error) {
	file := excelize.NewFile()
	sheet := sheetName
	file.SetSheetName("Sheet1", sheet)

	// Styles
	headerStyle, _ := file.NewStyle(&excelize.Style{
		Font:      &excelize.Font{Bold: true, Color: "FFFFFF"},
		Fill:      excelize.Fill{Type: "pattern", Color: []string{"#2F5496"}, Pattern: 1},
		Border:    []excelize.Border{{Type: "left", Color: "000000", Style: 1}, {Type: "right", Color: "000000", Style: 1}, {Type: "top", Color: "000000", Style: 1}, {Type: "bottom", Color: "000000", Style: 1}},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center"},
	})
	dayHeaderStyle, _ := file.NewStyle(&excelize.Style{
		Font:      &excelize.Font{Bold: true, Size: 12, Color: "FFFFFF"},
		Fill:      excelize.Fill{Type: "pattern", Color: []string{"#4472C4"}, Pattern: 1},
		Border:    []excelize.Border{{Type: "left", Color: "000000", Style: 1}, {Type: "right", Color: "000000", Style: 1}, {Type: "top", Color: "000000", Style: 1}, {Type: "bottom", Color: "000000", Style: 1}},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center"},
	})
	dataStyle, _ := file.NewStyle(&excelize.Style{
		Border: []excelize.Border{{Type: "left", Color: "CCCCCC", Style: 1}, {Type: "right", Color: "CCCCCC", Style: 1}, {Type: "top", Color: "CCCCCC", Style: 1}, {Type: "bottom", Color: "CCCCCC", Style: 1}},
		Alignment: &excelize.Alignment{Vertical: "center"},
	})
	numberStyle, _ := file.NewStyle(&excelize.Style{
		Border: []excelize.Border{{Type: "left", Color: "CCCCCC", Style: 1}, {Type: "right", Color: "CCCCCC", Style: 1}, {Type: "top", Color: "CCCCCC", Style: 1}, {Type: "bottom", Color: "CCCCCC", Style: 1}},
		Alignment: &excelize.Alignment{Horizontal: "right", Vertical: "center"},
		CustomNumFmt: strPtr("#,##0"),
	})
	totalStyle, _ := file.NewStyle(&excelize.Style{
		Font:      &excelize.Font{Bold: true},
		Fill:      excelize.Fill{Type: "pattern", Color: []string{"#D9E2F3"}, Pattern: 1},
		Border:    []excelize.Border{{Type: "left", Color: "000000", Style: 1}, {Type: "right", Color: "000000", Style: 1}, {Type: "top", Color: "000000", Style: 1}, {Type: "bottom", Color: "000000", Style: 1}},
		Alignment: &excelize.Alignment{Horizontal: "right", Vertical: "center"},
		CustomNumFmt: strPtr("#,##0"),
	})
	grandTotalStyle, _ := file.NewStyle(&excelize.Style{
		Font:      &excelize.Font{Bold: true, Size: 12, Color: "FFFFFF"},
		Fill:      excelize.Fill{Type: "pattern", Color: []string{"#2F5496"}, Pattern: 1},
		Border:    []excelize.Border{{Type: "left", Color: "000000", Style: 1}, {Type: "right", Color: "000000", Style: 1}, {Type: "top", Color: "000000", Style: 1}, {Type: "bottom", Color: "000000", Style: 1}},
		Alignment: &excelize.Alignment{Horizontal: "right", Vertical: "center"},
		CustomNumFmt: strPtr("#,##0"),
	})
	refHeaderStyle, _ := file.NewStyle(&excelize.Style{
		Font:      &excelize.Font{Bold: true, Color: "FFFFFF"},
		Fill:      excelize.Fill{Type: "pattern", Color: []string{"#70AD47"}, Pattern: 1},
		Border:    []excelize.Border{{Type: "left", Color: "000000", Style: 1}, {Type: "right", Color: "000000", Style: 1}, {Type: "top", Color: "000000", Style: 1}, {Type: "bottom", Color: "000000", Style: 1}},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center"},
	})
	refDataStyle, _ := file.NewStyle(&excelize.Style{
		Border: []excelize.Border{{Type: "left", Color: "CCCCCC", Style: 1}, {Type: "right", Color: "CCCCCC", Style: 1}, {Type: "top", Color: "CCCCCC", Style: 1}, {Type: "bottom", Color: "CCCCCC", Style: 1}},
		Alignment: &excelize.Alignment{Horizontal: "right", Vertical: "center"},
		CustomNumFmt: strPtr("#,##0"),
	})

	// Column widths
	file.SetColWidth(sheet, "A", "A", 14)  // Fecha
	file.SetColWidth(sheet, "B", "B", 14)  // N° Factura
	file.SetColWidth(sheet, "C", "C", 22)  // Cliente
	file.SetColWidth(sheet, "D", "D", 28)  // Producto
	file.SetColWidth(sheet, "E", "E", 10)  // Cantidad
	file.SetColWidth(sheet, "F", "F", 16)  // Valor antes IVA
	file.SetColWidth(sheet, "G", "G", 12)  // IVA
	file.SetColWidth(sheet, "H", "H", 16)  // Total
	file.SetColWidth(sheet, "J", "J", 28)  // Referencia Producto
	file.SetColWidth(sheet, "K", "K", 14)  // Referencia Precio

	// Write reference table header (right side)
	refHeaders := []string{"Producto Referencia", "Precio Unitario"}
	for i, h := range refHeaders {
		cell, _ := excelize.CoordinatesToCellName(refTableStartCol+i, 1)
		file.SetCellValue(sheet, cell, h)
		file.SetCellStyle(sheet, cell, cell, refHeaderStyle)
	}

	// Write reference data
	for i, p := range products {
		row := i + 2
		file.SetCellValue(sheet, fmt.Sprintf("%s%d", string(rune('A'+refTableStartCol-1)), row), p.Name)
		file.SetCellValue(sheet, fmt.Sprintf("%s%d", string(rune('A'+refTableStartCol)), row), p.Price)
		file.SetCellStyle(sheet, fmt.Sprintf("%s%d", string(rune('A'+refTableStartCol-1)), row), fmt.Sprintf("%s%d", string(rune('A'+refTableStartCol)), row), refDataStyle)
	}

	// Main table headers
	mainHeaders := []string{"Fecha", "N° Factura", "Cliente", "Producto", "Cantidad", "Valor antes IVA", "IVA (19%)", "Total"}
	for i, h := range mainHeaders {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		file.SetCellValue(sheet, cell, h)
		file.SetCellStyle(sheet, cell, cell, headerStyle)
	}

	// Group sales by day (for daily) or by month (for monthly) or just list all (ledger)
	row := 2
	var grandTotal int64

	switch reportType {
	case "daily":
		row = s.writeDailyReport(file, sheet, sales, products, row, &grandTotal, dataStyle, numberStyle, totalStyle, dayHeaderStyle)
	case "monthly":
		row = s.writeMonthlyReport(file, sheet, sales, products, row, &grandTotal, dataStyle, numberStyle, totalStyle, dayHeaderStyle)
	case "ledger":
		row = s.writeLedgerReport(file, sheet, sales, row, &grandTotal, dataStyle, numberStyle, totalStyle, dayHeaderStyle)
	}

	// Grand total row
	grandTotalRow := row
	file.SetCellValue(sheet, fmt.Sprintf("A%d", grandTotalRow), "TOTAL GENERAL")
	file.MergeCell(sheet, fmt.Sprintf("A%d", grandTotalRow), fmt.Sprintf("E%d", grandTotalRow))
	file.SetCellValue(sheet, fmt.Sprintf("H%d", grandTotalRow), grandTotal)
	file.SetCellStyle(sheet, fmt.Sprintf("A%d", grandTotalRow), fmt.Sprintf("H%d", grandTotalRow), grandTotalStyle)

	// Auto filter
	file.AutoFilter(sheet, "A1:H1", []excelize.AutoFilterOptions{{Column: "A", Expression: "x != \"\""}})

	var buf bytes.Buffer
	if err := file.Write(&buf); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

func (s *service) writeDailyReport(file *excelize.File, sheet string, sales []SaleDetail, products []ProductPrice, startRow int, grandTotal *int64, dataStyle, numberStyle, totalStyle, dayHeaderStyle int) int {
	row := startRow
	productTotals := make(map[string]struct{ quantity int; subtotal int64 })

	var currentDay string
	daySales := []SaleDetail{}

	flushDay := func(dayStr string, sales []SaleDetail, startRow int) int {
		if len(sales) == 0 {
			return startRow
		}
		// Day header
		file.SetCellValue(sheet, fmt.Sprintf("A%d", startRow), dayStr)
		file.MergeCell(sheet, fmt.Sprintf("A%d", startRow), fmt.Sprintf("H%d", startRow))
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", startRow), fmt.Sprintf("H%d", startRow), dayHeaderStyle)
		r := startRow + 1

		// Write sales for this day
		dayProductTotals := make(map[string]struct{ quantity int; subtotal int64 })
		for _, sale := range sales {
			file.SetCellValue(sheet, fmt.Sprintf("A%d", r), sale.Date.Format(dateFormat))
			file.SetCellValue(sheet, fmt.Sprintf("B%d", r), sale.InvoiceNum)
			file.SetCellValue(sheet, fmt.Sprintf("C%d", r), sale.ClientName)
			file.SetCellValue(sheet, fmt.Sprintf("D%d", r), sale.ProductName)
			file.SetCellValue(sheet, fmt.Sprintf("E%d", r), sale.Quantity)
			file.SetCellValue(sheet, fmt.Sprintf("F%d", r), sale.Subtotal)
			file.SetCellValue(sheet, fmt.Sprintf("G%d", r), sale.Tax)
			file.SetCellValue(sheet, fmt.Sprintf("H%d", r), sale.Total)

			file.SetCellStyle(sheet, fmt.Sprintf("A%d", r), fmt.Sprintf("E%d", r), dataStyle)
			file.SetCellStyle(sheet, fmt.Sprintf("F%d", r), fmt.Sprintf("H%d", r), numberStyle)

			*grandTotal += sale.Total
			dayProductTotals[sale.ProductName] = struct{ quantity int; subtotal int64 }{
				quantity: dayProductTotals[sale.ProductName].quantity + sale.Quantity,
				subtotal: dayProductTotals[sale.ProductName].subtotal + sale.Total,
			}
			productTotals[sale.ProductName] = struct{ quantity int; subtotal int64 }{
				quantity: productTotals[sale.ProductName].quantity + sale.Quantity,
				subtotal: productTotals[sale.ProductName].subtotal + sale.Total,
			}
			r++
		}

		// Day subtotals by product
		if len(dayProductTotals) > 0 {
			file.SetCellValue(sheet, fmt.Sprintf("A%d", r), "Subtotales del día")
			file.MergeCell(sheet, fmt.Sprintf("A%d", r), fmt.Sprintf("D%d", r))
			file.SetCellStyle(sheet, fmt.Sprintf("A%d", r), fmt.Sprintf("H%d", r), totalStyle)
			r++
for prodName, tot := range dayProductTotals {
				file.SetCellValue(sheet, fmt.Sprintf("D%d", r), prodName)
				file.SetCellValue(sheet, fmt.Sprintf("E%d", r), tot.quantity)
				file.SetCellValue(sheet, fmt.Sprintf("H%d", r), tot.subtotal)
				file.SetCellStyle(sheet, fmt.Sprintf("A%d", r), fmt.Sprintf("H%d", r), totalStyle)
				r++
			}
		}
		return r
	}

	for _, sale := range sales {
		dayKey := sale.Date.Format("2006-01-02")
		if currentDay != dayKey {
			if currentDay != "" {
				dayLabel := fmt.Sprintf("%s %s", dayNames[parseDayOfWeek(currentDay)], currentDay)
				row = flushDay(dayLabel, daySales, row)
			}
			currentDay = dayKey
			daySales = []SaleDetail{}
		}
		daySales = append(daySales, sale)
	}
	// Flush last day
	if currentDay != "" {
		dayLabel := fmt.Sprintf("%s %s", dayNames[parseDayOfWeek(currentDay)], currentDay)
		row = flushDay(dayLabel, daySales, row)
	}

	// Product totals at the end (for daily report)
	if len(productTotals) > 0 {
		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "TOTALES POR PRODUCTO")
		file.MergeCell(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("D%d", row))
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("H%d", row), totalStyle)
		row++
		for prodName, tot := range productTotals {
			file.SetCellValue(sheet, fmt.Sprintf("D%d", row), prodName)
			file.SetCellValue(sheet, fmt.Sprintf("E%d", row), tot.quantity)
			file.SetCellValue(sheet, fmt.Sprintf("H%d", row), tot.subtotal)
			file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("H%d", row), totalStyle)
			row++
		}
	}

	return row
}

func (s *service) writeMonthlyReport(file *excelize.File, sheet string, sales []SaleDetail, products []ProductPrice, startRow int, grandTotal *int64, dataStyle, numberStyle, totalStyle, dayHeaderStyle int) int {
	row := startRow
	productTotals := make(map[string]struct{ quantity int; subtotal int64 })

	// Group by day within month
	var currentDay string
	daySales := []SaleDetail{}

	flushDay := func(dayStr string, sales []SaleDetail, startRow int) int {
		if len(sales) == 0 {
			return startRow
		}
		file.SetCellValue(sheet, fmt.Sprintf("A%d", startRow), dayStr)
		file.MergeCell(sheet, fmt.Sprintf("A%d", startRow), fmt.Sprintf("H%d", startRow))
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", startRow), fmt.Sprintf("H%d", startRow), dayHeaderStyle)
		r := startRow + 1

		for _, sale := range sales {
			file.SetCellValue(sheet, fmt.Sprintf("A%d", r), sale.Date.Format(dateFormat))
			file.SetCellValue(sheet, fmt.Sprintf("B%d", r), sale.InvoiceNum)
			file.SetCellValue(sheet, fmt.Sprintf("C%d", r), sale.ClientName)
			file.SetCellValue(sheet, fmt.Sprintf("D%d", r), sale.ProductName)
			file.SetCellValue(sheet, fmt.Sprintf("E%d", r), sale.Quantity)
			file.SetCellValue(sheet, fmt.Sprintf("F%d", r), sale.Subtotal)
			file.SetCellValue(sheet, fmt.Sprintf("G%d", r), sale.Tax)
			file.SetCellValue(sheet, fmt.Sprintf("H%d", r), sale.Total)

			file.SetCellStyle(sheet, fmt.Sprintf("A%d", r), fmt.Sprintf("E%d", r), dataStyle)
			file.SetCellStyle(sheet, fmt.Sprintf("F%d", r), fmt.Sprintf("H%d", r), numberStyle)

			*grandTotal += sale.Total
			productTotals[sale.ProductName] = struct{ quantity int; subtotal int64 }{
				quantity: productTotals[sale.ProductName].quantity + sale.Quantity,
				subtotal: productTotals[sale.ProductName].subtotal + sale.Total,
			}
			r++
		}
		return r
	}

	for _, sale := range sales {
		dayKey := sale.Date.Format("2006-01-02")
		if currentDay != dayKey {
			if currentDay != "" {
				dayLabel := fmt.Sprintf("%s %s", dayNames[parseDayOfWeek(currentDay)], currentDay)
				row = flushDay(dayLabel, daySales, row)
			}
			currentDay = dayKey
			daySales = []SaleDetail{}
		}
		daySales = append(daySales, sale)
	}
	if currentDay != "" {
		dayLabel := fmt.Sprintf("%s %s", dayNames[parseDayOfWeek(currentDay)], currentDay)
		row = flushDay(dayLabel, daySales, row)
	}

	// Month totals by product
	if len(productTotals) > 0 {
		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "TOTALES DEL MES POR PRODUCTO")
		file.MergeCell(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("D%d", row))
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("H%d", row), totalStyle)
		row++
		for prodName, tot := range productTotals {
			file.SetCellValue(sheet, fmt.Sprintf("D%d", row), prodName)
			file.SetCellValue(sheet, fmt.Sprintf("E%d", row), tot.quantity)
			file.SetCellValue(sheet, fmt.Sprintf("H%d", row), tot.subtotal)
			file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("H%d", row), totalStyle)
			row++
		}
	}

	return row
}

func (s *service) writeLedgerReport(file *excelize.File, sheet string, sales []SaleDetail, startRow int, grandTotal *int64, dataStyle, numberStyle, totalStyle, dayHeaderStyle int) int {
	row := startRow
	productTotals := make(map[string]struct{ quantity int; subtotal int64 })

	var currentDay string
	daySales := []SaleDetail{}

	flushDay := func(dayStr string, sales []SaleDetail, startRow int) int {
		if len(sales) == 0 {
			return startRow
		}
		file.SetCellValue(sheet, fmt.Sprintf("A%d", startRow), dayStr)
		file.MergeCell(sheet, fmt.Sprintf("A%d", startRow), fmt.Sprintf("H%d", startRow))
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", startRow), fmt.Sprintf("H%d", startRow), dayHeaderStyle)
		r := startRow + 1

		for _, sale := range sales {
			file.SetCellValue(sheet, fmt.Sprintf("A%d", r), sale.Date.Format(dateTimeFormat))
			file.SetCellValue(sheet, fmt.Sprintf("B%d", r), sale.InvoiceNum)
			file.SetCellValue(sheet, fmt.Sprintf("C%d", r), sale.ClientName)
			file.SetCellValue(sheet, fmt.Sprintf("D%d", r), sale.ProductName)
			file.SetCellValue(sheet, fmt.Sprintf("E%d", r), sale.Quantity)
			file.SetCellValue(sheet, fmt.Sprintf("F%d", r), sale.Subtotal)
			file.SetCellValue(sheet, fmt.Sprintf("G%d", r), sale.Tax)
			file.SetCellValue(sheet, fmt.Sprintf("H%d", r), sale.Total)

			file.SetCellStyle(sheet, fmt.Sprintf("A%d", r), fmt.Sprintf("E%d", r), dataStyle)
			file.SetCellStyle(sheet, fmt.Sprintf("F%d", r), fmt.Sprintf("H%d", r), numberStyle)

			*grandTotal += sale.Total
			productTotals[sale.ProductName] = struct{ quantity int; subtotal int64 }{
				quantity: productTotals[sale.ProductName].quantity + sale.Quantity,
				subtotal: productTotals[sale.ProductName].subtotal + sale.Total,
			}
			r++
		}
		return r
	}

	for _, sale := range sales {
		dayKey := sale.Date.Format("2006-01-02")
		if currentDay != dayKey {
			if currentDay != "" {
				dayLabel := fmt.Sprintf("%s %s", dayNames[parseDayOfWeek(currentDay)], currentDay)
				row = flushDay(dayLabel, daySales, row)
			}
			currentDay = dayKey
			daySales = []SaleDetail{}
		}
		daySales = append(daySales, sale)
	}
	if currentDay != "" {
		dayLabel := fmt.Sprintf("%s %s", dayNames[parseDayOfWeek(currentDay)], currentDay)
		row = flushDay(dayLabel, daySales, row)
	}

	// Product totals at the end
	if len(productTotals) > 0 {
		row++
		file.SetCellValue(sheet, fmt.Sprintf("A%d", row), "TOTALES POR PRODUCTO")
		file.MergeCell(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("D%d", row))
		file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("H%d", row), totalStyle)
		row++
		for prodName, tot := range productTotals {
			file.SetCellValue(sheet, fmt.Sprintf("D%d", row), prodName)
			file.SetCellValue(sheet, fmt.Sprintf("E%d", row), tot.quantity)
			file.SetCellValue(sheet, fmt.Sprintf("H%d", row), tot.subtotal)
			file.SetCellStyle(sheet, fmt.Sprintf("A%d", row), fmt.Sprintf("H%d", row), totalStyle)
			row++
		}
	}

	return row
}

func parseDayOfWeek(dateStr string) int {
	t, _ := time.Parse("2006-01-02", dateStr)
	return int(t.Weekday())
}

func (s *service) workbook(sheet string, rows [][]any) ([]byte, error) {
	file := excelize.NewFile()
	file.SetSheetName("Sheet1", sheet)
	for r, row := range rows {
		for c, value := range row {
			cell, _ := excelize.CoordinatesToCellName(c+1, r+1)
			_ = file.SetCellValue(sheet, cell, value)
		}
	}
	h := &serviceHelper{}
	return h.writeBuffer(file)
}

func (s *service) Cash(q ReportQuery) ([]byte, error) {
	from, to, err := s.parseDateRange(q.From, q.To)
	if err != nil {
		return nil, err
	}
	
	userName := q.User
	if userName == "" {
		userName = "Administrador"
	}

	data, err := s.repo.GetCashReportData(q.BranchID, from, to, userName)
	if err != nil {
		return nil, err
	}
	
	return s.buildCashReportExcel(data)
}

func (s *service) CashData(q ReportQuery) (any, error) {
	from, to, err := s.parseDateRange(q.From, q.To)
	if err != nil {
		return nil, err
	}
	userName := q.User
	if userName == "" {
		userName = "Administrador"
	}
	return s.repo.GetCashReportData(q.BranchID, from, to, userName)
}

func strPtr(s string) *string { return &s }

func (s *service) Dashboard(branchID string) (map[string]any, error) {
	return s.repo.Dashboard(branchID)
}

func (s *service) parseDateRange(fromStr, toStr string) (time.Time, time.Time, error) {
	from, err := time.Parse("2006-01-02", fromStr)
	if err != nil {
		return time.Time{}, time.Time{}, err
	}
	to, err := time.Parse("2006-01-02", toStr)
	if err != nil {
		return time.Time{}, time.Time{}, err
	}
	to = to.Add(23*time.Hour + 59*time.Minute + 59*time.Second)
	return from, to, nil
}

func (s *service) writeHeaders(f *excelize.File, sheet string, headers []string) {
	for i, h := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		f.SetCellValue(sheet, cell, h)
	}
}

type serviceHelper struct{}

func (h *serviceHelper) writeBuffer(f *excelize.File) ([]byte, error) {
	var buf bytes.Buffer
	if err := f.Write(&buf); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}
