package reports

import (
	"fmt"
	"time"

	"github.com/xuri/excelize/v2"
)

type ExcelStyles struct {
	Header         int
	DataLight      int
	DataDark       int
	CurrencyLight  int
	CurrencyDark   int
	Title          int
	Subtitle       int
	TotalRow       int
	DiffGreen      int
	DiffYellow     int
	DiffRed        int
	NoData         int
	DateStyleLight int
	DateStyleDark  int
	TimeStyleLight int
	TimeStyleDark  int
	GeneralTotal   int
}

// createExcelStyles creates shared styles with corporate look (dark blue / green headers).
func createExcelStyles(file *excelize.File) ExcelStyles {
	var styles ExcelStyles

	headerStyle, _ := file.NewStyle(&excelize.Style{
		Font: &excelize.Font{Bold: true, Color: "FFFFFF", Family: "Arial", Size: 11},
		Fill: excelize.Fill{Type: "pattern", Color: []string{"#1F4E78"}, Pattern: 1}, // Dark Blue
		Border: []excelize.Border{
			{Type: "bottom", Color: "BFBFBF", Style: 1},
			{Type: "top", Color: "BFBFBF", Style: 1},
			{Type: "left", Color: "BFBFBF", Style: 1},
			{Type: "right", Color: "BFBFBF", Style: 1},
		},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center"},
	})
	styles.Header = headerStyle

	baseData := excelize.Style{
		Font: &excelize.Font{Family: "Arial", Size: 11, Color: "333333"},
		Border: []excelize.Border{
			{Type: "bottom", Color: "E0E0E0", Style: 1},
			{Type: "left", Color: "E0E0E0", Style: 1},
			{Type: "right", Color: "E0E0E0", Style: 1},
		},
		Alignment: &excelize.Alignment{Vertical: "center"},
	}

	lightFill := excelize.Fill{Type: "pattern", Color: []string{"FFFFFF"}, Pattern: 1}
	darkFill := excelize.Fill{Type: "pattern", Color: []string{"F2F2F2"}, Pattern: 1}

	// Data Light
	dl := baseData
	dl.Fill = lightFill
	styles.DataLight, _ = file.NewStyle(&dl)

	// Data Dark
	dd := baseData
	dd.Fill = darkFill
	styles.DataDark, _ = file.NewStyle(&dd)

	// Currency Light
	cl := dl
	cl.NumFmt = 43 // standard accounting format
	styles.CurrencyLight, _ = file.NewStyle(&cl)

	// Currency Dark
	cd := dd
	cd.NumFmt = 43
	styles.CurrencyDark, _ = file.NewStyle(&cd)

	// Title
	styles.Title, _ = file.NewStyle(&excelize.Style{
		Font:      &excelize.Font{Bold: true, Size: 18, Color: "1F4E78", Family: "Arial"},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center"},
	})

	// Subtitle
	styles.Subtitle, _ = file.NewStyle(&excelize.Style{
		Font:      &excelize.Font{Bold: true, Size: 12, Color: "444444", Family: "Arial"},
		Alignment: &excelize.Alignment{Horizontal: "center", Vertical: "center"},
	})

	// Total Row
	styles.TotalRow, _ = file.NewStyle(&excelize.Style{
		Font:   &excelize.Font{Bold: true, Size: 12, Color: "000000", Family: "Arial"},
		Fill:   excelize.Fill{Type: "pattern", Color: []string{"D9E1F2"}, Pattern: 1},
		NumFmt: 43,
		Border: []excelize.Border{
			{Type: "top", Color: "1F4E78", Style: 2},
			{Type: "bottom", Color: "1F4E78", Style: 2},
		},
	})

	// General Total (Green Bold)
	styles.GeneralTotal, _ = file.NewStyle(&excelize.Style{
		Font:   &excelize.Font{Bold: true, Size: 14, Color: "FFFFFF", Family: "Arial"},
		Fill:   excelize.Fill{Type: "pattern", Color: []string{"#2ca02c"}, Pattern: 1}, // Green
		NumFmt: 43,
		Border: []excelize.Border{
			{Type: "top", Color: "000000", Style: 2},
			{Type: "bottom", Color: "000000", Style: 2},
		},
		Alignment: &excelize.Alignment{Horizontal: "right", Vertical: "center"},
	})

	// Status Colors
	styles.DiffGreen, _ = file.NewStyle(&excelize.Style{
		Font: &excelize.Font{Color: "2ca02c", Bold: true, Family: "Arial"},
		Fill: lightFill,
	})
	styles.DiffYellow, _ = file.NewStyle(&excelize.Style{
		Font: &excelize.Font{Color: "ff7f0e", Bold: true, Family: "Arial"},
		Fill: lightFill,
	})
	styles.DiffRed, _ = file.NewStyle(&excelize.Style{
		Font: &excelize.Font{Color: "d62728", Bold: true, Family: "Arial"},
		Fill: lightFill,
	})

	styles.NoData, _ = file.NewStyle(&excelize.Style{
		Font:      &excelize.Font{Italic: true, Color: "888888", Family: "Arial"},
		Alignment: &excelize.Alignment{Horizontal: "center"},
	})

	// Date & Time
	dtl := dl
	dtl.NumFmt = 14
	styles.DateStyleLight, _ = file.NewStyle(&dtl)

	dtd := dd
	dtd.NumFmt = 14
	styles.DateStyleDark, _ = file.NewStyle(&dtd)

	tl := dl
	tl.NumFmt = 20
	styles.TimeStyleLight, _ = file.NewStyle(&tl)

	td := dd
	td.NumFmt = 20
	styles.TimeStyleDark, _ = file.NewStyle(&td)

	return styles
}

func writeCorporateHeader(file *excelize.File, sheet string, title string, styles ExcelStyles) {
	// Standard Corporate Header
	file.SetCellValue(sheet, "A1", "LOGO DEL NEGOCIO")
	file.SetCellValue(sheet, "A2", "NOMBRE DEL RESTAURANTE")
	file.SetCellValue(sheet, "A3", "NIT: 900.123.456-7")
	file.SetCellValue(sheet, "A4", title)
	file.SetCellValue(sheet, "A5", fmt.Sprintf("Fecha de Generación: %s", time.Now().Format("02/01/2006 15:04")))
	file.SetCellValue(sheet, "A6", "Usuario: Administrador") // Podría ser dinámico si tuviéramos el usuario

	// Merge all up to column H or I (we will merge up to I to ensure enough space)
	for i := 1; i <= 6; i++ {
		file.MergeCell(sheet, fmt.Sprintf("A%d", i), fmt.Sprintf("H%d", i))
	}

	file.SetCellStyle(sheet, "A1", "A1", styles.Subtitle) // Logo placeholder
	file.SetCellStyle(sheet, "A2", "A2", styles.Title)
	file.SetCellStyle(sheet, "A3", "A3", styles.Subtitle)
	file.SetCellStyle(sheet, "A4", "A4", styles.Title)
	file.SetCellStyle(sheet, "A5", "A6", styles.Subtitle)
}

func setColWidths(file *excelize.File, sheet string, cols ...int) {
	for i, w := range cols {
		colName, _ := excelize.ColumnNumberToName(i + 1)
		file.SetColWidth(sheet, colName, colName, float64(w))
	}
}
