package reports

type ReportQuery struct {
	BranchID string `json:"branch_id"`
	From     string `json:"from"`
	To       string `json:"to"`
	User     string `json:"user"`
}

type SalesReportData struct {
	Sales    any `json:"sales"`
	Products any `json:"products"`
}
