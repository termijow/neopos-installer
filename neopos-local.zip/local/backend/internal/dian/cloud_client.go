package dian

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"restaurant-pos-api/internal/platform/config"
	"restaurant-pos-api/internal/settings"

	"gorm.io/gorm"
)

type CloudFactusClient struct {
	cfg config.Config
	db  *gorm.DB
}

func NewCloudFactusClient(cfg config.Config, db *gorm.DB) *CloudFactusClient {
	return &CloudFactusClient{cfg: cfg, db: db}
}

func (c *CloudFactusClient) SendInvoice(payload []byte) (map[string]interface{}, error) {
	if c.cfg.SyncRemoteURL == "" {
		return nil, fmt.Errorf("Cloud sync URL not configured")
	}

	var rawPayload map[string]interface{}
	if err := json.Unmarshal(payload, &rawPayload); err != nil {
		return nil, fmt.Errorf("failed to parse local payload: %w", err)
	}

	token := c.cfg.LicenseKey
	var s struct{ Value string }
	if err := c.db.Table("settings").Select("value").Where("key = ?", "active_license_key").Scan(&s).Error; err == nil {
		if value := settings.DecodeValue(s.Value); value != "" {
			token = value
		}
	}

	cloudReqBody := map[string]interface{}{
		"tenant_id": 1,
		"token":     token,
		"node_id":   c.cfg.LocalNodeID,
		"payload":   rawPayload,
	}

	jsonData, _ := json.Marshal(cloudReqBody)
	req, err := http.NewRequest("POST", c.cfg.SyncRemoteURL+"/api/v1/invoice/validate", bytes.NewBuffer(jsonData))
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{Timeout: 30 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("http request to cloud failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 400 {
		buf := new(bytes.Buffer)
		_, _ = buf.ReadFrom(resp.Body)
		rawBody := buf.String()
		return nil, &FactusError{
			StatusCode:  resp.StatusCode,
			Message:     "Cloud rejected invoice",
			RawResponse: rawBody,
		}
	}

	var responseMap map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&responseMap); err != nil {
		return nil, fmt.Errorf("failed to decode response: %w", err)
	}

	return responseMap, nil
}
