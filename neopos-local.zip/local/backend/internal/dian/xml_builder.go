package dian

import (
	"encoding/xml"
	"fmt"
	"time"
)

type InvoiceXML struct {
	XMLName      xml.Name `xml:"Invoice"`
	ID           string   `xml:"ID"`
	IssueDate    string   `xml:"IssueDate"`
	IssueTime    string   `xml:"IssueTime"`
	InvoiceLines []Line   `xml:"InvoiceLine"`
	TaxTotal     TaxTotal `xml:"TaxTotal"`
	LegalTotal   float64  `xml:"LegalMonetaryTotal>PayableAmount"`
}

type Line struct {
	ID             int     `xml:"ID"`
	ItemName       string  `xml:"Item>Name"`
	Quantity       float64 `xml:"InvoicedQuantity"`
	LineExtension  float64 `xml:"LineExtensionAmount"`
	TaxCategory    string  `xml:"TaxTotal>TaxSubtotal>TaxCategory>Percent"`
}

type TaxTotal struct {
	TaxAmount float64       `xml:"TaxAmount"`
	Subtotals []TaxSubtotal `xml:"TaxSubtotal"`
}

type TaxSubtotal struct {
	TaxableAmount float64 `xml:"TaxableAmount"`
	TaxAmount     float64 `xml:"TaxAmount"`
	Percent       float64 `xml:"TaxCategory>Percent"`
	TaxScheme     string  `xml:"TaxCategory>TaxScheme>Name"` // IVA or INC
}

// BuildDIANXML constructs the structured XML required by DIAN
func BuildDIANXML(invoiceID string, items []map[string]interface{}) ([]byte, error) {
	inv := InvoiceXML{
		ID:        invoiceID,
		IssueDate: time.Now().Format("2006-01-02"),
		IssueTime: time.Now().Format("15:04:05-05:00"),
	}

	var totalTax float64
	var totalPayable float64
	var lines []Line
	var subtotals []TaxSubtotal

	for i, item := range items {
		qty := item["quantity"].(float64)
		price := item["price"].(float64)
		taxRate := item["tax_rate"].(float64) // e.g., 19.0, 8.0, 5.0, 0.0
		taxType := item["tax_type"].(string)  // "IVA" or "INC"

		lineExt := qty * price
		taxAmount := lineExt * (taxRate / 100.0)

		lines = append(lines, Line{
			ID:            i + 1,
			ItemName:      item["name"].(string),
			Quantity:      qty,
			LineExtension: lineExt,
			TaxCategory:   fmt.Sprintf("%.2f", taxRate),
		})

		subtotals = append(subtotals, TaxSubtotal{
			TaxableAmount: lineExt,
			TaxAmount:     taxAmount,
			Percent:       taxRate,
			TaxScheme:     taxType,
		})

		totalTax += taxAmount
		totalPayable += (lineExt + taxAmount)
	}

	inv.InvoiceLines = lines
	inv.TaxTotal = TaxTotal{
		TaxAmount: totalTax,
		Subtotals: subtotals,
	}
	inv.LegalTotal = totalPayable

	return xml.MarshalIndent(inv, "", "  ")
}
