package dian

import (
	"bytes"
	"fmt"
	"log"
	"net/smtp"
)

// GeneratePDF creates a PDF representation of the electronic invoice
func GeneratePDF(invoiceID string, items []map[string]interface{}, cufe, qrCode string) ([]byte, error) {
	// Note: In a real implementation, you would use a library like github.com/jung-kurt/gofpdf
	// to draw the invoice, add the CUFE text, and embed the QR Code image.
	// For this task, we return a mock PDF buffer representing the generated file.
	
	buf := new(bytes.Buffer)
	buf.WriteString("%PDF-1.4\n")
	buf.WriteString("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n")
	buf.WriteString(fmt.Sprintf("%% Invoice: %s, CUFE: %s, QR: %s\n", invoiceID, cufe, qrCode))
	buf.WriteString("%% EOF\n")
	
	return buf.Bytes(), nil
}

// SendEmail sends the generated PDF invoice to the customer
func SendEmail(smtpHost, smtpPort, smtpUser, smtpPass, customerEmail string, pdfBytes []byte) error {
	// Setup headers
	headers := make(map[string]string)
	headers["From"] = smtpUser
	headers["To"] = customerEmail
	headers["Subject"] = "Factura Electrónica NeoPOS"
	headers["MIME-Version"] = "1.0"
	headers["Content-Type"] = "application/pdf; name=\"factura.pdf\""
	headers["Content-Disposition"] = "attachment; filename=\"factura.pdf\""
	headers["Content-Transfer-Encoding"] = "base64"

	// Message
	var msg bytes.Buffer
	for k, v := range headers {
		msg.WriteString(fmt.Sprintf("%s: %s\r\n", k, v))
	}
	msg.WriteString("\r\n")
	
	// Just sending the raw bytes for the mock (real implementation needs base64 encoding if MIME is base64)
	msg.Write(pdfBytes)

	// Auth
	auth := smtp.PlainAuth("", smtpUser, smtpPass, smtpHost)

	// Send
	err := smtp.SendMail(smtpHost+":"+smtpPort, auth, smtpUser, []string{customerEmail}, msg.Bytes())
	if err != nil {
		log.Printf("Failed to send email to %s: %v\n", customerEmail, err)
		return err // In local testing without real SMTP, this might fail
	}

	return nil
}
