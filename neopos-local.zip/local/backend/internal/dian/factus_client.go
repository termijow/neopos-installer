package dian

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"strings"
	"time"
)

type FactusClient struct {
	BaseURL      string
	Email        string
	Password     string
	ClientID     string
	ClientSecret string
	Token        string
	HTTPClient   *http.Client
}

func NewFactusClient() *FactusClient {
	baseURL := os.Getenv("FACTUS_BASE_URL")
	if baseURL == "" {
		// Fallback for tests or old configs
		if apiURL := os.Getenv("FACTUS_API_URL"); apiURL != "" {
			baseURL = apiURL
		} else {
			baseURL = "https://api-sandbox.factus.com.co"
		}
	}

	token := os.Getenv("FACTUS_API_KEY")

	return &FactusClient{
		BaseURL:      baseURL,
		Email:        os.Getenv("FACTUS_EMAIL"),
		Password:     os.Getenv("FACTUS_PASSWORD"),
		ClientID:     os.Getenv("FACTUS_CLIENT_ID"),
		ClientSecret: os.Getenv("FACTUS_CLIENT_SECRET"),
		Token:        token,
		HTTPClient:   &http.Client{Timeout: 15 * time.Second},
	}
}

type FactusError struct {
	StatusCode  int
	Message     string
	RawResponse string
}

func (e *FactusError) Error() string {
	return fmt.Sprintf("factus API error: status %d: %s", e.StatusCode, e.Message)
}

func (c *FactusClient) GetToken() error {
	if c.Token != "" {
		return nil
	}

	reqURL := c.BaseURL + "/oauth/token"

	form := url.Values{}
	form.Add("grant_type", "password")
	form.Add("client_id", c.ClientID)
	form.Add("client_secret", c.ClientSecret)
	form.Add("username", c.Email)
	form.Add("password", c.Password)

	req, err := http.NewRequest("POST", reqURL, strings.NewReader(form.Encode()))
	if err != nil {
		return fmt.Errorf("failed to create auth request: %w", err)
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("Accept", "application/json")

	resp, err := c.HTTPClient.Do(req)
	if err != nil {
		return fmt.Errorf("auth http request failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 400 {
		buf := new(bytes.Buffer)
		_, _ = buf.ReadFrom(resp.Body)
		return fmt.Errorf("auth failed, status %d: %s", resp.StatusCode, buf.String())
	}

	var res struct {
		AccessToken string `json:"access_token"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&res); err != nil {
		return fmt.Errorf("failed to decode auth response: %w", err)
	}
	if res.AccessToken == "" {
		return fmt.Errorf("auth response did not contain an access token")
	}

	c.Token = res.AccessToken
	return nil
}

func (c *FactusClient) SendInvoice(payload []byte) (map[string]interface{}, error) {
	if err := c.GetToken(); err != nil {
		return nil, &FactusError{
			StatusCode:  500,
			Message:     err.Error(),
			RawResponse: "",
		}
	}

	reqURL := strings.TrimRight(c.BaseURL, "/") + "/v2/bills/validate"
	req, err := http.NewRequest("POST", reqURL, bytes.NewBuffer(payload))
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")
	if c.Token != "" {
		req.Header.Set("Authorization", "Bearer "+c.Token)
	}

	resp, err := c.HTTPClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("http request failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 400 {
		buf := new(bytes.Buffer)
		_, _ = buf.ReadFrom(resp.Body)
		rawBody := buf.String()

		message := fmt.Sprintf("status code %d", resp.StatusCode)
		var errMap map[string]interface{}
		if err := json.Unmarshal([]byte(rawBody), &errMap); err == nil {
			if msg, ok := errMap["message"].(string); ok {
				message = msg
			} else if errMsg, ok := errMap["error"].(string); ok {
				message = errMsg
			}
		}

		return nil, &FactusError{
			StatusCode:  resp.StatusCode,
			Message:     message,
			RawResponse: rawBody,
		}
	}

	var responseMap map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&responseMap); err != nil {
		return nil, fmt.Errorf("failed to decode response: %w", err)
	}

	return responseMap, nil
}
