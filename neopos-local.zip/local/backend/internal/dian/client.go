package dian

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"time"
)

// TechProviderClient defines the interface for communicating with technology providers.
type TechProviderClient interface {
	SendInvoice(payload []byte) (map[string]interface{}, error)
}

// DIANClient handles communication with the technology provider (e.g. Siigo)
type DIANClient struct {
	ProviderURL string
	APIKey      string
	HTTPClient  *http.Client
}

func NewDIANClient(providerURL, apiKey string) *DIANClient {
	return &DIANClient{
		ProviderURL: providerURL,
		APIKey:      apiKey,
		HTTPClient:  &http.Client{Timeout: 15 * time.Second},
	}
}

// SendInvoice sends the XML invoice to the provider and receives the signed response (CUFE, QR)
func (c *DIANClient) SendInvoice(xmlPayload []byte) (map[string]interface{}, error) {
	req, err := http.NewRequest("POST", c.ProviderURL+"/v1/invoices", bytes.NewBuffer(xmlPayload))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/xml")
	req.Header.Set("Authorization", "Bearer "+c.APIKey)

	resp, err := c.HTTPClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("provider returned status: %d", resp.StatusCode)
	}

	var result map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}
	return result, nil
}
