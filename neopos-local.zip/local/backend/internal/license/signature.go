package license

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"

	"restaurant-pos-api/internal/platform/config"
)

func licenseSigningSecret(cfg config.Config) string {
	return cfg.JWTSecret
}

func hasLicenseSigningSecret(cfg config.Config) bool {
	return licenseSigningSecret(cfg) != ""
}

func generateLicenseSignature(cfg config.Config, licenseType, expiresAt string) string {
	mac := hmac.New(sha256.New, []byte(licenseSigningSecret(cfg)))
	mac.Write([]byte(licenseType + "|" + expiresAt))
	return hex.EncodeToString(mac.Sum(nil))
}

func validLicenseSignature(cfg config.Config, cached CachedLicense) bool {
	expected := generateLicenseSignature(cfg, cached.LicenseType, cached.ExpiresAt)
	return hmac.Equal([]byte(expected), []byte(cached.Signature))
}
