package license

import (
	"restaurant-pos-api/internal/platform/config"
	"restaurant-pos-api/internal/settings"

	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB, cfg config.Config) {
	settingsRepo := settings.NewRepository(db)
	settingsSvc := settings.NewService(settingsRepo)
	controller := NewController(cfg, settingsSvc)

	router.Post("/license/activate", controller.Activate)
	router.Get("/license/status", controller.Status)
}
