package license

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"restaurant-pos-api/internal/platform/config"
	"restaurant-pos-api/internal/settings"
)

type ValidationResult struct {
	Valid       bool   `json:"valid"`
	LicenseType string `json:"license_type"`
	ExpiresAt   string `json:"expires_at"` // e.g. "2026-12-31"
	Error       string `json:"error,omitempty"`
}

type LicenseInfo struct {
	Valid       bool
	LicenseType string
	ExpiresAt   time.Time
	Warning     string
}

type Validator struct {
	cfg         config.Config
	settingsSvc settings.Service
	client      *http.Client
}

func NewValidator(cfg config.Config, settingsSvc settings.Service) *Validator {
	return &Validator{
		cfg:         cfg,
		settingsSvc: settingsSvc,
		client:      &http.Client{Timeout: 5 * time.Second},
	}
}

func (v *Validator) VerifyAndFallback(branchID string) (*LicenseInfo, error) {
	if !hasLicenseSigningSecret(v.cfg) {
		return nil, fmt.Errorf("secreto de firma de licencia no configurado")
	}

	// Try online verification first
	var onlineRes *ValidationResult

	if v.cfg.SyncRemoteURL != "" {
		token := v.cfg.LicenseKey
		if list, err := v.settingsSvc.List(); err == nil {
			for _, s := range list {
				if s.Key == "active_license_key" && s.Value != "" {
					token = s.Value
					break
				}
			}
		}

		payload := map[string]interface{}{
			"tenant_id": 1,
			"token":     token,
		}
		body, _ := json.Marshal(payload)

		req, err := http.NewRequest("POST", v.cfg.SyncRemoteURL+"/api/v1/licenses/verify", bytes.NewBuffer(body))
		if err == nil {
			req.Header.Set("Content-Type", "application/json")
			resp, err := v.client.Do(req)
			if err == nil {
				defer resp.Body.Close()
				var res ValidationResult
				if json.NewDecoder(resp.Body).Decode(&res) == nil {
					onlineRes = &res
				}
			}
		}
	}

	var finalRes *ValidationResult

	if onlineRes != nil {
		if !onlineRes.Valid || onlineRes.Error != "" {
			return nil, fmt.Errorf("licencia inactiva o inválida: %s", onlineRes.Error)
		}

		// Online succeeded, save to settings
		finalRes = onlineRes
		cached := CachedLicense{
			Valid:       onlineRes.Valid,
			LicenseType: onlineRes.LicenseType,
			ExpiresAt:   onlineRes.ExpiresAt,
			Signature:   generateLicenseSignature(v.cfg, onlineRes.LicenseType, onlineRes.ExpiresAt),
		}
		valBytes, _ := json.Marshal(cached)
		v.settingsSvc.Upsert(settings.UpsertSettingRequest{
			Key:   "cached_license",
			Value: string(valBytes),
		})
	} else {
		// Online failed or returned server error, fallback to local settings
		list, err := v.settingsSvc.List()
		if err == nil {
			for _, s := range list {
				if s.Key == "cached_license" {
					var cached CachedLicense
					if json.Unmarshal([]byte(s.Value), &cached) == nil && cached.Valid && validLicenseSignature(v.cfg, cached) {
						finalRes = &ValidationResult{
							Valid:       cached.Valid,
							LicenseType: cached.LicenseType,
							ExpiresAt:   cached.ExpiresAt,
						}
						break
					}
				}
			}
		}
	}

	if finalRes == nil {
		return nil, fmt.Errorf("no se pudo validar la licencia (ni online ni offline)")
	}

	if !finalRes.Valid {
		return nil, fmt.Errorf("licencia inactiva o inválida: %s", finalRes.Error)
	}

	expiresAt, err := time.Parse("2006-01-02", finalRes.ExpiresAt)
	if err != nil {
		expiresAt, err = time.Parse(time.RFC3339, finalRes.ExpiresAt)
		if err != nil {
			return nil, fmt.Errorf("fecha de expiración de licencia inválida")
		}
	}

	warning := ""
	daysLeft := int(time.Until(expiresAt).Hours() / 24)

	if finalRes.LicenseType == "premium" || finalRes.LicenseType == "annual" {
		if daysLeft >= 0 && daysLeft <= 7 {
			warning = fmt.Sprintf("¡Advertencia! Su licencia anual expira en %d días.", daysLeft)
		}
	} else {
		// Default to monthly rules
		if daysLeft >= 0 && daysLeft <= 5 {
			warning = fmt.Sprintf("¡Advertencia! Su licencia expira en %d días.", daysLeft)
		}
	}

	if daysLeft < 0 {
		return nil, fmt.Errorf("la licencia expiró hace %d días", -daysLeft)
	}

	return &LicenseInfo{
		Valid:       finalRes.Valid,
		LicenseType: finalRes.LicenseType,
		ExpiresAt:   expiresAt,
		Warning:     warning,
	}, nil
}
