package license

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"time"

	"restaurant-pos-api/internal/platform/config"
	"restaurant-pos-api/internal/settings"
	"restaurant-pos-api/pkg/response"

	"github.com/gofiber/fiber/v2"
)

type Controller struct {
	cfg         config.Config
	settingsSvc settings.Service
	client      *http.Client
}

func NewController(cfg config.Config, settingsSvc settings.Service) *Controller {
	return &Controller{
		cfg:         cfg,
		settingsSvc: settingsSvc,
		client:      &http.Client{Timeout: 5 * time.Second},
	}
}

type ActivateRequest struct {
	Code         string `json:"code"`
	BusinessName string `json:"business_name"`
	BranchID     string `json:"branch_id"`
}

type VerifyResponse struct {
	Valid       bool   `json:"valid"`
	LicenseType string `json:"license_type"`
	ExpiresAt   string `json:"expires_at"`
	Error       string `json:"error,omitempty"`
}

type CachedLicense struct {
	Valid       bool   `json:"valid"`
	LicenseType string `json:"license_type"`
	ExpiresAt   string `json:"expires_at"`
	Signature   string `json:"signature"`
}

func (c *Controller) generateSignature(licenseType, expiresAt string) string {
	return generateLicenseSignature(c.cfg, licenseType, expiresAt)
}

func (c *Controller) Activate(ctx *fiber.Ctx) error {
	var req ActivateRequest
	if err := ctx.BodyParser(&req); err != nil {
		return response.Error(ctx, fiber.StatusBadRequest, "Invalid request body")
	}
	req.Code = strings.TrimSpace(req.Code)
	req.BusinessName = strings.TrimSpace(req.BusinessName)
	req.BranchID = strings.TrimSpace(req.BranchID)
	if req.Code == "" || req.BusinessName == "" || req.BranchID == "" {
		return response.Error(ctx, fiber.StatusBadRequest, "License code, business name and branch are required")
	}
	if !hasLicenseSigningSecret(c.cfg) {
		return response.Error(ctx, fiber.StatusServiceUnavailable, "License signing secret is not configured")
	}

	remoteURL := c.cfg.SyncRemoteURL
	if remoteURL == "" {
		return response.Error(ctx, fiber.StatusServiceUnavailable, "License verification service is not configured")
	}

	payload := map[string]interface{}{
		"token":         req.Code,
		"business_name": req.BusinessName,
		"branch_id":     req.BranchID,
	}
	body, _ := json.Marshal(payload)

	var verifyRes VerifyResponse
	success := false

	httpReq, err := http.NewRequest("POST", remoteURL+"/api/v1/licenses/verify", bytes.NewBuffer(body))
	if err == nil {
		httpReq.Header.Set("Content-Type", "application/json")
		resp, err := c.client.Do(httpReq)
		if err == nil {
			defer resp.Body.Close()
			if err := json.NewDecoder(resp.Body).Decode(&verifyRes); err == nil {
				success = true
			}
		}
	}

	if !success {
		return response.Error(ctx, fiber.StatusBadGateway, "Failed to verify license with remote server")
	}

	if !verifyRes.Valid {
		return response.Error(ctx, fiber.StatusBadRequest, "License is invalid: "+verifyRes.Error)
	}

	cached := CachedLicense{
		Valid:       verifyRes.Valid,
		LicenseType: verifyRes.LicenseType,
		ExpiresAt:   verifyRes.ExpiresAt,
		Signature:   c.generateSignature(verifyRes.LicenseType, verifyRes.ExpiresAt),
	}

	cachedBytes, _ := json.Marshal(cached)
	_, err = c.settingsSvc.Upsert(settings.UpsertSettingRequest{
		Key:   "cached_license",
		Value: string(cachedBytes),
	})

	if err != nil {
		return response.Error(ctx, fiber.StatusInternalServerError, "Failed to save license cache")
	}

	_, err = c.settingsSvc.Upsert(settings.UpsertSettingRequest{
		Key:   "active_license_key",
		Value: req.Code,
	})

	if err != nil {
		return response.Error(ctx, fiber.StatusInternalServerError, "Failed to save license key")
	}

	return response.OK(ctx, fiber.Map{
		"valid":        true,
		"message":      "License activated successfully",
		"license_type": verifyRes.LicenseType,
		"expires_at":   verifyRes.ExpiresAt,
	})
}

func (c *Controller) Status(ctx *fiber.Ctx) error {
	if !hasLicenseSigningSecret(c.cfg) {
		return response.OK(ctx, fiber.Map{"valid": false, "error": "License signing secret is not configured"})
	}

	list, err := c.settingsSvc.List()
	if err != nil {
		return response.OK(ctx, fiber.Map{"valid": false, "error": "Could not read settings"})
	}

	var cachedVal string
	for _, s := range list {
		if s.Key == "cached_license" {
			cachedVal = s.Value
			break
		}
	}

	if cachedVal == "" {
		return response.OK(ctx, fiber.Map{"valid": false, "message": "No license found"})
	}

	var cached CachedLicense
	if err := json.Unmarshal([]byte(cachedVal), &cached); err != nil {
		return response.OK(ctx, fiber.Map{"valid": false, "message": "Invalid cached license format"})
	}

	if !cached.Valid {
		return response.OK(ctx, fiber.Map{"valid": false, "message": "License is inactive"})
	}
	if cached.LicenseType == "" {
		return response.OK(ctx, fiber.Map{"valid": false, "message": "Invalid cached license type"})
	}

	if !validLicenseSignature(c.cfg, cached) {
		return response.OK(ctx, fiber.Map{"valid": false, "message": "fraud_detected"})
	}

	expiresAt, err := time.Parse(time.RFC3339, cached.ExpiresAt)
	if err != nil {
		expiresAt, err = time.Parse("2006-01-02", cached.ExpiresAt)
		if err != nil {
			return response.OK(ctx, fiber.Map{"valid": false, "message": "Invalid expiration date format"})
		}
	}

	daysLeft := int(time.Until(expiresAt).Hours() / 24)
	if daysLeft < 0 {
		return response.OK(ctx, fiber.Map{"valid": false, "message": fmt.Sprintf("License expired %d days ago", -daysLeft)})
	}

	return response.OK(ctx, fiber.Map{
		"valid":      true,
		"expires_at": cached.ExpiresAt,
		"type":       cached.LicenseType,
		"days_left":  daysLeft,
	})
}
