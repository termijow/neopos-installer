package inventory

import (
	"restaurant-pos-api/internal/products"
	"restaurant-pos-api/pkg/model"

	"github.com/google/uuid"
)

const (
	MovementIn         = "IN"
	MovementOut        = "OUT"
	MovementAdjustment = "ADJUSTMENT"
)

type InventoryMovement struct {
	model.Base
	model.BranchScoped
	ProductID   uuid.UUID         `json:"product_id" gorm:"type:uuid;index;not null"`
	Product     *products.Product `json:"product" gorm:"foreignKey:ProductID"`
	SupplierID  uuid.UUID `json:"supplier_id" gorm:"type:uuid;index"`
	Type        string    `json:"type" gorm:"size:30;not null;index"`
	Quantity    int       `json:"quantity" gorm:"not null"`
	Reason      string    `json:"reason" gorm:"size:255"`
	ReferenceID uuid.UUID `json:"reference_id" gorm:"type:uuid;index"`
}
