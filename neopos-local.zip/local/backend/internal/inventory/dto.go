package inventory

import "github.com/google/uuid"

type MovementRequest struct {
	BranchID    uuid.UUID `json:"branch_id"`
	ProductID   uuid.UUID `json:"product_id"`
	SupplierID  uuid.UUID `json:"supplier_id"`
	Quantity    int       `json:"quantity"`
	Reason      string    `json:"reason"`
	ReferenceID uuid.UUID `json:"reference_id"`
}
