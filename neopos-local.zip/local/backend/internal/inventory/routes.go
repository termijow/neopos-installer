package inventory

import (
	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB) {
	controller := NewController(NewService(NewRepository(db)))
	router.Get("/inventory", controller.List)
	router.Get("/inventory/stock", controller.GetStock)
	router.Get("/inventory/prediction", controller.GetPrediction)
	router.Post("/inventory/in", controller.In)
	router.Post("/inventory/out", controller.Out)
	router.Post("/inventory/adjustment", controller.Adjustment)
}
