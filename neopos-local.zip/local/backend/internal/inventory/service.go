package inventory

import "github.com/google/uuid"

type Service interface {
	List(branchID uuid.UUID, page, limit int) ([]InventoryMovement, int, error)
	GetStock(branchID string) (map[uuid.UUID]int64, error)
	GetPrediction(branchID string) (map[uuid.UUID]int64, error)
	In(MovementRequest) (*InventoryMovement, error)
	Out(MovementRequest) (*InventoryMovement, error)
	Adjustment(MovementRequest) (*InventoryMovement, error)
}

type service struct{ repo Repository }
func NewService(repo Repository) Service { return &service{repo: repo} }
func (s *service) List(branchID uuid.UUID, page, limit int) ([]InventoryMovement, int, error) { return s.repo.List(branchID, page, limit) }
func (s *service) GetStock(branchID string) (map[uuid.UUID]int64, error) {
	bID, err := uuid.Parse(branchID)
	if err != nil {
		return nil, err
	}
	return s.repo.GetStock(bID)
}
func (s *service) GetPrediction(branchID string) (map[uuid.UUID]int64, error) {
	bID, err := uuid.Parse(branchID)
	if err != nil {
		return nil, err
	}
	return s.repo.GetPrediction(bID)
}
func (s *service) In(req MovementRequest) (*InventoryMovement, error) { return s.create(MovementIn, req) }
func (s *service) Out(req MovementRequest) (*InventoryMovement, error) { return s.create(MovementOut, req) }
func (s *service) Adjustment(req MovementRequest) (*InventoryMovement, error) { return s.create(MovementAdjustment, req) }
func (s *service) create(kind string, req MovementRequest) (*InventoryMovement, error) { item := &InventoryMovement{ProductID: req.ProductID, SupplierID: req.SupplierID, Type: kind, Quantity: req.Quantity, Reason: req.Reason, ReferenceID: req.ReferenceID}; item.BranchID = req.BranchID; if item.ReferenceID == uuid.Nil { item.ReferenceID = item.ID }; return item, s.repo.Create(item) }
