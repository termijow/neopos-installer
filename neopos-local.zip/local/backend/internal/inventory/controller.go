package inventory

import (
	"fmt"
	"restaurant-pos-api/pkg/response"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
)

type Controller struct{ service Service }
func NewController(service Service) *Controller { return &Controller{service: service} }
func (h *Controller) List(c *fiber.Ctx) error {
	page := c.QueryInt("page", 1)
	limit := c.QueryInt("limit", 50)
	
	var branchID uuid.UUID
	if b := c.Locals("branch_id"); b != nil {
		switch v := b.(type) {
		case string:
			branchID, _ = uuid.Parse(v)
		case uuid.UUID:
			branchID = v
		}
	}
	
	items, total, err := h.service.List(branchID, page, limit)
	if err != nil {
		return response.Error(c, fiber.StatusInternalServerError, err.Error())
	}
	return response.Paginated(c, items, page, limit, total)
}
func (h *Controller) GetStock(c *fiber.Ctx) error {
	branchID := c.Query("branch_id")
	if branchID == "" {
		if b := c.Locals("branch_id"); b != nil {
			switch v := b.(type) {
			case string:
				branchID = v
			case uuid.UUID:
				branchID = v.String()
			}
		}
	}
	stock, err := h.service.GetStock(branchID)
	if err != nil {
		return response.Error(c, fiber.StatusInternalServerError, err.Error())
	}
	return response.OK(c, stock)
}

func (h *Controller) GetPrediction(c *fiber.Ctx) error {
	branchID := c.Query("branch_id")
	if branchID == "" {
		if b := c.Locals("branch_id"); b != nil {
			switch v := b.(type) {
			case string:
				branchID = v
			case uuid.UUID:
				branchID = v.String()
			}
		}
	}
	pred, err := h.service.GetPrediction(branchID)
	if err != nil {
		return response.Error(c, fiber.StatusInternalServerError, err.Error())
	}
	return response.OK(c, pred)
}

func (h *Controller) In(c *fiber.Ctx) error { return h.movement(c, h.service.In) }
func (h *Controller) Out(c *fiber.Ctx) error { return h.movement(c, h.service.Out) }
func (h *Controller) Adjustment(c *fiber.Ctx) error { return h.movement(c, h.service.Adjustment) }
func (h *Controller) movement(c *fiber.Ctx, fn func(MovementRequest) (*InventoryMovement, error)) error { 
	var req MovementRequest; 
	if err := c.BodyParser(&req); err != nil { 
		return response.Error(c, fiber.StatusBadRequest, err.Error()) 
	}
	
	if b := c.Locals("branch_id"); b != nil {
		fmt.Printf("Locals branch_id is of type %T, value: %v\n", b, b)
		switch v := b.(type) {
		case string:
			req.BranchID, _ = uuid.Parse(v)
			fmt.Printf("Parsed string BranchID: %s\n", req.BranchID)
		case uuid.UUID:
			req.BranchID = v
			fmt.Printf("Parsed UUID BranchID: %s\n", req.BranchID)
		}
	} else {
		fmt.Printf("Locals branch_id is NIL\n")
	}
	
	item, err := fn(req); 
	if err != nil { 
		return response.Error(c, fiber.StatusBadRequest, err.Error()) 
	}
	return response.Created(c, item) 
}
