package inventory

import (
	"math"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface {
	List(branchID uuid.UUID, page, limit int) ([]InventoryMovement, int, error)
	GetStock(branchID uuid.UUID) (map[uuid.UUID]int64, error)
	GetPrediction(branchID uuid.UUID) (map[uuid.UUID]int64, error)
	Create(*InventoryMovement) error
}

type gormRepository struct{ db *gorm.DB }
func NewRepository(db *gorm.DB) Repository { return &gormRepository{db: db} }
func (r *gormRepository) List(branchID uuid.UUID, page, limit int) ([]InventoryMovement, int, error) {
	var items []InventoryMovement
	var total int64
	offset := (page - 1) * limit
	query := r.db.Model(&InventoryMovement{}).Where("branch_id = ?", branchID)
	
	if err := query.Count(&total).Error; err != nil { return nil, 0, err }
	err := query.Preload("Product").Order("created_at desc").Offset(offset).Limit(limit).Find(&items).Error
	return items, int(total), err
}
func (r *gormRepository) Create(item *InventoryMovement) error { return r.db.Create(item).Error }

func StockByProduct(db *gorm.DB, branchID, productID uuid.UUID) (int64, error) {
	var total int64
	err := db.Model(&InventoryMovement{}).
		Select("COALESCE(SUM(CASE WHEN type = ? THEN quantity WHEN type = ? THEN -quantity ELSE quantity END),0)", MovementIn, MovementOut).
		Where("branch_id = ? AND product_id = ?", branchID, productID).
		Scan(&total).Error
	return total, err
}

func (r *gormRepository) GetStock(branchID uuid.UUID) (map[uuid.UUID]int64, error) {
	type StockResult struct {
		ProductID uuid.UUID
		Total     int64
	}
	var results []StockResult
	
	err := r.db.Model(&InventoryMovement{}).
		Select("product_id, COALESCE(SUM(CASE WHEN type = ? THEN quantity WHEN type = ? THEN -quantity ELSE quantity END),0) as total", MovementIn, MovementOut).
		Where("branch_id = ?", branchID).
		Group("product_id").
		Scan(&results).Error

	if err != nil {
		return nil, err
	}

	stockMap := make(map[uuid.UUID]int64)
	for _, res := range results {
		stockMap[res.ProductID] = res.Total
	}
	return stockMap, nil
}

func (r *gormRepository) GetPrediction(branchID uuid.UUID) (map[uuid.UUID]int64, error) {
	type UsageResult struct {
		ProductID uuid.UUID
		Total     int64
	}

	// Step 1: Query total OUT movements per product over the last 28 days.
	var usageResults []UsageResult
	err := r.db.Model(&InventoryMovement{}).
		Select("product_id, SUM(quantity) as total").
		Where("branch_id = ? AND type = ? AND created_at >= current_date - interval '28 days'", branchID, MovementOut).
		Group("product_id").
		Scan(&usageResults).Error
	if err != nil {
		// Fallback for SQLite which does not support the interval syntax.
		err = r.db.Model(&InventoryMovement{}).
			Select("product_id, SUM(quantity) as total").
			Where("branch_id = ? AND type = ? AND created_at >= date('now', '-28 days')", branchID, MovementOut).
			Group("product_id").
			Scan(&usageResults).Error
		if err != nil {
			return nil, err
		}
	}

	// Build usedMap: productID -> total units consumed in the last 28 days.
	usedMap := make(map[uuid.UUID]int64, len(usageResults))
	for _, r := range usageResults {
		usedMap[r.ProductID] = r.Total
	}

	// If no OUT activity in 28 days, return an empty map.
	if len(usedMap) == 0 {
		return make(map[uuid.UUID]int64), nil
	}

	// Step 2: Query current stock (all-time SUM IN - SUM OUT) per product.
	type StockResult struct {
		ProductID uuid.UUID
		Total     int64
	}
	var stockResults []StockResult
	err = r.db.Model(&InventoryMovement{}).
		Select("product_id, COALESCE(SUM(CASE WHEN type = ? THEN quantity WHEN type = ? THEN -quantity ELSE quantity END),0) as total", MovementIn, MovementOut).
		Where("branch_id = ?", branchID).
		Group("product_id").
		Scan(&stockResults).Error
	if err != nil {
		return nil, err
	}

	stockMap := make(map[uuid.UUID]int64, len(stockResults))
	for _, s := range stockResults {
		stockMap[s.ProductID] = s.Total
	}

	// Step 3: Calculate recommended order quantity for each product with activity.
	//   daily_avg      = total_used_28days / 28
	//   projected_7d   = daily_avg * 7 * 1.2  (20% safety buffer)
	//   order_qty      = max(0, projected_7d - current_stock)
	predMap := make(map[uuid.UUID]int64)
	for productID, used := range usedMap {
		dailyAvg := float64(used) / 28.0
		projected7d := dailyAvg * 7 * 1.2
		currentStock := float64(stockMap[productID])
		orderQty := math.Max(0, projected7d-currentStock)
		if orderQty > 0 {
			predMap[productID] = int64(math.Ceil(orderQty))
		}
	}
	return predMap, nil
}
