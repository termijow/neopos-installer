package printers

import (
	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB) {
	controller := NewController(NewService(NewRepository(db)))
	router.Post("/print/ticket", controller.Ticket)
	router.Post("/print/kitchen", controller.Kitchen)
	router.Post("/print/invoice", controller.Invoice)
}
