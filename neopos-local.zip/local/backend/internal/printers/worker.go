package printers

import (
	"encoding/json"
	"fmt"
	"log"
	"time"

	"restaurant-pos-api/internal/printers/escpos"
)

func StartWorker(repo Repository, printerType string, address string, port int) {
	log.Println("Starting printer worker...")
	for {
		jobs, err := repo.GetQueuedJobs(10)
		if err != nil {
			log.Printf("Error fetching queued print jobs: %v", err)
			time.Sleep(5 * time.Second)
			continue
		}

		for _, job := range jobs {
			err := processJob(job, printerType, address, port)
			if err != nil {
				log.Printf("Error processing print job %s: %v", job.ID, err)
				repo.UpdateStatus(job.ID.String(), "FAILED")
			} else {
				repo.UpdateStatus(job.ID.String(), "COMPLETED")
			}
		}

		time.Sleep(2 * time.Second)
	}
}

func processJob(job *PrintJob, printerType string, address string, port int) error {
	var payload map[string]interface{}
	if err := json.Unmarshal([]byte(job.Payload), &payload); err != nil {
		return err
	}

	var data []byte
	switch job.Type {
	case "TICKET", "INVOICE":
		data = escpos.FormatTicket(payload)
	case "KITCHEN":
		data = escpos.FormatKitchen(payload)
	case "REPORT_Z", "REPORT_X":
		data = escpos.FormatReport(fmt.Sprintf("REPORTE %s", job.Type), payload)
	default:
		return fmt.Errorf("unknown print job type: %s", job.Type)
	}

	var device escpos.PrinterDevice
	var err error

	if printerType == "network" {
		device, err = escpos.NewNetworkPrinter(address, port)
	} else if printerType == "usb" {
		device, err = escpos.NewUSBPrinter(address)
	} else {
		return fmt.Errorf("unsupported printer type: %s", printerType)
	}

	if err != nil {
		return err
	}
	defer device.Close()

	return device.Write(data)
}
