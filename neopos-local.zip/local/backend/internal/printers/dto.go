package printers

import "github.com/google/uuid"

type PrintRequest struct {
	BranchID uuid.UUID `json:"branch_id"`
	RefID    uuid.UUID `json:"ref_id"`
	Payload  string    `json:"payload"`
}
