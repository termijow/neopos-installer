package printers

type Service interface { Ticket(PrintRequest) (*PrintJob, error); Kitchen(PrintRequest) (*PrintJob, error); Invoice(PrintRequest) (*PrintJob, error) }
type service struct{ repo Repository }
func NewService(repo Repository) Service { return &service{repo: repo} }
func (s *service) Ticket(req PrintRequest) (*PrintJob, error) { return s.queue("TICKET", req) }
func (s *service) Kitchen(req PrintRequest) (*PrintJob, error) { return s.queue("KITCHEN", req) }
func (s *service) Invoice(req PrintRequest) (*PrintJob, error) { return s.queue("INVOICE", req) }
func (s *service) queue(kind string, req PrintRequest) (*PrintJob, error) { item := &PrintJob{Type: kind, RefID: req.RefID, Payload: req.Payload, Status: "QUEUED"}; item.BranchID = req.BranchID; return item, s.repo.Queue(item) }
