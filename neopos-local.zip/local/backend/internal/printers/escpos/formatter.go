package escpos

import (
	"bytes"
	"fmt"
	"time"
)

// ESC/POS Commands
var (
	InitPrinter = []byte{0x1B, 0x40}
	LineFeed    = []byte{0x0A}
	CutPaper    = []byte{0x1D, 0x56, 0x42, 0x00}
	BoldOn      = []byte{0x1B, 0x45, 0x01}
	BoldOff     = []byte{0x1B, 0x45, 0x00}
	AlignCenter = []byte{0x1B, 0x61, 0x01}
	AlignLeft   = []byte{0x1B, 0x61, 0x00}
	AlignRight  = []byte{0x1B, 0x61, 0x02}
	TextSizeNormal = []byte{0x1D, 0x21, 0x00}
	TextSizeDouble = []byte{0x1D, 0x21, 0x11}
)

type Formatter struct {
	buffer *bytes.Buffer
}

func NewFormatter() *Formatter {
	f := &Formatter{buffer: new(bytes.Buffer)}
	f.buffer.Write(InitPrinter)
	return f
}

func (f *Formatter) WriteText(text string) {
	f.buffer.WriteString(text)
}

func (f *Formatter) WriteLine(text string) {
	f.buffer.WriteString(text)
	f.buffer.Write(LineFeed)
}

func (f *Formatter) FeedAndCut() {
	f.buffer.Write(LineFeed)
	f.buffer.Write(LineFeed)
	f.buffer.Write(LineFeed)
	f.buffer.Write(CutPaper)
}

func (f *Formatter) Bold(enable bool) {
	if enable {
		f.buffer.Write(BoldOn)
	} else {
		f.buffer.Write(BoldOff)
	}
}

func (f *Formatter) AlignCenter() {
	f.buffer.Write(AlignCenter)
}

func (f *Formatter) AlignLeft() {
	f.buffer.Write(AlignLeft)
}

func (f *Formatter) AlignRight() {
	f.buffer.Write(AlignRight)
}

func (f *Formatter) Bytes() []byte {
	return f.buffer.Bytes()
}

func getFloat(val interface{}) float64 {
	switch v := val.(type) {
	case float64:
		return v
	case int:
		return float64(v)
	case int64:
		return float64(v)
	case float32:
		return float64(v)
	default:
		return 0
	}
}

func getString(val interface{}) string {
	if s, ok := val.(string); ok {
		return s
	}
	return ""
}

// FormatTicket generates a raw ESC/POS binary ticket
func FormatTicket(data map[string]interface{}) []byte {
	f := NewFormatter()
	f.AlignCenter()
	f.Bold(true)
	f.buffer.Write(TextSizeDouble)
	f.WriteLine("NEOPOS - TICKET")
	f.buffer.Write(TextSizeNormal)
	f.Bold(false)
	f.WriteLine("--------------------------------")
	f.AlignLeft()
	
	if items, ok := data["items"].([]interface{}); ok {
		for _, item := range items {
			if m, ok := item.(map[string]interface{}); ok {
				name := getString(m["name"])
				qty := getFloat(m["quantity"])
				price := getFloat(m["price"])
				f.WriteLine(fmt.Sprintf("%v x %s - $%.2f", qty, name, price))
			}
		}
	}
	f.WriteLine("--------------------------------")
	if totalVal, ok := data["total"]; ok && totalVal != nil {
		total := getFloat(totalVal)
		f.AlignRight()
		f.Bold(true)
		f.WriteLine(fmt.Sprintf("TOTAL: $%.2f", total))
		f.Bold(false)
	}
	f.FeedAndCut()
	return f.Bytes()
}

// FormatKitchen generates a raw ESC/POS binary kitchen order
func FormatKitchen(data map[string]interface{}) []byte {
	f := NewFormatter()
	f.AlignCenter()
	f.Bold(true)
	f.buffer.Write(TextSizeDouble)
	f.WriteLine("COMANDA COCINA")
	f.buffer.Write(TextSizeNormal)
	f.Bold(false)
	f.WriteLine(fmt.Sprintf("Fecha: %s", time.Now().Format("2006-01-02 15:04:05")))
	f.WriteLine("--------------------------------")
	f.AlignLeft()
	
	if items, ok := data["items"].([]interface{}); ok {
		for _, item := range items {
			if m, ok := item.(map[string]interface{}); ok {
				name := getString(m["name"])
				qty := getFloat(m["quantity"])
				f.WriteLine(fmt.Sprintf("[ ] %v x %s", qty, name))
			}
		}
	}
	f.FeedAndCut()
	return f.Bytes()
}

// FormatReport generates Z or X reports
func FormatReport(title string, data map[string]interface{}) []byte {
	f := NewFormatter()
	f.AlignCenter()
	f.Bold(true)
	f.WriteLine(title)
	f.Bold(false)
	f.WriteLine("--------------------------------")
	f.AlignLeft()
	
	for k, v := range data {
		f.WriteLine(fmt.Sprintf("%s: %v", k, v))
	}
	f.FeedAndCut()
	return f.Bytes()
}
