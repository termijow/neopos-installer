package escpos

import (
	"fmt"
	"net"
	"os"
	"time"
)

type PrinterDevice interface {
	Write(data []byte) error
	Close() error
}

// NetworkPrinter implements TCP connection to a printer
type NetworkPrinter struct {
	IP   string
	Port int
	conn net.Conn
}

func NewNetworkPrinter(ip string, port int) (*NetworkPrinter, error) {
	conn, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", ip, port), 5*time.Second)
	if err != nil {
		return nil, err
	}
	return &NetworkPrinter{IP: ip, Port: port, conn: conn}, nil
}

func (np *NetworkPrinter) Write(data []byte) error {
	_, err := np.conn.Write(data)
	return err
}

func (np *NetworkPrinter) Close() error {
	return np.conn.Close()
}

// USBPrinter implements writing to a raw USB port (e.g. /dev/usb/lp0)
type USBPrinter struct {
	Path string
	file *os.File
}

func NewUSBPrinter(path string) (*USBPrinter, error) {
	file, err := os.OpenFile(path, os.O_WRONLY, 0)
	if err != nil {
		return nil, err
	}
	return &USBPrinter{Path: path, file: file}, nil
}

func (up *USBPrinter) Write(data []byte) error {
	_, err := up.file.Write(data)
	return err
}

func (up *USBPrinter) Close() error {
	return up.file.Close()
}
