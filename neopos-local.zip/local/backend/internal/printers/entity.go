package printers

import (
	"restaurant-pos-api/pkg/model"

	"github.com/google/uuid"
)

type PrintJob struct {
	model.Base
	model.BranchScoped
	Type    string    `json:"type" gorm:"size:40;not null;index"`
	RefID   uuid.UUID `json:"ref_id" gorm:"type:uuid;index"`
	Payload string    `json:"payload" gorm:"type:jsonb;default:'{}'"`
	Status  string    `json:"status" gorm:"size:40;not null;default:QUEUED"`
}
