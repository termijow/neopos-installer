package printers

import "gorm.io/gorm"

type Repository interface {
	Queue(*PrintJob) error
	GetQueuedJobs(limit int) ([]*PrintJob, error)
	UpdateStatus(id string, status string) error
}
type gormRepository struct{ db *gorm.DB }
func NewRepository(db *gorm.DB) Repository { return &gormRepository{db: db} }
func (r *gormRepository) Queue(item *PrintJob) error { return r.db.Create(item).Error }

func (r *gormRepository) GetQueuedJobs(limit int) ([]*PrintJob, error) {
	var jobs []*PrintJob
	err := r.db.Where("status = ?", "QUEUED").Limit(limit).Find(&jobs).Error
	return jobs, err
}

func (r *gormRepository) UpdateStatus(id string, status string) error {
	return r.db.Model(&PrintJob{}).Where("id = ?", id).Update("status", status).Error
}
