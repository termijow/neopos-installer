package printers

import (
	"restaurant-pos-api/pkg/response"

	"github.com/gofiber/fiber/v2"
)

type Controller struct{ service Service }
func NewController(service Service) *Controller { return &Controller{service: service} }
func (h *Controller) Ticket(c *fiber.Ctx) error { return h.print(c, h.service.Ticket) }
func (h *Controller) Kitchen(c *fiber.Ctx) error { return h.print(c, h.service.Kitchen) }
func (h *Controller) Invoice(c *fiber.Ctx) error { return h.print(c, h.service.Invoice) }
func (h *Controller) print(c *fiber.Ctx, fn func(PrintRequest) (*PrintJob, error)) error { var req PrintRequest; if err := c.BodyParser(&req); err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; item, err := fn(req); if err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; return response.Created(c, item) }
