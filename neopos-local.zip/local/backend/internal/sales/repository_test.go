package sales

import (
	"testing"

	"github.com/google/uuid"
	"github.com/stretchr/testify/require"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"

	"restaurant-pos-api/internal/sync"
	"restaurant-pos-api/pkg/model"
)

func TestQueueElectronicInvoiceGeneratesQueueID(t *testing.T) {
	db, err := gorm.Open(sqlite.Open(":memory:"), &gorm.Config{})
	require.NoError(t, err)
	require.NoError(t, db.AutoMigrate(&syncqueue.SyncQueue{}))

	sale := &Sale{Base: model.Base{ID: uuid.New()}}
	repo := &gormRepository{db: db}

	require.NoError(t, repo.QueueElectronicInvoice(sale))
	require.NoError(t, repo.QueueElectronicInvoice(sale))

	var queued syncqueue.SyncQueue
	require.NoError(t, db.First(&queued).Error)
	require.NotEqual(t, uuid.Nil, queued.ID)
	require.Equal(t, sale.ID.String(), queued.EntityID)
	var count int64
	require.NoError(t, db.Model(&syncqueue.SyncQueue{}).Count(&count).Error)
	require.Equal(t, int64(1), count)
}
