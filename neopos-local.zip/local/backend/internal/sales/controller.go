package sales

import (
	"restaurant-pos-api/pkg/response"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
)

type Controller struct{ service Service }
func NewController(service Service) *Controller { return &Controller{service: service} }
func (h *Controller) Register(c *fiber.Ctx) error {
	var req RegisterSaleRequest
	if err := c.BodyParser(&req); err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}
	if role, ok := c.Locals("role").(string); ok {
		req.UserRole = role
	}
	// Get branch_id from JWT token
	if branchID := c.Locals("branch_id"); branchID != nil {
		switch v := branchID.(type) {
		case string:
			req.BranchID = v
		case uuid.UUID:
			req.BranchID = v.String()
		}
	}
	item, err := h.service.Register(req)
	if err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}
	return response.Created(c, item)
}
func (h *Controller) Get(c *fiber.Ctx) error { id, err := uuid.Parse(c.Params("id")); if err != nil { return response.Error(c, fiber.StatusBadRequest, "invalid sale id") }; item, err := h.service.Get(id); if err != nil { return response.Error(c, fiber.StatusNotFound, err.Error()) }; return response.OK(c, item) }
func (h *Controller) List(c *fiber.Ctx) error {
	branchID := ""
	if bid := c.Locals("branch_id"); bid != nil {
		switch v := bid.(type) {
		case string:
			branchID = v
		case uuid.UUID:
			branchID = v.String()
		}
	}
	items, err := h.service.List(branchID)
	if err != nil { return response.Error(c, fiber.StatusInternalServerError, err.Error()) }
	return response.OK(c, items) 
}

func (h *Controller) CalculateSplit(c *fiber.Ctx) error {
	var req SplitBillRequest
	if err := c.BodyParser(&req); err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}
	result, err := h.service.CalculateSplit(req)
	if err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}
	return response.OK(c, result)
}

func (h *Controller) CalculateSplitByItems(c *fiber.Ctx) error {
	var req SplitBillItemRequest
	if err := c.BodyParser(&req); err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}
	result, err := h.service.CalculateSplitByItems(req)
	if err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}
	return response.OK(c, result)
}

func (h *Controller) MarkElectronic(c *fiber.Ctx) error {
	id, err := uuid.Parse(c.Params("id"))
	if err != nil {
		return response.Error(c, fiber.StatusBadRequest, "invalid sale id")
	}
	if err := h.service.MarkElectronic(id); err != nil {
		return response.Error(c, fiber.StatusInternalServerError, err.Error())
	}
	return response.OK(c, fiber.Map{"message": "Factura marcada como electrónica exitosamente"})
}
