package sales

import (
	"errors"

	"restaurant-pos-api/internal/inventory"
	"restaurant-pos-api/internal/recipes"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Service interface {
	Register(RegisterSaleRequest) (*Sale, error)
	Get(uuid.UUID) (*Sale, error)
	List(branchID string) ([]Sale, error)
	CalculateSplit(req SplitBillRequest) ([]BillCalculation, error)
	CalculateSplitByItems(req SplitBillItemRequest) (BillCalculation, error)
	MarkElectronic(id uuid.UUID) error
}

type service struct {
	repo      Repository
	inventory inventory.Service
	recipes   recipes.Service
}

func NewService(repo Repository, inventory inventory.Service, recipes recipes.Service) Service {
	return &service{repo: repo, inventory: inventory, recipes: recipes}
}

func (s *service) Register(req RegisterSaleRequest) (*Sale, error) {
	if len(req.Items) == 0 {
		return nil, errors.New("sale requires at least one item")
	}
	if req.PaymentMethod == "" {
		req.PaymentMethod = PaymentCash
	}

	branchID, _ := uuid.Parse(req.BranchID)
	orderID, _ := uuid.Parse(req.OrderID)
	cashSessionID, _ := uuid.Parse(req.CashSessionID)

	if cashSessionID == uuid.Nil {
		cashSessionID, _ = s.repo.GetActiveCashSession(req.BranchID)
	}

	if req.UserRole == "cajero" || req.UserRole == "cashier" {
		for _, itemReq := range req.Items {
			productID, _ := uuid.Parse(itemReq.ProductID)
			dbPrice, err := s.repo.GetProductPrice(productID)
			if err != nil {
				return nil, err
			}
			if dbPrice != itemReq.UnitPrice {
				return nil, errors.New("price modification not allowed for cashier role")
			}
		}
	}

	sale := &Sale{OrderID: orderID, CashSessionID: cashSessionID, PaymentMethod: req.PaymentMethod, Discount: req.Discount, Tip: req.Tip}
	sale.BranchID = branchID
	for _, itemReq := range req.Items {
		productID, _ := uuid.Parse(itemReq.ProductID)
		total := int64(itemReq.Quantity) * itemReq.UnitPrice
		sale.Subtotal += total
		sale.Items = append(sale.Items, SaleItem{ProductID: productID, Name: itemReq.Name, Quantity: itemReq.Quantity, UnitPrice: itemReq.UnitPrice, Total: total})
	}
	sale.Total = sale.Subtotal - sale.Discount + sale.Tip

	err := s.repo.ExecuteTx(func(tx *gorm.DB) error {
		if err := tx.Create(sale).Error; err != nil {
			return err
		}

		for _, item := range sale.Items {
			recipe, err := s.recipes.GetByProductID(item.ProductID)
			if err == nil && recipe != nil && len(recipe.Items) > 0 {
				for _, ri := range recipe.Items {
					mov := inventory.InventoryMovement{
						ProductID:   ri.InventoryItem,
						Type:        "OUT",
						Quantity:    int(ri.Quantity) * item.Quantity,
						Reason:      "sale_recipe",
						ReferenceID: sale.ID,
					}
					mov.BranchID = sale.BranchID
					if err := tx.Create(&mov).Error; err != nil {
						return err
					}
				}
			} else {
				mov := inventory.InventoryMovement{
					ProductID:   item.ProductID,
					Type:        "OUT",
					Quantity:    item.Quantity,
					Reason:      "sale",
					ReferenceID: sale.ID,
				}
				mov.BranchID = sale.BranchID
				if err := tx.Create(&mov).Error; err != nil {
					return err
				}
			}
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return sale, nil
}

func (s *service) Get(id uuid.UUID) (*Sale, error)      { return s.repo.FindByID(id) }
func (s *service) List(branchID string) ([]Sale, error) { return s.repo.List(branchID) }

func (s *service) CalculateSplit(req SplitBillRequest) ([]BillCalculation, error) {
	if req.Parts <= 0 {
		return nil, errors.New("parts must be greater than 0")
	}
	basePart := req.Subtotal / int64(req.Parts)
	remainder := req.Subtotal % int64(req.Parts)

	var result []BillCalculation
	for i := 0; i < req.Parts; i++ {
		subtotal := basePart
		if i < int(remainder) {
			subtotal += 1
		}
		tip := int64(float64(subtotal) * 0.10)
		result = append(result, BillCalculation{
			Subtotal:     subtotal,
			SuggestedTip: tip,
			Total:        subtotal + tip,
		})
	}
	return result, nil
}

func (s *service) CalculateSplitByItems(req SplitBillItemRequest) (BillCalculation, error) {
	var subtotal int64
	for _, item := range req.Items {
		subtotal += int64(item.Quantity) * item.UnitPrice
	}
	tip := int64(float64(subtotal) * 0.10)
	return BillCalculation{
		Subtotal:     subtotal,
		SuggestedTip: tip,
		Total:        subtotal + tip,
	}, nil
}

func (s *service) MarkElectronic(id uuid.UUID) error {
	sale, err := s.repo.FindByID(id)
	if err != nil {
		return err
	}
	// A previous attempt may have marked the sale before queue insertion failed.
	// Re-enqueue that sale, while avoiding duplicate events when the request is
	// retried after a successful insert.
	if sale.IsElectronic && sale.ElectronicStatus == "PENDING" {
		return s.repo.QueueElectronicInvoice(sale)
	}
	if sale.IsElectronic && sale.ElectronicStatus != "ERROR" {
		return nil
	}

	// Queue first so a database failure does not leave the sale marked as
	// electronic without a corresponding synchronization event.
	if err := s.repo.QueueElectronicInvoice(sale); err != nil {
		return err
	}
	sale.IsElectronic = true
	sale.ElectronicStatus = "PENDING"
	return s.repo.Update(sale)
}
