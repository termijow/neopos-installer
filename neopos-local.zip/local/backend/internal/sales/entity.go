package sales

import (
	"restaurant-pos-api/pkg/model"

	"github.com/google/uuid"
)

const (
	PaymentCash       = "CASH"
	PaymentCreditCard = "CREDIT_CARD"
	PaymentDebitCard  = "DEBIT_CARD"
	PaymentTransfer   = "TRANSFER"
	PaymentQR         = "QR"
)

type Sale struct {
	model.Base
	model.BranchScoped
	OrderID       uuid.UUID  `json:"order_id" gorm:"type:uuid;index"`
	CashSessionID uuid.UUID  `json:"cash_session_id" gorm:"type:uuid;index"`
	PaymentMethod string     `json:"payment_method" gorm:"size:40;not null"`
	Subtotal      int64      `json:"subtotal" gorm:"not null"`
	Discount      int64      `json:"discount"`
	Tip           int64      `json:"tip"`
	Total            int64      `json:"total" gorm:"not null"`
	IsElectronic     bool       `json:"is_electronic"`
	ElectronicStatus string     `json:"electronic_status" gorm:"size:20;default:'NONE'"` // NONE, PENDING, GENERATED, ERROR
	Items            []SaleItem `json:"items" gorm:"foreignKey:SaleID"`
}

type SaleItem struct {
	model.Base
	SaleID    uuid.UUID `json:"sale_id" gorm:"type:uuid;index;not null"`
	ProductID uuid.UUID `json:"product_id" gorm:"type:uuid;index;not null"`
	Name      string    `json:"name" gorm:"size:180;not null"`
	Quantity  int       `json:"quantity" gorm:"not null"`
	UnitPrice int64     `json:"unit_price" gorm:"not null"`
	Total     int64     `json:"total" gorm:"not null"`
}
