package sales

type RegisterSaleRequest struct {
	BranchID      string                `json:"branch_id"`
	OrderID       string                `json:"order_id"`
	CashSessionID string                `json:"cash_session_id"`
	PaymentMethod string                `json:"payment_method"`
	Discount      int64                 `json:"discount"`
	Tip           int64                 `json:"tip"`
	Items         []RegisterSaleItemDTO `json:"items"`
	UserRole      string                `json:"-"`
}

type RegisterSaleItemDTO struct {
	ProductID string `json:"product_id"`
	Name      string `json:"name"`
	Quantity  int    `json:"quantity"`
	UnitPrice int64  `json:"unit_price"`
}

type SplitBillRequest struct {
	Subtotal int64 `json:"subtotal"`
	Parts    int   `json:"parts"`
}

type SplitBillItemRequest struct {
	Items []RegisterSaleItemDTO `json:"items"`
}

type BillCalculation struct {
	Subtotal     int64 `json:"subtotal"`
	SuggestedTip int64 `json:"suggested_tip"`
	Total        int64 `json:"total"`
}
