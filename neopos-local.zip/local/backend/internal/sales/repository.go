package sales

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface {
	ExecuteTx(func(*gorm.DB) error) error
	Create(*Sale) error
	FindByID(uuid.UUID) (*Sale, error)
	List(string) ([]Sale, error)
	GetProductPrice(uuid.UUID) (int64, error)
	Update(*Sale) error
	QueueElectronicInvoice(*Sale) error
	GetActiveCashSession(string) (uuid.UUID, error)
}

type gormRepository struct{ db *gorm.DB }

func NewRepository(db *gorm.DB) Repository { return &gormRepository{db: db} }

func (r *gormRepository) ExecuteTx(fn func(*gorm.DB) error) error { return r.db.Transaction(fn) }

func (r *gormRepository) Create(item *Sale) error { return r.db.Create(item).Error }

func (r *gormRepository) FindByID(id uuid.UUID) (*Sale, error) {
	var item Sale
	if err := r.db.Preload("Items").First(&item, "id = ?", id).Error; err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *gormRepository) Update(item *Sale) error { return r.db.Save(item).Error }

func (r *gormRepository) List(branchID string) ([]Sale, error) {
	var items []Sale
	err := r.db.Preload("Items").Where("branch_id = ?", branchID).Order("created_at desc").Limit(500).Find(&items).Error
	return items, err
}

func (r *gormRepository) GetProductPrice(id uuid.UUID) (int64, error) {
	var price int64
	err := r.db.Table("products").Where("id = ?", id).Select("price").Row().Scan(&price)
	return price, err
}

func (r *gormRepository) GetActiveCashSession(branchID string) (uuid.UUID, error) {
	var id uuid.UUID
	bid, err := uuid.Parse(branchID)
	if err != nil {
		return uuid.Nil, err
	}
	err = r.db.Table("cash_register_sessions").
		Where("branch_id = ? AND status = 'OPEN'", bid).
		Select("id").
		Row().Scan(&id)
	return id, err
}

func (r *gormRepository) QueueElectronicInvoice(item *Sale) error {
	var existing int64
	if err := r.db.Table("sync_queue").Where(
		"entity = ? AND entity_id = ? AND operation = ? AND status IN ?",
		"electronic_invoices", item.ID.String(), "INSERT", []string{"PENDING", "SYNCED"},
	).Count(&existing).Error; err != nil {
		return err
	}
	if existing > 0 {
		return nil
	}

	payload := `{"sale_id":"` + item.ID.String() + `","type":"electronic_invoice"}`
	queueItem := map[string]interface{}{
		"id":         uuid.New(),
		"entity":     "electronic_invoices",
		"entity_id":  item.ID.String(),
		"operation":  "INSERT",
		"payload":    payload,
		"status":     "PENDING",
		"created_at": item.CreatedAt,
		"updated_at": item.UpdatedAt,
	}
	return r.db.Table("sync_queue").Create(queueItem).Error
}
