package sales

import (
	"restaurant-pos-api/internal/inventory"
	"restaurant-pos-api/internal/recipes"

	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB) {
	inventoryService := inventory.NewService(inventory.NewRepository(db))
	recipesService := recipes.NewService(recipes.NewRepository(db))
	controller := NewController(NewService(NewRepository(db), inventoryService, recipesService))
	router.Post("/sales", controller.Register)
	router.Get("/sales", controller.List)
	router.Get("/sales/:id", controller.Get)
	router.Post("/sales/split", controller.CalculateSplit)
	router.Post("/sales/split-items", controller.CalculateSplitByItems)
	router.Post("/sales/:id/electronic", controller.MarkElectronic)
}
