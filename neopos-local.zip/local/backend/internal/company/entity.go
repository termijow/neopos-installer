package company

import "restaurant-pos-api/pkg/model"

type Company struct {
	model.Base
	Name      string `json:"name" gorm:"size:180;not null"`
	NIT       string `json:"nit" gorm:"size:40;uniqueIndex;not null"`
	Email     string `json:"email" gorm:"size:180"`
	Phone     string `json:"phone" gorm:"size:60"`
	Address   string `json:"address" gorm:"size:255"`
	City      string `json:"city" gorm:"size:120"`
	Active    bool   `json:"active" gorm:"default:true"`
}
