package company

import "github.com/google/uuid"

type Service interface {
	List() ([]Company, error)
	Create(UpsertCompanyRequest) (*Company, error)
	Update(uuid.UUID, UpsertCompanyRequest) (*Company, error)
	Delete(uuid.UUID) error
}

type service struct{ repo Repository }

func NewService(repo Repository) Service { return &service{repo: repo} }

func (s *service) List() ([]Company, error) { return s.repo.List() }

func (s *service) Create(req UpsertCompanyRequest) (*Company, error) {
	active := true
	if req.Active != nil {
		active = *req.Active
	}
	item := &Company{Name: req.Name, NIT: req.NIT, Email: req.Email, Phone: req.Phone, Address: req.Address, City: req.City, Active: active}
	return item, s.repo.Create(item)
}

func (s *service) Update(id uuid.UUID, req UpsertCompanyRequest) (*Company, error) {
	item, err := s.repo.FindByID(id)
	if err != nil {
		return nil, err
	}
	if req.Name != "" { item.Name = req.Name }
	if req.NIT != "" { item.NIT = req.NIT }
	item.Email, item.Phone, item.Address, item.City = req.Email, req.Phone, req.Address, req.City
	if req.Active != nil { item.Active = *req.Active }
	return item, s.repo.Update(item)
}

func (s *service) Delete(id uuid.UUID) error { return s.repo.Delete(id) }
