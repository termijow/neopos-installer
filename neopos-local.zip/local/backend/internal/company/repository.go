package company

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface {
	List() ([]Company, error)
	Create(*Company) error
	FindByID(uuid.UUID) (*Company, error)
	Update(*Company) error
	Delete(uuid.UUID) error
}

type gormRepository struct{ db *gorm.DB }

func NewRepository(db *gorm.DB) Repository { return &gormRepository{db: db} }

func (r *gormRepository) List() ([]Company, error) {
	var items []Company
	err := r.db.Order("created_at desc").Find(&items).Error
	return items, err
}

func (r *gormRepository) Create(item *Company) error { return r.db.Create(item).Error }

func (r *gormRepository) FindByID(id uuid.UUID) (*Company, error) {
	var item Company
	if err := r.db.First(&item, "id = ?", id).Error; err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *gormRepository) Update(item *Company) error { return r.db.Save(item).Error }

func (r *gormRepository) Delete(id uuid.UUID) error { return r.db.Delete(&Company{}, "id = ?", id).Error }
