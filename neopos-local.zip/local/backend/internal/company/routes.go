package company

import (
	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB) {
	controller := NewController(NewService(NewRepository(db)))
	router.Get("/company", controller.List)
	router.Post("/company", controller.Create)
	router.Put("/company/:id", controller.Update)
	router.Delete("/company/:id", controller.Delete)
}
