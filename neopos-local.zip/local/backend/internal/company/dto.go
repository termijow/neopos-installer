package company

type UpsertCompanyRequest struct {
	Name    string `json:"name"`
	NIT     string `json:"nit"`
	Email   string `json:"email"`
	Phone   string `json:"phone"`
	Address string `json:"address"`
	City    string `json:"city"`
	Active  *bool  `json:"active"`
}
