package invoices

import (
	"restaurant-pos-api/pkg/model"

	"github.com/google/uuid"
)

const (
	InvoiceStatusDraft  = "DRAFT"
	InvoiceStatusIssued = "ISSUED"
	InvoiceStatusVoid   = "VOID"
)

type Invoice struct {
	model.Base
	model.BranchScoped
	SaleID   uuid.UUID `json:"sale_id" gorm:"type:uuid;index;not null"`
	Number   string    `json:"number" gorm:"size:80;uniqueIndex;not null"`
	Subtotal int64     `json:"subtotal" gorm:"not null"`
	Tax      int64     `json:"tax"`
	Total    int64     `json:"total" gorm:"not null"`
	CUFE     string    `json:"cufe" gorm:"size:255;index"`
	Status   string    `json:"status" gorm:"size:40;not null;default:DRAFT;index"`
}
