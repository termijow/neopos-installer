package invoices

import (
	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB) {
	controller := NewController(NewService(NewRepository(db)))
	router.Post("/invoices", controller.Create)
	router.Get("/invoices/:id", controller.Get)
}
