package invoices

import "github.com/google/uuid"

type Service interface { Create(CreateInvoiceRequest) (*Invoice, error); Get(uuid.UUID) (*Invoice, error); MarkIssued(uuid.UUID, string) (*Invoice, error) }
type service struct{ repo Repository }
func NewService(repo Repository) Service { return &service{repo: repo} }
func (s *service) Create(req CreateInvoiceRequest) (*Invoice, error) { item := &Invoice{SaleID: req.SaleID, Number: req.Number, Subtotal: req.Subtotal, Tax: req.Tax, Total: req.Total, Status: InvoiceStatusDraft}; item.BranchID = req.BranchID; return item, s.repo.Create(item) }
func (s *service) Get(id uuid.UUID) (*Invoice, error) { return s.repo.FindByID(id) }
func (s *service) MarkIssued(id uuid.UUID, cufe string) (*Invoice, error) { item, err := s.repo.FindByID(id); if err != nil { return nil, err }; item.CUFE = cufe; item.Status = InvoiceStatusIssued; return item, s.repo.Update(item) }
