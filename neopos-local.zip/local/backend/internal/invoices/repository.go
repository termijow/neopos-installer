package invoices

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface { Create(*Invoice) error; FindByID(uuid.UUID) (*Invoice, error); Update(*Invoice) error }
type gormRepository struct{ db *gorm.DB }
func NewRepository(db *gorm.DB) Repository { return &gormRepository{db: db} }
func (r *gormRepository) Create(item *Invoice) error { return r.db.Create(item).Error }
func (r *gormRepository) FindByID(id uuid.UUID) (*Invoice, error) { var item Invoice; if err := r.db.First(&item, "id = ?", id).Error; err != nil { return nil, err }; return &item, nil }
func (r *gormRepository) Update(item *Invoice) error { return r.db.Save(item).Error }
