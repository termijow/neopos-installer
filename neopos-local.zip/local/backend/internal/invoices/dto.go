package invoices

import "github.com/google/uuid"

type CreateInvoiceRequest struct {
	BranchID uuid.UUID `json:"branch_id"`
	SaleID   uuid.UUID `json:"sale_id"`
	Number   string    `json:"number"`
	Subtotal int64     `json:"subtotal"`
	Tax      int64     `json:"tax"`
	Total    int64     `json:"total"`
}
