package kitchen

import (
	"sync"
	"github.com/google/uuid"
)

type Service interface {
	List() ([]KitchenOrder, error)
	Create(CreateKitchenOrderRequest) (*KitchenOrder, error)
	UpdateStatus(uuid.UUID, UpdateKitchenStatusRequest) (*KitchenOrder, error)
	Subscribe() <-chan KitchenOrder
	Unsubscribe(<-chan KitchenOrder)
}

type service struct {
	repo    Repository
	clients []chan KitchenOrder
	mu      sync.Mutex
}

func NewService(repo Repository) Service { return &service{repo: repo} }

func (s *service) Subscribe() <-chan KitchenOrder {
	s.mu.Lock()
	defer s.mu.Unlock()
	ch := make(chan KitchenOrder, 10)
	s.clients = append(s.clients, ch)
	return ch
}

func (s *service) Unsubscribe(ch <-chan KitchenOrder) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i, c := range s.clients {
		if c == ch {
			s.clients = append(s.clients[:i], s.clients[i+1:]...)
			close(c)
			break
		}
	}
}

func (s *service) notify(order KitchenOrder) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, ch := range s.clients {
		select {
		case ch <- order:
		default:
		}
	}
}

func (s *service) List() ([]KitchenOrder, error) { return s.repo.List() }
func (s *service) Create(req CreateKitchenOrderRequest) (*KitchenOrder, error) {
	item := &KitchenOrder{OrderID: req.OrderID, Status: StatusPending, Notes: req.Notes}
	item.BranchID = req.BranchID
	if err := s.repo.Create(item); err != nil {
		return nil, err
	}
	s.notify(*item)
	return item, nil
}
func (s *service) UpdateStatus(id uuid.UUID, req UpdateKitchenStatusRequest) (*KitchenOrder, error) {
	item, err := s.repo.FindByID(id)
	if err != nil {
		return nil, err
	}
	item.Status = req.Status
	if err := s.repo.Update(item); err != nil {
		return nil, err
	}
	s.notify(*item)
	return item, nil
}
