package kitchen

import (
	"bufio"
	"encoding/json"
	"fmt"
	"restaurant-pos-api/pkg/response"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
)

type Controller struct{ service Service }
func NewController(service Service) *Controller { return &Controller{service: service} }
func (h *Controller) List(c *fiber.Ctx) error { items, err := h.service.List(); if err != nil { return response.Error(c, fiber.StatusInternalServerError, err.Error()) }; return response.OK(c, items) }
func (h *Controller) UpdateStatus(c *fiber.Ctx) error { id, err := uuid.Parse(c.Params("id")); if err != nil { return response.Error(c, fiber.StatusBadRequest, "invalid kitchen order id") }; var req UpdateKitchenStatusRequest; if err := c.BodyParser(&req); err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; item, err := h.service.UpdateStatus(id, req); if err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; return response.OK(c, item) }

func (h *Controller) SSE(c *fiber.Ctx) error {
	c.Set("Content-Type", "text/event-stream")
	c.Set("Cache-Control", "no-cache")
	c.Set("Connection", "keep-alive")
	c.Set("Transfer-Encoding", "chunked")

	ch := h.service.Subscribe()
	defer h.service.Unsubscribe(ch)

	c.Context().SetBodyStreamWriter(func(w *bufio.Writer) {
		for {
			select {
			case <-c.Context().Done():
				return
			case order, ok := <-ch:
				if !ok {
					return
				}
				data, _ := json.Marshal(order)
				fmt.Fprintf(w, "event: update\ndata: %s\n\n", data)
				if err := w.Flush(); err != nil {
					return
				}
			}
		}
	})
	return nil
}
