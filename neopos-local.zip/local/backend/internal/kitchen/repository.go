package kitchen

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface {
	List() ([]KitchenOrder, error)
	Create(*KitchenOrder) error
	FindByID(uuid.UUID) (*KitchenOrder, error)
	Update(*KitchenOrder) error
}

type gormRepository struct{ db *gorm.DB }
func NewRepository(db *gorm.DB) Repository { return &gormRepository{db: db} }
func (r *gormRepository) List() ([]KitchenOrder, error) {
	var items []KitchenOrder
	cutoff := time.Now().Add(-3 * time.Minute)
	err := r.db.
		Where("status != ? OR updated_at > ?", StatusServed, cutoff).
		Order("created_at asc").
		Find(&items).Error
	return items, err
}
func (r *gormRepository) Create(item *KitchenOrder) error { return r.db.Create(item).Error }
func (r *gormRepository) FindByID(id uuid.UUID) (*KitchenOrder, error) { var item KitchenOrder; if err := r.db.First(&item, "id = ?", id).Error; err != nil { return nil, err }; return &item, nil }
func (r *gormRepository) Update(item *KitchenOrder) error { return r.db.Save(item).Error }
