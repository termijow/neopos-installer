package kitchen

import "github.com/google/uuid"

type CreateKitchenOrderRequest struct {
	BranchID uuid.UUID `json:"branch_id"`
	OrderID  uuid.UUID `json:"order_id"`
	Notes    string    `json:"notes"`
}

type UpdateKitchenStatusRequest struct {
	Status string `json:"status"`
}
