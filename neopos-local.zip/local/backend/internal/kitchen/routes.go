package kitchen

import (
	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB) {
	controller := NewController(NewService(NewRepository(db)))
	router.Get("/kitchen/orders", controller.List)
	router.Get("/kitchen/orders/stream", controller.SSE)
	router.Put("/kitchen/orders/:id/status", controller.UpdateStatus)
}
