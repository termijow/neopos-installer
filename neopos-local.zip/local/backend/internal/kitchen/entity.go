package kitchen

import (
	"restaurant-pos-api/pkg/model"

	"github.com/google/uuid"
)

const (
	StatusPending = "PENDING"
	StatusCooking = "COOKING"
	StatusReady   = "READY"
	StatusServed  = "SERVED"
)

type KitchenOrder struct {
	model.Base
	model.BranchScoped
	OrderID uuid.UUID `json:"order_id" gorm:"type:uuid;index;not null"`
	Status  string    `json:"status" gorm:"size:30;not null;default:PENDING;index"`
	Notes   string    `json:"notes" gorm:"size:500"`
}
