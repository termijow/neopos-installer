package cash_register

import (
	"github.com/google/uuid"
	"restaurant-pos-api/internal/license"
	"restaurant-pos-api/pkg/response"

	"github.com/gofiber/fiber/v2"
)

type Controller struct {
	service   Service
	validator *license.Validator
}

func NewController(service Service, validator *license.Validator) *Controller {
	return &Controller{service: service, validator: validator}
}

func (h *Controller) Open(c *fiber.Ctx) error {
	var req OpenCashRequest
	if err := c.BodyParser(&req); err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}
	// Get branch_id from JWT token
	if branchID := c.Locals("branch_id"); branchID != nil {
		switch v := branchID.(type) {
		case string:
			if bid, err := uuid.Parse(v); err == nil {
				req.BranchID = bid
			}
		case uuid.UUID:
			req.BranchID = v
		}
	}
	// Get user_id from JWT token
	if userID := c.Locals("user_id"); userID != nil {
		switch v := userID.(type) {
		case string:
			if uid, err := uuid.Parse(v); err == nil {
				req.OpenedBy = uid
			}
		case uuid.UUID:
			req.OpenedBy = v
		}
	}
	branchStr := ""
	if req.BranchID != uuid.Nil {
		branchStr = req.BranchID.String()
	}

	licenseInfo, err := h.validator.VerifyAndFallback(branchStr)
	if err != nil {
		return response.Error(c, fiber.StatusPaymentRequired, err.Error())
	}

	item, err := h.service.Open(req)
	if err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}

	res := fiber.Map{
		"session": item,
		"license": licenseInfo,
	}
	return response.Created(c, res)
}

func (h *Controller) Close(c *fiber.Ctx) error {
	var req CloseCashRequest
	if err := c.BodyParser(&req); err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}

	// Get branch_id from JWT token
	branchID := ""
	if b := c.Locals("branch_id"); b != nil {
		switch v := b.(type) {
		case string:
			branchID = v
		case uuid.UUID:
			branchID = v.String()
		}
	}
	if branchID == "" {
		return response.Error(c, fiber.StatusBadRequest, "branch_id not found in token")
	}

	// Get user_id from JWT token
	if userID := c.Locals("user_id"); userID != nil {
		switch v := userID.(type) {
		case string:
			if uid, err := uuid.Parse(v); err == nil {
				req.ClosedBy = uid
			}
		case uuid.UUID:
			req.ClosedBy = v
		}
	}

	licenseInfo, err := h.validator.VerifyAndFallback(branchID)
	if err != nil {
		return response.Error(c, fiber.StatusPaymentRequired, err.Error())
	}

	item, err := h.service.Close(branchID, req)
	if err != nil {
		errStr := err.Error()
		if len(errStr) > 0 && errStr[0] == '{' {
			c.Set("Content-Type", "application/json")
			return c.Status(fiber.StatusBadRequest).SendString(errStr)
		}
		return response.Error(c, fiber.StatusBadRequest, errStr)
	}

	res := fiber.Map{
		"session": item,
		"license": licenseInfo,
	}
	return response.OK(c, res)
}

func (h *Controller) Active(c *fiber.Ctx) error {
	branchID := ""
	if b := c.Locals("branch_id"); b != nil {
		switch v := b.(type) {
		case string:
			branchID = v
		case uuid.UUID:
			branchID = v.String()
		}
	}
	if branchID == "" {
		return response.Error(c, fiber.StatusBadRequest, "branch_id not found in token")
	}

	item, err := h.service.GetActiveSession(branchID)
	if err != nil {
		return response.Error(c, fiber.StatusNotFound, "No hay caja abierta")
	}
	return response.OK(c, item)
}

func (h *Controller) Report(c *fiber.Ctx) error {
	items, err := h.service.Report()
	if err != nil {
		return response.Error(c, fiber.StatusInternalServerError, err.Error())
	}
	return response.OK(c, items)
}

func (h *Controller) History(c *fiber.Ctx) error {
	branchID := ""
	if b := c.Locals("branch_id"); b != nil {
		switch v := b.(type) {
		case string:
			branchID = v
		case uuid.UUID:
			branchID = v.String()
		}
	}
	if branchID == "" {
		return response.Error(c, fiber.StatusBadRequest, "branch_id not found in token")
	}

	items, err := h.service.History(branchID)
	if err != nil {
		return response.Error(c, fiber.StatusInternalServerError, err.Error())
	}
	return response.OK(c, items)
}

type CreateMovementRequest struct {
	Type   string `json:"type"`
	Amount int64  `json:"amount"`
	Reason string `json:"reason"`
}

func (h *Controller) Movement(c *fiber.Ctx) error {
	var req CreateMovementRequest
	if err := c.BodyParser(&req); err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}

	branchID := ""
	if b := c.Locals("branch_id"); b != nil {
		switch v := b.(type) {
		case string:
			branchID = v
		case uuid.UUID:
			branchID = v.String()
		}
	}
	if branchID == "" {
		return response.Error(c, fiber.StatusBadRequest, "branch_id not found in token")
	}

	item, err := h.service.CreateMovement(branchID, req.Type, req.Amount, req.Reason)
	if err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}
	return response.Created(c, item)
}