package cash_register

import (
	"encoding/json"
	"errors"
	"time"

	"github.com/google/uuid"
)

type Service interface {
	Open(OpenCashRequest) (*CashRegisterSession, error)
	Close(string, CloseCashRequest) (*CashRegisterSession, error)
	Report() ([]CashRegisterSession, error)
	GetActiveSession(string) (*CashRegisterSession, error)
	History(string) ([]CashRegisterSession, error)
	CreateMovement(string, string, int64, string) (*CashMovement, error)
	GetMovements(string) ([]CashMovement, error)
}

type service struct{ repo Repository }

func NewService(repo Repository) Service { return &service{repo: repo} }

func (s *service) Open(req OpenCashRequest) (*CashRegisterSession, error) {
	// Check if there is already an active session for this branch
	if existing, err := s.repo.FindOpen(req.BranchID.String()); err == nil && existing != nil {
		return nil, errors.New("ya existe una caja abierta para esta sucursal")
	}

	item := &CashRegisterSession{OpenedBy: req.OpenedBy, OpeningAmount: req.OpeningAmount, Status: CashStatusOpen}
	if req.Notes != "" {
		item.Notes = "Apertura: " + req.Notes
	}
	item.BranchID = req.BranchID
	return item, s.repo.Open(item)
}

func (s *service) Close(branchID string, req CloseCashRequest) (*CashRegisterSession, error) {
	bid, _ := uuid.Parse(branchID)
	item, err := s.repo.FindOpen(bid.String())
	if err != nil {
		return nil, err
	}
	
	// Validate negative inventory before closing
	negativeItems, err := s.repo.CheckNegativeInventory(branchID)
	if err != nil {
		return nil, err
	}
	if len(negativeItems) > 0 {
		// Return JSON string so controller can parse it or just return it to the frontend
		bytes, _ := json.Marshal(map[string]interface{}{
			"error": "INVENTORY_NEGATIVE",
			"message": "Existen diferencias de inventario con stock negativo.",
			"items": negativeItems,
		})
		return nil, errors.New(string(bytes))
	}

	now := time.Now()
	item.ClosedBy, item.ClosingAmount, item.ExpectedAmount = req.ClosedBy, req.ClosingAmount, req.ExpectedAmount
	item.Difference = req.ClosingAmount - req.ExpectedAmount
	if req.Notes != "" {
		if item.Notes != "" {
			item.Notes += "\n\n"
		}
		item.Notes += "Cierre: " + req.Notes
	}
	item.Status = CashStatusClosed
	item.ClosedAt = &now
	return item, s.repo.Update(item)
}

func (s *service) Report() ([]CashRegisterSession, error) { return s.repo.Report() }

func (s *service) GetActiveSession(branchID string) (*CashRegisterSession, error) {
	bid, _ := uuid.Parse(branchID)
	return s.repo.FindOpen(bid.String())
}

func (s *service) History(branchID string) ([]CashRegisterSession, error) {
	return s.repo.History(branchID)
}

func (s *service) CreateMovement(branchID, movType string, amount int64, reason string) (*CashMovement, error) {
	bid, _ := uuid.Parse(branchID)
	session, err := s.repo.FindOpen(bid.String())
	if err != nil {
		return nil, errors.New("no active cash register session")
	}

	movement := &CashMovement{
		SessionID: session.ID,
		Type:      movType,
		Amount:    amount,
		Reason:    reason,
	}

	if err := s.repo.CreateMovement(movement); err != nil {
		return nil, err
	}
	return movement, nil
}

func (s *service) GetMovements(sessionID string) ([]CashMovement, error) {
	sid, _ := uuid.Parse(sessionID)
	return s.repo.GetMovements(sid)
}