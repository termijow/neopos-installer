package cash_register

import "github.com/google/uuid"

type OpenCashRequest struct {
	BranchID      uuid.UUID `json:"branch_id"`
	OpenedBy      uuid.UUID `json:"opened_by"`
	OpeningAmount int64     `json:"opening_amount"`
	Notes         string    `json:"notes"`
}

type CloseCashRequest struct {
	ClosedBy       uuid.UUID `json:"closed_by"`
	ClosingAmount  int64     `json:"closing_amount"`
	ExpectedAmount int64     `json:"expected_amount"`
	Notes          string    `json:"notes"`
}
