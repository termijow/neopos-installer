package cash_register

import (
	"time"

	"restaurant-pos-api/pkg/model"

	"github.com/google/uuid"
)

const (
	CashStatusOpen   = "OPEN"
	CashStatusClosed = "CLOSED"
)

type CashRegisterSession struct {
	model.Base
	model.BranchScoped
	OpenedBy      uuid.UUID  `json:"opened_by" gorm:"type:uuid;index;not null"`
	ClosedBy      uuid.UUID  `json:"closed_by" gorm:"type:uuid;index"`
	OpeningAmount int64      `json:"opening_amount" gorm:"not null"`
	ClosingAmount int64      `json:"closing_amount"`
	ExpectedAmount int64     `json:"expected_amount"`
	Difference     int64     `json:"difference"`
	Notes          string    `json:"notes" gorm:"type:text"`
	Status        string     `json:"status" gorm:"size:30;not null;default:OPEN;index"`
	Withdrawals   int64      `json:"withdrawals" gorm:"-"`
	Deposits      int64      `json:"deposits" gorm:"-"`
	CashSales     int64      `json:"cash_sales" gorm:"-"`
	CardSales     int64      `json:"card_sales" gorm:"-"`
	Transfers     int64      `json:"transfers" gorm:"-"`
	Tips          int64      `json:"tips" gorm:"-"`
	ClosedAt      *time.Time `json:"closed_at,omitempty"`
}

type CashMovement struct {
	model.Base
	SessionID uuid.UUID `json:"session_id" gorm:"type:uuid;index;not null"`
	Type      string    `json:"type" gorm:"size:20;not null"` // WITHDRAWAL, DEPOSIT
	Amount    int64     `json:"amount" gorm:"not null"`
	Reason    string    `json:"reason" gorm:"size:255"`
}
