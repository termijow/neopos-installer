package cash_register

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface { 
	Open(*CashRegisterSession) error; 
	FindOpen(string) (*CashRegisterSession, error); 
	Update(*CashRegisterSession) error; 
	Report() ([]CashRegisterSession, error) 
	History(string) ([]CashRegisterSession, error)
	CreateMovement(*CashMovement) error
	GetMovements(sessionID uuid.UUID) ([]CashMovement, error)
	CheckNegativeInventory(string) ([]map[string]interface{}, error)
}
type gormRepository struct{ db *gorm.DB }
func NewRepository(db *gorm.DB) Repository { return &gormRepository{db: db} }
func (r *gormRepository) Open(item *CashRegisterSession) error { return r.db.Create(item).Error }
func (r *gormRepository) FindOpen(branchID string) (*CashRegisterSession, error) { 
	var item CashRegisterSession
	bid, _ := uuid.Parse(branchID)
	if err := r.db.Where("branch_id = ? AND status = ?", bid, CashStatusOpen).First(&item).Error; err != nil { 
		return nil, err 
	}
	
	// Calculate Movements
	var withdrawals, deposits int64
	r.db.Model(&CashMovement{}).Where("session_id = ? AND type = ?", item.ID, "WITHDRAWAL").Select("COALESCE(SUM(amount), 0)").Scan(&withdrawals)
	r.db.Model(&CashMovement{}).Where("session_id = ? AND type = ?", item.ID, "DEPOSIT").Select("COALESCE(SUM(amount), 0)").Scan(&deposits)
	item.Withdrawals = withdrawals
	item.Deposits = deposits

	// Calculate Sales
	var cashSales, cardSales, transfers, tips int64
	r.db.Table("sales").Where("cash_session_id = ? AND payment_method IN ?", item.ID, []string{"CASH", "efectivo"}).Select("COALESCE(SUM(total), 0)").Scan(&cashSales)
	r.db.Table("sales").Where("cash_session_id = ? AND payment_method IN ?", item.ID, []string{"CREDIT_CARD", "DEBIT_CARD", "tarjeta"}).Select("COALESCE(SUM(total), 0)").Scan(&cardSales)
	r.db.Table("sales").Where("cash_session_id = ? AND payment_method IN ?", item.ID, []string{"TRANSFER", "transferencia"}).Select("COALESCE(SUM(total), 0)").Scan(&transfers)
	r.db.Table("sales").Where("cash_session_id = ?", item.ID).Select("COALESCE(SUM(tip), 0)").Scan(&tips)
	
	item.CashSales = cashSales
	item.CardSales = cardSales
	item.Transfers = transfers
	item.Tips = tips

	return &item, nil 
}
func (r *gormRepository) Update(item *CashRegisterSession) error { return r.db.Save(item).Error }
func (r *gormRepository) Report() ([]CashRegisterSession, error) { 
	var items []CashRegisterSession; 
	err := r.db.Order("created_at desc").Find(&items).Error; 
	return items, err 
}

func (r *gormRepository) History(branchID string) ([]CashRegisterSession, error) {
	var items []CashRegisterSession
	bid, _ := uuid.Parse(branchID)
	thirtyDaysAgo := time.Now().AddDate(0, 0, -30)
	err := r.db.Where("branch_id = ? AND created_at >= ?", bid, thirtyDaysAgo).Order("created_at desc").Find(&items).Error
	
	if err == nil {
		for i, item := range items {
			var withdrawals int64
			r.db.Model(&CashMovement{}).Where("session_id = ? AND type = ?", item.ID, "WITHDRAWAL").Select("COALESCE(SUM(amount), 0)").Scan(&withdrawals)
			items[i].Withdrawals = withdrawals
			
			var deposits int64
			r.db.Model(&CashMovement{}).Where("session_id = ? AND type = ?", item.ID, "DEPOSIT").Select("COALESCE(SUM(amount), 0)").Scan(&deposits)
			items[i].Deposits = deposits

			var cashSales int64
			r.db.Table("sales").Where("cash_session_id = ? AND payment_method IN ? AND deleted_at IS NULL", item.ID, []string{"CASH", "efectivo"}).Select("COALESCE(SUM(total), 0)").Scan(&cashSales)
			items[i].CashSales = cashSales
		}
	}
	
	return items, err
}

func (r *gormRepository) CreateMovement(item *CashMovement) error {
	return r.db.Create(item).Error
}

func (r *gormRepository) GetMovements(sessionID uuid.UUID) ([]CashMovement, error) {
	var items []CashMovement
	err := r.db.Where("session_id = ?", sessionID).Order("created_at desc").Find(&items).Error
	return items, err
}

func (r *gormRepository) CheckNegativeInventory(branchID string) ([]map[string]interface{}, error) {
	bid, err := uuid.Parse(branchID)
	if err != nil {
		return nil, err
	}
	
	type NegativeStock struct {
		Name  string
		Total int64
	}
	var results []NegativeStock
	
	err = r.db.Table("inventory_movements").
		Select("products.name, COALESCE(SUM(CASE WHEN inventory_movements.type = 'IN' THEN inventory_movements.quantity WHEN inventory_movements.type = 'OUT' THEN -inventory_movements.quantity ELSE inventory_movements.quantity END),0) as total").
		Joins("JOIN products ON products.id = inventory_movements.product_id").
		Where("inventory_movements.branch_id = ?", bid).
		Group("inventory_movements.product_id, products.name").
		Having("COALESCE(SUM(CASE WHEN inventory_movements.type = 'IN' THEN inventory_movements.quantity WHEN inventory_movements.type = 'OUT' THEN -inventory_movements.quantity ELSE inventory_movements.quantity END),0) < 0").
		Scan(&results).Error

	if err != nil {
		return nil, err
	}

	var out []map[string]interface{}
	for _, r := range results {
		out = append(out, map[string]interface{}{
			"name":    r.Name,
			"missing": -r.Total,
		})
	}
	return out, nil
}
