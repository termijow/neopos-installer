package cash_register

import (
	"restaurant-pos-api/internal/license"
	"restaurant-pos-api/internal/platform/config"
	"restaurant-pos-api/internal/settings"

	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB, cfg config.Config) {
	settingsRepo := settings.NewRepository(db)
	settingsSvc := settings.NewService(settingsRepo)
	validator := license.NewValidator(cfg, settingsSvc)
	controller := NewController(NewService(NewRepository(db)), validator)
	router.Post("/cash/open", controller.Open)
	router.Post("/cash/close", controller.Close)
	router.Get("/cash/active", controller.Active)
	router.Get("/cash/report", controller.Report)
	router.Get("/cash/history", controller.History)
	router.Post("/cash/movement", controller.Movement)
}
