package recipes

import (
	"restaurant-pos-api/pkg/model"

	"github.com/google/uuid"
)

type Recipe struct {
	model.Base
	model.BranchScoped
	ProductID   uuid.UUID    `json:"product_id" gorm:"type:uuid;uniqueIndex;not null"`
	Description string       `json:"description"`
	Yield       float64      `json:"yield" gorm:"default:1.0"`
	Items       []RecipeItem `json:"items" gorm:"foreignKey:RecipeID"`
}

type RecipeItem struct {
	model.Base
	RecipeID      uuid.UUID `json:"recipe_id" gorm:"type:uuid;index;not null"`
	InventoryItem uuid.UUID `json:"inventory_item_id" gorm:"type:uuid;index;not null"`
	Quantity      float64   `json:"quantity" gorm:"not null"`
	Unit          string    `json:"unit" gorm:"size:20"`
}
