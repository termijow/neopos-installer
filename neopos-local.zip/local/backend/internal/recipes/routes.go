package recipes

import (
	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB) {
	controller := NewController(NewService(NewRepository(db)))
	router.Post("/recipes", controller.Create)
	router.Get("/recipes", controller.List)
	router.Get("/recipes/:id", controller.Get)
	router.Put("/recipes/:id", controller.Update)
	router.Delete("/recipes/:id", controller.Delete)
}
