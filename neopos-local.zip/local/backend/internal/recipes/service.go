package recipes

import (
	"fmt"
	"github.com/google/uuid"
)

type Service interface {
	List(page, limit int) ([]Recipe, int64, error)
	Get(uuid.UUID) (*Recipe, error)
	GetByProductID(productID uuid.UUID) (*Recipe, error)
	Create(UpsertRecipeRequest) (*Recipe, error)
	Update(uuid.UUID, UpsertRecipeRequest) (*Recipe, error)
	Delete(uuid.UUID) error
}

type service struct {
	repo Repository
}

func NewService(repo Repository) Service {
	return &service{repo: repo}
}

func (s *service) List(page, limit int) ([]Recipe, int64, error) {
	return s.repo.List(page, limit)
}

func (s *service) Get(id uuid.UUID) (*Recipe, error) {
	return s.repo.FindByID(id)
}

func (s *service) GetByProductID(productID uuid.UUID) (*Recipe, error) {
	return s.repo.FindByProductID(productID)
}

func (s *service) Create(req UpsertRecipeRequest) (*Recipe, error) {
	existing, _ := s.repo.FindByProductID(req.ProductID)
	if existing != nil && existing.ID != uuid.Nil {
		return nil, fmt.Errorf("este producto ya tiene una receta asignada")
	}

	recipe := &Recipe{
		ProductID:   req.ProductID,
		Description: req.Description,
		Yield:       req.Yield,
	}
	recipe.BranchID = req.BranchID
	for _, it := range req.Items {
		recipe.Items = append(recipe.Items, RecipeItem{
			InventoryItem: it.InventoryItem,
			Quantity:      it.Quantity,
			Unit:          it.Unit,
		})
	}
	err := s.repo.Create(recipe)
	return recipe, err
}

func (s *service) Update(id uuid.UUID, req UpsertRecipeRequest) (*Recipe, error) {
	recipe, err := s.repo.FindByID(id)
	if err != nil {
		return nil, err
	}
	recipe.Description = req.Description
	recipe.Yield = req.Yield
	// For simplicity, we just clear and add items again in this basic implementation
	// Real implementation would diff or we can rely on GORM's association replace.
	var newItems []RecipeItem
	for _, it := range req.Items {
		newItems = append(newItems, RecipeItem{
			InventoryItem: it.InventoryItem,
			Quantity:      it.Quantity,
			Unit:          it.Unit,
		})
	}
	recipe.Items = newItems
	err = s.repo.Update(recipe)
	return recipe, err
}

func (s *service) Delete(id uuid.UUID) error {
	return s.repo.Delete(id)
}
