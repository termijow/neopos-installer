package recipes

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface {
	Create(*Recipe) error
	Update(*Recipe) error
	List(page, limit int) ([]Recipe, int64, error)
	FindByID(uuid.UUID) (*Recipe, error)
	FindByProductID(uuid.UUID) (*Recipe, error)
	Delete(uuid.UUID) error
}

type repository struct {
	db *gorm.DB
}

func NewRepository(db *gorm.DB) Repository {
	return &repository{db: db}
}

func (r *repository) Create(item *Recipe) error {
	return r.db.Create(item).Error
}

func (r *repository) Update(item *Recipe) error {
	// Clean up old items before saving new ones
	r.db.Where("recipe_id = ?", item.ID).Delete(&RecipeItem{})
	return r.db.Save(item).Error
}

func (r *repository) Delete(id uuid.UUID) error {
	r.db.Where("recipe_id = ?", id).Delete(&RecipeItem{})
	return r.db.Where("id = ?", id).Delete(&Recipe{}).Error
}

func (r *repository) List(page, limit int) ([]Recipe, int64, error) {
	var items []Recipe
	var total int64
	offset := (page - 1) * limit
	if err := r.db.Model(&Recipe{}).Count(&total).Error; err != nil {
		return nil, 0, err
	}
	err := r.db.Preload("Items").Offset(offset).Limit(limit).Find(&items).Error
	return items, total, err
}

func (r *repository) FindByID(id uuid.UUID) (*Recipe, error) {
	var item Recipe
	err := r.db.Preload("Items").Where("id = ?", id).First(&item).Error
	return &item, err
}

func (r *repository) FindByProductID(productID uuid.UUID) (*Recipe, error) {
	var item Recipe
	err := r.db.Preload("Items").Where("product_id = ?", productID).First(&item).Error
	return &item, err
}

