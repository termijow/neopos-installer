package recipes

import "github.com/google/uuid"

type UpsertRecipeRequest struct {
	BranchID    uuid.UUID              `json:"branch_id"`
	ProductID   uuid.UUID              `json:"product_id"`
	Description string                 `json:"description"`
	Yield       float64                `json:"yield"`
	Items       []UpsertRecipeItemDTO  `json:"items"`
}

type UpsertRecipeItemDTO struct {
	InventoryItem uuid.UUID `json:"inventory_item_id"`
	Quantity      float64   `json:"quantity"`
	Unit          string    `json:"unit"`
}
