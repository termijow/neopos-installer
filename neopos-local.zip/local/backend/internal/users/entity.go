package users

import (
	"time"

	"restaurant-pos-api/pkg/model"

	"github.com/google/uuid"
)

type User struct {
	model.Base
	model.BranchScoped
	Name         string     `json:"name" gorm:"size:140;not null"`
	Email        string     `json:"email" gorm:"size:180;uniqueIndex;not null"`
	PasswordHash string     `json:"-" gorm:"size:255;not null"`
	RoleID       uuid.UUID  `json:"role_id" gorm:"type:uuid;index"`
	RoleName     string     `json:"role_name" gorm:"size:80;default:cashier"`
	Active       bool       `json:"active" gorm:"default:true"`
	LastLoginAt  *time.Time `json:"last_login_at,omitempty"`
}
