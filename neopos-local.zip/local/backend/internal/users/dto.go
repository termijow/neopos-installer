package users

import "github.com/google/uuid"

type CreateUserRequest struct {
	Name     string    `json:"name"`
	Email    string    `json:"email"`
	Password string    `json:"password"`
	RoleID   uuid.UUID `json:"role_id"`
	RoleName string    `json:"role_name"`
	BranchID uuid.UUID `json:"branch_id"`
	Active   *bool     `json:"active"`
}

type UpdateUserRequest struct {
	Name     string    `json:"name"`
	Email    string    `json:"email"`
	Password string    `json:"password"`
	RoleID   uuid.UUID `json:"role_id"`
	RoleName string    `json:"role_name"`
	BranchID uuid.UUID `json:"branch_id"`
	Active   *bool     `json:"active"`
}
