package users

import (
	"errors"
	"strings"

	"restaurant-pos-api/pkg/security"

	"github.com/google/uuid"
)

type Service interface {
	List() ([]User, error)
	Create(req CreateUserRequest) (*User, error)
	Update(id uuid.UUID, req UpdateUserRequest) (*User, error)
	Delete(id uuid.UUID) error
}

type service struct {
	repo Repository
}

func NewService(repo Repository) Service {
	return &service{repo: repo}
}

func (s *service) List() ([]User, error) {
	return s.repo.List()
}

func (s *service) Create(req CreateUserRequest) (*User, error) {
	if strings.TrimSpace(req.Email) == "" || strings.TrimSpace(req.Password) == "" {
		return nil, errors.New("email and password are required")
	}
	if len(req.Password) < 12 {
		return nil, errors.New("password must be at least 12 characters long")
	}

	hash, err := security.HashPassword(req.Password)
	if err != nil {
		return nil, err
	}
	active := true
	if req.Active != nil {
		active = *req.Active
	}
	roleName := req.RoleName
	if roleName == "" {
		roleName = "cashier"
	}
	user := &User{
		Name:         req.Name,
		Email:        strings.ToLower(req.Email),
		PasswordHash: hash,
		RoleID:       req.RoleID,
		RoleName:     roleName,
		Active:       active,
	}
	user.BranchID = req.BranchID
	return user, s.repo.Create(user)
}

func (s *service) Update(id uuid.UUID, req UpdateUserRequest) (*User, error) {
	user, err := s.repo.FindByID(id)
	if err != nil {
		return nil, err
	}
	if req.Name != "" {
		user.Name = req.Name
	}
	if req.Email != "" {
		user.Email = strings.ToLower(req.Email)
	}
	if req.Password != "" {
		if len(req.Password) < 12 {
			return nil, errors.New("password must be at least 12 characters long")
		}
		hash, err := security.HashPassword(req.Password)
		if err != nil {
			return nil, err
		}
		user.PasswordHash = hash
	}
	if req.RoleID != uuid.Nil {
		user.RoleID = req.RoleID
	}
	if req.RoleName != "" {
		user.RoleName = req.RoleName
	}
	if req.BranchID != uuid.Nil {
		user.BranchID = req.BranchID
	}
	if req.Active != nil {
		user.Active = *req.Active
	}
	return user, s.repo.Update(user)
}

func (s *service) Delete(id uuid.UUID) error {
	return s.repo.Delete(id)
}
