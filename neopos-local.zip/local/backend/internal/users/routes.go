package users

import (
	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB) {
	controller := NewController(NewService(NewRepository(db)))
	router.Get("/users", controller.List)
	router.Post("/users", controller.Create)
	router.Put("/users/:id", controller.Update)
	router.Delete("/users/:id", controller.Delete)
}
