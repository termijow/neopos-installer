package audit

import (
	"restaurant-pos-api/pkg/model"

	"github.com/google/uuid"
)

type AuditLog struct {
	model.Base
	model.BranchScoped
	UserID   uuid.UUID `json:"user_id" gorm:"type:uuid;index"`
	Action   string    `json:"action" gorm:"size:80;not null;index"`
	Entity   string    `json:"entity" gorm:"size:120;not null;index"`
	EntityID string    `json:"entity_id" gorm:"size:80;index"`
	Metadata string    `json:"metadata" gorm:"type:jsonb;default:'{}'"`
}
