package audit

import "gorm.io/gorm"

type Repository interface { List(AuditQuery) ([]AuditLog, error) }
type gormRepository struct{ db *gorm.DB }
func NewRepository(db *gorm.DB) Repository { return &gormRepository{db: db} }
func (r *gormRepository) List(q AuditQuery) ([]AuditLog, error) {
	var items []AuditLog
	db := r.db.Order("created_at desc")
	if q.Entity != "" { db = db.Where("entity = ?", q.Entity) }
	if q.Action != "" { db = db.Where("action = ?", q.Action) }
	if q.BranchID.String() != "00000000-0000-0000-0000-000000000000" { db = db.Where("branch_id = ?", q.BranchID) }
	err := db.Find(&items).Error
	return items, err
}
