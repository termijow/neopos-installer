package audit

import "github.com/google/uuid"

type AuditQuery struct {
	BranchID uuid.UUID `json:"branch_id"`
	Entity   string    `json:"entity"`
	Action   string    `json:"action"`
}
