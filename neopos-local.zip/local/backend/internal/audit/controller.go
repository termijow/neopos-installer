package audit

import (
	"restaurant-pos-api/pkg/response"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
)

type Controller struct{ service Service }
func NewController(service Service) *Controller { return &Controller{service: service} }
func (h *Controller) List(c *fiber.Ctx) error { branchID, _ := uuid.Parse(c.Query("branch_id")); items, err := h.service.List(AuditQuery{BranchID: branchID, Entity: c.Query("entity"), Action: c.Query("action")}); if err != nil { return response.Error(c, fiber.StatusInternalServerError, err.Error()) }; return response.OK(c, items) }
