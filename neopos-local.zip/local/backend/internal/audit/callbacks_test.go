package audit

import (
	"context"
	"encoding/json"
	"testing"

	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

type TestEntity struct {
	ID   uuid.UUID `gorm:"type:uuid;primaryKey"`
	Name string
}

func setupTestDB(t *testing.T) *gorm.DB {
	db, err := gorm.Open(sqlite.Open("file::memory:?cache=shared"), &gorm.Config{})
	assert.NoError(t, err)

	err = db.AutoMigrate(&AuditLog{}, &TestEntity{})
	assert.NoError(t, err)

	RegisterCallbacks(db)
	return db
}

func TestAuditCallbacks(t *testing.T) {
	db := setupTestDB(t)
	userID := uuid.New()
	ctx := context.WithValue(context.Background(), "user_id", userID)

	dbWithContext := db.WithContext(ctx)

	t.Run("Create Audit Log", func(t *testing.T) {
		entity := TestEntity{ID: uuid.New(), Name: "Test"}
		err := dbWithContext.Create(&entity).Error
		assert.NoError(t, err)

		var logs []AuditLog
		db.Find(&logs)
		
		assert.Len(t, logs, 1)
		assert.Equal(t, "CREATE", logs[0].Action)
		assert.Equal(t, "test_entities", logs[0].Entity)
		assert.Equal(t, entity.ID.String(), logs[0].EntityID)
		assert.Equal(t, userID, logs[0].UserID)

		var payload StructuredPayload
		json.Unmarshal([]byte(logs[0].Metadata), &payload)
		assert.Equal(t, "Test", payload.State["Name"])
	})

	t.Run("Update Audit Log", func(t *testing.T) {
		db.Exec("DELETE FROM audit_logs") // Clear previous logs
		
		entity := TestEntity{ID: uuid.New(), Name: "Initial"}
		dbWithContext.Create(&entity)
		db.Exec("DELETE FROM audit_logs") // Clear create logs

		// Update
		entity.Name = "Updated"
		dbWithContext.Save(&entity)

		var logs []AuditLog
		db.Find(&logs)
		
		assert.Len(t, logs, 1)
		assert.Equal(t, "UPDATE", logs[0].Action)
		assert.Equal(t, "test_entities", logs[0].Entity)
		
		var payload StructuredPayload
		json.Unmarshal([]byte(logs[0].Metadata), &payload)
		assert.Equal(t, "Updated", payload.State["Name"])
	})

	t.Run("Delete Audit Log", func(t *testing.T) {
		db.Exec("DELETE FROM audit_logs")
		
		entity := TestEntity{ID: uuid.New(), Name: "To Delete"}
		dbWithContext.Create(&entity)
		db.Exec("DELETE FROM audit_logs")

		dbWithContext.Delete(&entity)

		var logs []AuditLog
		db.Find(&logs)
		
		assert.Len(t, logs, 1)
		assert.Equal(t, "DELETE", logs[0].Action)
		assert.Equal(t, "test_entities", logs[0].Entity)
	})
}
