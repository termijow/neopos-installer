package audit

type Service interface { List(AuditQuery) ([]AuditLog, error) }
type service struct{ repo Repository }
func NewService(repo Repository) Service { return &service{repo: repo} }
func (s *service) List(q AuditQuery) ([]AuditLog, error) { return s.repo.List(q) }
