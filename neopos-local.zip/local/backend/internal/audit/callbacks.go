package audit

import (
	"encoding/json"
	"fmt"
	"reflect"
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

var auditSkippedTables = map[string]bool{
	"sync_queue": true,
	"audit_logs": true,
}

func RegisterCallbacks(db *gorm.DB) {
	db.Callback().Create().After("gorm:create").Register("pos:audit_create", audit("CREATE"))
	db.Callback().Update().After("gorm:update").Register("pos:audit_update", audit("UPDATE"))
	db.Callback().Delete().After("gorm:delete").Register("pos:audit_delete", audit("DELETE"))
}

type StructuredPayload struct {
	State map[string]interface{} `json:"state,omitempty"`
}

func audit(action string) func(*gorm.DB) {
	return func(tx *gorm.DB) {
		if tx.Error != nil || tx.Statement == nil || auditSkippedTables[tx.Statement.Table] {
			return
		}

		var userID interface{} = nil
		if tx.Statement.Context != nil {
			userID = tx.Statement.Context.Value("user_id")
		}

		// Basic structured payload
		var state map[string]interface{}
		destBytes, _ := json.Marshal(tx.Statement.Dest)
		json.Unmarshal(destBytes, &state)

		payload := StructuredPayload{
			State: state,
		}

		payloadBytes, _ := json.Marshal(payload)

		tx.Session(&gorm.Session{NewDB: true}).Exec(
			"INSERT INTO audit_logs (id, created_at, updated_at, action, entity, entity_id, user_id, metadata) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
			uuid.New(), time.Now(), time.Now(), action, tx.Statement.Table, primaryID(tx), userID, string(payloadBytes),
		)
	}
}

func primaryID(tx *gorm.DB) string {
	if tx.Statement.Schema == nil || tx.Statement.Schema.PrioritizedPrimaryField == nil {
		return ""
	}
	rv := reflect.Indirect(tx.Statement.ReflectValue)
	if rv.Kind() == reflect.Slice || rv.Kind() == reflect.Array {
		if rv.Len() > 0 {
			value, zero := tx.Statement.Schema.PrioritizedPrimaryField.ValueOf(tx.Statement.Context, reflect.Indirect(rv.Index(0)))
			if zero {
				return ""
			}
			return formatValue(value)
		}
		return ""
	}
	value, zero := tx.Statement.Schema.PrioritizedPrimaryField.ValueOf(tx.Statement.Context, rv)
	if zero {
		return ""
	}
	return formatValue(value)
}

func formatValue(value interface{}) string {
	val := reflect.ValueOf(value)
	if val.Kind() == reflect.Ptr {
		if val.IsNil() {
			return ""
		}
		return fmt.Sprint(val.Elem().Interface())
	}
	return fmt.Sprint(value)
}
