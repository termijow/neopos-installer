package tables

import (
	"errors"

	"github.com/google/uuid"
)

type Service interface {
	List() ([]Table, error)
	Create(CreateTableRequest) (*Table, error)
	Open(uuid.UUID) (*Table, error)
	Close(uuid.UUID) (*Table, error)
	Transfer(uuid.UUID, TransferTableRequest) (*Table, error)
	Merge(uuid.UUID, TransferTableRequest) (*Table, error)
}

type service struct{ repo Repository }
func NewService(repo Repository) Service { return &service{repo: repo} }
func (s *service) List() ([]Table, error) { return s.repo.List() }
func (s *service) Create(req CreateTableRequest) (*Table, error) { status := req.Status; if status == "" { status = StatusFree }; item := &Table{Number: req.Number, Capacity: req.Capacity, Status: status}; item.BranchID = req.BranchID; return item, s.repo.Create(item) }
func (s *service) Open(id uuid.UUID) (*Table, error) { item, err := s.repo.FindByID(id); if err != nil { return nil, err }; if item.Status != StatusFree && item.Status != StatusReserved { return nil, errors.New("table is not available") }; item.Status = StatusOccupied; return item, s.repo.Update(item) }
func (s *service) Close(id uuid.UUID) (*Table, error) { 
	hasPending, err := s.repo.HasPendingOrders(id)
	if err != nil {
		return nil, err
	}
	if hasPending {
		return nil, errors.New("cannot close table with active orders")
	}
	item, err := s.repo.FindByID(id)
	if err != nil { 
		return nil, err 
	}
	item.Status = StatusFree
	return item, s.repo.Update(item) 
}
func (s *service) Transfer(id uuid.UUID, req TransferTableRequest) (*Table, error) { target, err := s.repo.FindByID(req.TargetTableID); if err != nil { return nil, err }; if target.Status != StatusFree { return nil, errors.New("target table is not free") }; if err := s.repo.TransferTables(id, req.TargetTableID); err != nil { return nil, err }; return target, nil }
func (s *service) Merge(id uuid.UUID, req TransferTableRequest) (*Table, error) { target, err := s.repo.FindByID(req.TargetTableID); if err != nil { return nil, err }; if err := s.repo.MergeTables(id, req.TargetTableID); err != nil { return nil, err }; return target, nil }
