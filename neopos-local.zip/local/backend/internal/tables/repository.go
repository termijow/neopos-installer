package tables

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface {
	List() ([]Table, error)
	Create(*Table) error
	FindByID(uuid.UUID) (*Table, error)
	Update(*Table) error
	MergeTables(sourceID, targetID uuid.UUID) error
	TransferTables(sourceID, targetID uuid.UUID) error
	HasPendingOrders(uuid.UUID) (bool, error)
}

type gormRepository struct{ db *gorm.DB }
func NewRepository(db *gorm.DB) Repository { return &gormRepository{db: db} }
func (r *gormRepository) List() ([]Table, error) { var items []Table; err := r.db.Order("number asc").Find(&items).Error; return items, err }
func (r *gormRepository) Create(item *Table) error { return r.db.Create(item).Error }
func (r *gormRepository) FindByID(id uuid.UUID) (*Table, error) { var item Table; if err := r.db.First(&item, "id = ?", id).Error; err != nil { return nil, err }; return &item, nil }
func (r *gormRepository) Update(item *Table) error { return r.db.Save(item).Error }
func (r *gormRepository) MergeTables(sourceID, targetID uuid.UUID) error {
	if err := r.db.Exec("UPDATE orders SET table_id = ? WHERE table_id = ? AND status NOT IN ('BILLED', 'CANCELED')", targetID, sourceID).Error; err != nil {
		return err
	}
	if err := r.db.Exec("UPDATE tables SET status = 'OCCUPIED' WHERE id IN (?, ?)", sourceID, targetID).Error; err != nil {
		return err
	}
	return nil
}
func (r *gormRepository) TransferTables(sourceID, targetID uuid.UUID) error {
	if err := r.db.Exec("UPDATE orders SET table_id = ? WHERE table_id = ? AND status NOT IN ('BILLED', 'CANCELED')", targetID, sourceID).Error; err != nil {
		return err
	}
	if err := r.db.Exec("UPDATE tables SET status = 'FREE' WHERE id = ?", sourceID).Error; err != nil {
		return err
	}
	if err := r.db.Exec("UPDATE tables SET status = 'OCCUPIED' WHERE id = ?", targetID).Error; err != nil {
		return err
	}
	return nil
}
func (r *gormRepository) HasPendingOrders(id uuid.UUID) (bool, error) {
	var count int64
	err := r.db.Table("orders").Where("table_id = ? AND status NOT IN ('BILLED', 'CANCELED')", id).Count(&count).Error
	return count > 0, err
}
