package tables

import "restaurant-pos-api/pkg/model"

const (
	StatusFree     = "FREE"
	StatusOccupied = "OCCUPIED"
	StatusReserved = "RESERVED"
	StatusCleaning = "CLEANING"
)

type Table struct {
	model.Base
	model.BranchScoped
	Number   int    `json:"number" gorm:"not null;index:idx_tables_branch_number,unique"`
	Capacity int    `json:"capacity" gorm:"not null"`
	Status   string `json:"status" gorm:"size:30;not null;default:FREE;index"`
}
