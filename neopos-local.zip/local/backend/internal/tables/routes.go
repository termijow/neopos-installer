package tables

import (
	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB) {
	controller := NewController(NewService(NewRepository(db)))
	router.Get("/tables", controller.List)
	router.Post("/tables", controller.Create)
	router.Put("/tables/:id/open", controller.Open)
	router.Put("/tables/:id/close", controller.Close)
	router.Put("/tables/:id/transfer", controller.Transfer)
	router.Put("/tables/:id/merge", controller.Merge)
}
