package tables

import "github.com/google/uuid"

type CreateTableRequest struct {
	BranchID uuid.UUID `json:"branch_id"`
	Number   int       `json:"number"`
	Capacity int       `json:"capacity"`
	Status   string    `json:"status"`
}

type TransferTableRequest struct {
	TargetTableID uuid.UUID `json:"target_table_id"`
}
