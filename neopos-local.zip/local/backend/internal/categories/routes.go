package categories

import (
	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB) {
	controller := NewController(NewService(NewRepository(db)))
	router.Get("/categories", controller.List)
	router.Post("/categories", controller.Create)
	router.Put("/categories/:id", controller.Update)
	router.Delete("/categories/:id", controller.Delete)
}
