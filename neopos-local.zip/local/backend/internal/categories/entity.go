package categories

import "restaurant-pos-api/pkg/model"

type Category struct {
	model.Base
	model.BranchScoped
	Name     string `json:"name" gorm:"size:140;not null"`
	Active   bool   `json:"active" gorm:"default:true"`
	IsHidden bool   `json:"is_hidden" gorm:"default:false"`
}
