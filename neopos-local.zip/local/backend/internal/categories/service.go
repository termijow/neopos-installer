package categories

import "github.com/google/uuid"

type Service interface { List() ([]Category, error); Create(UpsertCategoryRequest) (*Category, error); Update(uuid.UUID, UpsertCategoryRequest) (*Category, error); Delete(uuid.UUID) error }
type service struct{ repo Repository }
func NewService(repo Repository) Service { return &service{repo: repo} }
func (s *service) List() ([]Category, error) { return s.repo.List() }
func (s *service) Create(req UpsertCategoryRequest) (*Category, error) { active := true; isHidden := false; if req.Active != nil { active = *req.Active }; if req.IsHidden != nil { isHidden = *req.IsHidden }; item := &Category{Name: req.Name, Active: active, IsHidden: isHidden}; item.BranchID = req.BranchID; return item, s.repo.Create(item) }
func (s *service) Update(id uuid.UUID, req UpsertCategoryRequest) (*Category, error) { item, err := s.repo.FindByID(id); if err != nil { return nil, err }; if req.Name != "" { item.Name = req.Name }; if req.BranchID != uuid.Nil { item.BranchID = req.BranchID }; if req.Active != nil { item.Active = *req.Active }; if req.IsHidden != nil { item.IsHidden = *req.IsHidden }; return item, s.repo.Update(item) }
func (s *service) Delete(id uuid.UUID) error { return s.repo.Delete(id) }
