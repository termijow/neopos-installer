package categories

import (
	"errors"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface { List() ([]Category, error); Create(*Category) error; FindByID(uuid.UUID) (*Category, error); Update(*Category) error; Delete(uuid.UUID) error }
type gormRepository struct{ db *gorm.DB }
func NewRepository(db *gorm.DB) Repository { return &gormRepository{db: db} }
func (r *gormRepository) List() ([]Category, error) { var items []Category; err := r.db.Order("name asc").Find(&items).Error; return items, err }
func (r *gormRepository) Create(item *Category) error { return r.db.Create(item).Error }
func (r *gormRepository) FindByID(id uuid.UUID) (*Category, error) { var item Category; if err := r.db.First(&item, "id = ?", id).Error; err != nil { return nil, err }; return &item, nil }
func (r *gormRepository) Update(item *Category) error { return r.db.Save(item).Error }
func (r *gormRepository) Delete(id uuid.UUID) error {
	var count int64
	r.db.Table("products").Where("category_id = ? AND deleted_at IS NULL", id).Count(&count)
	if count > 0 {
		return errors.New("No se puede eliminar la categoría porque tiene productos asociados")
	}
	return r.db.Delete(&Category{}, "id = ?", id).Error
}
