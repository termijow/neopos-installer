package categories

import (
	"restaurant-pos-api/pkg/response"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
)

type Controller struct{ service Service }
func NewController(service Service) *Controller { return &Controller{service: service} }
func (h *Controller) List(c *fiber.Ctx) error { items, err := h.service.List(); if err != nil { return response.Error(c, fiber.StatusInternalServerError, err.Error()) }; return response.OK(c, items) }
func (h *Controller) Create(c *fiber.Ctx) error { var req UpsertCategoryRequest; if err := c.BodyParser(&req); err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; item, err := h.service.Create(req); if err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; return response.Created(c, item) }
func (h *Controller) Update(c *fiber.Ctx) error { id, err := uuid.Parse(c.Params("id")); if err != nil { return response.Error(c, fiber.StatusBadRequest, "invalid category id") }; var req UpsertCategoryRequest; if err := c.BodyParser(&req); err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; item, err := h.service.Update(id, req); if err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; return response.OK(c, item) }
func (h *Controller) Delete(c *fiber.Ctx) error { id, err := uuid.Parse(c.Params("id")); if err != nil { return response.Error(c, fiber.StatusBadRequest, "invalid category id") }; if err := h.service.Delete(id); err != nil { if err.Error() == "foreign key violated" || err.Error() == "a foreign key constraint fails" || err.Error() == "No se puede eliminar la categoría porque tiene productos asociados" { return response.Error(c, fiber.StatusBadRequest, "No se puede eliminar la categoría porque tiene productos asociados") }; return response.Error(c, fiber.StatusBadRequest, err.Error()) }; return response.NoContent(c) }
