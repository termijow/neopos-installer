package categories

import "github.com/google/uuid"

type UpsertCategoryRequest struct {
	BranchID uuid.UUID `json:"branch_id"`
	Name     string    `json:"name"`
	Active   *bool     `json:"active"`
	IsHidden *bool     `json:"is_hidden"`
}
