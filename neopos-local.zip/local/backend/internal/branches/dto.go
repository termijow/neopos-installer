package branches

import "github.com/google/uuid"

type UpsertBranchRequest struct {
	CompanyID uuid.UUID `json:"company_id"`
	Name      string    `json:"name"`
	Code      string    `json:"code"`
	Address   string    `json:"address"`
	City      string    `json:"city"`
	Active    *bool     `json:"active"`
}
