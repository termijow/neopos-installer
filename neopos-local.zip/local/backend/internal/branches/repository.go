package branches

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface {
	List() ([]Branch, error)
	Create(*Branch) error
	FindByID(uuid.UUID) (*Branch, error)
	Update(*Branch) error
	Delete(uuid.UUID) error
}

type gormRepository struct{ db *gorm.DB }
func NewRepository(db *gorm.DB) Repository { return &gormRepository{db: db} }
func (r *gormRepository) List() ([]Branch, error) { var items []Branch; err := r.db.Order("name asc").Find(&items).Error; return items, err }
func (r *gormRepository) Create(item *Branch) error { return r.db.Create(item).Error }
func (r *gormRepository) FindByID(id uuid.UUID) (*Branch, error) { var item Branch; if err := r.db.First(&item, "id = ?", id).Error; err != nil { return nil, err }; return &item, nil }
func (r *gormRepository) Update(item *Branch) error { return r.db.Save(item).Error }
func (r *gormRepository) Delete(id uuid.UUID) error { return r.db.Delete(&Branch{}, "id = ?", id).Error }
