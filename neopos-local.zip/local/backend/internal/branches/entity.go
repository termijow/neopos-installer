package branches

import (
	"restaurant-pos-api/pkg/model"

	"github.com/google/uuid"
)

type Branch struct {
	model.Base
	CompanyID uuid.UUID `json:"company_id" gorm:"type:uuid;index;not null"`
	Name      string    `json:"name" gorm:"size:160;not null"`
	Code      string    `json:"code" gorm:"size:40;uniqueIndex;not null"`
	Address   string    `json:"address" gorm:"size:255"`
	City      string    `json:"city" gorm:"size:120"`
	Active    bool      `json:"active" gorm:"default:true"`
}
