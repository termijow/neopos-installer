package branches

import "github.com/google/uuid"

type Service interface { List() ([]Branch, error); Create(UpsertBranchRequest) (*Branch, error); Update(uuid.UUID, UpsertBranchRequest) (*Branch, error); Delete(uuid.UUID) error }
type service struct{ repo Repository }
func NewService(repo Repository) Service { return &service{repo: repo} }
func (s *service) List() ([]Branch, error) { return s.repo.List() }
func (s *service) Create(req UpsertBranchRequest) (*Branch, error) { active := true; if req.Active != nil { active = *req.Active }; item := &Branch{CompanyID: req.CompanyID, Name: req.Name, Code: req.Code, Address: req.Address, City: req.City, Active: active}; return item, s.repo.Create(item) }
func (s *service) Update(id uuid.UUID, req UpsertBranchRequest) (*Branch, error) { item, err := s.repo.FindByID(id); if err != nil { return nil, err }; if req.CompanyID != uuid.Nil { item.CompanyID = req.CompanyID }; if req.Name != "" { item.Name = req.Name }; if req.Code != "" { item.Code = req.Code }; item.Address, item.City = req.Address, req.City; if req.Active != nil { item.Active = *req.Active }; return item, s.repo.Update(item) }
func (s *service) Delete(id uuid.UUID) error { return s.repo.Delete(id) }
