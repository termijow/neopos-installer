package ai

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"

	"restaurant-pos-api/internal/platform/config"
)

type LLMClient interface {
	Chat(ctx context.Context, req ChatRequest) (*ChatResponse, error)
	HealthCheck(ctx context.Context) error
	GetProviderName() string
}

type ChatRequest struct {
	Messages    []Message  `json:"messages"`
	Tools       []Tool     `json:"tools,omitempty"`
	ToolChoice  string     `json:"tool_choice,omitempty"`
	Temperature float32    `json:"temperature"`
	MaxTokens   int        `json:"max_tokens"`
	Stream      bool       `json:"stream"`
}

type ChatResponse struct {
	Message   Message     `json:"message"`
	ToolCalls []ToolCall  `json:"tool_calls,omitempty"`
	Usage     Usage       `json:"usage,omitempty"`
	Model     string      `json:"model"`
	Provider  string      `json:"provider"`
}

type Message struct {
	Role       string     `json:"role"`
	Content    string     `json:"content,omitempty"`
	ToolCalls  []ToolCall `json:"tool_calls,omitempty"`
	ToolCallID string     `json:"tool_call_id,omitempty"`
	Name       string     `json:"name,omitempty"`
}

type ToolCall struct {
	ID       string       `json:"id"`
	Type     string       `json:"type"`
	Function FunctionCall `json:"function"`
}

type FunctionCall struct {
	Name      string `json:"name"`
	Arguments string `json:"arguments"`
}

type Tool struct {
	Type     string   `json:"type"`
	Function Function `json:"function"`
}

type Function struct {
	Name        string     `json:"name"`
	Description string     `json:"description"`
	Parameters  ToolSchema `json:"parameters"`
}

type ToolSchema struct {
	Type       string              `json:"type"`
	Properties map[string]Property `json:"properties"`
	Required   []string            `json:"required"`
}

type Property struct {
	Type        string   `json:"type"`
	Description string   `json:"description"`
	Enum        []string `json:"enum,omitempty"`
}

type Usage struct {
	PromptTokens     int `json:"prompt_tokens"`
	CompletionTokens int `json:"completion_tokens"`
	TotalTokens      int `json:"total_tokens"`
}

type ollamaClient struct {
	baseURL string
	model   string
	client  *http.Client
}

func NewOllamaClient(cfg config.Config) LLMClient {
	return &ollamaClient{
		baseURL: cfg.OllamaBaseURL,
		model:   cfg.OllamaModel,
		client:  &http.Client{Timeout: 120 * time.Second},
	}
}

func (c *ollamaClient) GetProviderName() string {
	return "ollama"
}

func (c *ollamaClient) HealthCheck(ctx context.Context) error {
	req, err := http.NewRequestWithContext(ctx, "GET", c.baseURL+"/api/tags", nil)
	if err != nil {
		return err
	}
	resp, err := c.client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("ollama health check failed: %d", resp.StatusCode)
	}
	return nil
}

func (c *ollamaClient) Chat(ctx context.Context, req ChatRequest) (*ChatResponse, error) {
	ollamaReq := map[string]interface{}{
		"model":    c.model,
		"messages": req.Messages,
		"stream":   req.Stream,
		"options": map[string]interface{}{
			"temperature": req.Temperature,
			"num_predict": req.MaxTokens,
		},
	}

	if len(req.Tools) > 0 {
		tools := make([]map[string]interface{}, len(req.Tools))
		for i, t := range req.Tools {
			tools[i] = map[string]interface{}{
				"type":     t.Type,
				"function": t.Function,
			}
		}
		ollamaReq["tools"] = tools
		if req.ToolChoice != "" {
			ollamaReq["tool_choice"] = req.ToolChoice
		}
	}

	body, _ := json.Marshal(ollamaReq)
	httpReq, err := http.NewRequestWithContext(ctx, "POST", c.baseURL+"/api/chat", bytes.NewBuffer(body))
	if err != nil {
		return nil, err
	}
	httpReq.Header.Set("Content-Type", "application/json")

	resp, err := c.client.Do(httpReq)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("ollama error %d: %s", resp.StatusCode, string(respBody))
	}

	var ollamaResp struct {
		Message struct {
			Role      string        `json:"role"`
			Content   string        `json:"content"`
			ToolCalls []ToolCall    `json:"tool_calls"`
		} `json:"message"`
		Model string `json:"model"`
	}

	if err := json.Unmarshal(respBody, &ollamaResp); err != nil {
		return nil, err
	}

	return &ChatResponse{
		Message: Message{
			Role:      ollamaResp.Message.Role,
			Content:   ollamaResp.Message.Content,
			ToolCalls: ollamaResp.Message.ToolCalls,
		},
		Model:    ollamaResp.Model,
		Provider: "ollama",
	}, nil
}

type groqClient struct {
	apiKey string
	model  string
	client *http.Client
}

func NewGroqClient(cfg config.Config) LLMClient {
	return &groqClient{
		apiKey: cfg.GroqAPIKey,
		model:  cfg.GroqModel,
		client: &http.Client{Timeout: 60 * time.Second},
	}
}

func (c *groqClient) GetProviderName() string {
	return "groq"
}

func (c *groqClient) HealthCheck(ctx context.Context) error {
	if c.apiKey == "" {
		return fmt.Errorf("groq api key not configured")
	}
	req, err := http.NewRequestWithContext(ctx, "GET", "https://api.groq.com/openai/v1/models", nil)
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+c.apiKey)
	resp, err := c.client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("groq health check failed: %d", resp.StatusCode)
	}
	return nil
}

func (c *groqClient) Chat(ctx context.Context, req ChatRequest) (*ChatResponse, error) {
	groqReq := map[string]interface{}{
		"model":       c.model,
		"messages":    req.Messages,
		"temperature": req.Temperature,
		"max_tokens":  req.MaxTokens,
		"stream":      req.Stream,
	}

	if len(req.Tools) > 0 {
		tools := make([]map[string]interface{}, len(req.Tools))
		for i, t := range req.Tools {
			tools[i] = map[string]interface{}{
				"type":     t.Type,
				"function": t.Function,
			}
		}
		groqReq["tools"] = tools
		if req.ToolChoice != "" {
			groqReq["tool_choice"] = req.ToolChoice
		}
	}

	body, _ := json.Marshal(groqReq)
	httpReq, err := http.NewRequestWithContext(ctx, "POST", "https://api.groq.com/openai/v1/chat/completions", bytes.NewBuffer(body))
	if err != nil {
		return nil, err
	}
	httpReq.Header.Set("Content-Type", "application/json")
	httpReq.Header.Set("Authorization", "Bearer "+c.apiKey)

	resp, err := c.client.Do(httpReq)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("groq error %d: %s", resp.StatusCode, string(respBody))
	}

	var groqResp struct {
		Choices []struct {
			Message struct {
				Role      string     `json:"role"`
				Content   string     `json:"content"`
				ToolCalls []ToolCall `json:"tool_calls"`
			} `json:"message"`
		} `json:"choices"`
		Usage Usage `json:"usage"`
		Model string `json:"model"`
	}

	if err := json.Unmarshal(respBody, &groqResp); err != nil {
		return nil, err
	}

	if len(groqResp.Choices) == 0 {
		return nil, fmt.Errorf("no choices in groq response")
	}

	choice := groqResp.Choices[0]
	return &ChatResponse{
		Message: Message{
			Role:      choice.Message.Role,
			Content:   choice.Message.Content,
			ToolCalls: choice.Message.ToolCalls,
		},
		Usage:    groqResp.Usage,
		Model:    groqResp.Model,
		Provider: "groq",
	}, nil
}

type FallbackClient struct {
	primary   LLMClient
	fallback  LLMClient
}

func NewFallbackClient(primary, fallback LLMClient) *FallbackClient {
	return &FallbackClient{
		primary:  primary,
		fallback: fallback,
	}
}

func (c *FallbackClient) GetProviderName() string {
	return c.primary.GetProviderName() + "->" + c.fallback.GetProviderName()
}

func (c *FallbackClient) HealthCheck(ctx context.Context) error {
	if err := c.primary.HealthCheck(ctx); err == nil {
		return nil
	}
	return c.fallback.HealthCheck(ctx)
}

func (c *FallbackClient) Chat(ctx context.Context, req ChatRequest) (*ChatResponse, error) {
	resp, err := c.primary.Chat(ctx, req)
	if err == nil {
		return resp, nil
	}

	fallbackResp, fallbackErr := c.fallback.Chat(ctx, req)
	if fallbackErr != nil {
		return nil, fmt.Errorf("primary (%s) failed: %v; fallback (%s) failed: %v",
			c.primary.GetProviderName(), err, c.fallback.GetProviderName(), fallbackErr)
	}
	return fallbackResp, nil
}

func NewLLMClient(cfg config.Config) LLMClient {
	var primary, fallback LLMClient

	switch cfg.AIProvider {
	case "groq":
		primary = NewGroqClient(cfg)
		fallback = NewOllamaClient(cfg)
	case "ollama":
		fallthrough
	default:
		primary = NewOllamaClient(cfg)
		if cfg.GroqAPIKey != "" {
			fallback = NewGroqClient(cfg)
		} else {
			fallback = &noopClient{}
		}
	}

	if fallback == nil {
		fallback = &noopClient{}
	}

	return NewFallbackClient(primary, fallback)
}

type noopClient struct{}

func (n *noopClient) GetProviderName() string { return "none" }
func (n *noopClient) HealthCheck(ctx context.Context) error { return fmt.Errorf("no fallback configured") }
func (n *noopClient) Chat(ctx context.Context, req ChatRequest) (*ChatResponse, error) {
	return nil, fmt.Errorf("no LLM provider available")
}