package ai

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"restaurant-pos-api/internal/platform/config"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type AIService struct {
	client   LLMClient
	db       *gorm.DB
	cfg      config.Config
}

type ServiceChatRequest struct {
	Message     string
	History     []Message
	UserContext UserContext
}

type UserContext struct {
	UserID   uuid.UUID
	BranchID uuid.UUID
	Role     string
}

type ServiceChatResponse struct {
	Response     string
	DataSources  []string
	ToolCalls    []ToolCall
	Provider     string
	Model        string
	LatencyMs    int64
}

func NewAIService(db *gorm.DB, cfg config.Config) *AIService {
	return &AIService{
		client: NewLLMClient(cfg),
		db:     db,
		cfg:    cfg,
	}
}

func (s *AIService) Chat(ctx context.Context, req ServiceChatRequest) (*ServiceChatResponse, error) {
	start := time.Now()

	if req.UserContext.BranchID == uuid.Nil {
		return nil, fmt.Errorf("branch_id requerido en user_context")
	}

	messages := s.buildMessages(req)

	tools := GetToolSchemas()
	toolMap := make(map[string]Tool)
	for _, t := range tools {
		toolMap[t.Function.Name] = t
	}

	var finalResponse string
	var dataSources []string
	var executedTools []ToolCall
	maxIterations := 3

	for i := 0; i < maxIterations; i++ {
		chatReq := ChatRequest{
			Messages:    messages,
			Tools:       tools,
			ToolChoice:  "auto",
			Temperature: s.cfg.AITemperature,
			MaxTokens:   s.cfg.AIMaxTokens,
			Stream:      false,
		}

		resp, err := s.client.Chat(ctx, chatReq)
		if err != nil {
			return nil, fmt.Errorf("LLM error: %v", err)
		}

		if len(resp.Message.ToolCalls) == 0 {
			finalResponse = resp.Message.Content
			break
		}

		for _, tc := range resp.Message.ToolCalls {
			executedTools = append(executedTools, tc)

			var args map[string]interface{}
			if err := json.Unmarshal([]byte(tc.Function.Arguments), &args); err != nil {
				args = map[string]interface{}{}
			}

			result, err := ExecuteTool(ctx, tc.Function.Name, args, s.db,
				req.UserContext.UserID, req.UserContext.BranchID, req.UserContext.Role)

			toolResult := map[string]interface{}{
				"tool": tc.Function.Name,
				"args": args,
			}
			if err != nil {
				toolResult["error"] = err.Error()
			} else {
				toolResult["result"] = result
				dataSources = appendUnique(dataSources, tc.Function.Name)
			}

			messages = append(messages, Message{
				Role:       "tool",
				Content:    toJSON(toolResult),
				ToolCallID: tc.ID,
				Name:       tc.Function.Name,
			})
		}
	}

	if finalResponse == "" {
		finalResponse = "No pude generar una respuesta. Intenta reformular tu pregunta."
	}

	return &ServiceChatResponse{
		Response:    finalResponse,
		DataSources: unique(dataSources),
		ToolCalls:   executedTools,
		Provider:    "ollama",
		Model:       s.cfg.OllamaModel,
		LatencyMs:   time.Since(start).Milliseconds(),
	}, nil
}

func (s *AIService) buildMessages(req ServiceChatRequest) []Message {
	messages := []Message{
		{Role: "system", Content: NeoPOSSystemPrompt},
	}

	for _, h := range req.History {
		if h.Role == "user" || h.Role == "assistant" {
			messages = append(messages, Message{
				Role:    h.Role,
				Content: h.Content,
			})
		}
	}

	messages = append(messages, Message{
		Role:    "user",
		Content: req.Message,
	})

	return messages
}

func toJSON(v interface{}) string {
	b, _ := json.Marshal(v)
	return string(b)
}

func unique(s []string) []string {
	seen := make(map[string]bool)
	result := []string{}
	for _, v := range s {
		if !seen[v] {
			seen[v] = true
			result = append(result, v)
		}
	}
	return result
}

func appendUnique(s []string, v string) []string {
	for _, existing := range s {
		if existing == v {
			return s
		}
	}
	return append(s, v)
}