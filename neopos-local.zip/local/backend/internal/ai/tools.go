package ai

import (
	"context"
	"fmt"
	"time"

	"restaurant-pos-api/internal/cash_register"
	"restaurant-pos-api/internal/invoices"
	"restaurant-pos-api/internal/products"
	"restaurant-pos-api/internal/sales"
	"restaurant-pos-api/internal/tables"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type ToolHandler func(ctx context.Context, args map[string]interface{}) (any, error)

type ToolDef struct {
	Name        string
	Description string
	Parameters  ToolSchema
	Handler     ToolHandler
}

var AllTools []ToolDef

func init() {
	AllTools = []ToolDef{
		{
			Name:        "get_sales_report",
			Description: "Obtiene reporte de ventas por rango de fechas. Filtra por sucursal del usuario autenticado.",
			Parameters: ToolSchema{
				Type: "object",
				Properties: map[string]Property{
					"date_from": {Type: "string", Description: "Fecha inicio formato YYYY-MM-DD (ej: 2024-01-15)"},
					"date_to":   {Type: "string", Description: "Fecha fin formato YYYY-MM-DD (ej: 2024-01-15)"},
				},
				Required: []string{"date_from", "date_to"},
			},
			Handler: handleGetSalesReport,
		},
		{
			Name:        "get_low_stock_alerts",
			Description: "Obtiene productos con stock bajo del punto de reorden. Filtra por sucursal del usuario.",
			Parameters: ToolSchema{
				Type: "object",
				Properties: map[string]Property{
					"branch_id": {Type: "string", Description: "ID de sucursal (opcional, usa la del usuario si no se proporciona)"},
				},
				Required: []string{},
			},
			Handler: handleGetLowStockAlerts,
		},
		{
			Name:        "get_invoice_status",
			Description: "Obtiene estado de facturación electrónica (emitidas, rechazadas, pendientes) por rango de fechas.",
			Parameters: ToolSchema{
				Type: "object",
				Properties: map[string]Property{
					"date_from": {Type: "string", Description: "Fecha inicio YYYY-MM-DD"},
					"date_to":   {Type: "string", Description: "Fecha fin YYYY-MM-DD"},
				},
				Required: []string{"date_from", "date_to"},
			},
			Handler: handleGetInvoiceStatus,
		},
		{
			Name:        "get_product_catalog",
			Description: "Obtiene catálogo de productos con precios, stock y categoría. Filtra por sucursal y opcionalmente por categoría.",
			Parameters: ToolSchema{
				Type: "object",
				Properties: map[string]Property{
					"category_id": {Type: "string", Description: "ID de categoría (opcional)"},
					"active_only": {Type: "boolean", Description: "Solo productos activos (default true)"},
				},
				Required: []string{},
			},
			Handler: handleGetProductCatalog,
		},
		{
			Name:        "get_table_status",
			Description: "Obtiene estado actual de mesas (libres, ocupadas, reservadas) con tiempo de ocupación.",
			Parameters: ToolSchema{
				Type: "object",
				Properties: map[string]Property{
					"branch_id": {Type: "string", Description: "ID de sucursal (opcional)"},
				},
				Required: []string{},
			},
			Handler: handleGetTableStatus,
		},
		{
			Name:        "get_active_cash_session",
			Description: "Obtiene la sesión de caja activa del usuario/sucursal con montos de apertura/esperado/actual.",
			Parameters: ToolSchema{
				Type: "object",
				Properties: map[string]Property{
					"branch_id": {Type: "string", Description: "ID de sucursal (requerido)"},
				},
				Required: []string{"branch_id"},
			},
			Handler: handleGetActiveCashSession,
		},
	}
}

func GetToolSchemas() []Tool {
	var schemas []Tool
	for _, t := range AllTools {
		schemas = append(schemas, Tool{
			Type: "function",
			Function: Function{
				Name:        t.Name,
				Description: t.Description,
				Parameters:  t.Parameters,
			},
		})
	}
	return schemas
}

func GetToolByName(name string) *ToolDef {
	for i := range AllTools {
		if AllTools[i].Name == name {
			return &AllTools[i]
		}
	}
	return nil
}

type ToolContext struct {
	DB       *gorm.DB
	UserID   uuid.UUID
	BranchID uuid.UUID
	Role     string
}

func handleGetSalesReport(ctx context.Context, args map[string]interface{}) (any, error) {
	tc := ctx.Value("tool_context").(*ToolContext)

	dateFromStr, _ := args["date_from"].(string)
	dateToStr, _ := args["date_to"].(string)

	dateFrom, err := time.Parse("2006-01-02", dateFromStr)
	if err != nil {
		return nil, fmt.Errorf("date_from inválido: %v", err)
	}
	dateTo, err := time.Parse("2006-01-02", dateToStr)
	if err != nil {
		return nil, fmt.Errorf("date_to inválido: %v", err)
	}
	dateTo = dateTo.Add(23*time.Hour + 59*time.Minute + 59*time.Second)

	query := tc.DB.Model(&sales.Sale{}).
		Where("branch_id = ? AND created_at BETWEEN ? AND ?", tc.BranchID, dateFrom, dateTo)

	var totalOrders int64
	var totalAmount int64
	var byPaymentMethod []struct {
		PaymentMethod string
		Count         int64
		Total         int64
	}

	query.Count(&totalOrders)
	query.Select("COALESCE(SUM(total), 0)").Scan(&totalAmount)
	query.Select("payment_method, COUNT(*) as count, COALESCE(SUM(total), 0) as total").
		Group("payment_method").
		Scan(&byPaymentMethod)

	topProducts := []struct {
		Name     string
		Quantity int64
		Revenue  int64
	}{}
	tc.DB.Table("sale_items si").
		Select("si.name, COALESCE(SUM(si.quantity), 0) as quantity, COALESCE(SUM(si.total), 0) as revenue").
		Joins("JOIN sales s ON s.id = si.sale_id").
		Where("s.branch_id = ? AND s.created_at BETWEEN ? AND ?", tc.BranchID, dateFrom, dateTo).
		Group("si.name").
		Order("revenue DESC").
		Limit(5).
		Scan(&topProducts)

	return map[string]interface{}{
		"period":           fmt.Sprintf("%s a %s", dateFromStr, dateToStr),
		"branch_id":        tc.BranchID.String(),
		"total_orders":     totalOrders,
		"total_amount_cop": totalAmount,
		"by_payment_method": byPaymentMethod,
		"top_products":     topProducts,
		"currency":         "COP",
	}, nil
}

func handleGetLowStockAlerts(ctx context.Context, args map[string]interface{}) (any, error) {
	tc := ctx.Value("tool_context").(*ToolContext)

	var alerts []struct {
		ProductID   uuid.UUID `json:"product_id"`
		ProductName string    `json:"product_name"`
		CurrentStock int      `json:"current_stock"`
		MinStock    int       `json:"min_stock"`
		Category    string    `json:"category"`
	}

	tc.DB.Table("products p").
		Select("p.id as product_id, p.name as product_name, p.price, c.name as category").
		Joins("LEFT JOIN categories c ON c.id = p.category_id").
		Where("p.branch_id = ? AND p.active = true", tc.BranchID).
		Scan(&alerts)

	for i := range alerts {
		var stock int64
		tc.DB.Table("inventory_movements im").
			Select("COALESCE(SUM(CASE WHEN im.type = ? THEN im.quantity WHEN im.type = ? THEN -im.quantity ELSE im.quantity END), 0)").
			Where("im.branch_id = ? AND im.product_id = ?", tc.BranchID, alerts[i].ProductID).
			Scan(&stock)
		alerts[i].CurrentStock = int(stock)
		alerts[i].MinStock = 10
	}

	var lowStock []map[string]interface{}
	for _, a := range alerts {
		if a.CurrentStock <= a.MinStock {
			lowStock = append(lowStock, map[string]interface{}{
				"product_id":    a.ProductID.String(),
				"product_name":  a.ProductName,
				"current_stock": a.CurrentStock,
				"min_stock":     a.MinStock,
				"category":      a.Category,
			})
		}
	}

	return map[string]interface{}{
		"branch_id":    tc.BranchID.String(),
		"low_stock":    lowStock,
		"alert_count":  len(lowStock),
		"checked_at":   time.Now().Format("2006-01-02 15:04:05"),
	}, nil
}

func handleGetInvoiceStatus(ctx context.Context, args map[string]interface{}) (any, error) {
	tc := ctx.Value("tool_context").(*ToolContext)

	dateFromStr, _ := args["date_from"].(string)
	dateToStr, _ := args["date_to"].(string)

	dateFrom, err := time.Parse("2006-01-02", dateFromStr)
	if err != nil {
		return nil, fmt.Errorf("date_from inválido: %v", err)
	}
	dateTo, err := time.Parse("2006-01-02", dateToStr)
	if err != nil {
		return nil, fmt.Errorf("date_to inválido: %v", err)
	}
	dateTo = dateTo.Add(23*time.Hour + 59*time.Minute + 59*time.Second)

	var statusCounts []struct {
		Status string
		Count  int64
		Total  int64
	}

	tc.DB.Model(&invoices.Invoice{}).
		Select("status, COUNT(*) as count, COALESCE(SUM(total), 0) as total").
		Where("branch_id = ? AND created_at BETWEEN ? AND ?", tc.BranchID, dateFrom, dateTo).
		Group("status").
		Scan(&statusCounts)

	var recentInvoices []struct {
		ID        uuid.UUID `json:"id"`
		Number    string    `json:"number"`
		Status    string    `json:"status"`
		Total     int64     `json:"total"`
		CUFE      string    `json:"cufe"`
		CreatedAt time.Time `json:"created_at"`
	}

	tc.DB.Model(&invoices.Invoice{}).
		Where("branch_id = ? AND created_at BETWEEN ? AND ?", tc.BranchID, dateFrom, dateTo).
		Order("created_at DESC").
		Limit(10).
		Find(&recentInvoices)

	issued := int64(0)
	draft := int64(0)
	void := int64(0)
	rejected := int64(0)

	for _, s := range statusCounts {
		switch s.Status {
		case "ISSUED":
			issued = s.Count
		case "DRAFT":
			draft = s.Count
		case "VOID":
			void = s.Count
		case "REJECTED":
			rejected = s.Count
		}
	}

	return map[string]interface{}{
		"period":          fmt.Sprintf("%s a %s", dateFromStr, dateToStr),
		"branch_id":       tc.BranchID.String(),
		"issued":          issued,
		"draft":           draft,
		"void":            void,
		"rejected":        rejected,
		"total_invoices":  issued + draft + void + rejected,
		"recent_invoices": recentInvoices,
	}, nil
}

func handleGetProductCatalog(ctx context.Context, args map[string]interface{}) (any, error) {
	tc := ctx.Value("tool_context").(*ToolContext)

	categoryIDStr, _ := args["category_id"].(string)
	activeOnly := true
	if v, ok := args["active_only"].(bool); ok {
		activeOnly = v
	}

	query := tc.DB.Model(&products.Product{}).
		Where("branch_id = ?", tc.BranchID)

	if activeOnly {
		query = query.Where("active = ?", true)
	}
	if categoryIDStr != "" {
		if catID, err := uuid.Parse(categoryIDStr); err == nil {
			query = query.Where("category_id = ?", catID)
		}
	}

	var productList []struct {
		ID          uuid.UUID `json:"id"`
		Name        string    `json:"name"`
		Code        string    `json:"code"`
		Price       int64     `json:"price"`
		CategoryID  uuid.UUID `json:"category_id"`
		Category    string    `json:"category"`
		Active      bool      `json:"active"`
		CurrentStock int      `json:"current_stock"`
	}

	query.Select("p.id, p.name, p.code, p.price, p.category_id, c.name as category, p.active").
		Joins("LEFT JOIN categories c ON c.id = p.category_id").
		Scan(&productList)

	for i := range productList {
		var stock int64
		tc.DB.Table("inventory_movements im").
			Select("COALESCE(SUM(CASE WHEN im.type = ? THEN im.quantity WHEN im.type = ? THEN -im.quantity ELSE im.quantity END), 0)").
			Where("im.branch_id = ? AND im.product_id = ?", tc.BranchID, productList[i].ID).
			Scan(&stock)
		productList[i].CurrentStock = int(stock)
	}

	return map[string]interface{}{
		"branch_id": tc.BranchID.String(),
		"products":  productList,
		"count":     len(productList),
		"currency":  "COP",
	}, nil
}

func handleGetTableStatus(ctx context.Context, args map[string]interface{}) (any, error) {
	tc := ctx.Value("tool_context").(*ToolContext)

	branchIDStr, _ := args["branch_id"].(string)
	branchID := tc.BranchID
	if branchIDStr != "" {
		if id, err := uuid.Parse(branchIDStr); err == nil {
			branchID = id
		}
	}

	var tablesList []struct {
		ID        uuid.UUID `json:"id"`
		Number    int       `json:"number"`
		Capacity  int       `json:"capacity"`
		Status    string    `json:"status"`
		OrderID   uuid.UUID `json:"order_id,omitempty"`
		OpenedAt  *time.Time `json:"opened_at,omitempty"`
	}

	tc.DB.Model(&tables.Table{}).
		Where("branch_id = ?", branchID).
		Order("number").
		Find(&tablesList)

	free := 0
	occupied := 0
	reserved := 0
	cleaning := 0

	for i := range tablesList {
		switch tablesList[i].Status {
		case "FREE":
			free++
		case "OCCUPIED":
			occupied++
		case "RESERVED":
			reserved++
		case "CLEANING":
			cleaning++
		}
	}

	return map[string]interface{}{
		"branch_id":     branchID.String(),
		"total_tables":  len(tablesList),
		"free":          free,
		"occupied":      occupied,
		"reserved":      reserved,
		"cleaning":      cleaning,
		"tables":        tablesList,
		"checked_at":    time.Now().Format("2006-01-02 15:04:05"),
	}, nil
}

func handleGetActiveCashSession(ctx context.Context, args map[string]interface{}) (any, error) {
	tc := ctx.Value("tool_context").(*ToolContext)

	branchIDStr, _ := args["branch_id"].(string)
	branchID := tc.BranchID
	if branchIDStr != "" {
		if id, err := uuid.Parse(branchIDStr); err == nil {
			branchID = id
		}
	}

	var session cash_register.CashRegisterSession
	err := tc.DB.Where("branch_id = ? AND status = ?", branchID, "OPEN").
		Order("created_at DESC").
		First(&session).Error

	if err != nil {
		if err == gorm.ErrRecordNotFound {
			return map[string]interface{}{
				"branch_id": branchID.String(),
				"active":    false,
				"message":   "No hay sesión de caja abierta",
			}, nil
		}
		return nil, err
	}

	return map[string]interface{}{
		"branch_id":        branchID.String(),
		"session_id":       session.ID.String(),
		"active":           true,
		"opened_by":        session.OpenedBy.String(),
		"opening_amount":   session.OpeningAmount,
		"closing_amount":   session.ClosingAmount,
		"expected_amount":  session.ExpectedAmount,
		"difference":       session.Difference,
		"opened_at":        session.CreatedAt.Format("2006-01-02 15:04:05"),
		"currency":         "COP",
	}, nil
}

func ExecuteTool(ctx context.Context, name string, args map[string]interface{}, db *gorm.DB, userID, branchID uuid.UUID, role string) (any, error) {
	tool := GetToolByName(name)
	if tool == nil {
		return nil, fmt.Errorf("tool %s not found", name)
	}

	tc := &ToolContext{
		DB:       db,
		UserID:   userID,
		BranchID: branchID,
		Role:     role,
	}

	ctx = context.WithValue(ctx, "tool_context", tc)

	return tool.Handler(ctx, args)
}