package ai

import (
	"bytes"
	"encoding/json"
	"net/http"
	"time"

	"restaurant-pos-api/internal/platform/config"
	"restaurant-pos-api/internal/settings"
	"restaurant-pos-api/pkg/response"

	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

type ChatAPIRequest struct {
	Message string    `json:"message"`
	History []Message `json:"history,omitempty"`
}

type ChatAPIResponse struct {
	Response    string     `json:"response"`
	DataSources []string   `json:"data_sources,omitempty"`
	ToolCalls   []ToolCall `json:"tool_calls,omitempty"`
	Provider    string     `json:"provider,omitempty"`
	Model       string     `json:"model,omitempty"`
	LatencyMs   int64      `json:"latency_ms,omitempty"`
}

type Controller struct {
	aiService *AIService
	cfg       config.Config
	db        *gorm.DB
}

func NewController(db *gorm.DB, cfg config.Config) *Controller {
	return &Controller{
		cfg: cfg,
		db:  db,
	}
}

func (ctrl *Controller) SetAIService(svc *AIService) {
	ctrl.aiService = svc
}

func (ctrl *Controller) Chat(c *fiber.Ctx) error {
	var req ChatAPIRequest
	if err := c.BodyParser(&req); err != nil {
		return response.Error(c, fiber.StatusBadRequest, "invalid request body")
	}

	// Send query to Cloud Backend
	if ctrl.cfg.SyncRemoteURL != "" {
		token := ctrl.cfg.LicenseKey
		var s struct{ Value string }
		if err := ctrl.db.Table("settings").Select("value").Where("key = ?", "active_license_key").Scan(&s).Error; err == nil {
			if value := settings.DecodeValue(s.Value); value != "" {
				token = value
			}
		}

		client := &http.Client{Timeout: 30 * time.Second}
		payload := map[string]interface{}{
			"tenant_id": 1,
			"token":     token,
			"node_id":   ctrl.cfg.LocalNodeID,
			"message":   req.Message,
		}
		jsonPayload, _ := json.Marshal(payload)

		queryReq, err := http.NewRequest("POST", ctrl.cfg.SyncRemoteURL+"/api/v1/ai/query", bytes.NewBuffer(jsonPayload))
		if err != nil {
			return response.Error(c, fiber.StatusInternalServerError, "failed to create ai query request")
		}
		queryReq.Header.Set("Content-Type", "application/json")

		resp, err := client.Do(queryReq)
		if err != nil {
			return response.Error(c, fiber.StatusServiceUnavailable, "No se pudo conectar con la IA en la nube")
		}
		defer resp.Body.Close()

		if resp.StatusCode == fiber.StatusTooManyRequests {
			return response.Error(c, fiber.StatusTooManyRequests, "Límite diario de consultas IA alcanzado")
		}
		if resp.StatusCode != http.StatusOK {
			return response.Error(c, fiber.StatusPaymentRequired, "Error al consultar la IA (Licencia inválida o error en servidor)")
		}

		var queryRes map[string]interface{}
		if err := json.NewDecoder(resp.Body).Decode(&queryRes); err != nil {
			return response.Error(c, fiber.StatusInternalServerError, "Error al decodificar respuesta de la IA")
		}

		reply, _ := queryRes["text"].(string)
		if reply == "" {
			if r2, ok := queryRes["response"].(string); ok {
				reply = r2
			} else {
				return response.Error(c, fiber.StatusInternalServerError, "Respuesta inválida de la IA")
			}
		}

		var actions []map[string]interface{}
		if act, ok := queryRes["actions"].([]interface{}); ok {
			for _, a := range act {
				if am, ok2 := a.(map[string]interface{}); ok2 {
					actions = append(actions, am)
				}
			}
		}

		return response.OK(c, fiber.Map{
			"text":    reply,
			"actions": actions,
		})
	}

	return response.Error(c, fiber.StatusPaymentRequired, "Licencia no configurada")
}
