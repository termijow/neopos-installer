package debug

import (
	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
	"restaurant-pos-api/internal/platform/config"
	"restaurant-pos-api/internal/settings"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB, cfg config.Config) {
	settingsRepo := settings.NewRepository(db)
	settingsSvc := settings.NewService(settingsRepo)
	controller := NewController(db, cfg, settingsSvc)

	router.Post("/debug/seed", controller.RunSeeder)
	router.Get("/debug/seed/status", controller.GetSeederStatus)
	router.Post("/debug/license-expire-soon", controller.LicenseExpireSoon)
	router.Post("/debug/license-invalid", controller.LicenseInvalid)
	router.Post("/debug/license-valid", controller.LicenseValid)
	router.Post("/debug/license-fraud", controller.LicenseFraud)
	router.Get("/debug/cloud-logs", controller.GetCloudLogs)
}
