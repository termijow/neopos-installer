package debug

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math/rand"
	"net/http"
	"sync"
	"time"

	"restaurant-pos-api/internal/audit"
	"restaurant-pos-api/internal/branches"
	"restaurant-pos-api/internal/categories"
	"restaurant-pos-api/internal/inventory"
	"restaurant-pos-api/internal/platform/config"
	"restaurant-pos-api/internal/products"
	"restaurant-pos-api/internal/recipes"
	"restaurant-pos-api/internal/sales"
	"restaurant-pos-api/internal/settings"
	"restaurant-pos-api/internal/users"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Controller struct {
	db          *gorm.DB
	cfg         config.Config
	settingsSvc settings.Service
	mu          sync.Mutex
	status      SeederStatus
}

type SeederStatus struct {
	IsRunning          bool   `json:"is_running"`
	Level              string `json:"level"`
	Progress           int    `json:"progress"` // 0 to 100
	TargetSales        int    `json:"target_sales"`
	SalesCreated       int    `json:"sales_created"`
	SaleItemsCreated   int    `json:"sale_items_created"`
	InventoryCreated   int    `json:"inventory_created"`
	ProductsCreated    int    `json:"products_created"`
	CustomersCreated   int    `json:"customers_created"`
	AuditLogsCreated   int    `json:"audit_logs_created"`
	StatusMessage      string `json:"status_message"`
}

func NewController(db *gorm.DB, cfg config.Config, settingsSvc settings.Service) *Controller {
	return &Controller{db: db, cfg: cfg, settingsSvc: settingsSvc}
}

func (c *Controller) GetSeederStatus(ctx *fiber.Ctx) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	return ctx.JSON(fiber.Map{"data": c.status})
}

func (c *Controller) RunSeeder(ctx *fiber.Ctx) error {
	var body struct {
		Level string `json:"level"`
	}
	if err := ctx.BodyParser(&body); err != nil {
		body.Level = "pequeño"
	}

	c.mu.Lock()
	if c.status.IsRunning {
		c.mu.Unlock()
		return ctx.Status(400).JSON(fiber.Map{"error": "El seeder ya está corriendo"})
	}

	targetSales, targetProducts, targetCustomers, targetAudit, targetRecipes := 5000, 100, 500, 10000, 5000
	switch body.Level {
	case "mediano":
		targetSales, targetProducts, targetCustomers, targetAudit, targetRecipes = 50000, 1000, 5000, 100000, 8000
	case "grande":
		targetSales, targetProducts, targetCustomers, targetAudit, targetRecipes = 250000, 5000, 15000, 500000, 12000
	case "apocalipsis":
		targetSales, targetProducts, targetCustomers, targetAudit, targetRecipes = 1000000, 15000, 30000, 2000000, 15000
	}

	c.status = SeederStatus{
		IsRunning:        true,
		Level:            body.Level,
		TargetSales:      targetSales,
		Progress:         0,
		StatusMessage:    "Iniciando...",
	}
	c.mu.Unlock()

	go c.runAsyncSeeder(targetSales, targetProducts, targetCustomers, targetAudit, targetRecipes)

	return ctx.JSON(fiber.Map{
		"data": fiber.Map{
			"message": "Seeder iniciado en segundo plano",
		},
	})
}

func (c *Controller) runAsyncSeeder(targetSales, targetProducts, targetCustomers, targetAudit, targetRecipes int) {
	defer func() {
		c.mu.Lock()
		c.status.IsRunning = false
		c.status.Progress = 100
		c.status.StatusMessage = "Completado exitosamente"
		c.mu.Unlock()
	}()

	var branch branches.Branch
	if err := c.db.First(&branch).Error; err != nil {
		c.mu.Lock()
		c.status.StatusMessage = "Error: Sucursal no encontrada"
		c.mu.Unlock()
		return
	}

	var category categories.Category
	if err := c.db.First(&category).Error; err != nil {
		category = categories.Category{Name: "General"}; category.BranchID = branch.ID
		category.ID = uuid.New()
		c.db.Create(&category)
	}

	r := rand.New(rand.NewSource(time.Now().UnixNano()))

	firstNames := []string{"Juan", "Maria", "Carlos", "Ana", "Luis", "Elena", "Pedro", "Laura", "Jose", "Sofia", "Miguel", "Isabella", "Andres", "Camila", "Diego", "Valeria", "Jorge", "Lucia", "Fernando", "Marta"}
	lastNames := []string{"Perez", "Lopez", "Ramirez", "Gonzalez", "Rodriguez", "Fernandez", "Gomez", "Diaz", "Martinez", "Hernandez", "Gimenez", "Sanchez", "Romero", "Suarez", "Ortiz", "Silva", "Vargas", "Castro", "Ruiz", "Alvarez"}
	
	productNames := []string{"Hamburguesa", "Pizza", "Gaseosa", "Jugo", "Cerveza", "Papas Fritas", "Perro Caliente", "Ensalada", "Sopa", "Postre", "Taco", "Burrito", "Nachos", "Limonada", "Agua", "Cafe", "Te", "Sandwich", "Empanada", "Arepa"}
	productAdjectives := []string{"Especial", "Sencillo", "Doble", "Grande", "Pequeño", "Mediano", "Familiar", "Picante", "Dulce", "Salado", "Premium", "Gourmet", "Artesanal", "Clasico", "Original", "Extra", "Supremo", "Light", "Zero", "Max"}

	c.updateStatus("Creando clientes...", 5)
	var customers []users.User
	for i := 0; i < targetCustomers; {
		batchSize := 20000
		if targetCustomers-i < 20000 {
			batchSize = targetCustomers - i
		}
		var batch []users.User
		for j := 0; j < batchSize; j++ {
			id := uuid.New()
			firstName := firstNames[r.Intn(len(firstNames))]
			lastName := lastNames[r.Intn(len(lastNames))]
			batch = append(batch, users.User{
				PasswordHash: "debug-hash",
				RoleID:       uuid.Nil,
				Name:         fmt.Sprintf("%s %s", firstName, lastName),
				Email:        fmt.Sprintf("%s.%s%s@test.com", firstName, lastName, id.String()[:4]),
			})
			batch[len(batch)-1].ID = id
			batch[len(batch)-1].BranchID = branch.ID
		}
		c.db.CreateInBatches(batch, 5000)
		customers = append(customers, batch...)
		
		c.mu.Lock()
		c.status.CustomersCreated += batchSize
		c.mu.Unlock()
		i += batchSize
	}

	c.updateStatus("Creando productos...", 10)
	var allProducts []products.Product
	for i := 0; i < targetProducts; {
		batchSize := 10000
		if targetProducts-i < 10000 {
			batchSize = targetProducts - i
		}
		var batch []products.Product
		for j := 0; j < batchSize; j++ {
			id := uuid.New()
			name := productNames[r.Intn(len(productNames))]
			adj := productAdjectives[r.Intn(len(productAdjectives))]
			prod := products.Product{
				Name:       fmt.Sprintf("%s %s", name, adj),
				CategoryID: category.ID,
				Price:      int64(r.Intn(40000) + 5000),
				Code:       fmt.Sprintf("%s-%s", string(name[0]), id.String()[:6]),
			}
			prod.ID = id
			prod.BranchID = branch.ID
			batch = append(batch, prod)
		}
		c.db.CreateInBatches(batch, 5000)
		
		// Initial stock IN movements
		var initStock []inventory.InventoryMovement
		for _, p := range batch {
			im := inventory.InventoryMovement{
				ProductID: p.ID,
				Type:      inventory.MovementIn,
				Quantity:  r.Intn(1000) + 500, // 500 to 1500 units initial stock
				Reason:    "Inventario Inicial",
			}
			im.ID = uuid.New()
			im.BranchID = branch.ID
			im.CreatedAt = time.Now().AddDate(-5, 0, 0)
			initStock = append(initStock, im)
		}
		c.db.CreateInBatches(initStock, 5000)
		
		allProducts = append(allProducts, batch...)

		c.mu.Lock()
		c.status.ProductsCreated += batchSize
		c.mu.Unlock()
		i += batchSize
	}

	if len(allProducts) == 0 {
		c.db.Where("branch_id = ?", branch.ID).Find(&allProducts)
	}
	if len(customers) == 0 {
		c.db.Where("branch_id = ?", branch.ID).Find(&customers)
	}

	c.updateStatus("Creando recetas...", 12)
	actualRecipes := targetRecipes
	if len(allProducts) < actualRecipes {
		actualRecipes = len(allProducts)
	}
	for i := 0; i < actualRecipes; {
		batchSize := 5000
		if actualRecipes-i < 5000 {
			batchSize = actualRecipes - i
		}
		var recipeBatch []recipes.Recipe
		var recipeItemsBatch []recipes.RecipeItem
		for j := 0; j < batchSize; j++ {
			prod := allProducts[i+j]
			rec := recipes.Recipe{
				ProductID:   prod.ID,
				Description: fmt.Sprintf("Receta estandar para %s", prod.Name),
				Yield:       1.0,
			}
			rec.ID = uuid.New()
			rec.BranchID = branch.ID
			recipeBatch = append(recipeBatch, rec)
			
			// Link random raw materials
			numMaterials := r.Intn(4) + 1
			for m := 0; m < numMaterials; m++ {
				rawMaterial := allProducts[r.Intn(len(allProducts))]
				ri := recipes.RecipeItem{
					RecipeID:      rec.ID,
					InventoryItem: rawMaterial.ID,
					Quantity:      float64(r.Intn(5) + 1),
					Unit:          "und",
				}
				ri.ID = uuid.New()
				recipeItemsBatch = append(recipeItemsBatch, ri)
			}
		}
		c.db.CreateInBatches(recipeBatch, 1000)
		c.db.CreateInBatches(recipeItemsBatch, 1000)
		i += batchSize
	}

	c.updateStatus("Creando ventas e inventario...", 15)
	
	paymentMethods := []string{sales.PaymentCash, sales.PaymentCreditCard, sales.PaymentDebitCard, sales.PaymentTransfer}
	
	startDate := time.Now().AddDate(-5, 0, 0)
	totalDays := int(time.Now().Sub(startDate).Hours() / 24)
	if totalDays <= 0 {
		totalDays = 1
	}

	var salesBatch []sales.Sale
	var saleItemsBatch []sales.SaleItem
	var invBatch []inventory.InventoryMovement
	var auditBatch []audit.AuditLog

	salesProcessed := 0

	for salesProcessed < targetSales {
		// Calculate a random date within the last 5 years
		randomDays := r.Intn(totalDays)
		saleTime := startDate.AddDate(0, 0, randomDays).Add(time.Duration(r.Intn(14*60)) * time.Minute).Add(time.Hour * 8)

		saleID := uuid.New()

		sale := sales.Sale{
			PaymentMethod: paymentMethods[r.Intn(len(paymentMethods))],
			CashSessionID: uuid.New(),
		}
		sale.ID = saleID
		sale.BranchID = branch.ID
		sale.CreatedAt = saleTime
		sale.UpdatedAt = saleTime

		numItems := r.Intn(6) + 1 // 1 to 6 items per sale (realistic average)
		var subtotal int64

		for k := 0; k < numItems; k++ {
			prod := allProducts[r.Intn(len(allProducts))]
			qty := r.Intn(3) + 1
			itemTotal := prod.Price * int64(qty)
			subtotal += itemTotal

			saleItem := sales.SaleItem{
				SaleID:    saleID,
				ProductID: prod.ID,
				Name:      prod.Name,
				Quantity:  qty,
				UnitPrice: prod.Price,
				Total:     itemTotal,
			}
			saleItem.ID = uuid.New()
			saleItem.CreatedAt = saleTime
			saleItem.UpdatedAt = saleTime
			saleItemsBatch = append(saleItemsBatch, saleItem)

			invMov := inventory.InventoryMovement{
				ProductID: prod.ID,
				Type:      inventory.MovementOut,
				Quantity:  qty,
				Reason:    "Sale",
			}
			invMov.ID = uuid.New()
			invMov.BranchID = branch.ID
			invMov.CreatedAt = saleTime
			invMov.UpdatedAt = saleTime
			invBatch = append(invBatch, invMov)
		}

		sale.Subtotal = subtotal
		sale.Total = subtotal
		salesBatch = append(salesBatch, sale)
		salesProcessed++

		if len(salesBatch) >= 20000 {
			c.db.CreateInBatches(salesBatch, 5000)
			c.db.CreateInBatches(saleItemsBatch, 5000)
			c.db.CreateInBatches(invBatch, 5000)

			c.mu.Lock()
			c.status.SalesCreated += len(salesBatch)
			c.status.SaleItemsCreated += len(saleItemsBatch)
			c.status.InventoryCreated += len(invBatch)
			c.status.Progress = 15 + int(float64(salesProcessed)/float64(targetSales)*75)
			c.status.StatusMessage = fmt.Sprintf("Ventas: %d / %d", salesProcessed, targetSales)
			c.mu.Unlock()

			salesBatch = nil
			saleItemsBatch = nil
			invBatch = nil
		}
	}

	if len(salesBatch) > 0 {
		c.db.CreateInBatches(salesBatch, 5000)
		c.db.CreateInBatches(saleItemsBatch, 5000)
		c.db.CreateInBatches(invBatch, 5000)
		
		c.mu.Lock()
		c.status.SalesCreated += len(salesBatch)
		c.status.SaleItemsCreated += len(saleItemsBatch)
		c.status.InventoryCreated += len(invBatch)
		c.mu.Unlock()
	}

	c.updateStatus("Creando registros de auditoría (Logs)...", 95)
	logsProcessed := 0
	for logsProcessed < targetAudit {
		batchSize := 50000
		if targetAudit-logsProcessed < 50000 {
			batchSize = targetAudit - logsProcessed
		}
		for j := 0; j < batchSize; j++ {
			logTime := startDate.AddDate(0, 0, r.Intn(totalDays))
			aLog := audit.AuditLog{
				UserID:    customers[r.Intn(len(customers))].ID,
				Action:    "CREATE",
				Entity:    "Sale",
				EntityID:  uuid.New().String(),
				Metadata:  "{}",
			}
			aLog.ID = uuid.New()
			aLog.BranchID = branch.ID
			aLog.CreatedAt = logTime
			auditBatch = append(auditBatch, aLog)
		}
		c.db.CreateInBatches(auditBatch, 10000)
		
		c.mu.Lock()
		c.status.AuditLogsCreated += len(auditBatch)
		c.mu.Unlock()
		
		auditBatch = nil
		logsProcessed += batchSize
	}
}

func (c *Controller) updateStatus(msg string, progress int) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.status.StatusMessage = msg
	c.status.Progress = progress
}

func (c *Controller) generateSignature(licenseType, expiresAt string) string {
	secret := c.cfg.JWTSecret
	if secret == "" {
		secret = "default_local_secret"
	}
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(licenseType + "|" + expiresAt))
	return hex.EncodeToString(mac.Sum(nil))
}

type CachedLicense struct {
	Valid       bool   `json:"valid"`
	LicenseType string `json:"license_type"`
	ExpiresAt   string `json:"expires_at"`
	Signature   string `json:"signature"`
}

func (c *Controller) updateLicense(ctx *fiber.Ctx, valid bool, licenseType, expiresAt string, resign bool) error {
	var sig string
	if resign {
		sig = c.generateSignature(licenseType, expiresAt)
	} else {
		list, _ := c.settingsSvc.List()
		for _, s := range list {
			if s.Key == "cached_license" {
				var old CachedLicense
				if err := json.Unmarshal([]byte(s.Value), &old); err == nil {
					sig = old.Signature
				}
				break
			}
		}
	}

	cached := CachedLicense{
		Valid:       valid,
		LicenseType: licenseType,
		ExpiresAt:   expiresAt,
		Signature:   sig,
	}

	valBytes, _ := json.Marshal(cached)
	c.settingsSvc.Upsert(settings.UpsertSettingRequest{
		Key:   "cached_license",
		Value: string(valBytes),
	})

	return ctx.JSON(fiber.Map{"data": fiber.Map{"message": "License updated", "new_state": cached}})
}

func (c *Controller) LicenseExpireSoon(ctx *fiber.Ctx) error {
	expiresAt := time.Now().Add(3 * 24 * time.Hour).Format(time.RFC3339)
	return c.updateLicense(ctx, true, "annual", expiresAt, true)
}

func (c *Controller) LicenseInvalid(ctx *fiber.Ctx) error {
	expiresAt := time.Now().Add(-10 * 24 * time.Hour).Format(time.RFC3339)
	return c.updateLicense(ctx, false, "annual", expiresAt, true)
}

func (c *Controller) LicenseValid(ctx *fiber.Ctx) error {
	expiresAt := time.Now().Add(365 * 24 * time.Hour).Format(time.RFC3339)
	return c.updateLicense(ctx, true, "annual", expiresAt, true)
}

func (c *Controller) LicenseFraud(ctx *fiber.Ctx) error {
	expiresAt := time.Now().Add(100 * 365 * 24 * time.Hour).Format(time.RFC3339)
	return c.updateLicense(ctx, true, "annual", expiresAt, false)
}

func (c *Controller) GetCloudLogs(ctx *fiber.Ctx) error {
	remoteURL := c.cfg.SyncRemoteURL
	if remoteURL == "" {
		return ctx.Status(400).JSON(fiber.Map{"error": "SYNC_REMOTE_URL not configured"})
	}

	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Get(remoteURL + "/api/v1/admin/system-logs")
	if err != nil {
		return ctx.Status(500).JSON(fiber.Map{"error": err.Error()})
	}
	defer resp.Body.Close()

	bodyBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		return ctx.Status(500).JSON(fiber.Map{"error": "failed to read cloud response"})
	}

	var data interface{}
	if err := json.Unmarshal(bodyBytes, &data); err != nil {
		// Fallback to returning raw text if it's not JSON (e.g., 404 or 502 HTML pages)
		return ctx.JSON(fiber.Map{"data": fiber.Map{"logs": fmt.Sprintf("HTTP %d\n%s", resp.StatusCode, string(bodyBytes))}})
	}

	return ctx.JSON(fiber.Map{"data": data})
}
