package clients

import (
	"restaurant-pos-api/pkg/model"
)

type Client struct {
	model.Base
	model.BranchScoped
	DocumentType string `json:"document_type" gorm:"size:20;not null"`
	Document     string `json:"document" gorm:"size:50;not null"`
	Name         string `json:"name" gorm:"size:150;not null"`
	Email        string `json:"email" gorm:"size:150"`
	Phone        string `json:"phone" gorm:"size:50"`
}
