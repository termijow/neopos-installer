package clients

import (
	"errors"

	"github.com/google/uuid"
	"restaurant-pos-api/pkg/model"
)

type Service interface {
	List(branchID string) ([]Client, error)
	Create(branchID string, item *Client) error
	GetByID(branchID string, id uuid.UUID) (*Client, error)
	Update(branchID string, item *Client) error
	Delete(branchID string, id uuid.UUID) error
}

type service struct {
	repo Repository
}

func NewService(repo Repository) Service {
	return &service{repo: repo}
}

func (s *service) List(branchID string) ([]Client, error) {
	return s.repo.List(branchID)
}

func (s *service) Create(branchID string, item *Client) error {
	branchUUID, err := uuid.Parse(branchID)
	if err != nil {
		return errors.New("invalid branch_id format")
	}
	item.BranchScoped = model.BranchScoped{BranchID: branchUUID}
	
	if item.Name == "" || item.Document == "" {
		return errors.New("name and document are required")
	}

	return s.repo.Create(item)
}

func (s *service) GetByID(branchID string, id uuid.UUID) (*Client, error) {
	return s.repo.FindByID(branchID, id)
}

func (s *service) Update(branchID string, item *Client) error {
	branchUUID, err := uuid.Parse(branchID)
	if err != nil {
		return errors.New("invalid branch_id format")
	}
	item.BranchScoped = model.BranchScoped{BranchID: branchUUID}

	if item.Name == "" || item.Document == "" {
		return errors.New("name and document are required")
	}

	existing, err := s.repo.FindByID(branchID, item.ID)
	if err != nil {
		return err
	}

	existing.Name = item.Name
	existing.DocumentType = item.DocumentType
	existing.Document = item.Document
	existing.Email = item.Email
	existing.Phone = item.Phone

	return s.repo.Update(existing)
}

func (s *service) Delete(branchID string, id uuid.UUID) error {
	return s.repo.Delete(branchID, id)
}
