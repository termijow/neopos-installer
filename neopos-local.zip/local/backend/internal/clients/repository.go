package clients

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface {
	List(branchID string) ([]Client, error)
	Create(*Client) error
	FindByID(branchID string, id uuid.UUID) (*Client, error)
	Update(*Client) error
	Delete(branchID string, id uuid.UUID) error
}

type gormRepository struct {
	db *gorm.DB
}

func NewRepository(db *gorm.DB) Repository {
	return &gormRepository{db: db}
}

func (r *gormRepository) List(branchID string) ([]Client, error) {
	var items []Client
	err := r.db.Where("branch_id = ?", branchID).Order("name asc").Find(&items).Error
	return items, err
}

func (r *gormRepository) Create(item *Client) error {
	return r.db.Create(item).Error
}

func (r *gormRepository) FindByID(branchID string, id uuid.UUID) (*Client, error) {
	var item Client
	if err := r.db.First(&item, "id = ? AND branch_id = ?", id, branchID).Error; err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *gormRepository) Update(item *Client) error {
	return r.db.Save(item).Error
}

func (r *gormRepository) Delete(branchID string, id uuid.UUID) error {
	return r.db.Delete(&Client{}, "id = ? AND branch_id = ?", id, branchID).Error
}
