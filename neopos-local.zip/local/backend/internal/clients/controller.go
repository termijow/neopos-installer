package clients

import (
	"fmt"
	"net/http"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
)

type Controller struct {
	svc Service
}

func NewController(svc Service) *Controller {
	return &Controller{svc: svc}
}

func (c *Controller) List(ctx *fiber.Ctx) error {
	branchID := fmt.Sprintf("%v", ctx.Locals("branch_id"))
	
	items, err := c.svc.List(branchID)
	if err != nil {
		return ctx.Status(http.StatusInternalServerError).JSON(fiber.Map{"error": err.Error()})
	}
	return ctx.JSON(fiber.Map{"data": items})
}

func (c *Controller) Create(ctx *fiber.Ctx) error {
	branchID := fmt.Sprintf("%v", ctx.Locals("branch_id"))

	var item Client
	if err := ctx.BodyParser(&item); err != nil {
		return ctx.Status(http.StatusBadRequest).JSON(fiber.Map{"error": "Invalid request body"})
	}

	if err := c.svc.Create(branchID, &item); err != nil {
		return ctx.Status(http.StatusBadRequest).JSON(fiber.Map{"error": err.Error()})
	}

	return ctx.Status(http.StatusCreated).JSON(fiber.Map{"data": item})
}

func (c *Controller) Update(ctx *fiber.Ctx) error {
	branchID := fmt.Sprintf("%v", ctx.Locals("branch_id"))
	id, err := uuid.Parse(ctx.Params("id"))
	if err != nil {
		return ctx.Status(http.StatusBadRequest).JSON(fiber.Map{"error": "Invalid ID"})
	}

	var item Client
	if err := ctx.BodyParser(&item); err != nil {
		return ctx.Status(http.StatusBadRequest).JSON(fiber.Map{"error": "Invalid request body"})
	}
	item.ID = id

	if err := c.svc.Update(branchID, &item); err != nil {
		return ctx.Status(http.StatusBadRequest).JSON(fiber.Map{"error": err.Error()})
	}

	return ctx.JSON(fiber.Map{"data": item})
}

func (c *Controller) Delete(ctx *fiber.Ctx) error {
	branchID := fmt.Sprintf("%v", ctx.Locals("branch_id"))
	id, err := uuid.Parse(ctx.Params("id"))
	if err != nil {
		return ctx.Status(http.StatusBadRequest).JSON(fiber.Map{"error": "Invalid ID"})
	}

	if err := c.svc.Delete(branchID, id); err != nil {
		return ctx.Status(http.StatusInternalServerError).JSON(fiber.Map{"error": err.Error()})
	}

	return ctx.SendStatus(http.StatusNoContent)
}
