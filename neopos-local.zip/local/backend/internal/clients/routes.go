package clients

import (
	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func SetupRoutes(router fiber.Router, db *gorm.DB) {
	repo := NewRepository(db)
	svc := NewService(repo)
	controller := NewController(svc)

	router.Get("/clients", controller.List)
	router.Post("/clients", controller.Create)
	router.Put("/clients/:id", controller.Update)
	router.Delete("/clients/:id", controller.Delete)
}
