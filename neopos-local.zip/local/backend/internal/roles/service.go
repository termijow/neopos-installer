package roles

import "github.com/google/uuid"

type Service interface {
	List() ([]Role, error)
	Create(req UpsertRoleRequest) (*Role, error)
	Update(id uuid.UUID, req UpsertRoleRequest) (*Role, error)
	Delete(id uuid.UUID) error
}

type service struct{ repo Repository }

func NewService(repo Repository) Service { return &service{repo: repo} }

func (s *service) List() ([]Role, error) { return s.repo.List() }

func (s *service) Create(req UpsertRoleRequest) (*Role, error) {
	active := true
	if req.Active != nil {
		active = *req.Active
	}
	role := &Role{Name: req.Name, Description: req.Description, Permissions: req.Permissions, Active: active}
	return role, s.repo.Create(role)
}

func (s *service) Update(id uuid.UUID, req UpsertRoleRequest) (*Role, error) {
	role, err := s.repo.FindByID(id)
	if err != nil {
		return nil, err
	}
	if req.Name != "" {
		role.Name = req.Name
	}
	role.Description = req.Description
	if req.Permissions != "" {
		role.Permissions = req.Permissions
	}
	if req.Active != nil {
		role.Active = *req.Active
	}
	return role, s.repo.Update(role)
}

func (s *service) Delete(id uuid.UUID) error { return s.repo.Delete(id) }
