package roles

import "restaurant-pos-api/pkg/model"

type Role struct {
	model.Base
	Name        string `json:"name" gorm:"size:80;uniqueIndex;not null"`
	Description string `json:"description" gorm:"size:255"`
	Permissions string `json:"permissions" gorm:"type:jsonb;default:'[]'"`
	Active      bool   `json:"active" gorm:"default:true"`
}
