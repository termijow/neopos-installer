package roles

import (
	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB) {
	controller := NewController(NewService(NewRepository(db)))
	router.Get("/roles", controller.List)
	router.Post("/roles", controller.Create)
	router.Put("/roles/:id", controller.Update)
	router.Delete("/roles/:id", controller.Delete)
}
