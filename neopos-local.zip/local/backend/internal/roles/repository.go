package roles

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface {
	List() ([]Role, error)
	Create(role *Role) error
	FindByID(id uuid.UUID) (*Role, error)
	Update(role *Role) error
	Delete(id uuid.UUID) error
}

type gormRepository struct{ db *gorm.DB }

func NewRepository(db *gorm.DB) Repository { return &gormRepository{db: db} }

func (r *gormRepository) List() ([]Role, error) {
	var roles []Role
	err := r.db.Order("name asc").Find(&roles).Error
	return roles, err
}

func (r *gormRepository) Create(role *Role) error { return r.db.Create(role).Error }

func (r *gormRepository) FindByID(id uuid.UUID) (*Role, error) {
	var role Role
	if err := r.db.First(&role, "id = ?", id).Error; err != nil {
		return nil, err
	}
	return &role, nil
}

func (r *gormRepository) Update(role *Role) error { return r.db.Save(role).Error }

func (r *gormRepository) Delete(id uuid.UUID) error {
	return r.db.Delete(&Role{}, "id = ?", id).Error
}
