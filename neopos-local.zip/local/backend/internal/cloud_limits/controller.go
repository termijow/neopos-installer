package cloud_limits

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"restaurant-pos-api/internal/platform/config"
	"restaurant-pos-api/internal/settings"
	"restaurant-pos-api/pkg/response"

	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

type Controller struct {
	cfg config.Config
	db  *gorm.DB
}

type usageLimitUpdate struct {
	AIMonthlyLimit                int `json:"ai_monthly_limit"`
	ElectronicInvoiceMonthlyLimit int `json:"electronic_invoice_monthly_limit"`
}

func NewController(cfg config.Config, db *gorm.DB) *Controller {
	return &Controller{cfg: cfg, db: db}
}

func (h *Controller) Get(c *fiber.Ctx) error {
	data, status, err := h.callCloud(http.MethodPost, "/read", nil)
	if err != nil {
		return response.Error(c, status, err.Error())
	}
	return response.OK(c, data)
}

func (h *Controller) Update(c *fiber.Ctx) error {
	var payload usageLimitUpdate
	if err := c.BodyParser(&payload); err != nil {
		return response.Error(c, fiber.StatusBadRequest, "invalid request body")
	}
	data, status, err := h.callCloud(http.MethodPost, "", payload)
	if err != nil {
		return response.Error(c, status, err.Error())
	}
	return response.OK(c, data)
}

func (h *Controller) callCloud(method, path string, body interface{}) (map[string]interface{}, int, error) {
	if strings.TrimSpace(h.cfg.SyncRemoteURL) == "" {
		return nil, fiber.StatusServiceUnavailable, fmt.Errorf("Cloud sync URL is not configured")
	}
	token := h.cfg.LicenseKey
	var stored struct{ Value string }
	if err := h.db.Table("settings").Select("value").Where("key = ?", "active_license_key").Scan(&stored).Error; err == nil {
		if decoded := settings.DecodeValue(stored.Value); decoded != "" {
			token = decoded
		}
	}

	var requestBody io.Reader
	payload := map[string]interface{}{"token": token}
	if body != nil {
		update := body.(usageLimitUpdate)
		payload["ai_monthly_limit"] = update.AIMonthlyLimit
		payload["electronic_invoice_monthly_limit"] = update.ElectronicInvoiceMonthlyLimit
	}
	encoded, err := json.Marshal(payload)
	if err != nil {
		return nil, fiber.StatusInternalServerError, err
	}
	requestBody = bytes.NewReader(encoded)
	target := strings.TrimRight(h.cfg.SyncRemoteURL, "/") + "/api/v1/usage-limits" + path
	req, err := http.NewRequest(method, target, requestBody)
	if err != nil {
		return nil, fiber.StatusInternalServerError, err
	}
	req.Header.Set("Content-Type", "application/json")
	resp, err := (&http.Client{Timeout: 15 * time.Second}).Do(req)
	if err != nil {
		return nil, fiber.StatusServiceUnavailable, fmt.Errorf("could not contact Cloud")
	}
	defer resp.Body.Close()
	raw, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fiber.StatusBadGateway, err
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		var cloudErr struct {
			Error string `json:"error"`
		}
		_ = json.Unmarshal(raw, &cloudErr)
		if cloudErr.Error == "" {
			cloudErr.Error = "Cloud rejected usage limit request"
		}
		return nil, resp.StatusCode, fmt.Errorf("%s", cloudErr.Error)
	}
	var result map[string]interface{}
	if err := json.Unmarshal(raw, &result); err != nil {
		return nil, fiber.StatusBadGateway, fmt.Errorf("invalid Cloud response")
	}
	return result, fiber.StatusOK, nil
}
