package cloud_limits

import (
	"restaurant-pos-api/internal/platform/config"

	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, cfg config.Config, db *gorm.DB) {
	controller := NewController(cfg, db)
	router.Get("/usage-limits", controller.Get)
	router.Post("/usage-limits", controller.Update)
}
