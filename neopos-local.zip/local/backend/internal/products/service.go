package products

import "github.com/google/uuid"

type Service interface {
	List(page, limit int) ([]Product, int, error)
	Create(UpsertProductRequest) (*Product, error)
	Update(uuid.UUID, UpsertProductRequest) (*Product, error)
	Delete(uuid.UUID) error
}

type service struct {
	repo Repository
}

func NewService(repo Repository) Service {
	return &service{repo: repo}
}

func (s *service) List(page, limit int) ([]Product, int, error) {
	return s.repo.List(page, limit)
}

func (s *service) Create(req UpsertProductRequest) (*Product, error) {
	active := true
	if req.Active != nil {
		active = *req.Active
	}
	item := &Product{
		Name:       req.Name,
		Code:       req.Code,
		Price:      req.Price,
		TaxID:      req.TaxID,
		TaxType:    req.TaxType,
		Tax:        req.Tax,
		CategoryID: req.CategoryID,
		Image:      req.Image,
		Active:     active,
	}
	item.BranchID = req.BranchID
	return item, s.repo.Create(item)
}

func (s *service) Update(id uuid.UUID, req UpsertProductRequest) (*Product, error) {
	item, err := s.repo.FindByID(id)
	if err != nil {
		return nil, err
	}
	if req.Name != "" {
		item.Name = req.Name
	}
	if req.Code != "" {
		item.Code = req.Code
	}
	if req.Price > 0 {
		item.Price = req.Price
	}
	if req.TaxID != uuid.Nil {
		item.TaxID = req.TaxID
	}
	if req.TaxType != "" {
		item.TaxType = req.TaxType
		item.Tax = req.Tax
	}
	if req.CategoryID != uuid.Nil {
		item.CategoryID = req.CategoryID
	}
	if req.Image != "" {
		item.Image = req.Image
	}
	if req.BranchID != uuid.Nil {
		item.BranchID = req.BranchID
	}
	if req.Active != nil {
		item.Active = *req.Active
	}
	return item, s.repo.Update(item)
}

func (s *service) Delete(id uuid.UUID) error {
	return s.repo.Delete(id)
}
