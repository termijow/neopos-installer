package products

import (
	"encoding/csv"
	"fmt"
	"net/http"
	"strconv"

	"github.com/gofiber/fiber/v2"
)

type ImportController struct {
	importService ImportService
	productRepo   Repository // We need this for export
}

func NewImportController(importService ImportService, productRepo Repository) *ImportController {
	return &ImportController{importService: importService, productRepo: productRepo}
}

func (c *ImportController) DownloadTemplate(ctx *fiber.Ctx) error {
	ctx.Set("Content-Disposition", "attachment; filename=plantilla_productos.csv")
	ctx.Set("Content-Type", "text/csv")
	
	writer := csv.NewWriter(ctx.Response().BodyWriter())
	headers := []string{"Categoria", "Subcategoria", "Producto", "Descripcion", "Precio", "Costo", "IVA", "Disponible", "CodigoBarras", "SKU", "Orden", "Imagen"}
	writer.Write(headers)
	writer.Write([]string{"Hamburguesas", "", "Burger Birria", "Birria, lechuga, tomate y salsa chipotle", "24900", "12000", "19", "SI", "", "HAM-001", "1", ""})
	writer.Write([]string{"Hamburguesas", "", "La Especial", "Doble carne, queso y tocineta", "26900", "14000", "19", "SI", "", "HAM-002", "2", ""})
	writer.Write([]string{"Perros", "", "Perra Birria", "Salchicha alemana y birria", "23900", "11000", "19", "SI", "", "PER-001", "1", ""})
	writer.Flush()
	return nil
}

func (c *ImportController) ProcessCSV(ctx *fiber.Ctx) error {
	branchID := fmt.Sprintf("%v", ctx.Locals("branch_id"))
	if branchID == "" || branchID == "<nil>" {
		return ctx.Status(http.StatusBadRequest).JSON(fiber.Map{"error": "branch_id is required"})
	}

	fileHeader, err := ctx.FormFile("file")
	if err != nil {
		return ctx.Status(http.StatusBadRequest).JSON(fiber.Map{"error": "Archivo no enviado o inválido"})
	}

	file, err := fileHeader.Open()
	if err != nil {
		return ctx.Status(http.StatusInternalServerError).JSON(fiber.Map{"error": "No se pudo abrir el archivo"})
	}
	defer file.Close()

	resp, err := c.importService.ProcessCSV(branchID, file)
	if err != nil {
		return ctx.Status(http.StatusInternalServerError).JSON(fiber.Map{"error": err.Error()})
	}

	// For the initial upload, we just return the ImportID and headers validation status
	return ctx.Status(http.StatusOK).JSON(fiber.Map{
		"import_id": resp.ImportID,
		"headers_valid": resp.HeadersValid,
		"missing_headers": resp.MissingHeaders,
	})
}

func (c *ImportController) GetPreview(ctx *fiber.Ctx) error {
	branchID := fmt.Sprintf("%v", ctx.Locals("branch_id"))
	importID := ctx.Params("importId")

	resp, err := c.importService.GetPreview(branchID, importID)
	if err != nil {
		return ctx.Status(http.StatusInternalServerError).JSON(fiber.Map{"error": err.Error()})
	}

	return ctx.Status(http.StatusOK).JSON(fiber.Map{"data": resp})
}

func (c *ImportController) ExecuteImport(ctx *fiber.Ctx) error {
	branchID := fmt.Sprintf("%v", ctx.Locals("branch_id"))
	importID := ctx.Params("importId")

	var req ImportExecuteRequest
	if err := ctx.BodyParser(&req); err != nil {
		req.RowsOverrides = make(map[string]string)
	}
	if req.RowsOverrides == nil {
		req.RowsOverrides = make(map[string]string)
	}

	resp, err := c.importService.ExecuteImport(branchID, importID, req.RowsOverrides)
	if err != nil {
		return ctx.Status(http.StatusInternalServerError).JSON(fiber.Map{"error": err.Error()})
	}

	return ctx.Status(http.StatusOK).JSON(fiber.Map{"data": resp})
}

func (c *ImportController) ExportCSV(ctx *fiber.Ctx) error {
	_ = fmt.Sprintf("%v", ctx.Locals("branch_id"))
	products, _, err := c.productRepo.List(1, 100000)
	if err != nil {
		return ctx.Status(http.StatusInternalServerError).JSON(fiber.Map{"error": "Error al obtener productos"})
	}

	ctx.Set("Content-Disposition", "attachment; filename=productos_exportados.csv")
	ctx.Set("Content-Type", "text/csv")
	
	writer := csv.NewWriter(ctx.Response().BodyWriter())
	headers := []string{"Categoria", "Subcategoria", "Producto", "Descripcion", "Precio", "Costo", "IVA", "Disponible", "CodigoBarras", "SKU", "Orden", "Imagen"}
	writer.Write(headers)

	for _, p := range products {
		catName := ""
		if p.Category.Name != "" {
			catName = p.Category.Name
		}
		
		avail := "NO"
		if p.Active {
			avail = "SI"
		}

		writer.Write([]string{
			catName,
			"", // Subcategoria
			p.Name,
			"", // Descripcion
			strconv.FormatInt(p.Price, 10),
			"0", // Costo (not in entity)
			strconv.FormatFloat(p.Tax, 'f', -1, 64),
			avail,
			p.Code,
			"", // SKU
			"1", // Orden
			p.Image,
		})
	}

	writer.Flush()
	return nil
}
