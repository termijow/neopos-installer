package products

import "github.com/google/uuid"

type UpsertProductRequest struct {
	BranchID   uuid.UUID `json:"branch_id"`
	Name       string    `json:"name"`
	Code       string    `json:"code"`
	Price      int64     `json:"price"`
	TaxID      uuid.UUID `json:"tax_id"`
	TaxType    string    `json:"tax_type"`
	Tax        float64   `json:"tax"`
	CategoryID uuid.UUID `json:"category_id"`
	Image      string    `json:"image"`
	Active     *bool     `json:"active"`
}
