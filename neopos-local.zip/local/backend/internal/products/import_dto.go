package products

type ImportPreviewResponse struct {
	ImportID       string        `json:"import_id"`
	HeadersValid   bool          `json:"headers_valid"`
	MissingHeaders []string      `json:"missing_headers"`
	Summary        ImportSummary `json:"summary"`
	Rows           []ImportRow   `json:"rows"`
}

type ImportSummary struct {
	TotalRows       int `json:"total_rows"`
	NewCategories   int `json:"new_categories"`
	NewProducts     int `json:"new_products"`
	Existing        int `json:"existing"`
	Errors          int `json:"errors"`
}

type ImportRow struct {
	ID           string   `json:"id"`
	OriginalRow  int      `json:"original_row"`
	Category     string   `json:"category"`
	Subcategory  string   `json:"subcategory"`
	ProductName  string   `json:"product_name"`
	Description  string   `json:"description"`
	Price        float64  `json:"price"`
	Cost         float64  `json:"cost"`
	Tax          float64  `json:"tax"`
	Available    bool     `json:"available"`
	Barcode      string   `json:"barcode"`
	SKU          string   `json:"sku"`
	OrderIndex   int      `json:"order"`
	Image        string   `json:"image"`
	
	Status       string   `json:"status"` // "Nuevo", "Existente", "Error"
	Errors       []string `json:"errors"`
	IsNewCategory bool    `json:"is_new_category"`
	Action       string   `json:"action"` // "import", "update", "skip", "duplicate"
}

type ImportExecuteRequest struct {
	// Optional modifications made by the user in the UI (like changing action to "skip")
	RowsOverrides map[string]string `json:"rows_overrides"` // map[rowID]action
}

type ImportExecuteResponse struct {
	Imported      int     `json:"imported"`
	Updated       int     `json:"updated"`
	Categories    int     `json:"categories_created"`
	Omitted       int     `json:"omitted"`
	ExecutionTime float64 `json:"execution_time"`
}
