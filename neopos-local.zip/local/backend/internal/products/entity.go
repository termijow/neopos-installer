package products

import (
	"restaurant-pos-api/internal/categories"
	"restaurant-pos-api/pkg/model"

	"github.com/google/uuid"
)

type Product struct {
	model.Base
	model.BranchScoped
	Name       string              `json:"name" gorm:"size:180;not null"`
	Code       string              `json:"code" gorm:"size:50;index"`
	Price      int64               `json:"price" gorm:"not null"`
	TaxID      uuid.UUID           `json:"tax_id" gorm:"type:uuid;index"`
	TaxType    string              `json:"tax_type" gorm:"size:20;default:'IVA'"`
	Tax        float64             `json:"tax" gorm:"default:19"`
	CategoryID uuid.UUID           `json:"category_id" gorm:"type:uuid;index"`
	Category   categories.Category `json:"category" gorm:"foreignKey:CategoryID"`
	Image      string              `json:"image" gorm:"size:512"`
	Active     bool                `json:"active" gorm:"default:true"`
}
