package products

import (
	"encoding/csv"
	"fmt"
	"io"
	"strconv"
	"strings"
	"sync"
	"time"

	"restaurant-pos-api/internal/categories"
	"restaurant-pos-api/pkg/model"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type ImportService interface {
	ProcessCSV(branchID string, reader io.Reader) (*ImportPreviewResponse, error)
	GetPreview(branchID, importID string) (*ImportPreviewResponse, error)
	ExecuteImport(branchID, importID string, overrides map[string]string) (*ImportExecuteResponse, error)
}

type importService struct {
	db     *gorm.DB
	repo   Repository
	
	// Cache to store the parsed rows by importID temporarily
	// In a real distributed system, we'd use Redis. For this local POS, memory is fine.
	cache sync.Map 
}

func NewImportService(db *gorm.DB, repo Repository) ImportService {
	return &importService{db: db, repo: repo}
}

type cachedImport struct {
	BranchID string
	Rows     []ImportRow
	Summary  ImportSummary
}

func (s *importService) ProcessCSV(branchID string, reader io.Reader) (*ImportPreviewResponse, error) {
	csvReader := csv.NewReader(reader)
	csvReader.Comma = ','
	csvReader.LazyQuotes = true

	records, err := csvReader.ReadAll()
	if err != nil {
		return nil, fmt.Errorf("error reading CSV: %v", err)
	}

	if len(records) == 0 {
		return nil, fmt.Errorf("el archivo CSV está vacío")
	}

	headers := records[0]
	importID := uuid.NewString()
	resp := &ImportPreviewResponse{
		ImportID:       importID,
		HeadersValid:   true,
		MissingHeaders: []string{},
		Rows:           []ImportRow{},
	}

	headerMap := make(map[string]int)
	for i, h := range headers {
		hLower := strings.ToLower(strings.TrimSpace(h))
		// Handle BOM and special chars
		hLower = strings.Trim(hLower, "\ufeff")
		headerMap[hLower] = i
	}

	// Validate required headers
	required := []string{"categoria", "producto", "precio"}
	for _, req := range required {
		if _, ok := headerMap[req]; !ok {
			resp.HeadersValid = false
			resp.MissingHeaders = append(resp.MissingHeaders, req)
		}
	}

	if !resp.HeadersValid {
		return resp, nil
	}

	// Fetch existing data for comparison
	var existingCategories []categories.Category
	s.db.Where("branch_id = ?", branchID).Find(&existingCategories)
	catMap := make(map[string]bool) // lower(name)
	for _, c := range existingCategories {
		catMap[strings.ToLower(c.Name)] = true
	}

	var existingProducts []Product
	// We need to fetch products with their categories to compare "Categoría + Producto"
	s.db.Preload("Category").Where("branch_id = ?", branchID).Find(&existingProducts)
	prodMap := make(map[string]bool) // "categoria|producto"
	for _, p := range existingProducts {
		catName := ""
		if p.Category.Name != "" {
			catName = strings.ToLower(p.Category.Name)
		}
		key := catName + "|" + strings.ToLower(p.Name)
		prodMap[key] = true
	}

	// Track uniqueness within the same CSV
	csvProdNames := make(map[string]bool)
	csvSKUs := make(map[string]bool)
	csvBarcodes := make(map[string]bool)

	for i := 1; i < len(records); i++ {
		row := records[i]
		
		// Skip entirely empty rows
		isEmpty := true
		for _, col := range row {
			if strings.TrimSpace(col) != "" {
				isEmpty = false
				break
			}
		}
		if isEmpty {
			continue
		}

		ir := ImportRow{
			ID:          uuid.NewString(),
			OriginalRow: i + 1,
			Action:      "import", // Default action
			Available:   true,     // Default
		}

		// Read fields safely
		getField := func(key string) string {
			if idx, ok := headerMap[key]; ok && idx < len(row) {
				return strings.TrimSpace(row[idx])
			}
			return ""
		}

		ir.Category = getField("categoria")
		ir.Subcategory = getField("subcategoria")
		ir.ProductName = getField("producto")
		ir.Description = getField("descripcion")
		
		// Parse numbers
		priceStr := getField("precio")
		priceStr = strings.ReplaceAll(strings.ReplaceAll(priceStr, "$", ""), ",", "")
		if p, err := strconv.ParseFloat(priceStr, 64); err == nil {
			ir.Price = p
		}

		costStr := getField("costo")
		if c, err := strconv.ParseFloat(costStr, 64); err == nil {
			ir.Cost = c
		}

		taxStr := getField("iva")
		if t, err := strconv.ParseFloat(taxStr, 64); err == nil {
			ir.Tax = t
		}

		availStr := strings.ToLower(getField("disponible"))
		if availStr == "no" || availStr == "false" || availStr == "0" {
			ir.Available = false
		}

		ir.Barcode = getField("codigobarras")
		ir.SKU = getField("sku")
		
		orderStr := getField("orden")
		if o, err := strconv.Atoi(orderStr); err == nil {
			ir.OrderIndex = o
		}
		ir.Image = getField("imagen")

		// -----------------------------
		// VALIDATIONS
		// -----------------------------
		
		// 1. Category validation
		if ir.Category == "" {
			ir.Errors = append(ir.Errors, "Categoría vacía")
		} else if !catMap[strings.ToLower(ir.Category)] {
			ir.IsNewCategory = true
		}

		// 2. Name validation
		if ir.ProductName == "" {
			ir.Errors = append(ir.Errors, "Nombre de producto vacío")
		}
		
		// 3. Price validation
		if priceStr == "" {
			ir.Errors = append(ir.Errors, "Precio vacío")
		} else if ir.Price < 0 {
			ir.Errors = append(ir.Errors, "Precio negativo")
		} else if ir.Price == 0 {
			ir.Errors = append(ir.Errors, "Precio igual a cero")
		}

		// 4. Tax validation
		if ir.Tax < 0 || ir.Tax > 100 {
			ir.Errors = append(ir.Errors, "IVA inválido")
		}

		// 5. Duplicates in CSV
		uniqueKey := strings.ToLower(ir.Category) + "|" + strings.ToLower(ir.ProductName)
		if csvProdNames[uniqueKey] {
			ir.Errors = append(ir.Errors, "Producto repetido en el archivo")
		} else {
			csvProdNames[uniqueKey] = true
		}

		if ir.SKU != "" {
			if csvSKUs[ir.SKU] {
				ir.Errors = append(ir.Errors, "SKU repetido en el archivo")
			}
			csvSKUs[ir.SKU] = true
		}
		if ir.Barcode != "" {
			if csvBarcodes[ir.Barcode] {
				ir.Errors = append(ir.Errors, "Código de barras repetido en el archivo")
			}
			csvBarcodes[ir.Barcode] = true
		}

		// 6. DB Duplicates
		if len(ir.Errors) == 0 {
			if prodMap[uniqueKey] {
				ir.Status = "Existente"
				ir.Action = "update" // Default to update instead of skip for ERP style, or skip. User UI decides.
			} else {
				ir.Status = "Nuevo"
			}
		}

		if len(ir.Errors) > 0 {
			ir.Status = "Error"
			ir.Action = "skip"
		}

		resp.Rows = append(resp.Rows, ir)
	}

	// Calculate summary
	resp.Summary.TotalRows = len(resp.Rows)
	newCats := make(map[string]bool)
	for _, r := range resp.Rows {
		if r.IsNewCategory && len(r.Errors) == 0 {
			newCats[strings.ToLower(r.Category)] = true
		}
		if r.Status == "Error" {
			resp.Summary.Errors++
		} else if r.Status == "Existente" {
			resp.Summary.Existing++
		} else if r.Status == "Nuevo" {
			resp.Summary.NewProducts++
		}
	}
	resp.Summary.NewCategories = len(newCats)

	// Store in cache
	s.cache.Store(importID, cachedImport{
		BranchID: branchID,
		Rows:     resp.Rows,
		Summary:  resp.Summary,
	})

	// To avoid returning the 10,000 rows in the POST request (just in case), we COULD omit Rows here, 
	// but the GET endpoint will fetch them. Actually, returning them here is fine for small files,
	// but returning them in the GET request is safer. The UI will just use the GET.
	return resp, nil
}

func (s *importService) GetPreview(branchID, importID string) (*ImportPreviewResponse, error) {
	val, ok := s.cache.Load(importID)
	if !ok {
		return nil, fmt.Errorf("sesión de importación no encontrada o expirada")
	}
	cached := val.(cachedImport)
	if cached.BranchID != branchID {
		return nil, fmt.Errorf("acceso denegado")
	}

	return &ImportPreviewResponse{
		ImportID:     importID,
		HeadersValid: true,
		Summary:      cached.Summary,
		Rows:         cached.Rows,
	}, nil
}

func (s *importService) ExecuteImport(branchID, importID string, overrides map[string]string) (*ImportExecuteResponse, error) {
	val, ok := s.cache.Load(importID)
	if !ok {
		return nil, fmt.Errorf("sesión de importación no encontrada o expirada")
	}
	cached := val.(cachedImport)
	if cached.BranchID != branchID {
		return nil, fmt.Errorf("acceso denegado")
	}

	start := time.Now()
	resp := &ImportExecuteResponse{}

	err := s.db.Transaction(func(tx *gorm.DB) error {
		branchUUID, err := uuid.Parse(branchID)
		if err != nil {
			return err
		}

		// Fetch existing categories map to avoid dupes
		var existingCategories []categories.Category
		tx.Where("branch_id = ?", branchID).Find(&existingCategories)
		catMap := make(map[string]uuid.UUID)
		for _, c := range existingCategories {
			catMap[strings.ToLower(c.Name)] = c.ID
		}

		// Process Categories first
		for _, row := range cached.Rows {
			action := row.Action
			if override, exists := overrides[row.ID]; exists {
				action = override
			}
			
			if action == "skip" || row.Status == "Error" {
				continue
			}
			
			catNameLower := strings.ToLower(row.Category)
			if _, exists := catMap[catNameLower]; !exists && row.Category != "" {
				newCat := categories.Category{
					Base:         model.Base{ID: uuid.New()},
					BranchScoped: model.BranchScoped{BranchID: branchUUID},
					Name:         row.Category,
				}
				if err := tx.Create(&newCat).Error; err != nil {
					return fmt.Errorf("error creando categoría %s: %v", row.Category, err)
				}
				catMap[catNameLower] = newCat.ID
				resp.Categories++
			}
		}

		// Process Products
		for _, row := range cached.Rows {
			action := row.Action
			if override, exists := overrides[row.ID]; exists {
				action = override
			}

			if action == "skip" || row.Status == "Error" {
				resp.Omitted++
				continue
			}

			catID := catMap[strings.ToLower(row.Category)]

			if action == "import" || action == "duplicate" || (action == "update" && row.Status == "Nuevo") {
				prod := Product{
					Base:         model.Base{ID: uuid.New()},
					BranchScoped: model.BranchScoped{BranchID: branchUUID},
					CategoryID:   catID,
					Name:         row.ProductName,
					Code:         row.Barcode, // Code is generally barcode or internal code
					Price:        int64(row.Price),
					Tax:          row.Tax,
					TaxType:      "IVA", // Default
					Image:        row.Image,
					Active:       row.Available,
				}
				if err := tx.Create(&prod).Error; err != nil {
					return fmt.Errorf("error creando producto %s: %v", row.ProductName, err)
				}
				resp.Imported++
			} else if action == "update" {
				var prod Product
				// Find by Category ID AND Name
				if err := tx.Where("branch_id = ? AND category_id = ? AND lower(name) = ?", branchID, catID, strings.ToLower(row.ProductName)).First(&prod).Error; err == nil {
					prod.Price = int64(row.Price)
					if row.Barcode != "" {
						prod.Code = row.Barcode
					}
					prod.Tax = row.Tax
					prod.Image = row.Image
					prod.Active = row.Available
					if err := tx.Save(&prod).Error; err != nil {
						return fmt.Errorf("error actualizando producto %s: %v", row.ProductName, err)
					}
					resp.Updated++
				} else {
					return fmt.Errorf("producto a actualizar no encontrado: %s", row.ProductName)
				}
			}
		}

		return nil
	})

	if err != nil {
		return nil, err
	}

	// Clean up cache
	s.cache.Delete(importID)

	resp.ExecutionTime = time.Since(start).Seconds()
	return resp, nil
}
