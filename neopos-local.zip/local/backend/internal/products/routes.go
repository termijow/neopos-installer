package products

import (
	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB) {
	controller := NewController(NewService(NewRepository(db)))
	router.Get("/products", controller.List)
	router.Post("/products", controller.Create)
	router.Put("/products/:id", controller.Update)
	router.Delete("/products/:id", controller.Delete)
	router.Post("/products/upload", controller.UploadImage)
	
	repo := NewRepository(db)
	importController := NewImportController(NewImportService(db, repo), repo)
	router.Get("/products/import/template", importController.DownloadTemplate)
	router.Post("/products/import", importController.ProcessCSV)
	router.Get("/products/import/:importId", importController.GetPreview)
	router.Post("/products/import/:importId/execute", importController.ExecuteImport)
	router.Get("/products/export", importController.ExportCSV)
}
