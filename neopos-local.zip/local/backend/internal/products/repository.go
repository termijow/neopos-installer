package products

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface {
	List(page, limit int) ([]Product, int, error)
	Create(*Product) error
	FindByID(uuid.UUID) (*Product, error)
	Update(*Product) error
	Delete(uuid.UUID) error
}

type gormRepository struct {
	db *gorm.DB
}

func NewRepository(db *gorm.DB) Repository {
	return &gormRepository{db: db}
}

func (r *gormRepository) List(page, limit int) ([]Product, int, error) {
	var items []Product
	var total int64

	query := r.db.Model(&Product{})
	if err := query.Count(&total).Error; err != nil {
		return nil, 0, err
	}

	offset := (page - 1) * limit
	err := r.db.Preload("Category").Order("name asc").Offset(offset).Limit(limit).Find(&items).Error
	return items, int(total), err
}

func (r *gormRepository) Create(item *Product) error {
	return r.db.Create(item).Error
}

func (r *gormRepository) FindByID(id uuid.UUID) (*Product, error) {
	var item Product
	if err := r.db.Preload("Category").First(&item, "id = ?", id).Error; err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *gormRepository) Update(item *Product) error {
	return r.db.Save(item).Error
}

func (r *gormRepository) Delete(id uuid.UUID) error {
	return r.db.Delete(&Product{}, "id = ?", id).Error
}
