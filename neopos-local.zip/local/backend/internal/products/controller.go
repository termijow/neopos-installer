package products

import (
	"restaurant-pos-api/internal/storage"
	"restaurant-pos-api/pkg/response"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
)

type Controller struct{ service Service }
func NewController(service Service) *Controller { return &Controller{service: service} }
func (h *Controller) List(c *fiber.Ctx) error {
	page := c.QueryInt("page", 1)
	limit := c.QueryInt("limit", 50)
	items, total, err := h.service.List(page, limit)
	if err != nil {
		return response.Error(c, fiber.StatusInternalServerError, err.Error())
	}
	return response.Paginated(c, items, page, limit, total)
}
func (h *Controller) Create(c *fiber.Ctx) error { var req UpsertProductRequest; if err := c.BodyParser(&req); err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; item, err := h.service.Create(req); if err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; return response.Created(c, item) }
func (h *Controller) Update(c *fiber.Ctx) error { id, err := uuid.Parse(c.Params("id")); if err != nil { return response.Error(c, fiber.StatusBadRequest, "invalid product id") }; var req UpsertProductRequest; if err := c.BodyParser(&req); err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; item, err := h.service.Update(id, req); if err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; return response.OK(c, item) }
func (h *Controller) Delete(c *fiber.Ctx) error { id, err := uuid.Parse(c.Params("id")); if err != nil { return response.Error(c, fiber.StatusBadRequest, "invalid product id") }; if err := h.service.Delete(id); err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; return response.NoContent(c) }

func (h *Controller) UploadImage(c *fiber.Ctx) error {
	file, err := c.FormFile("image")
	if err != nil {
		return response.Error(c, fiber.StatusBadRequest, "No image file provided")
	}

	// Generate a unique name for the file
	objectName := uuid.New().String() + "-" + file.Filename

	// Upload to MinIO
	url, err := storage.UploadFile(file, objectName)
	if err != nil {
		return response.Error(c, fiber.StatusInternalServerError, "Failed to upload image")
	}

	return response.OK(c, fiber.Map{"url": url})
}
