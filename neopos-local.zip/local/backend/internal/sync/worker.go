package syncqueue

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"sync"
	"time"

	"restaurant-pos-api/internal/settings"

	"gorm.io/gorm"
)

const (
	maxSyncItemsPerBatch = 1000
	maxSyncPayloadBytes  = 20 * 1024 * 1024
)

type WorkerStatus struct {
	LastAttempt time.Time `json:"last_attempt"`
	LastSuccess time.Time `json:"last_success"`
	Status      string    `json:"status"`
	LastError   string    `json:"last_error,omitempty"`
}

var (
	CurrentStatus = WorkerStatus{Status: "pending"}
	statusMutex   sync.RWMutex
	triggerChan   = make(chan bool, 1)
)

func GetStatus() WorkerStatus {
	statusMutex.RLock()
	defer statusMutex.RUnlock()
	return CurrentStatus
}

func updateStatus(status string, success bool, lastErr string) {
	statusMutex.Lock()
	defer statusMutex.Unlock()
	now := time.Now()
	CurrentStatus.LastAttempt = now
	CurrentStatus.Status = status
	CurrentStatus.LastError = lastErr
	if success {
		CurrentStatus.LastSuccess = now
	}
}

func TriggerManualSync() {
	select {
	case triggerChan <- true:
	default:
	}
}

// StartWorker begins a background loop to periodically sync local records to the cloud
func StartWorker(db *gorm.DB, service Service, remoteURL string, token string, interval time.Duration) {
	if remoteURL == "" {
		log.Println("Sync worker not started: SYNC_REMOTE_URL is empty")
		return
	}

	log.Printf("Starting sync worker targeting %s (interval: %v)\n", remoteURL, interval)

	client := &http.Client{Timeout: 120 * time.Second} // Increased to 120s for slow connections

	for {
		syncedCount, hasMore, err := performSync(db, client, service, remoteURL, token)

		var waitTime time.Duration
		if err != nil {
			log.Printf("[Sync Worker] Sync failed, retrying in 15 minutes. Error: %v", err)
			updateStatus("error", false, err.Error())
			waitTime = 15 * time.Minute
		} else {
			updateStatus("success", true, "")
			if hasMore {
				log.Println("[Sync Worker] Batch limit reached (chunking), scheduling next part in 5 minutes.")
				waitTime = 5 * time.Minute
			} else {
				waitTime = interval
			}

			if syncedCount > 0 {
				logEntry := SyncLog{SyncedRecords: syncedCount}
				db.Create(&logEntry)
				var count int64
				db.Model(&SyncLog{}).Count(&count)
				if count > 50 {
					db.Exec("DELETE FROM sync_logs WHERE id NOT IN (SELECT id FROM sync_logs ORDER BY created_at DESC LIMIT 50)")
				}
			}
		}

		select {
		case <-time.After(waitTime):
		case <-triggerChan:
			log.Println("[Sync Worker] Manual sync triggered")
		}
	}
}

func performSync(db *gorm.DB, client *http.Client, service Service, remoteURL string, fallbackToken string) (int, bool, error) {
	token := fallbackToken
	var s struct{ Value string }
	if err := db.Table("settings").Select("value").Where("key = ?", "active_license_key").Scan(&s).Error; err == nil {
		if value := settings.DecodeValue(s.Value); value != "" {
			token = value
		}
	}

	// 1. Verify License with Cloud
	verifyReq, err := http.NewRequest("POST", remoteURL+"/api/v1/licenses/verify", bytes.NewBuffer([]byte(`{"tenant_id":1,"token":"`+token+`"}`)))
	if err == nil {
		verifyReq.Header.Set("Content-Type", "application/json")
		if resp, err := client.Do(verifyReq); err == nil {
			var res map[string]interface{}
			if err := json.NewDecoder(resp.Body).Decode(&res); err != nil {
				resp.Body.Close()
				return 0, false, err
			}
			resp.Body.Close()
			if valid, ok := res["valid"].(bool); !ok || !valid {
				return 0, false, nil // Don't retry if license is invalid, just wait for next interval
			}
		} else {
			return 0, false, err
		}
	}

	pending, err := service.Pending()
	if err != nil {
		return 0, false, err
	}

	if len(pending) == 0 {
		return 0, false, nil
	}

	log.Printf("[Sync Worker] Found %d pending items in queue", len(pending))

	// Group records into a batch to optimize network usage (Selective Sync)
	var selectiveBatch []SyncQueue
	entityCounts := make(map[string]int)
	var currentPayloadSize int
	hasMore := false

	for _, item := range pending {
		if len(selectiveBatch) >= maxSyncItemsPerBatch {
			hasMore = true
			break
		}

		nextItemSize := currentPayloadSize + len(item.Payload) + 200
		if len(selectiveBatch) > 0 && nextItemSize > maxSyncPayloadBytes {
			hasMore = true
			break
		}

		if item.Entity == "sales" || item.Entity == "invoices" || item.Entity == "inventory_movements" || item.Entity == "cash_register_sessions" || item.Entity == "cash_movements" || item.Entity == "electronic_invoices" {
			selectiveBatch = append(selectiveBatch, item)
			entityCounts[item.Entity]++
			currentPayloadSize = nextItemSize // estimate JSON struct overhead
		} else {
			// Mark as synced locally so they don't block the queue
			_ = service.MarkSynced(item.ID)
		}
	}

	if len(selectiveBatch) == 0 {
		if hasMore {
			return 0, true, nil
		}
		log.Println("[Sync Worker] All pending items were non-syncable entities and marked as synced.")
		return 0, false, nil
	}

	batchPayload, err := json.Marshal(selectiveBatch)
	if err != nil {
		return 0, false, err
	}

	log.Printf("[Sync Worker] Preparing batch of %d items. Payload size: %.2f MB", len(selectiveBatch), float64(len(batchPayload))/(1024*1024))
	for entity, count := range entityCounts {
		log.Printf("[Sync Worker]  - %s: %d records", entity, count)
	}

	req, err := http.NewRequest("POST", remoteURL+"/api/v1/sync/batch", bytes.NewBuffer(batchPayload))
	if err != nil {
		return 0, false, err
	}

	req.Header.Set("Content-Type", "application/json")
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	}

	resp, err := client.Do(req)
	if err != nil {
		return 0, false, err
	}
	defer resp.Body.Close()

	if resp.StatusCode == http.StatusOK {
		var res map[string]interface{}
		if err := json.NewDecoder(resp.Body).Decode(&res); err == nil {
			if updates, ok := res["updates"].([]interface{}); ok {
				for _, upd := range updates {
					if updMap, ok := upd.(map[string]interface{}); ok {
						if id, ok := updMap["id"].(string); ok {
							if status, ok := updMap["electronic_status"].(string); ok {
								db.Exec("UPDATE sales SET electronic_status = ? WHERE id = ?", status, id)
							}
						}
					}
				}
			}
		}

		// If successful, mark them as synced
		for _, item := range selectiveBatch {
			err := service.MarkSynced(item.ID)
			if err != nil {
				log.Printf("[Sync Worker] Error marking item %s as synced: %v", item.ID, err)
			}
		}
	} else {
		log.Printf("[Sync Worker] Failed to sync batch, server returned status: %d", resp.StatusCode)
		// Return an error to trigger retry
		return 0, false, fmt.Errorf("server returned status: %d", resp.StatusCode)
	}

	return len(selectiveBatch), hasMore, nil
}
