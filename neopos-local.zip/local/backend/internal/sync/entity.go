package syncqueue

import (
	"time"

	"restaurant-pos-api/pkg/model"
)

const (
	OperationInsert = "INSERT"
	OperationUpdate = "UPDATE"
	OperationDelete = "DELETE"
	SyncPending     = "PENDING"
	SyncSynced      = "SYNCED"
	SyncConflict    = "CONFLICT"
)

type SyncQueue struct {
	model.Base
	Entity    string     `json:"entity" gorm:"size:120;not null;index"`
	EntityID  string     `json:"entity_id" gorm:"size:80;not null;index"`
	Operation string     `json:"operation" gorm:"size:20;not null;index"`
	Payload   string     `json:"payload" gorm:"type:jsonb;default:'{}'"`
	Status    string     `json:"status" gorm:"size:40;not null;default:PENDING;index"`
	Attempts  int        `json:"attempts" gorm:"default:0"`
	LastError string     `json:"last_error" gorm:"size:500"`
	SyncedAt  *time.Time `json:"synced_at,omitempty"`
}

func (SyncQueue) TableName() string {
	return "sync_queue"
}

type SyncLog struct {
	model.Base
	SyncedRecords int `json:"synced_records"`
}

func (SyncLog) TableName() string {
	return "sync_logs"
}
