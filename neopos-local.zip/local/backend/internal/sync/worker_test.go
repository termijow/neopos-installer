package syncqueue

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

type mockSyncService struct {
	pendingRecords []SyncQueue
	syncedMap      map[uuid.UUID]bool
	mu             sync.Mutex
}

func (m *mockSyncService) Pending() ([]SyncQueue, error) {
	m.mu.Lock()
	defer m.mu.Unlock()

	var activePending []SyncQueue
	for _, item := range m.pendingRecords {
		if !m.syncedMap[item.ID] {
			activePending = append(activePending, item)
		}
	}
	return activePending, nil
}

func (m *mockSyncService) MarkSynced(id uuid.UUID) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.syncedMap[id] = true
	return nil
}

func (m *mockSyncService) ResolveConflict(id uuid.UUID, req ResolveConflictRequest) error {
	return nil
}

func (m *mockSyncService) Logs() ([]SyncLog, error) {
	return nil, nil
}

func TestSyncWorkerRetryOnDisconnect(t *testing.T) {
	// 1. Enqueued item details
	itemID := uuid.New()
	item := SyncQueue{
		Entity:    "inventory_movements",
		EntityID:  "movement-123",
		Operation: "CREATE",
		Payload:   `{"product_id": "prod-123", "quantity": 10}`,
	}
	item.ID = itemID
	item.CreatedAt = time.Now()

	mockSvc := &mockSyncService{
		pendingRecords: []SyncQueue{item},
		syncedMap:      make(map[uuid.UUID]bool),
	}

	// 2. Spin up a test mock HTTP server
	var statusCode int32 = http.StatusServiceUnavailable

	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		status := int(atomic.LoadInt32(&statusCode))

		if r.URL.Path == "/api/v1/licenses/verify" {
			if status == http.StatusOK {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusOK)
				w.Write([]byte(`{"valid": true, "license_type": "standard", "expires_at": "2026-07-03"}`))
			} else {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(status)
				w.Write([]byte(`{"valid": false, "error": "server temporarily down"}`))
			}
			return
		}

		if r.URL.Path == "/api/v1/sync/batch" {
			if status == http.StatusOK {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusOK)
				w.Write([]byte(`{"status": "success", "synced_count": 1}`))
			} else {
				w.WriteHeader(status)
			}
			return
		}

		w.WriteHeader(http.StatusNotFound)
	}))
	defer server.Close()

	// 3. Start worker with 20ms poll interval in separate goroutine
	testDB, err := gorm.Open(sqlite.Open(":memory:"), &gorm.Config{})
	assert.NoError(t, err)
	go StartWorker(testDB, mockSvc, server.URL, "test-token", 20*time.Millisecond)

	// 4. Initially server is 503. Wait a bit and check that item remains PENDING
	time.Sleep(100 * time.Millisecond)
	mockSvc.mu.Lock()
	isSynced := mockSvc.syncedMap[itemID]
	mockSvc.mu.Unlock()
	assert.False(t, isSynced, "Item should remain PENDING when remote server returns 503")

	// 5. Change server status to 200 OK
	atomic.StoreInt32(&statusCode, http.StatusOK)

	// 6. Wait for worker to poll again and succeed
	time.Sleep(100 * time.Millisecond)
	mockSvc.mu.Lock()
	isSynced = mockSvc.syncedMap[itemID]
	mockSvc.mu.Unlock()
	assert.True(t, isSynced, "Item should transition to SYNCED once remote server returns 200 OK")
}

func TestPerformSyncLimitsItemsPerBatch(t *testing.T) {
	const totalItems = maxSyncItemsPerBatch + 1
	items := make([]SyncQueue, totalItems)
	for i := range items {
		items[i] = SyncQueue{
			Entity:    "inventory_movements",
			EntityID:  uuid.NewString(),
			Operation: OperationInsert,
			Payload:   `{"product_id":"product-1","type":"IN","quantity":1}`,
		}
		items[i].ID = uuid.New()
		items[i].CreatedAt = time.Now().Add(time.Duration(i) * time.Millisecond)
	}

	mockSvc := &mockSyncService{
		pendingRecords: items,
		syncedMap:      make(map[uuid.UUID]bool),
	}

	var receivedBatchSizes []int
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/api/v1/licenses/verify" {
			w.Header().Set("Content-Type", "application/json")
			_, _ = w.Write([]byte(`{"valid":true}`))
			return
		}
		if r.URL.Path == "/api/v1/sync/batch" {
			var batch []SyncQueue
			assert.NoError(t, json.NewDecoder(r.Body).Decode(&batch))
			receivedBatchSizes = append(receivedBatchSizes, len(batch))
			w.Header().Set("Content-Type", "application/json")
			_, _ = w.Write([]byte(`{"status":"success"}`))
			return
		}
		http.NotFound(w, r)
	}))
	defer server.Close()

	testDB, err := gorm.Open(sqlite.Open(":memory:"), &gorm.Config{})
	assert.NoError(t, err)
	client := server.Client()

	synced, hasMore, err := performSync(testDB, client, mockSvc, server.URL, "test-token")
	assert.NoError(t, err)
	assert.Equal(t, maxSyncItemsPerBatch, synced)
	assert.True(t, hasMore)
	assert.Equal(t, []int{maxSyncItemsPerBatch}, receivedBatchSizes)

	synced, hasMore, err = performSync(testDB, client, mockSvc, server.URL, "test-token")
	assert.NoError(t, err)
	assert.Equal(t, 1, synced)
	assert.False(t, hasMore)
	assert.Equal(t, []int{maxSyncItemsPerBatch, 1}, receivedBatchSizes)
}
