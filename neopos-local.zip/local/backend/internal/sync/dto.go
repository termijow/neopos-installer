package syncqueue

type ResolveConflictRequest struct {
	Strategy string `json:"strategy"`
	Payload  string `json:"payload"`
}
