package syncqueue

import (
	"encoding/json"
	"fmt"
	"reflect"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

var syncSkippedTables = map[string]bool{
	"sync_queue": true,
	"audit_logs": true,
}

func RegisterCallbacks(db *gorm.DB) {
	db.Callback().Create().After("gorm:create").Register("pos:sync_create", enqueue(OperationInsert))
	db.Callback().Update().After("gorm:update").Register("pos:sync_update", enqueue(OperationUpdate))
	db.Callback().Delete().After("gorm:delete").Register("pos:sync_delete", enqueue(OperationDelete))
}

func enqueue(operation string) func(*gorm.DB) {
	return func(tx *gorm.DB) {
		if tx.Error != nil || tx.Statement == nil || syncSkippedTables[tx.Statement.Table] {
			return
		}
		payload, _ := json.Marshal(tx.Statement.Dest)
		entityID := primaryID(tx)
		if entityID == "" {
			entityID = uuid.NewString()
		}
		tx.Session(&gorm.Session{NewDB: true}).Exec(
			"INSERT INTO sync_queue (id, created_at, updated_at, entity, entity_id, operation, payload, status, attempts) VALUES (?::uuid, now(), now(), ?, ?, ?, ?::jsonb, ?, 0)",
			uuid.NewString(), tx.Statement.Table, entityID, operation, string(payload), SyncPending,
		)
	}
}

func primaryID(tx *gorm.DB) string {
	if tx.Statement.Schema == nil || tx.Statement.Schema.PrioritizedPrimaryField == nil {
		return ""
	}
	rv := reflect.Indirect(tx.Statement.ReflectValue)
	if rv.Kind() == reflect.Slice || rv.Kind() == reflect.Array {
		if rv.Len() > 0 {
			value, zero := tx.Statement.Schema.PrioritizedPrimaryField.ValueOf(tx.Statement.Context, reflect.Indirect(rv.Index(0)))
			if zero {
				return ""
			}
			return fmt.Sprint(value)
		}
		return ""
	}
	value, zero := tx.Statement.Schema.PrioritizedPrimaryField.ValueOf(tx.Statement.Context, rv)
	if zero {
		return ""
	}
	return fmt.Sprint(value)
}
