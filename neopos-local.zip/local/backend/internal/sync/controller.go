package syncqueue

import (
	"restaurant-pos-api/pkg/response"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
)

type Controller struct{ service Service }
func NewController(service Service) *Controller { return &Controller{service: service} }
func (h *Controller) Pending(c *fiber.Ctx) error { items, err := h.service.Pending(); if err != nil { return response.Error(c, fiber.StatusInternalServerError, err.Error()) }; return response.OK(c, items) }
func (h *Controller) MarkSynced(c *fiber.Ctx) error { id, err := uuid.Parse(c.Params("id")); if err != nil { return response.Error(c, fiber.StatusBadRequest, "invalid sync id") }; if err := h.service.MarkSynced(id); err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; return response.NoContent(c) }
func (h *Controller) ResolveConflict(c *fiber.Ctx) error { id, err := uuid.Parse(c.Params("id")); if err != nil { return response.Error(c, fiber.StatusBadRequest, "invalid sync id") }; var req ResolveConflictRequest; if err := c.BodyParser(&req); err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; if err := h.service.ResolveConflict(id, req); err != nil { return response.Error(c, fiber.StatusBadRequest, err.Error()) }; return response.NoContent(c) }
func (h *Controller) Status(c *fiber.Ctx) error {
	ws := GetStatus()
	return response.OK(c, fiber.Map{
		"last_attempt": ws.LastAttempt,
		"last_success": ws.LastSuccess,
		"status":       ws.Status,
		"last_error":   ws.LastError,
		"is_healthy":   ws.Status == "success" || ws.Status == "pending",
	})
}
func (h *Controller) Trigger(c *fiber.Ctx) error { TriggerManualSync(); return response.OK(c, fiber.Map{"message": "Sync triggered"}) }
func (h *Controller) Logs(c *fiber.Ctx) error {
	logs, err := h.service.Logs()
	if err != nil {
		return response.Error(c, fiber.StatusInternalServerError, err.Error())
	}
	workerStatus := GetStatus()
	return response.OK(c, fiber.Map{
		"logs":         logs,
		"is_healthy":   workerStatus.Status == "success" || workerStatus.Status == "pending",
		"last_attempt": workerStatus.LastAttempt,
		"last_success": workerStatus.LastSuccess,
		"status":       workerStatus.Status,
		"last_error":   workerStatus.LastError,
	})
}
