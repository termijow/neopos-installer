package syncqueue

import (
	"github.com/gofiber/fiber/v2"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB) {
	controller := NewController(NewService(NewRepository(db)))
	router.Get("/sync/queue", controller.Pending)
	router.Put("/sync/queue/:id/synced", controller.MarkSynced)
	router.Put("/sync/queue/:id/conflict", controller.ResolveConflict)
	router.Get("/sync/status", controller.Status)
	router.Get("/sync/logs", controller.Logs)
	router.Post("/sync/trigger", controller.Trigger)
}
