package syncqueue

import "github.com/google/uuid"

type Service interface { Pending() ([]SyncQueue, error); MarkSynced(uuid.UUID) error; ResolveConflict(uuid.UUID, ResolveConflictRequest) error; Logs() ([]SyncLog, error) }
type service struct{ repo Repository }
func NewService(repo Repository) Service { return &service{repo: repo} }
func (s *service) Pending() ([]SyncQueue, error) { return s.repo.Pending() }
func (s *service) MarkSynced(id uuid.UUID) error { return s.repo.MarkSynced(id) }
func (s *service) ResolveConflict(id uuid.UUID, req ResolveConflictRequest) error { return s.repo.MarkConflict(id, req.Strategy) }
func (s *service) Logs() ([]SyncLog, error) { return s.repo.Logs() }
