package syncqueue

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface {
	Pending() ([]SyncQueue, error)
	MarkSynced(uuid.UUID) error
	MarkConflict(uuid.UUID, string) error
	Logs() ([]SyncLog, error)
}

type gormRepository struct{ db *gorm.DB }
func NewRepository(db *gorm.DB) Repository { return &gormRepository{db: db} }
func (r *gormRepository) Pending() ([]SyncQueue, error) { var items []SyncQueue; err := r.db.Where("status = ?", SyncPending).Order("created_at asc").Find(&items).Error; return items, err }
func (r *gormRepository) MarkSynced(id uuid.UUID) error { return r.db.Model(&SyncQueue{}).Where("id = ?", id).Updates(map[string]any{"status": SyncSynced, "synced_at": time.Now()}).Error }
func (r *gormRepository) MarkConflict(id uuid.UUID, message string) error { return r.db.Model(&SyncQueue{}).Where("id = ?", id).Updates(map[string]any{"status": SyncConflict, "last_error": message}).Error }
func (r *gormRepository) Logs() ([]SyncLog, error) { var logs []SyncLog; err := r.db.Order("created_at desc").Limit(10).Find(&logs).Error; return logs, err }
