package auth

import (
	"restaurant-pos-api/pkg/response"

	"github.com/gofiber/fiber/v2"
)

type Controller struct{ service Service }

func NewController(service Service) *Controller { return &Controller{service: service} }

func (h *Controller) Login(c *fiber.Ctx) error {
	var req LoginRequest
	if err := c.BodyParser(&req); err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}
	tokens, err := h.service.Login(req)
	if err != nil {
		return response.Error(c, fiber.StatusUnauthorized, err.Error())
	}
	return response.OK(c, tokens)
}

func (h *Controller) Refresh(c *fiber.Ctx) error {
	var req RefreshRequest
	if err := c.BodyParser(&req); err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}
	tokens, err := h.service.Refresh(req)
	if err != nil {
		return response.Error(c, fiber.StatusUnauthorized, err.Error())
	}
	return response.OK(c, tokens)
}

func (h *Controller) Logout(c *fiber.Ctx) error {
	var req LogoutRequest
	if err := c.BodyParser(&req); err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}
	if err := h.service.Logout(req); err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}
	return response.NoContent(c)
}

func (h *Controller) ForgotPassword(c *fiber.Ctx) error {
	var req ForgotPasswordRequest
	if err := c.BodyParser(&req); err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}
	if err := h.service.ForgotPassword(req); err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}
	return response.OK(c, fiber.Map{"message": "password recovery accepted"})
}

func (h *Controller) ResetPassword(c *fiber.Ctx) error {
	var req ResetPasswordRequest
	if err := c.BodyParser(&req); err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}
	if err := h.service.ResetPassword(req); err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}
	return response.OK(c, fiber.Map{"message": "password reset accepted"})
}

func (h *Controller) Override(c *fiber.Ctx) error {
	var req OverrideRequest
	if err := c.BodyParser(&req); err != nil {
		return response.Error(c, fiber.StatusBadRequest, err.Error())
	}
	res, err := h.service.Override(req)
	if err != nil {
		return response.Error(c, fiber.StatusUnauthorized, err.Error())
	}
	return response.OK(c, res)
}
