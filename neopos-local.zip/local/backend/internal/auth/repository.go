package auth

import (
	"time"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Repository interface {
	SaveRefreshToken(token *RefreshToken) error
	FindActiveRefreshToken(hash string) (*RefreshToken, error)
	RevokeRefreshToken(hash string) error
}

type gormRepository struct{ db *gorm.DB }

func NewRepository(db *gorm.DB) Repository { return &gormRepository{db: db} }

func (r *gormRepository) SaveRefreshToken(token *RefreshToken) error {
	return r.db.Create(token).Error
}

func (r *gormRepository) FindActiveRefreshToken(hash string) (*RefreshToken, error) {
	var token RefreshToken
	err := r.db.Where("token_hash = ? AND revoked_at IS NULL AND expires_at > ?", hash, time.Now()).First(&token).Error
	if err != nil {
		return nil, err
	}
	return &token, nil
}

func (r *gormRepository) RevokeRefreshToken(hash string) error {
	return r.db.Model(&RefreshToken{}).
		Where("token_hash = ? AND revoked_at IS NULL", hash).
		Updates(map[string]any{"revoked_at": time.Now()}).Error
}

func newRefreshToken(userID uuid.UUID, hash string, expiresAt time.Time) *RefreshToken {
	return &RefreshToken{UserID: userID, TokenHash: hash, ExpiresAt: expiresAt}
}
