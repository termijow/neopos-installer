package auth

import (
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"strings"
	"time"

	"restaurant-pos-api/internal/users"
	"restaurant-pos-api/pkg/security"
)

type Service interface {
	Login(req LoginRequest) (*TokenResponse, error)
	Refresh(req RefreshRequest) (*TokenResponse, error)
	Logout(req LogoutRequest) error
	ForgotPassword(req ForgotPasswordRequest) error
	ResetPassword(req ResetPasswordRequest) error
	Override(req OverrideRequest) (*OverrideResponse, error)
}

type service struct {
	repo      Repository
	users     users.Repository
	jwt       *security.JWTManager
	accessTTL time.Duration
	refreshTTL time.Duration
}

func NewService(repo Repository, users users.Repository, jwt *security.JWTManager, accessTTL, refreshTTL time.Duration) Service {
	return &service{repo: repo, users: users, jwt: jwt, accessTTL: accessTTL, refreshTTL: refreshTTL}
}

func (s *service) Login(req LoginRequest) (*TokenResponse, error) {
	user, err := s.users.FindByEmail(strings.ToLower(req.Email))
	if err != nil || !user.Active || !security.VerifyPassword(user.PasswordHash, req.Password) {
		return nil, errors.New("invalid credentials")
	}
	if err := s.users.TouchLogin(user.ID); err != nil {
		return nil, err
	}
	return s.issueTokens(user)
}

func (s *service) Refresh(req RefreshRequest) (*TokenResponse, error) {
	hash := tokenHash(req.RefreshToken)
	stored, err := s.repo.FindActiveRefreshToken(hash)
	if err != nil {
		return nil, errors.New("invalid refresh token")
	}
	claims, err := s.jwt.Parse(req.RefreshToken)
	if err != nil || claims.UserID != stored.UserID {
		return nil, errors.New("invalid refresh token")
	}
	user, err := s.users.FindByID(stored.UserID)
	if err != nil || !user.Active {
		return nil, errors.New("invalid refresh token")
	}
	_ = s.repo.RevokeRefreshToken(hash)
	return s.issueTokens(user)
}

func (s *service) Logout(req LogoutRequest) error {
	return s.repo.RevokeRefreshToken(tokenHash(req.RefreshToken))
}

func (s *service) ForgotPassword(_ ForgotPasswordRequest) error {
	return nil
}

func (s *service) ResetPassword(_ ResetPasswordRequest) error {
	return nil
}

func (s *service) issueTokens(user *users.User) (*TokenResponse, error) {
	access, err := s.jwt.Generate(user.ID, user.BranchID, user.RoleName, s.accessTTL)
	if err != nil {
		return nil, err
	}
	refresh, err := s.jwt.Generate(user.ID, user.BranchID, user.RoleName, s.refreshTTL)
	if err != nil {
		return nil, err
	}
	if err := s.repo.SaveRefreshToken(newRefreshToken(user.ID, tokenHash(refresh), time.Now().Add(s.refreshTTL))); err != nil {
		return nil, err
	}
	return &TokenResponse{
		AccessToken: access,
		RefreshToken: refresh,
		TokenType: "Bearer",
		ExpiresIn: int64(s.accessTTL.Seconds()),
	}, nil
}

func tokenHash(token string) string {
	sum := sha256.Sum256([]byte(token))
	return hex.EncodeToString(sum[:])
}

func (s *service) Override(req OverrideRequest) (*OverrideResponse, error) {
	user, err := s.users.FindByEmail(strings.ToLower(req.Email))
	if err != nil || !user.Active || !security.VerifyPassword(user.PasswordHash, req.Password) {
		return nil, errors.New("invalid credentials")
	}

	if user.RoleName != "admin" && user.RoleName != "manager" {
		return nil, errors.New("insufficient permissions: user is not a supervisor")
	}

	return &OverrideResponse{
		SupervisorName: user.Name,
		Role:           user.RoleName,
	}, nil
}
