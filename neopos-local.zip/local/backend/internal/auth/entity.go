package auth

import (
	"time"

	"restaurant-pos-api/pkg/model"

	"github.com/google/uuid"
)

type RefreshToken struct {
	model.Base
	UserID    uuid.UUID  `json:"user_id" gorm:"type:uuid;index;not null"`
	TokenHash string     `json:"-" gorm:"size:255;index;not null"`
	ExpiresAt time.Time  `json:"expires_at"`
	RevokedAt *time.Time `json:"revoked_at,omitempty"`
}
