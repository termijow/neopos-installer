package auth

import (
	"time"

	"restaurant-pos-api/internal/users"
	"restaurant-pos-api/pkg/security"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/limiter"
	"gorm.io/gorm"
)

func RegisterRoutes(router fiber.Router, db *gorm.DB, jwt *security.JWTManager, accessTTL, refreshTTL time.Duration) {
	controller := NewController(NewService(NewRepository(db), users.NewRepository(db), jwt, accessTTL, refreshTTL))
	
	rateLimiter := limiter.New(limiter.Config{
		Max:        100,
		Expiration: 1 * time.Minute,
	})
	
	group := router.Group("/auth", rateLimiter)
	group.Post("/login", controller.Login)
	group.Post("/logout", controller.Logout)
	group.Post("/refresh", controller.Refresh)
	group.Post("/forgot-password", controller.ForgotPassword)
	group.Post("/reset-password", controller.ResetPassword)
	group.Post("/override", controller.Override)
}
