-- Script de inicialización de la base de datos PostgreSQL para soporte multitenant
-- Se pueden crear esquemas por cada sucursal o franquicia

CREATE SCHEMA IF NOT EXISTS tenant_default;
CREATE SCHEMA IF NOT EXISTS tenant_sucursal_1;

-- Extensión para generación de UUIDs (usado en el backend)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Tablas compartidas o de administración podrían ir en el esquema public
-- Tablas específicas de cada tenant en su propio esquema
