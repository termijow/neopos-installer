@echo off
echo ===================================
echo NeoPOS - Iniciando Sistema
echo ===================================

echo Iniciando servicios en segundo plano...
powershell -ExecutionPolicy Bypass -File "%~dp0start.ps1" --prod --no-logs

echo.
echo Esperando a que los servicios respondan (5 segundos)...
timeout /t 5 >nul

echo Abriendo tu navegador...
start http://localhost:5173

exit
