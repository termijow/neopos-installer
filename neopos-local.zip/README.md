# Restaurant POS API

Backend REST para un POS de restaurantes colombianos construido con Go 1.24+, Fiber, PostgreSQL 16, GORM, JWT y Docker.

## Ejecutar Modo Producción

```bash
cp .env.example .env
docker compose up -d --build
```
*(Nota: Si hiciste cambios en el código y estás en modo producción, debes ejecutar `docker compose up -d --build frontend` para forzar la reconstrucción del contenedor)*

La API principal queda disponible en `http://localhost:8080/api/v1`.
El servicio independiente de impresión queda disponible en `http://localhost:8081/api/v1`.
El frontend NeoPOS queda disponible en `http://localhost:5173`.

## Ejecutar Modo Desarrollo (Recomendado)

Para tener **recarga en vivo (hot-reload)** mientras modificas el código:

En Windows:
```powershell
.\start.ps1
```

En Linux/Mac:
```bash
./start.sh
```

## Frontend

La app web vive en `frontend/` y usa React 19, TypeScript, Vite, Material UI, Zustand, TanStack Query, React Router, React Hook Form, Zod, Workbox PWA, Recharts, SheetJS y React-to-Print.

```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

## Módulos

La estructura sigue Clean Architecture por módulo: `entity`, `dto`, `repository`, `service`, `controller` y `routes`.

Incluye autenticación JWT, soft delete, UUID, auditoría, cola de sincronización offline, multisede, inventario, cocina, caja, ventas, facturación electrónica y servicio REST independiente de impresión.

## Arquitectura de Servicios de Nube (IA y Facturación Electrónica)

### Flujo de Inteligencia Artificial (DeepSeek)
El uso de IA (DeepSeek) sigue una arquitectura de intermediación y validación para proteger credenciales, controlar el consumo y centralizar el historial:

1. **Local:** El usuario ingresa un prompt (consulta) en la interfaz de `neopos-local`.
2. **Envío a Cloud:** El prompt se envía de forma segura al backend central `neopos-cloud`, adjuntando identificadores clave (ID del local, token de licencia, etc.).
3. **Validación (Cloud):** `neopos-cloud` intercepta la petición y valida:
   - Que la licencia del restaurante esté vigente.
   - Que el *Tenant* no haya excedido el *rate limit* de cuota interna (ej. 10 consultas por día).
4. **Procesamiento AI:** Si la validación pasa, `neopos-cloud` se encarga de retransmitir la consulta a la API de DeepSeek utilizando las API keys privadas del sistema.
5. **Almacenamiento y Respuesta:** Al recibir la respuesta de DeepSeek:
   - Se guarda el registro del prompt y respuesta en la base de datos de `neopos-cloud`, vinculados al ID del cliente (*Tenant ID*). Este historial podrá auditarse desde `https://neopos-cloud.prismabitetesting.xyz/admin/tenants/[ID]`.
   - Se devuelve la respuesta al restaurante emisor original utilizando su ID único para asegurar aislamiento total de los datos (sin riesgo de cruce de información entre locales).

### Flujo de Facturación Electrónica
El proceso de Facturación Electrónica utiliza el mismo principio de enrutamiento a través de `neopos-cloud`. Todas las facturas generadas localmente viajan a la nube donde se valida la licencia antes de reenviar el XML/JSON al proveedor tecnológico autorizado (DIAN, Alegra, Siigo). El estado y registro de envío quedan almacenados en el panel administrativo del Tenant.
