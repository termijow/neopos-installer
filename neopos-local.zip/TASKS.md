# Tareas Realizadas y Faltantes - NeoPOS

## Tareas Completadas

1. **Renombramiento Global de NeoPOS:** Se corrigieron todas las instancias donde el proyecto aparecía como "neopost", "NEOPOST" o variaciones incorrectas, estandarizando el nombre a **NeoPOS** tanto en el frontend, backend, manifest, configuration, README, etc.
2. **Actualización de Roadmap (Fases Arquitectónicas):** Se añadió una nueva sección en el `Roadmap.md` explicando las dos fases del proyecto:
   - **Fase Cloud:** Gestión centralizada (SuperAdmin para licencias, dueños para métricas) y procesamiento batch para entidades como la DIAN, evitando la sobrecarga.
   - **Fase Local:** Ejecución de las operaciones del Punto de Venta (POS) con funcionalidad "offline-first", encolando facturas e información para su sincronización asíncrona.
3. **Flags para Despliegue con Docker:** Se creó el script `start.sh` en la raíz del proyecto. Este script permite ejecutar selectivamente los contenedores mediante los parámetros:
   - `--local`: (Por defecto) Levanta los contenedores y servicios locales requeridos (`docker-compose.yml`).
   - `--cloud`: Levanta los contenedores de la nube (`docker-compose.infra.yml`).
   - `--all`: Levanta ambos.
4. **Despliegue en la VPS (Cloud):** Se empaquetó el repositorio y se copió por SCP al servidor VPS (`100.91.151.85`). Posteriormente, se extrajo el contenido y se ejecutó únicamente la versión cloud mediante `./start.sh --cloud`.
5. **Ejecución de la versión Local:** Se inicializó la versión local en este dispositivo utilizando `./start.sh --local`.

## Tareas Faltantes / Roadmap de la Versión Cloud

### 1. Infraestructura Cloud
- [x] **Configuración de Base de Datos:** Añadir contenedor de PostgreSQL al `docker-compose.infra.yml`.
- [x] **Migraciones/Inicialización:** Crear un `init-cloud.sql` para inicializar el SuperAdmin por defecto y las tablas para Licencias y Tenants.

### 2. Backend Cloud (Go/Fiber)
- [x] **Conexión a Base de Datos:** Conexión a DB Cloud implementada con éxito (usando Prisma Client Go en lugar de GORM para una arquitectura más moderna).
- [x] **Autenticación (SuperAdmin):** Endpoint `/api/v1/auth/login` con validación JWT.
- [x] **Gestión de Licencias y Tenants:** Endpoints CRUD para crear nuevos clientes, sucursales y generar tokens de licencia con validación (mensual o anual).
- [x] **Recepción de Batches (Sincronización Selectiva):** Endpoints seguros que reciban lotes de operaciones desde las sedes locales y respondan con acuses de recibo (ACK). (Ojo: Sólo ciertos datos permitidos subirán a la nube para visualización del cliente).

### 3. Frontend Cloud (Next.js)
- [x] **Diseño Visual Premium:** Implementada página de bienvenida con animaciones, Glassmorphism y tipografía moderna en Next.js.
- [x] **Sistema de Login:** Página de inicio de sesión estilizada para los dueños y SuperAdmins.
- [x] **Panel de SuperAdmin:** Vista para que nuestro equipo pueda gestionar a todos los clientes, ver el estado de sus pagos y revocar/generar licencias.
- [x] **Panel de Cliente (Dueño):** Dashboard con métricas globales consolidadas (Ventas recientes, sucursales activas) sin requerir acceso al local. Los clientes deben poder ver la información seleccionada que se sincroniza.

## Tareas Faltantes / Roadmap de la Versión Local
- [x] **Sincronización Diferida y Selectiva:** Implementado el flujo asíncrono para subir información específica (no toda) al Cloud en lotes para que el cliente pueda visualizarla.
- [x] **Validación de Licencia Local:** Verificar con el Cloud que la licencia de la caja local esté activa, soportando la verificación de forma periódica.
- [x] **Sistema de Permisos y Roles Locales Multi-Usuario (RBAC):**
  - [x] **Ampliación de Roles Locales:** Implementar control de accesos basado en roles para la versión local, separando las responsabilidades de la caja diaria de las de administración:
    - `Administrador/Dueño`: Acceso total sin restricciones a inventarios, precios y métricas de ganancias.
    - `Supervisor`: Permisos de administración intermedios, incluyendo la autorización de cierres de caja, ajustes de stock y anulación de facturas (mapeado al rol `manager`).
    - `Cajero`: Rol operativo limitado a la venta y facturación estándar (mapeado al rol `cashier`).
  - [x] **Restricciones Específicas para el Rol de `Cajero`:**
    - **Prohibición de Modificación de Precios:** El cajero no podrá alterar manualmente el precio unitario de venta de un producto durante el checkout en el POS. Los precios deben ser fijos según la base de datos de inventario para evitar fraudes, errores o malentendidos con clientes.
    - **Restricción de Ajustes Directos de Inventario:** El cajero tiene prohibido realizar modificaciones manuales de stock (cantidades de inventario) fuera de los procesos de venta normales. Los ajustes físicos de inventario por merma, pérdida o auditoría quedan restringidos.
    - **Bloqueo del Dashboard de Métricas:** El cajero no tendrá acceso al Dashboard local que muestra métricas de ventas acumuladas, utilidades, reportes de turnos generales ni márgenes financieros.
  - **Lógica e Implementación Propuesta:**
    - **Backend (Go/Fiber):**
      - [x] Extender el modelo de datos de `User` en la base de datos local para incluir el campo `role` (campo `role_name`).
      - [x] Implementar un middleware de autorización `RequireRole(allowedRoles ...string)` que valide el rol del usuario autenticado extraído del token JWT local.
      - [x] Restringir endpoints de inventario y edición de precios (ej. `PATCH /api/v1/products/:id`) y consultas de métricas (ej. `GET /api/v1/metrics/dashboard`) devolviendo un estado `403 Forbidden` si el rol es `cajero`.
      - [x] Proveer un endpoint de anulación o autorización temporal `POST /api/v1/auth/override` para permitir que un Supervisor ingrese su credencial (PIN o contraseña rápida) y autorice temporalmente un cambio de precio o descuento específico en la venta en curso sin cerrar la sesión del cajero.
    - **Frontend (React):**
      - [x] Controlar la renderización condicional de rutas y componentes de navegación. Si el usuario activo tiene el rol `cajero`, se ocultan/deshabilitan los accesos al Dashboard, Inventario y Configuración.
      - [x] Configurar el campo de texto de precio de producto en el carrito de compras como `read-only` cuando el rol de la sesión activa sea `cajero`.
      - [x] Diseñar un modal de "Autorización Requerida" que se lance automáticamente si se intenta realizar una acción protegida, permitiendo la lectura de un código de supervisor para continuar.
