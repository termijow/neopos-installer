import os
import json
import zipfile

def create_release():
    source_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) # Root of neopos-local
    releases_dir = os.path.join(source_dir, 'releases')
    
    if not os.path.exists(releases_dir):
        os.makedirs(releases_dir)
        
    release_filename = 'neopos-local.zip'
    release_path = os.path.join(releases_dir, release_filename)
    
    # Exclude these directories/files from the release
    exclude_dirs = {'.git', 'node_modules', 'releases', 'dist', '.next', '__pycache__'}
    exclude_files = {
        release_filename,
        'release-manifest.json',
        'local.db',
        'api',
        'api.pid',
        'tmp_build',
    }

    print(f"📦 Empaquetando {source_dir} -> {release_path}")
    
    manifest = {
        "schema_version": 1,
        "app_version": os.environ.get("RELEASE_VERSION", "development"),
        "database_migration": "additive",
        "breaking_changes": False,
        "release_notes": "Cambios compatibles y migraciones aditivas.",
    }
    manifest_source = os.path.join(source_dir, "release-manifest.json")
    if os.path.exists(manifest_source):
        with open(manifest_source, "r", encoding="utf-8") as manifest_file:
            manifest.update(json.load(manifest_file))
    manifest["app_version"] = os.environ.get("RELEASE_VERSION", manifest.get("app_version", "development"))

    with zipfile.ZipFile(release_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(source_dir):
            # Modifying dirs in-place to exclude unwanted directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                if file in exclude_files:
                    continue
                    
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, source_dir)
                
                # Exclude hidden files (like .env) if you don't want to ship them!
                # Actually, we want to ship .env.example, but not .env.
                if arcname.endswith('.env'):
                    continue
                    
                zipf.write(file_path, arcname)

        zipf.writestr("release-manifest.json", json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
                
    print(f"✅ ¡Release creada exitosamente en {release_path}!")
    print(f"👉 Ahora puedes subir este archivo .zip a GitHub Releases.")

if __name__ == "__main__":
    create_release()
