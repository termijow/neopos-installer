#!/bin/bash
# NeoPOS Database Backup Script
# Creates a compressed, encrypted backup of PostgreSQL and uploads to S3
set -e

# Configuration
DB_HOST=${DB_HOST:-"localhost"}
DB_PORT=${DB_PORT:-"5432"}
DB_USER=${DB_USER:-"pos"}
DB_NAME=${DB_NAME:-"pos"}
BACKUP_DIR="/tmp/neopos_backups"
S3_BUCKET=${S3_BUCKET:-"s3://neopos-backups"}
GPG_PASSPHRASE=${GPG_PASSPHRASE:-"secret"}

DATE=$(date +"%Y-%m-%d_%H-%M-%S")
BACKUP_FILE="${BACKUP_DIR}/pos_${DATE}.sql.gz"
ENCRYPTED_FILE="${BACKUP_FILE}.gpg"

mkdir -p "$BACKUP_DIR"

echo "Starting backup for $DB_NAME..."

# Dump and compress
PGPASSWORD=$DB_PASSWORD pg_dump -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" | gzip > "$BACKUP_FILE"

# Encrypt
echo "Encrypting backup..."
gpg --symmetric --batch --passphrase "$GPG_PASSPHRASE" -o "$ENCRYPTED_FILE" "$BACKUP_FILE"

# Upload to S3
echo "Uploading to $S3_BUCKET..."
aws s3 cp "$ENCRYPTED_FILE" "$S3_BUCKET/"

# Cleanup old local files
rm "$BACKUP_FILE" "$ENCRYPTED_FILE"

echo "Backup completed successfully!"
