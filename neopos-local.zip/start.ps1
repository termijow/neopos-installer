# NeoPOS - Script de inicio para Windows (PowerShell)
# Uso: .\start.ps1 [--local | --cloud | --all] [--prod] [--no-logs] [--auto]
#   --local    : Inicia servicios locales (por defecto)
#   --cloud    : Inicia servicios cloud
#   --all      : Inicia ambos entornos
#   --prod     : Modo producción (build sin caché, contenedores en -d)
#   --no-logs  : En modo prod, no muestra logs (solo up -d)

Set-Location $PSScriptRoot

# Docker Desktop puede instalarse para todos los usuarios o únicamente para
# el usuario actual. Añadimos ambas rutas para que una instalación nueva no
# dependa de que Windows haya refrescado el PATH del proceso.
$dockerCliDirectories = @()
if ($env:ProgramFiles) {
    $dockerCliDirectories += (Join-Path $env:ProgramFiles "Docker\Docker\resources\bin")
}
if ($env:LOCALAPPDATA) {
    $dockerCliDirectories += (Join-Path $env:LOCALAPPDATA "Programs\Docker\resources\bin")
}
foreach ($dockerCliDirectory in $dockerCliDirectories) {
    if ((Test-Path (Join-Path $dockerCliDirectory "docker.exe")) -and -not (($env:Path -split ';') -contains $dockerCliDirectory)) {
        $env:Path = "$dockerCliDirectory;$env:Path"
    }
}

# Defaults
$Target = "--local"
$Mode = "dev"
$ShowLogs = $true
$AutoStart = $false

# Parse args
foreach ($arg in $args) {
    switch -Regex ($arg.ToLower()) {
        "^--?(local|cloud|all)$" { $Target = "--" + $Matches[1] }
        "^--?prod$" { $Mode = "prod" }
        "^--?no-?logs$" { $ShowLogs = $false }
        "^--?auto$" { $AutoStart = $true; $Mode = "prod"; $ShowLogs = $false }
        default {
            Write-Warning "Flag no reconocido: $arg"
            Write-Host "Uso: .\start.ps1 [--local | --cloud | --all] [--prod] [--no-logs] [--auto]"
            Exit 1
        }
    }
}

# Check Docker
if (-not (Get-Command "docker" -ErrorAction SilentlyContinue)) {
    Write-Error "Docker no está instalado o no está en el PATH. Instala Docker Desktop."
    Exit 1
}

# Docker Desktop puede tardar unos segundos en iniciar después del login.
# Si está instalado pero no configurado para iniciar automáticamente, lo
# lanzamos desde la tarea de NeoPOS antes de esperar al daemon.
$dockerDesktopCandidates = @()
if ($env:ProgramFiles) {
    $dockerDesktopCandidates += (Join-Path $env:ProgramFiles "Docker\Docker\Docker Desktop.exe")
}
if ($env:LOCALAPPDATA) {
    $dockerDesktopCandidates += (Join-Path $env:LOCALAPPDATA "Programs\Docker\Docker\Docker Desktop.exe")
}
foreach ($dockerDesktop in $dockerDesktopCandidates) {
    if (Test-Path $dockerDesktop) {
        Start-Process -FilePath $dockerDesktop -WindowStyle Hidden
        break
    }
}
$dockerReady = $false
for ($attempt = 1; $attempt -le 30; $attempt++) {
    docker info *> $null
    if ($LASTEXITCODE -eq 0) {
        $dockerReady = $true
        break
    }
    Write-Host "[DOCKER] Esperando al daemon... ($attempt/30)" -ForegroundColor Gray
    Start-Sleep -Seconds 2
}
if (-not $dockerReady) {
    Write-Error "Docker Desktop no está disponible después de 60 segundos."
    Exit 1
}

# Ensure .env files exist
function Ensure-EnvFile($envPath, $examplePath) {
    if (-not (Test-Path $envPath) -and (Test-Path $examplePath)) {
        Write-Host "[SYS] Creando $envPath desde .env.example..." -ForegroundColor Yellow
        Copy-Item $examplePath $envPath
    }
}

if ($Target -in @("--local", "--all")) {
    Ensure-EnvFile "$PSScriptRoot\local\backend\.env" "$PSScriptRoot\local\backend\.env.example"
}
if ($Target -in @("--cloud", "--all")) {
    Ensure-EnvFile "$PSScriptRoot\cloud\backend\.env" "$PSScriptRoot\cloud\backend\.env.example"
}

# Modo usado por el Programador de tareas del instalador. No reconstruye
# imágenes en cada inicio; Docker Compose y restart: unless-stopped mantienen
# los contenedores activos y los recuperan si un proceso se cae.
if ($AutoStart) {
    if ($Target -ne "--local") {
        Write-Error "El modo --auto solo está soportado para NeoPOS Local."
        Exit 1
    }
    docker compose -p neopos-local -f docker-compose.yml up -d --remove-orphans
    if ($LASTEXITCODE -ne 0) {
        Write-Error "No se pudieron iniciar los servicios locales."
        Exit $LASTEXITCODE
    }
    exit 0
}

# Start cloud infra if needed
if ($Target -in @("--cloud", "--all")) {
    Write-Host "[SYS] Iniciando infraestructura cloud (traefik, cloudflared)..." -ForegroundColor Yellow
    docker compose -p neopos-cloud -f docker-compose.infra.yml up -d
}

# ===================== MODO DESARROLLO =====================
if ($Mode -eq "dev") {
    Write-Host "[START] Iniciando NeoPOS en MODO DESARROLLO (Hot Reload)..." -ForegroundColor Cyan

    switch ($Target) {
        "--local" {
            Write-Host "[DOCKER] Limpiando posible conflicto con frontend en produccion..." -ForegroundColor Gray
            docker compose -p neopos-local -f docker-compose.yml stop frontend 2> $null
            docker compose -p neopos-local -f docker-compose.yml rm -f frontend 2> $null

            Write-Host "[DOCKER] Levantando postgres, api, printer, minio..." -ForegroundColor Gray
            docker compose -p neopos-local -f docker-compose.yml up -d api printer postgres minio

            # Start backend logs in background job
            $logJob = Start-Job -ScriptBlock {
                docker compose -p neopos-local -f docker-compose.yml logs -f
            }

            # Start frontend dev server (blocking - shows in same console)
            Write-Host "[VITE] Iniciando servidor de desarrollo frontend (puerto 5173)..." -ForegroundColor Gray
            Write-Host "`n[OK] Todo levantado. Logs del backend arriba. Frontend en http://localhost:5173" -ForegroundColor Green
            Write-Host "[INFO] Presiona Ctrl+C para detener todo." -ForegroundColor Yellow

            try {
                Push-Location "$PSScriptRoot\local\frontend"
                if (-not (Test-Path "node_modules")) {
                    Write-Host "[NPM] Instalando dependencias del frontend local..." -ForegroundColor Gray
                    npm install
                }
                npm run dev -- --host 0.0.0.0 --clearScreen false
            }
            finally {
                Pop-Location
                Write-Host "`n[STOP] Deteniendo servicios..." -ForegroundColor Yellow
                $logJob | Stop-Job | Out-Null
                docker compose -p neopos-local -f docker-compose.yml down
            }
        }

        "--cloud" {
            Write-Host "[DOCKER] Levantando infraestructura cloud..." -ForegroundColor Gray
            docker compose -p neopos-cloud -f docker-compose.infra.yml up -d

            $logJob = Start-Job -ScriptBlock {
                docker compose -p neopos-cloud -f docker-compose.infra.yml logs -f
            }

            Write-Host "[NEXT] Iniciando servidor de desarrollo Next.js (puerto 3000)..." -ForegroundColor Gray
            Write-Host "`n[OK] Todo levantado. Logs arriba. Frontend en http://localhost:3000" -ForegroundColor Green
            Write-Host "[INFO] Presiona Ctrl+C para detener todo." -ForegroundColor Yellow

            try {
                Push-Location "$PSScriptRoot\cloud\frontend"
                if (-not (Test-Path "node_modules")) {
                    Write-Host "[NPM] Instalando dependencias del frontend cloud..." -ForegroundColor Gray
                    npm install
                }
                npm run dev
            }
            finally {
                Pop-Location
                Write-Host "`n[STOP] Deteniendo servicios..." -ForegroundColor Yellow
                $logJob | Stop-Job | Out-Null
                docker compose -p neopos-cloud -f docker-compose.infra.yml down
            }
        }

        "--all" {
            Write-Host "[DOCKER] Levantando TODOS los servicios backend..." -ForegroundColor Gray
            docker compose -p neopos-local -f docker-compose.yml up -d api printer postgres minio
            docker compose -p neopos-cloud -f docker-compose.infra.yml up -d

            # Start log streaming for both
            $logJob1 = Start-Job -ScriptBlock {
                docker compose -p neopos-local -f docker-compose.yml logs -f
            }
            $logJob2 = Start-Job -ScriptBlock {
                docker compose -p neopos-cloud -f docker-compose.infra.yml logs -f
            }

            # Start both frontends in parallel background jobs
            $feLocal = Start-Job -ScriptBlock {
                param($dir)
                Push-Location $dir
                try { 
                    if (-not (Test-Path "node_modules")) { npm install }
                    npm run dev -- --host 0.0.0.0 --clearScreen false 
                } finally { Pop-Location }
            } -ArgumentList "$PSScriptRoot\local\frontend"

            $feCloud = Start-Job -ScriptBlock {
                param($dir)
                Push-Location $dir
                try { 
                    if (-not (Test-Path "node_modules")) { npm install }
                    npm run dev 
                } finally { Pop-Location }
            } -ArgumentList "$PSScriptRoot\cloud\frontend"

            Write-Host "`n[OK] TODO LEVANTADO. Logs mezclados arriba." -ForegroundColor Green
            Write-Host "  Frontend Local:  http://localhost:5173" -ForegroundColor Cyan
            Write-Host "  Frontend Cloud:  http://localhost:3000" -ForegroundColor Cyan
            Write-Host "  API Local:       http://localhost:8080" -ForegroundColor Cyan
            Write-Host "[INFO] Presiona Ctrl+C para detener todo." -ForegroundColor Yellow

            try {
                while ($true) { Start-Sleep -Seconds 1 }
            }
            catch {
                Write-Host "`n[STOP] Deteniendo todos los servicios..." -ForegroundColor Yellow
                $logJob1, $logJob2, $feLocal, $feCloud | Stop-Job | Out-Null
                docker compose -p neopos-local -f docker-compose.yml down
                docker compose -p neopos-cloud -f docker-compose.infra.yml down
            }
        }
    }
} else {
    # ===================== MODO PRODUCCION =====================
    Write-Host "[START] Iniciando NeoPOS en MODO PRODUCCION..." -ForegroundColor Cyan

    switch ($Target) {
        "--local" {
            Write-Host "Construyendo e iniciando contenedores locales sin caché..." -ForegroundColor Gray
            docker compose -p neopos-local -f docker-compose.yml build --no-cache
            if ($ShowLogs) {
                docker compose -p neopos-local -f docker-compose.yml up --force-recreate
            }
            else {
                docker compose -p neopos-local -f docker-compose.yml up -d --force-recreate
                Write-Host "[OK] Servicios iniciados en background. Usa 'docker compose logs -f' para ver logs." -ForegroundColor Green
            }
        }

        "--cloud" {
            Write-Host "Construyendo e iniciando contenedores cloud sin caché..." -ForegroundColor Gray
            docker compose -p neopos-cloud -f docker-compose.infra.yml build --no-cache
            if ($ShowLogs) {
                docker compose -p neopos-cloud -f docker-compose.infra.yml up --force-recreate
            }
            else {
                docker compose -p neopos-cloud -f docker-compose.infra.yml up -d --force-recreate
                Write-Host "[OK] Servicios iniciados en background. Usa 'docker compose logs -f' para ver logs." -ForegroundColor Green
            }
        }

        "--all" {
            Write-Host "Construyendo e iniciando TODOS los contenedores sin caché..." -ForegroundColor Gray
            docker compose -p neopos-local -f docker-compose.yml build --no-cache
            docker compose -p neopos-cloud -f docker-compose.infra.yml build --no-cache

            docker compose -p neopos-local -f docker-compose.yml up -d --force-recreate
            docker compose -p neopos-cloud -f docker-compose.infra.yml up -d --force-recreate

            if ($ShowLogs) {
                Write-Host "Mostrando logs de ambos entornos..." -ForegroundColor Gray
                $cloudLogs = Start-Job -ScriptBlock {
                    docker compose -p neopos-cloud -f docker-compose.infra.yml logs -f
                }
                docker compose -p neopos-local -f docker-compose.yml logs -f
                $cloudLogs | Stop-Job | Out-Null
            }
            else {
                Write-Host "[OK] Todos los servicios iniciados en background." -ForegroundColor Green
            }
        }
    }
}
