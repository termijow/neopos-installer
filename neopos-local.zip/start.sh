#!/bin/bash

# Cambiar al directorio del script para resolver rutas relativas correctamente
cd "$( dirname "${BASH_SOURCE[0]}" )" || exit 1

# NeoPOS - Script de inicio Local (Modo Desarrollo)
# Ahora siempre ignora los flags y enciende únicamente en local y desarrollo

echo "🚀 Iniciando NeoPOS en MODO DESARROLLO LOCAL..."

# Asegurar que las dependencias de Node.js estén instaladas localmente
if [ ! -d "local/frontend/node_modules" ]; then
    echo "📦 node_modules no encontrado en local/frontend. Instalando dependencias..."
    (cd local/frontend && npm install) || { echo "❌ Error al instalar dependencias de local/frontend"; exit 1; }
fi

echo "🛑 Asegurando que no haya conflictos de puerto con el contenedor de frontend en producción..."
docker compose -p neopos-local -f docker-compose.yml stop frontend 2>/dev/null
docker compose -p neopos-local -f docker-compose.yml rm -f frontend 2>/dev/null

echo "📂 Levantando base de datos y backend local en Docker..."
# Levanta los contenedores en background (con --build para aplicar cambios de código)
docker compose -p neopos-local -f docker-compose.yml up -d --build api printer postgres minio

echo "📋 Iniciando logs de Docker en tiempo real..."
# Sigue los logs de Docker en background
docker compose -p neopos-local -f docker-compose.yml logs -f &
DOCKER_LOGS_PID=$!

echo "💻 Iniciando servidor de desarrollo Vite para frontend local..."
# Inicia Vite en background
cd local/frontend && npm run dev -- --clearScreen false &
VITE_PID=$!

# Capturar Ctrl+C para matar limpiamente los procesos de frontend y logs de Docker
trap 'echo -e "\n🛑 Deteniendo servidor Vite y logs de Docker..."; kill $VITE_PID $DOCKER_LOGS_PID 2>/dev/null; exit' SIGINT

# Esperar a que terminen los procesos
wait $VITE_PID $DOCKER_LOGS_PID
