# Roadmap de Desarrollo - NeoPOS

Este documento describe la planificación de desarrollo y entrega para el sistema **NeoPOS**. El proyecto se guiará por estándares de ingeniería de software de alto nivel.

---

## 💡 Principios y Buenas Prácticas de Ingeniería

Para garantizar la mantenibilidad, escalabilidad y robustez del sistema, el desarrollo se regirá bajo los siguientes principios:

*   **Arquitectura Hexagonal (Puertos y Adaptadores):** Separación estricta entre la lógica de dominio (casos de uso) y los detalles técnicos de infraestructura (bases de datos, controladores HTTP, colas de sincronización, impresión física).
*   **Diseño Guiado por el Dominio (DDD):** El núcleo del software modelará fielmente los procesos de un restaurante colombiano (cajas, mesas, comandas, facturas, impuestos).
*   **Desarrollo Guiado por Pruebas (TDD):** Se escribirán pruebas unitarias automatizadas antes de la lógica de negocio para asegurar un código libre de regresiones.
*   **Principio de Responsabilidad Única (SOLID):** Componentes pequeños y modulares tanto en el Backend (Go) como en el Frontend (React con Zustand y hooks desacoplados).
*   **Diseño de Interfaz Premium:** Interfaces altamente optimizadas para entornos de alta velocidad (pantallas táctiles de caja), rápidas (<100ms de respuesta) y con feedback visual instantáneo.
*   **Commits por Tarea:** Cada vez que se complete un paso o tarea del checklist, se deberá realizar el commit correspondiente en el repositorio para mantener un historial de cambios limpio, rastreable y modular.

---

## 🗺️ Fases Arquitectónicas del Proyecto

El proyecto de NeoPOS se divide estructuralmente en 2 grandes fases o entornos:

### 1. Fase Cloud (Nube)
Servirá como el centro de gestión y consolidación, diseñado de forma ligera:
*   **Rol SuperAdmin (Equipo NeoPOS):** Gestión integral del software, permitiendo crear y administrar licencias para los clientes cuando adquieren el sistema.
*   **Rol Cliente (Dueños de Negocios):** Plataforma web (y futura app) para visualizar las métricas más importantes de sus negocios (ventas recientes, reportes) sin sobrecargar el servidor principal.
*   **Procesamiento Externo (DIAN):** Recibirá los lotes (batches) de facturación del entorno local, procesándolos y enviándolos a la DIAN o a nuestro proveedor de facturación electrónica.

### 2. Fase Local (Punto de Venta)
El cliente que procesará toda la operatividad del restaurante:
*   **Operación Offline:** Funcionará sin necesidad de internet permanente para procesar todo lo relacionado al POS (Punto de Venta).
*   **Sincronización Diferida:** Las facturas electrónicas y otras transacciones se almacenarán en un "batch" local, esperando a conectarse para que el servidor cloud las procese.

---

## 🗺️ Roadmap de Desarrollo

El roadmap se divide en **Módulos**, los cuales se desglosan en **Fases** y estas a su vez en **Pasos** tácticos y accionables asignados equitativamente entre los integrantes del equipo.

---

### 📦 MÓDULO 1: Base de Infraestructura y Administración

#### **Fase 1.1: Configuración de Entornos y Contenedores**
*   [x] **Paso 1.1.1 [Backend] (Juan Pablo):** Crear archivos de configuración de entorno `.env.example` separados para local y cloud.
*   [x] **Paso 1.1.2 [DevOps] (Juan Diego):** Reubicar y reescribir los Dockerfiles en `local/backend/Dockerfile` y `local/frontend/Dockerfile` para que compilen desde las nuevas rutas.
*   [x] **Paso 1.1.3 [DevOps] (Juan Diego):** Adaptar el archivo `docker-compose.yml` en la raíz para orquestar la base de datos PostgreSQL, la API local, el servicio de impresión local y el frontend local.
*   [x] **Paso 1.1.4 [Base de datos] (Juan Diego):** Configurar los scripts de inicialización de la base de datos en la VPS para dar soporte multitenant (creación de esquemas o partición lógica).

#### **Fase 1.2: Configuración Inicial de Proyectos**
*   [x] **Paso 1.2.1 [Backend] (Juan Diego):** Configurar la estructura de carpetas en `local/backend` bajo principios de arquitectura hexagonal (separando dominio de infraestructura HTTP y GORM).
*   [ ] **Paso 1.2.2 [Backend] (Juan Pablo):** Implementar el test y el código para autenticación JWT (registro, login, actualización de token con refresh tokens).
*   [ ] **Paso 1.2.3 [Backend] (Juan Pablo):** Crear middlewares de autenticación y autorización por roles (Admin, Cajero, Mesero, Cocinero).
*   [x] **Paso 1.2.4 [Backend] (Juan Diego):** Refactorizar el módulo de auditoría de GORM para registrar cambios de forma estructurada con su correspondiente suite de pruebas unitarias.

#### **Fase 1.3: Gestión Administrativa Básica**
*   [ ] **Paso 1.3.1 [Backend] (Juan Pablo):** Crear CRUD de usuarios con validaciones de contraseñas seguras y asignación de sedes.
*   [ ] **Paso 1.3.2 [Backend] (Juan Pablo):** Crear CRUD de roles y mapeo de permisos específicos.
*   [ ] **Paso 1.3.3 [Frontend] (Juan Pablo):** Diseñar en React las vistas de inicio de sesión e interfaz base con enrutamiento protegido según el rol del usuario.

---

### 📦 MÓDULO 2: Operación del Restaurante (Mesa, Caja y Cocina)

#### **Fase 2.1: Gestión de Salón y Mesas**
*   [ ] **Paso 2.1.1 [Backend] (Juan Pablo):** Diseñar modelos de bases de datos para Áreas (Salón, Terraza, etc.) y Mesas.
*   [ ] **Paso 2.1.2 [Backend] (Juan Pablo):** Crear endpoints para obtener el estado actual de las mesas y realizar acciones como "Cambiar Mesa" o "Unificar Cuentas".
*   [x] **Paso 2.1.3 [Frontend] (Juan Diego):** Diseñar el maquetado interactivo y responsive (arrastrar y soltar opcional) para la distribución visual del mapa de mesas.
*   [ ] **Paso 2.1.4 [Frontend] (Juan Pablo):** Implementar indicador visual del estado de las mesas (Libre, Ocupada, Pidiendo, Por Cobrar).

#### **Fase 2.2: Punto de Venta (POS) y Gestión de Caja**
*   [ ] **Paso 2.2.1 [Backend] (Juan Pablo):** Crear endpoints para apertura y cierre ciego de caja (cajero no conoce el valor calculado por el sistema antes del conteo).
*   [ ] **Paso 2.2.2 [Backend] (Juan Pablo):** Implementar endpoints para egresos e ingresos menores de caja con justificación.
*   [x] **Paso 2.2.3 [Backend] (Juan Diego):** Implementar cálculo y distribución de propina sugerida (10% en Colombia) y división de cuentas (Split Bill) por partes iguales o por ítems.
*   [x] **Paso 2.2.4 [Frontend] (Juan Diego):** Crear la interfaz del POS táctil con búsqueda rápida de productos, selección de mesa asociada e integración con Zustand para manejar el estado del pedido actual.

#### **Fase 2.3: Cocina Digital (KDS - Kitchen Display System)**
*   [ ] **Paso 2.3.1 [Frontend] (Jara):** Construir la vista KDS con columnas Kanban (Pendiente, En Preparación, Listo) soportando drag-and-drop.
*   [x] **Paso 2.3.2 [Backend] (Juan Diego):** Añadir soporte de WebSockets o Server-Sent Events (SSE) para enviar actualizaciones en tiempo real a la pantalla de cocina cuando se genera una nueva comanda.
*   [ ] **Paso 2.3.3 [Frontend] (Jara):** Conectar el KDS con SSE/WebSockets y mostrar alertas visuales (colores) basadas en el tiempo de espera del pedido (cambia a amarillo o rojo si el pedido se retrasa).

---

### 📦 MÓDULO 3: Logística e Inventario (Recetas y Kardex)

#### **Fase 3.1: Catálogo y Movimientos de Inventario**
*   [ ] **Paso 3.1.1 [Backend] (Juan Pablo):** Implementar CRUD para categorías y productos.
*   [ ] **Paso 3.1.2 [Backend] (Juan Pablo):** Crear tabla de Kardex para registrar movimientos de inventario (`IN`, `OUT`, `ADJUSTMENT`) con autor de auditoría y motivo del movimiento.
*   [ ] **Paso 3.1.3 [Backend] (Juan Pablo):** Configurar alertas de stock crítico por producto y endpoints de consulta para el administrador.
*   [ ] **Paso 3.1.4 [Frontend] (Juan Pablo):** Diseñar vistas CRUD de catálogo e inventario con buscadores interactivos.

#### **Fase 3.2: Recetas y Gestión de Insumos**
*   [x] **Paso 3.2.1 [Backend] (Juan Diego):** Crear entidades `Recipe` y `RecipeItem` y establecer relación con los `Products` para soporte de recetas escaladas.
*   [x] **Paso 3.2.2 [Backend] (Juan Diego):** Desarrollar servicio que se conecte al evento de "Pago completado" o "Pedido entregado" para descontar automáticamente los insumos en el submódulo de Inventario según la receta configurada.
*   [x] **Paso 3.2.3 [Backend] (Juan Diego):** Crear CRUD básico para `Suppliers` (Proveedores) y registrar compras (`Purchases`) que actualicen el stock y el costo promedio de inventario.
*   [x] **Paso 3.2.4 [Frontend] (Juan Diego):** Diseñar el panel de configuración de recetas de productos, permitiendo agregar insumos con cantidad y unidad de medida.

---

### 📦 MÓDULO 4: Impresión y Facturación Electrónica (DIAN)

#### **Fase 4.1: Impresión Térmica Local**
*   [x] **Paso 4.1.1 [Backend] (Juan Diego):** Desarrollar la lógica del servicio local `cmd/printer` para comunicarse con puertos USB o direcciones IP de red de impresoras térmicas.
*   [x] **Paso 4.1.2 [Backend] (Juan Diego):** Implementar formateadores ESC/POS en binario crudo para generar tickets de caja, comandas de cocina y reportes de cierre diario (Z y X).
*   [ ] **Paso 4.1.3 [Frontend] (Juan Pablo):** Diseñar el flujo de impresión directa mediante peticiones locales e integrar botón de respaldo con "React-to-print" usando diálogo nativo del navegador.

#### **Fase 4.2: Facturación Electrónica DIAN**
*   [x] **Paso 4.2.1 [Backend] (Juan Diego):** Crear cliente HTTP para la conexión y firma digital con la API del proveedor tecnológico seleccionado (Siigo, Alegra o Carvajal).
*   [x] **Paso 4.2.2 [Backend] (Juan Diego):** Implementar constructor de XML estructurado DIAN con soporte para IVA (0%, 5%, 19%) e Impuesto al Consumo (INC 8%).
*   [x] **Paso 4.2.3 [Backend] (Juan Diego):** Desarrollar el flujo de generación del PDF con código QR y CUFE y envío automatizado al correo del cliente.
*   [ ] **Paso 4.2.4 [Backend] (Juan Pablo):** Crear soporte para Notas Crédito y Débito asociadas a facturas previas para anulaciones o descuentos posteriores.

---

### 📦 MÓDULO 5: Resiliencia y Sincronización Local-Cloud

#### **Fase 5.1: Mecanismo de Sincronización en Segundo Plano**
*   [x] **Paso 5.1.1 [Backend] (Juan Diego):** Crear un worker en segundo plano en el POS local en Go que consulte periódicamente la tabla `sync_queue` buscando registros pendientes de envío.
*   [ ] **Paso 5.1.2 [Backend - Cloud] (Juan Pablo):** Crear endpoints HTTP seguros en el backend de la nube para recibir lotes de operaciones desde las sedes locales.
*   [x] **Paso 5.1.3 [Backend - Cloud] (Juan Diego):** Desarrollar el algoritmo de validación de integridad referencial y resolución de conflictos cronológica al aplicar operaciones en el servidor de la nube.
*   [ ] **Paso 5.1.4 [Backend] (Juan Pablo):** Marcar registros locales como sincronizados una vez el servidor de la VPS confirme la persistencia exitosa.

#### **Fase 5.2: Continuidad de Negocio Frontend (Offline First)**
*   [x] **Paso 5.2.1 [Frontend] (Juan Diego):** Configurar Workbox PWA para cachear recursos estáticos, permitiendo cargar la app web sin conexión a internet.
*   [ ] **Paso 5.2.2 [Frontend] (Juan Pablo):** Diseñar notificaciones en la UI (Chips/Banners) para alertar al cajero sobre el estado de la conexión de red (Offline/Online) y la cantidad de transacciones pendientes por sincronizar.
*   [ ] **Paso 5.2.3 [Frontend] (Juan Pablo):** Probar la resincronización automatizada de la cola local de `localStorage` al detectar eventos `online` del navegador.

---

### 📦 MÓDULO 6: Reportes, QA y Despliegue

#### **Fase 6.1: Generación de Reportes y Auditoría**
*   [ ] **Paso 6.1.1 [Backend] (Juan Pablo):** Implementar en `reports/service.go` consultas agregadas reales en SQL/GORM para consolidar datos financieros de ventas diarias y mensuales.
*   [ ] **Paso 6.1.2 [Backend] (Juan Pablo):** Formatear y generar los archivos Excel con el motor `excelize` estructurando pestañas, totales e impuestos (IVA, INC) para contabilidad.
*   [x] **Paso 6.1.3 [Frontend] (Juan Diego):** Crear un Dashboard con gráficos interactivos usando Recharts para mostrar métricas clave de rendimiento (platos más vendidos, horas pico de venta, utilidades).

#### **Fase 6.2: Pruebas, Control de Calidad e Implementación**
*   [x] **Paso 6.2.1 [QA] (Juan Diego):** Desarrollar pruebas de integración simulando flujos de venta de extremo a extremo (toma de pedido ➔ envío a cocina ➔ cobro ➔ facturación electrónica).
*   [x] **Paso 6.2.2 [QA] (Juan Diego):** Realizar pruebas de carga y concurrencia simulando cientos de pedidos en la API local para certificar estabilidad.
*   [x] **Paso 6.2.3 [DevOps] (Juan Diego):** Configurar copias de seguridad (backups) automáticas cifradas de la base de datos local y la base de datos de la VPS en almacenamiento en la nube (S3 o similar).
*   [ ] **Paso 6.2.4 [Despliegue] (Juan Pablo):** Instalar y desplegar el sistema local en los equipos físicos de **TAQUERIA MX** en Villavicencio, Colombia, y capacitar al personal administrador, cajeros y meseros.
