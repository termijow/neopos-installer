# Lineamientos de Diseño - NeoPOS

Este documento establece la propuesta visual y de experiencia de usuario (UX/UI) para la plataforma **NeoPOS**, optimizada para el entorno exigente de restaurantes y puntos de venta.

---

## 🎨 Identidad Visual y Paleta de Colores (Material-UI)

Aunque no se cuenta con un branding definitivo, NeoPOS debe transmitir **rapidez, modernidad y fiabilidad**. Proponemos una paleta de colores de alto contraste implementada a través de **Material-UI (MUI)**:

### 🟢 Colores Principales
*   **Primary (Base/Contenedores):** `#0f172a` (Gris azulado profundo)
    *   *Uso:* Barra lateral (aside), Dashboard, botones de confirmación y encabezados. Transmite estabilidad y seriedad corporativa.
*   **Secondary (Tecnológico):** `#0891b2` (Electric Cyan)
    *   *Uso:* Indicadores, enlaces secundarios, chips de filtros rápidos de categorías.

### 🟡 Colores de Estado
*   **Success (Éxito):** `#16a34a` (Pagado, Sincronizado, Caja Abierta)
*   **Warning (Alerta/Ámbar):** `#f59e0b` (Pedido Pendiente, Stock Crítico)
    *   *Uso adicional:* Resaltados que requieren atención del usuario, aportando calidez.
*   **Error (Rojo):** `#dc2626` (Pedido Cancelado, Error de Red, Diferencia en Caja)

### ⚪ Fondos e Interfaz
*   **Fondo de Aplicación (`background.default`):** `#f8fafc` (Gris extra claro para evitar fatiga visual)
*   **Papel / Tarjetas (`background.paper`):** `#ffffff` (Blanco puro, con bordes `#e2e8f0` y sombra suave `0 10px 30px rgba(15, 23, 42, 0.06)`)

---

## ✍️ Tipografía

Buscamos máxima legibilidad en pantallas táctiles y bajo condiciones de luz cambiantes (típicas en la barra o en la caja de un restaurante).

*   **Tipografía de Interfaz:** `Inter`, `Roboto`, `Arial`, `sans-serif` (Configuración de MUI).
    *   *Razón:* Fuentes sans-serif geométricas con un excelente interlineado nativo, lo que facilita leer nombres largos de platos en segundos. Los encabezados (h1-h6) tienen un `fontWeight: 800` para jerarquía clara.
*   **Tipografía Numérica (Precios y Totales):** `Inter` utilizando la propiedad CSS `font-variant-numeric: tabular-nums;` o una fuente semi-mono.
    *   *Razón:* Los precios deben estar alineados verticalmente en la factura o lista de pedido para facilitar la lectura y evitar saltos de línea molestos.

---

## ⚡ Patrones de Experiencia de Usuario (UX)

Un sistema POS de restaurante se mide por su velocidad de facturación. Cada segundo cuenta en horas pico.

1.  **UX de un Solo Toque (One-Tap Add):**
    *   Al tocar un producto en el menú del POS, este se agrega inmediatamente al carrito de compras con cantidad `1`. Si ya existe en el carrito, incrementa la cantidad. No se debe abrir un modal de configuración a menos que el producto requiera modificadores (ej. "Término de carne", "Sin cebolla").
2.  **Transiciones Fluidas (Micro-Interactions):**
    *   Los botones deben encogerse sutilmente al ser presionados (`transform: scale(0.97)`) para emular el tacto de un botón físico.
    *   Las transiciones de estados (ej. cambiar comanda de "Preparando" a "Listo") deben tener animaciones suaves de desvanecimiento (fade-in) para que el ojo del usuario note el cambio sin resultar invasivo.
3.  **Interfaz KDS (Monitor de Cocina) Simplificada:**
    *   Tarjetas grandes con textos legibles a 1.5 metros de distancia (los cocineros suelen trabajar de pie con la pantalla colgada).
    *   Colores de cabeceras dinámicos según el tiempo transcurrido (Verde: <10 min, Amarillo: 10-20 min, Rojo: >20 min).

---

## 🛠️ Temas (Light & Dark Mode)

*   **Modo Claro (Por defecto en Caja):** Ideal para entornos muy iluminados de día.
*   **Modo Oscuro (Por defecto en Cocina / Turnos Nocturnos):** Minimiza la fatiga ocular del personal y ahorra batería en dispositivos portátiles o tablets.
