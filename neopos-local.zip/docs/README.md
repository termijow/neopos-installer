# NeoPOS Documentation Hub (Local & Cloud)

Welcome to the central documentation directory for the **NeoPOS** project. NeoPOS is a hybrid local/cloud POS (Point of Sale) system designed for retail and restaurants in Colombia, featuring offline-first local execution and centralized cloud metrics and licensing.

This directory contains the OpenAPI (Swagger) specifications for both backends, along with integration guides and code examples:

1. **Local POS API Specification**: [openapi-local.yaml](file:///home/termihoe/Documents/NeoPOS/docs/openapi-local.yaml) - For local POS sales, inventory, tables, printing, and Factus electronic invoicing.
2. **Cloud Centralized API Specification**: [openapi-cloud.yaml](file:///home/termihoe/Documents/NeoPOS/docs/openapi-cloud.yaml) - For cloud dashboard, license management, tenant creation, and offline sync batch reception.

---

## Table of Contents
- [How to View the Swagger Documentation](#how-to-view-the-swagger-documentation)
- [Local POS Integration Guide](#local-pos-integration-guide)
  - [1. Authentication Flow & Realistic Example](#1-authentication-flow--realistic-example)
  - [2. RBAC Roles & Restrictions (Cajero vs Supervisor/Admin)](#2-rbac-roles--restrictions-cajero-vs-supervisoradmin)
  - [3. Cash Register Flow (Caja Diaria)](#3-cash-register-flow-caja-diaria)
  - [4. Factus/DIAN Electronic Invoicing & Error Handling](#4-factusdian-electronic-invoicing--error-handling)
- [Cloud Centralized Integration Guide](#cloud-centralized-integration-guide)
  - [1. Cloud Login & Credentials](#1-cloud-login--credentials)
  - [2. License Verification Flow](#2-license-verification-flow)
  - [3. Batch Sync Service](#3-batch-sync-service)
- [Code Examples](#code-examples)
  - [Authentication Example (cURL, JS, Go)](#authentication-example-curl-js-go)
  - [Register Sale Example (cURL, JS, Go)](#register-sale-example-curl-js-go)
  - [Sync Batch Example (cURL, JS, Go)](#sync-batch-example-curl-js-go)
- [Global Error Response Schema](#global-error-response-schema)

---

## How to View the Swagger Documentation

You can view and interact with the Swagger documentation using any standard OpenAPI viewer. Here are the recommended ways:

### Option A: VS Code / IDE Extensions
Install the **OpenAPI (Swagger) Editor** or **Swagger Viewer** extension and open:
* Local: `docs/openapi-local.yaml`
* Cloud: `docs/openapi-cloud.yaml`
Press `Shift + Alt + P` (or right-click -> Preview Swagger) to see the interactive HTML documentation.

### Option B: Local Docker Container
Run the official Swagger UI in Docker mapping the local files:
```bash
docker run -d -p 8081:8080 -v "/home/termihoe/Documents/NeoPOS/docs:/usr/share/nginx/html/specs" -e URLS="[{url: 'specs/openapi-local.yaml', name: 'Local POS API'}, {url: 'specs/openapi-cloud.yaml', name: 'Cloud API'}]" swaggerapi/swagger-ui
```
Then visit: [http://localhost:8081](http://localhost:8081)

### Option C: Online Swagger Editor
Copy the contents of `openapi-local.yaml` or `openapi-cloud.yaml` and paste them directly into the online [Swagger Editor](https://editor.swagger.io/).

---

## Local POS Integration Guide

The Local POS runs on port `8080` (or as configured in `.env`). It handles offline-first operations for restaurants/retail stores.

### 1. Authentication Flow & Realistic Example
The local system is secured using JSON Web Tokens (JWT). 

* **Default Admin Credentials (Local)**:
  * **Email**: `admin@pos.local`
  * **Password**: `NeoPOS_Local_S3cur3Admin!_2026`
* **Authentication Endpoint**: `POST /api/v1/auth/login`
* **Token Lifetime**: 
  * Access Token: `30 minutes` (included in `Authorization: Bearer <token>` header).
  * Refresh Token: `7 days` (168 hours) - used to request a new access token at `POST /api/v1/auth/refresh`.

#### Login JSON Example:
```json
{
  "email": "admin@pos.local",
  "password": "NeoPOS_Local_S3cur3Admin!_2026"
}
```

#### Success Response (200 OK):
```json
{
  "data": {
    "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoi...",
    "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoi...",
    "token_type": "Bearer",
    "expires_in": 1800
  }
}
```

### 2. RBAC Roles & Restrictions (Cajero vs Supervisor/Admin)
The local backend implements Role-Based Access Control (RBAC).

| Role | Permissions | Key Restrictions |
|---|---|---|
| `admin` (Owner/Admin) | Full access. CRUD products, inventory, users, settings, and reports. | None |
| `manager` (Supervisor) | Intermediate access. Can open/close cash session, modify categories, edit products, adjust inventory, view reports. | Cannot manage users, settings, or roles. |
| `cajero` (Cashier)| Basic operational access. Can open cash session, register sales, create orders, open tables, and request invoice printouts. | **Forbidden**: Modifying product unit prices, direct stock adjustments (inventario), and dashboard metrics. |

#### Supervisor Override (`POST /api/v1/auth/override`)
When a cashier (`cajero`) needs to perform a restricted action (such as giving a discount or overriding a unit price on a sale item), the frontend should prompt a supervisor credentials modal. The frontend calls:
```json
{
  "email": "admin@pos.local",
  "password": "NeoPOS_Local_S3cur3Admin!_2026"
}
```
If successful, it returns the supervisor's info. The sale can then be sent with the supervisor details without logging out the cashier:
```json
{
  "supervisor_name": "Administrador",
  "role": "admin"
}
```

### 3. Cash Register Flow (Caja Diaria)
A cashier cannot make sales without an active cash register session:
1. **Open Session**: `POST /api/v1/cash/open` with opening balance.
2. **Operational Sales**: Process sales (`POST /api/v1/sales`) which automatically binds to the active `cash_session_id`.
3. **Close Session**: `POST /api/v1/cash/close` with ending balance. This triggers the Z-Report and synchronizes the totals.

### 4. Factus/DIAN Electronic Invoicing & Error Handling
Local sales can be promoted to Electronic Invoices (`POST /api/v1/electronic-invoices`). The system integrates with SIIGO or Factus.

For testing DIAN compliance, we have a mock provider endpoint (`POST /mock-factus/v1/bills`).
#### Mocking Factus Error Scenarios:
To test resilience and client-side error handling, use these special customer NIT identifications in the invoicing payload:
1. **Transient Error (503 Service Unavailable)**:
   * Trigger: Pass identification/NIT containing `888888888`.
   * Result: The endpoint responds with `503 Service Unavailable`.
   * Expected behavior: The local POS enqueues the invoice in the local sync queue and retries later.
2. **Validation Error (400 Bad Request)**:
   * Trigger: Pass identification/NIT containing `777777777`.
   * Result: The endpoint responds with `400 Bad Request`.
   * Expected behavior: The local POS flags this as a hard validation failure, displays the error to the cashier, and does not retry.

---

## Cloud Centralized Integration Guide

The Cloud API (running on port `8080` in the cloud environment) acts as a centralized dashboard and synchronization collector.

### 1. Cloud Login & Credentials
Owners and SuperAdmins log in to the cloud console.

* **Default SuperAdmin Credentials (Cloud)**:
  * **Email**: `admin@neopos.com`
  * **Password**: `NeoPOS_Cloud_S3cur3Admin!_2026`
* **Authentication Endpoint**: `POST /api/v1/auth/login`

### 2. License Verification Flow
Local POS servers periodically call `POST /api/v1/licenses/verify` to confirm their license validation status.

#### Payload:
```json
{
  "tenant_id": 1,
  "token": "local-node-license-token-abc"
}
```

#### Response:
```json
{
  "valid": true,
  "license_type": "standard",
  "expires_at": "2026-12-31T23:59:59Z"
}
```

### 3. Batch Sync Service (`POST /api/v1/sync/batch`)
The local POS has an internal background worker that collects local mutations (`sales`, `invoices`, `inventory_movements`) and pushes them to the Cloud.

* **Auth**: Requests must include the Header `Authorization: Bearer <LOCAL_NODE_ID>` (e.g. `Bearer local-001`).
* **Payload**:
```json
[
  {
    "id": "e8a716c5-231a-4d7a-80bb-26661d402b9f",
    "entity": "sales",
    "operation": "INSERT",
    "payload": {
      "id": "d0d62d29-a1b7-4c7b-bc83-d5d41c9b83f3",
      "payment_method": "CASH",
      "total": 34000
    }
  }
]
```
* **Conflict Resolution**: The Cloud backend compares timestamps (`updated_at`). In case of conflict, it applies a "last write wins" policy or flags it for manual override on the client side.

---

## Code Examples

### Authentication Example

#### cURL
```bash
curl -X POST http://localhost:8080/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "admin@pos.local", "password": "NeoPOS_Local_S3cur3Admin!_2026"}'
```

#### JavaScript (Fetch)
```javascript
const login = async () => {
  const response = await fetch('http://localhost:8080/api/v1/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: 'admin@pos.local',
      password: 'NeoPOS_Local_S3cur3Admin!_2026'
    })
  });
  const result = await response.json();
  if (response.ok) {
    localStorage.setItem('access_token', result.data.access_token);
    console.log('Logged in successfully!');
  } else {
    console.error('Error:', result.error);
  }
};
```

#### Go
```go
package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
)

type LoginRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

type TokenResponse struct {
	Data struct {
		AccessToken string `json:"access_token"`
	} `json:"data"`
}

func login() (string, error) {
	reqBody, _ := json.Marshal(LoginRequest{
		Email:    "admin@pos.local",
		Password: "NeoPOS_Local_S3cur3Admin!_2026",
	})
	resp, err := http.Post("http://localhost:8080/api/v1/auth/login", "application/json", bytes.NewBuffer(reqBody))
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("failed login: status %d", resp.StatusCode)
	}

	body, _ := io.ReadAll(resp.Body)
	var tr TokenResponse
	json.Unmarshal(body, &tr)
	return tr.Data.AccessToken, nil
}
```

---

### Register Sale Example

#### cURL
```bash
curl -X POST http://localhost:8080/api/v1/sales \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN_HERE" \
  -H "Content-Type: application/json" \
  -d '{
    "branch_id": "00000000-0000-0000-0000-000000000000",
    "order_id": "d027f62b-e106-444f-a7e3-3e198305c48b",
    "cash_session_id": "f5a77cbb-deef-4573-b778-9e672ee1ab63",
    "payment_method": "CASH",
    "discount": 0,
    "tip": 3000,
    "items": [
      {
        "product_id": "c1f7b889-8d77-4b77-8c33-e7de19cb83e9",
        "name": "Hamburguesa Clasica",
        "quantity": 1,
        "unit_price": 26000
      }
    ]
  }'
```

#### JavaScript (Fetch)
```javascript
const registerSale = async (token, saleData) => {
  const response = await fetch('http://localhost:8080/api/v1/sales', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(saleData)
  });
  return await response.json();
};
```

#### Go
```go
package main

import (
	"bytes"
	"encoding/json"
	"net/http"
)

func registerSale(token string, saleData any) (*http.Response, error) {
	jsonBytes, _ := json.Marshal(saleData)
	req, _ := http.NewRequest("POST", "http://localhost:8080/api/v1/sales", bytes.NewBuffer(jsonBytes))
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")
	
	client := &http.Client{}
	return client.Do(req)
}
```

---

### Sync Batch Example

#### cURL
```bash
curl -X POST https://api-neopos-cloud.prismabitetesting.xyz/api/v1/sync/batch \
  -H "Authorization: Bearer local-001" \
  -H "Content-Type: application/json" \
  -d '[
    {
      "id": "e8a716c5-231a-4d7a-80bb-26661d402b9f",
      "entity": "sales",
      "operation": "INSERT",
      "payload": {
        "id": "d0d62d29-a1b7-4c7b-bc83-d5d41c9b83f3",
        "branch_id": "8b51d5ff-c063-44f2-95be-28d88e63a13b",
        "payment_method": "CASH",
        "total": 34000,
        "created_at": "2026-07-14T01:50:00Z",
        "updated_at": "2026-07-14T01:50:00Z"
      }
    }
  ]'
```

#### JavaScript (Fetch)
```javascript
const syncBatch = async (nodeId, batchItems) => {
  const response = await fetch('https://api-neopos-cloud.prismabitetesting.xyz/api/v1/sync/batch', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${nodeId}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(batchItems)
  });
  return await response.json();
};
```

#### Go
```go
package main

import (
	"bytes"
	"encoding/json"
	"net/http"
)

func syncBatch(nodeID string, batchData any) (*http.Response, error) {
	jsonBytes, _ := json.Marshal(batchData)
	req, _ := http.NewRequest("POST", "https://api-neopos-cloud.prismabitetesting.xyz/api/v1/sync/batch", bytes.NewBuffer(jsonBytes))
	req.Header.Set("Authorization", "Bearer "+nodeID)
	req.Header.Set("Content-Type", "application/json")
	
	client := &http.Client{}
	return client.Do(req)
}
```

---

## Global Error Response Schema

Every API error response (whether from authentication failure, authorization blocking, or missing parameters) follows a standardized format:

```json
{
  "error": "Short detailed error message explaining what failed."
}
```

### HTTP Error Codes Reference

* **400 Bad Request**: Missing or malformed body parameters.
* **401 Unauthorized**: Invalid credentials on login, or missing/expired JWT access token.
* **403 Forbidden**: Access denied due to role restrictions (e.g. `cajero` accessing dashboard).
* **404 Not Found**: Resource (user, product, sale, table) not found.
* **429 Too Many Requests**: Triggered when a client exceeds the limit of 100 requests per minute.
* **500 Internal Server Error**: Database connection loss or unexpected panic.
* **503 Service Unavailable**: Third-party invoicing providers (Factus/DIAN) down (Mocked using identification NIT `888888888`).
