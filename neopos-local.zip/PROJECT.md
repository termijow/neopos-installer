# Project: NeoPOS (Colombia Electronic Invoicing & Inventory Sync)

## Architecture
NeoPOS has a hybrid local/cloud architecture:
1. **Local POS Backend**:
   - Go Fiber web server + GORM with PostgreSQL (local db port 5433).
   - Invoicing module (`internal/electronic_invoicing`, `internal/dian`) handles local invoice creation and technological provider DIAN integrations.
   - Sync module (`internal/sync`) hooks database operations via GORM callbacks to enqueue updates into `sync_queue` and pushes them to the Cloud.
2. **Cloud Centralized Backend**:
   - Go Fiber web server + Prisma Client Go with PostgreSQL (cloud db port 5432/5433).
   - Sync API parses batch updates (`sales`, `invoices`, `inventory_movements`) and updates central business metrics and triggers inventory alerts.

## Code Layout
- `/local/backend`: Go backend for the local POS client.
  - `cmd/api`: Main entrypoint for local API server.
  - `internal`: Internal domain modules (auth, electronic_invoicing, dian, inventory, invoices, sales, sync, etc.).
- `/cloud/backend`: Go backend for the centralized cloud dashboard.
  - `cmd/cloud`: Main entrypoint for cloud API server.
  - `internal/handlers`: HTTP handler functions (including sync).
  - `prisma`: Database schema and generated client.
- `/.agents`: coordination metadata and handoffs for agents (no codebase changes here).

## Milestones
| # | Name | Scope | Dependencies | Status |
|---|---|---|---|---|
| M1 | Codebase Exploration and Plan design | Analyze codebase structure, test suites, and write PROJECT.md | None | DONE |
| M2 | R1 - Factus Integration | Local Factus REST client, mock Factus endpoint, status handling for transient/hard errors, and integration tests | M1 | DONE |
| M3 | R2 - Cloud Sync and Batch Endpoint | Cloud routes `/api/v1/sync/batch` & `/api/v1/licenses/verify`, Prisma model updates for stock, batch insertion, conflict resolution, and tests | M2 | IN_PROGRESS |
| M4 | E2E Verification & Auditing | Full end-to-end flow, disconnect/retry testing, and final security/forensic integrity checks | M3 | PLANNED |

## Interface Contracts
### Local POS ↔ Factus REST API
- URL: `POST /v1/bills`
- Headers: `Authorization: Bearer <API_KEY>`, `Content-Type: application/json`
- Response formats:
  - **Success (201)**: `{"status": "OK", "data": {"cufe": "<cufe>", "qr": "<qr_url>", "number": "<invoice_num>"}}`
  - **Validation Error (400)**: `{"status": "ERROR", "message": "Invalid NIT"}`
  - **Transient Error (503)**: `{"status": "ERROR", "message": "Service Temporarily Unavailable"}`

### Local POS ↔ Cloud API (Sync Service)
- Endpoint: `POST /api/v1/licenses/verify`
  - Payload: `{"tenant_id": 1, "token": "<node_id>"}`
  - Response: `{"valid": true, "license_type": "standard", "expires_at": "2026-12-31"}`
- Endpoint: `POST /api/v1/sync/batch`
  - Headers: `Authorization: Bearer <node_id>`, `Content-Type: application/json`
  - Payload: List of serialized sync items `[{"id": "<uuid>", "entity": "invoices|sales|inventory_movements", "operation": "INSERT|UPDATE", "payload": {...}}]`
  - Response: `{"status": "success", "synced_count": N}`
